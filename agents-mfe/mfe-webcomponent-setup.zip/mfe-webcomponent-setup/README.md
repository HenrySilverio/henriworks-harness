# mfe-webcomponent-setup

Agente + skill do GitHub Copilot (VS Code) que transforma um projeto Angular 21 em **MFE web component**, exposto via `remoteEntry.json` com o `@angular-architects/native-federation`. Segue o padrão dos projetos **posvenda** e **reneg**.

O agente não "escreve código livre": ele valida o projeto, conversa com você e chama scripts Node que geram sempre o mesmo resultado. Duas pessoas com as mesmas respostas recebem os mesmos arquivos.

---

## Conceitos em 1 minuto

| Termo | O que é |
|---|---|
| **MFE (micro frontend)** | Um app Angular publicado sozinho e carregado dentro de outro app, o **shell**. |
| **Web component** | Uma tag HTML própria (ex.: `<recr-fed-agc-posvenda>`). O shell só cria a tag e não precisa saber que é Angular por dentro. |
| **remoteEntry.json** | "Índice" gerado no build. Diz ao shell qual arquivo JS carregar para registrar a tag. |
| **`shared: {}`** | O MFE leva o próprio Angular. Nada é dividido com o shell, então cada um atualiza versão sem quebrar o outro. |
| **Variável global de config** | O MFE lê as URLs (BFF, Dynatrace) de uma variável no `window`. Cada MFE tem a sua, com nome único, porque dentro do shell todos dividem o mesmo `window`. |
| **`.j2`** | Template que o deploy preenche com os valores do `config/<AMBIENTE>/config.yaml`. |

---

## Instalação (por projeto)

No Git Bash, na raiz do projeto Angular:

```bash
cp -r /caminho/do/pacote/mfe-webcomponent-setup/.github/. .github/
# Hoje .github/ não pode subir para os repositórios de produto: deixe fora do git sem mexer no .gitignore
printf '.github/agents/mfe-webcomponent-setup.agent.md\n.github/skills/mfe-webcomponent-setup/\n' >> .git/info/exclude
```

Requisitos: Node 20.19+, 22.12+ ou 24+, que são os mesmos do Angular 21. Os scripts usam só módulos nativos do Node, sem nada para instalar.

## Como usar

1. Abra o Copilot Chat no VS Code e escolha o agente **mfe-webcomponent-setup**.
2. Escreva: `configura este projeto como MFE web component`.
3. Responda o que ele perguntar: nome do projeto, componente, `contextPath` e URLs por ambiente. URL que você não souber pode ficar em branco: vira `PREENCHER` e aparece nas pendências.
4. Revise o plano e diga "ok".
5. Siga o roteiro **Como validar** que ele mostra no final.

## O que é criado ou ajustado

| Arquivo | Para que serve |
|---|---|
| `federation.config.js` | Nome do remote, `shared: {}` e expõe **só** `./bootstrap-webcomponent`. |
| `src/bootstrap-webcomponent.ts` | Módulo que o shell importa. Ele registra a tag. |
| `src/app/web-component.module.ts` | Cria o app Angular e registra `<nome-do-projeto>`, com guard contra registro duplo. |
| `src/main.ts` / `src/bootstrap.ts` | `main.ts` inicia a federation. O bootstrap original do app vai para `bootstrap.ts`, sem perder nada. |
| `tsconfig.app.json` | Se usa `"files"`, ganha `src/bootstrap-webcomponent.ts`. Sem isso o build passa, mas o web component sai sem checagem de tipos ("not found in TypeScript compilation"). |
| `angular.json` | Ajuste pontual: `build` passa a ser `native-federation:build`, o build original vira `esbuild`, `dist/` na raiz e `es-module-shims` nos polyfills. Formatação reescrita com 2 espaços. |
| `src/index.html` | Carrega o config local. Com `app-config.js` a tag leva `id=<nome>`, e o service, achando o id, não busca o arquivo de novo. |
| `src/app/core/config/app-config.service.ts` | Carrega `<contextPath>/assets/config/app-config.js` e expõe `waitUntilLoaded()`. |
| `src/assets/config/app-config.js` **ou** `app.config.js` | Config para rodar local. O agente mantém o nome que o projeto já usa (reneg: `app-config.js`; posvenda: `app.config.js`). |
| `config/DEV\|HOM\|PRD/config.yaml` | Valores por ambiente. **Arquivo existente nunca é substituído**: o agente só acrescenta as chaves que faltam. |
| `config/all/config/app-config.js.j2` | Template preenchido no deploy com o `config.yaml` do ambiente. |

O `package.json` **nunca** é alterado. Se faltar dependência, o agente mostra o comando e para.

**Não é criado:** `tsconfig.federation.json`. O native-federation gera esse arquivo a cada build a partir do `tsconfig.app.json`, então se ele sumir não tem problema. `postBuild.js`, `mocks/` e scripts do projeto também ficam de fora.

Se o projeto já tem uma variável global de config, como `appConfigMfeReneg`, o agente **preserva o nome**.

## Como validar (resumo)

```bash
node .github/skills/mfe-webcomponent-setup/scripts/verify-remote.mjs          # consistência do código
npm run build
node .github/skills/mfe-webcomponent-setup/scripts/verify-remote.mjs --dist   # remoteEntry.json
npm start                                                                     # app sozinho, local
```

Depois, no console do navegador (com o `npm start` rodando), teste o MFE como o shell carregaria:

```js
const re = await (await fetch('/remoteEntry.json')).json();
await import('/' + re.exposes.find((e) => e.key === './bootstrap-webcomponent').outFileName);
typeof customElements.get('recr-fed-agc-exemplo');                          // "function"
document.body.appendChild(document.createElement('recr-fed-agc-exemplo'));  // aparece no fim da página
```

## Problemas comuns

| Mensagem | O que fazer |
|---|---|
| `STATUS: BLOQUEADO` | Leia as linhas `✖`. Geralmente é uma dependência faltando (rode o `npm install` mostrado) ou um Angular que não é 21. |
| `CONFLITO` no plano | O arquivo existe e é diferente do padrão. O agente mostra a diferença e você decide se substitui. Nada é sobrescrito sem você pedir. |
| `PREENCHER` no `config.yaml` | Coloque a URL real antes do deploy. O `verify-remote` avisa enquanto houver pendência. |
| `NotSupportedError: ... has already been used` | O registro está sem guard. O `web-component.module.ts` do padrão já tem o guard. |
| `Cannot find module '@angular-devkit/build-angular/...'` no build | O builder do native-federation precisa desse pacote mesmo em projeto com `@angular/build`. O check já acusa isso. |

## Manutenção

| Quero… | Onde mexer |
|---|---|
| Liberar Angular 22 | `regras.json` → `angularMajorsSuportados` (depois de validar um build real) |
| Mudar o conteúdo de um arquivo gerado | `templates/`. Placeholders `__ASSIM__`, para não confundir com o `{{ }}` do Jinja. |
| Mudar padrões (porta, ambientes, timeouts) | `regras.json` → `padroes` |
| Mudar o fluxo de conversa | `SKILL.md` |
