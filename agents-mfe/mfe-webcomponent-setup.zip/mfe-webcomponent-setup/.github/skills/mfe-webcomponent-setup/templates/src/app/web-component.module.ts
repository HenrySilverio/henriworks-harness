import { createApplication } from '@angular/platform-browser';
import { createCustomElement } from '@angular/elements';
import { appConfig } from './app.config';
import { __CLASSE__ } from '__IMPORT_COMPONENTE__';

const TAG = '__NOME__';

(async () => {
  // Guard: se a tag já existe (shell carregou o remote por outra URL, cache-busting,
  // HMR), um segundo customElements.define() lança NotSupportedError.
  if (customElements.get(TAG)) {
    console.log(`Web component "${TAG}" já registrado.`);
    return;
  }

  try {
    const app = await createApplication(appConfig);

    const appElement = createCustomElement(__CLASSE__, {
      injector: app.injector,
    });

    // Rechecagem: duas cargas concorrentes podem ter passado pelo guard antes do await.
    if (!customElements.get(TAG)) {
      customElements.define(TAG, appElement);
      console.log(`Web component "${TAG}" registered successfully.`);
    }
  } catch (error) {
    console.error(`❌ Error creating web component "${TAG}":`, error);
  }
})();
