// Configuração para testes LOCAIS (ng serve), carregada pelo src/index.html.
// Em DEV/HOM/PRD quem vale é o config/all/config/app-config.js.j2, renderizado no deploy.
var __GLOBAL__ = {
  config: {
    apiTimeout: __TIMEOUT_LOCAL__,
  },
  apiURL: {
    clientAPI: '__CLIENTAPI_LOCAL__',
  },
  urlMonitoramento: '',
};
