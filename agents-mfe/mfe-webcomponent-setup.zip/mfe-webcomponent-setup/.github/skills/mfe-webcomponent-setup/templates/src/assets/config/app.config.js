// Configuração para testes LOCAIS (ng serve), carregada pelo src/index.html (src/assets/config/__CONFIG_LOCAL__).
// Em DEV/HOM/PRD quem vale é o config/all/config/app-config.js.j2, renderizado no deploy.
var __GLOBAL__ = {
  config: {
    apiTimeout: __TIMEOUT_LOCAL__,
  },
  apiURL: {
    clientAPI: '__CLIENTAPI_LOCAL__',
  },
  urlMonitoramento: '',
  __SE_FEDERATION__
  federation: {
    shellRemoteEntry: '__SHELL_LOCAL__',
  },
  __FIM_FEDERATION__
};
