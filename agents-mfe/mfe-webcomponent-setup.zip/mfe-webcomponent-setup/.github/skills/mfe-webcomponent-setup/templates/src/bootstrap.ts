import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { __CLASSE__ } from '__IMPORT_COMPONENTE_SRC__';

bootstrapApplication(__CLASSE__, appConfig).catch((err) => console.error('[X] Erro ao inicializar app:', err));
