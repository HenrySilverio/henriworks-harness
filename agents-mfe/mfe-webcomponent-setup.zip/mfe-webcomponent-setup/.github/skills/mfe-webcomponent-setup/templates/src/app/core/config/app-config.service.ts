import { inject, Injectable } from '@angular/core';

import { BehaviorSubject, filter, firstValueFrom, Observable, take } from 'rxjs';
import { DOCUMENT } from '@angular/common';

/**
 * Variável global criada pelo script de configuração do ambiente:
 * - local (ng serve): src/assets/config/app.config.js, carregado pelo index.html
 * - DEV/HOM/PRD: config/all/config/app-config.js.j2, renderizado no deploy
 * O nome é único por MFE porque, dentro do shell, todos os MFEs dividem o mesmo `window`.
 */
declare let __GLOBAL__: TAppConfig | undefined;

export type TAppConfig = {
  config: {
    apiTimeout: number;
  };
  apiURL: {
    clientAPI: string;
  };
  urlMonitoramento: string;
};

@Injectable({
  providedIn: 'root',
})
export class AppConfigService {
  MFE_APP_CONFIG_SCRIPT_ID = '__NOME__';
  MFE_APP_CONFIG_SCRIPT_URL = '__CONTEXT_PATH__/assets/config/app-config.js';
  info: TAppConfig = this.defaultConfig();

  private _isLoaded = false;
  private loadedSubject = new BehaviorSubject<boolean>(false);
  private documentRef = inject(DOCUMENT);

  constructor() {
    console.log('AppConfigService: carregando configurações externas...');
    this.loadExternalScript(this.MFE_APP_CONFIG_SCRIPT_URL)
      .then(() => {
        this.init();
      })
      .catch(() => {
        this.init();
      });
  }

  private markAsLoaded(): void {
    this._isLoaded = true;
    this.loadedSubject.next(true);
  }

  init(): void {
    try {
      if (typeof __GLOBAL__ !== 'undefined') {
        this.info = __GLOBAL__ as TAppConfig;
        console.log('Configurações carregadas com sucesso:', this.info);
      } else {
        console.warn('__GLOBAL__ não encontrado, usando configuração padrão');
        this.info = this.defaultConfig();
      }
    } catch (erro) {
      console.error('Erro ao carregar configurações:', erro);
      this.info = this.defaultConfig();
    }
    this.loadMonitoramentoScript();
    this.markAsLoaded();
  }

  get isLoaded(): boolean {
    return this._isLoaded;
  }

  get loaded$(): Observable<boolean> {
    return this.loadedSubject.asObservable();
  }

  async waitUntilLoaded(): Promise<TAppConfig> {
    if (this._isLoaded) {
      return this.info;
    }

    await firstValueFrom(
      this.loadedSubject.pipe(
        filter((loaded) => loaded === true),
        take(1),
      ),
    );

    return this.info;
  }

  defaultConfig(): TAppConfig {
    return {
      config: {
        apiTimeout: 30000,
      },
      apiURL: {
        clientAPI: '/v1/',
      },
      urlMonitoramento: '',
    };
  }

  private loadMonitoramentoScript(): void {
    // Sem URL (ex.: local), não injeta: <script src=""> carregaria a própria página como script.
    if (!this.info.urlMonitoramento) {
      return;
    }
    const script = this.documentRef.createElement('script');
    script.src = this.info.urlMonitoramento;
    script.crossOrigin = 'anonymous';
    script.defer = true;
    this.documentRef.head.appendChild(script);
  }

  private loadExternalScript(scriptUrl: string): Promise<void> {
    return new Promise((resolve, reject) => {
      const existingScript: HTMLElement | null = this.documentRef.getElementById(this.MFE_APP_CONFIG_SCRIPT_ID);
      if (existingScript) {
        console.log('Script já foi carregado:', scriptUrl);
        resolve();
        return;
      }

      const script = this.documentRef.createElement('script');
      script.id = this.MFE_APP_CONFIG_SCRIPT_ID;
      script.type = 'text/javascript';
      script.src = scriptUrl;
      script.async = false;

      script.onload = () => {
        console.log('Script carregado com sucesso:', scriptUrl);
        resolve();
      };

      script.onerror = (error: Event | string) => {
        console.error('Erro ao carregar script:', scriptUrl, error);
        reject(error);
      };

      const head = this.documentRef.head || this.documentRef.getElementsByTagName('head')[0];
      head.appendChild(script);
    });
  }
}
