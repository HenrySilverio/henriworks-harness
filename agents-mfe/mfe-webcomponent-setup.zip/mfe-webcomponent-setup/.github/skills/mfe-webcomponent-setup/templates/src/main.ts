import { initFederation } from '@angular-architects/native-federation';

function start() {
  import('./bootstrap').then(() => console.log('[✓] App inicializado')).catch((err) => console.error('[X] Erro no bootstrap:', err));
}

initFederation()
  .then(() => {
    console.log('[✓] Federation inicializado com sucesso');
    start();
  })
  .catch((err) => {
    console.error('[!] Federation falhou, usando fallback:', err);
    start();
  });
