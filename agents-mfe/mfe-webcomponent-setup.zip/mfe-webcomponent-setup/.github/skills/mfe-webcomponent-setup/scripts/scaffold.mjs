#!/usr/bin/env node
// Gera/ajusta os arquivos do MFE web component a partir dos templates da skill.
// Determinístico: a mesma resposta gera o mesmo resultado para qualquer dev.
//
// Uso:
//   node <skill>/scripts/scaffold.mjs --respostas .mfe-setup.json              (dry-run: só mostra o plano)
//   node <skill>/scripts/scaffold.mjs --respostas .mfe-setup.json --aplicar    (escreve)
//        [--sobrescrever src/app/core/config/app-config.service.ts,federation.config.js | --sobrescrever todos]
//   node <skill>/scripts/scaffold.mjs --respostas .mfe-setup.json --mostrar <arquivo>   (imprime o conteúdo proposto)
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import {
  args, ler, existe, lerJson, REGRAS, projetoAngular, nomeGlobal, validarNome,
  importRelativo, origem, aplicarTokens, template, escrever,
  configLocal, leShellRemoteEntry, tsconfigApp, tsconfigCobre, blocos,
} from './lib.mjs';

const a = args();
const raiz = path.resolve(a.raiz ?? '.');
const p = (rel) => path.join(raiz, rel);
const sair = (msg) => { console.error(`✖ ${msg}`); process.exit(1); };

if (!a.respostas) sair('informe --respostas <arquivo.json>');
const arqRespostas = path.resolve(raiz, a.respostas);
const r = lerJson(arqRespostas) ?? sair(`não li ${a.respostas}`);
const D = REGRAS.padroes;

// ---------- validação das respostas ----------
const erroNome = validarNome(r.nome);
if (erroNome) sair(`nome "${r.nome}": ${erroNome}`);
if (!r.componente?.classe || !r.componente?.arquivo) sair('componente.classe e componente.arquivo são obrigatórios');
const compSrc = ler(p(r.componente.arquivo));
if (!compSrc) sair(`componente.arquivo não existe: ${r.componente.arquivo}`);
if (!new RegExp(`class\\s+${r.componente.classe}\\b`).test(compSrc)) sair(`classe ${r.componente.classe} não encontrada em ${r.componente.arquivo}`);
const contextPath = String(r.contextPath ?? '').trim().replace(/\/+$/, '');
if (!/^\/[\w\-/]+$/.test(contextPath)) sair(`contextPath "${r.contextPath}" inválido. Esperado algo como /recr/agcposvenda (caminho público onde o MFE é publicado).`);
const ambientes = r.ambientes && Object.keys(r.ambientes).length ? r.ambientes : Object.fromEntries(D.ambientes.map((e) => [e, {}]));

const NOME = r.nome;
// Global existente e consistente é preservada (renomear obrigaria trocar service + config local + .j2).
const GLOBAL = r.global || nomeGlobal(NOME);
if (!/^[A-Za-z_$][\w$]*$/.test(GLOBAL)) sair(`global "${GLOBAL}" não é um identificador JS válido`);
const LOCAL = configLocal(raiz);
const ARQ_LOCAL = r.arquivoConfigLocal || LOCAL.arquivo;
if (!/^app[.-]config\.js$/.test(ARQ_LOCAL)) sair(`arquivoConfigLocal "${ARQ_LOCAL}" inválido: use app-config.js ou app.config.js`);
const REL_LOCAL = `src/assets/config/${ARQ_LOCAL}`;
const FEDERATION = r.shellRemoteEntry ?? leShellRemoteEntry(raiz);
const pendencias = [];
const valor = (v, onde) => {
  if (v === undefined || v === null || String(v).trim() === '') { pendencias.push(onde); return D.pendente; }
  return String(v).trim();
};

const tokensBase = {
  NOME,
  GLOBAL,
  CLASSE: r.componente.classe,
  CONTEXT_PATH: contextPath,
  IMPORT_COMPONENTE: importRelativo('src/app', r.componente.arquivo),
  IMPORT_COMPONENTE_SRC: importRelativo('src', r.componente.arquivo),
  TIMEOUT_LOCAL: Number(r.local?.apiTimeout ?? D.timeoutLocal),
  CLIENTAPI_LOCAL: r.local?.clientAPI || D.clientApiLocal,
  TIMEOUT: Number(r.apiTimeout ?? D.timeoutAmbiente),
  CONFIG_LOCAL: ARQ_LOCAL,
  SHELL_LOCAL: r.local?.shellRemoteEntry ?? '',
};

// ---------- monta o plano ----------
/** @type {{arquivo:string, acao:string, detalhe?:string, conteudo?:string}[]} */
const plano = [];
const norm = (t) => t.replace(/\r\n/g, '\n').replace(/[ \t]+$/gm, '').trimEnd();

function arquivo(rel, conteudo) {
  const atual = ler(p(rel));
  if (atual === null) plano.push({ arquivo: rel, acao: 'CRIAR', conteudo });
  else if (norm(atual) === norm(conteudo)) plano.push({ arquivo: rel, acao: 'IGUAL' });
  else plano.push({ arquivo: rel, acao: 'CONFLITO', detalhe: 'existe e é diferente do padrão', conteudo });
}
const tpl = (rel, extra = {}) => aplicarTokens(blocos(template(rel), { FEDERATION }), { ...tokensBase, ...extra });

arquivo('federation.config.js', tpl('federation.config.js'));
arquivo('src/bootstrap-webcomponent.ts', tpl('src/bootstrap-webcomponent.ts'));
arquivo('src/app/web-component.module.ts', tpl('src/app/web-component.module.ts'));

// main.ts / bootstrap.ts: main passa a iniciar a federation; o bootstrap do app vai para bootstrap.ts.
{
  const main = ler(p('src/main.ts'));
  const boot = ler(p('src/bootstrap.ts'));
  const mainFed = tpl('src/main.ts');
  if (main === null) {
    plano.push({ arquivo: 'src/main.ts', acao: 'CRIAR', conteudo: mainFed });
    if (boot === null) plano.push({ arquivo: 'src/bootstrap.ts', acao: 'CRIAR', conteudo: tpl('src/bootstrap.ts') });
  } else if (/initFederation\s*\(/.test(main)) {
    plano.push({ arquivo: 'src/main.ts', acao: 'IGUAL', detalhe: 'já chama initFederation()' });
    if (boot === null) plano.push({ arquivo: 'src/bootstrap.ts', acao: 'CRIAR', conteudo: tpl('src/bootstrap.ts') });
  } else if (boot === null) {
    plano.push({ arquivo: 'src/bootstrap.ts', acao: 'MOVER', detalhe: 'recebe o conteúdo atual do src/main.ts (bootstrap do app preservado)', conteudo: main });
    plano.push({ arquivo: 'src/main.ts', acao: 'MOVER', detalhe: 'passa a chamar initFederation() e depois importar ./bootstrap', conteudo: mainFed });
  } else {
    plano.push({ arquivo: 'src/main.ts', acao: 'CONFLITO', detalhe: 'não chama initFederation() e src/bootstrap.ts já existe — revisar à mão', conteudo: mainFed });
  }
}

arquivo('src/app/core/config/app-config.service.ts', tpl('src/app/core/config/app-config.service.ts'));
arquivo(REL_LOCAL, tpl('src/assets/config/app.config.js'));
const outroLocal = `src/assets/config/${ARQ_LOCAL === 'app.config.js' ? 'app-config.js' : 'app.config.js'}`;
if (existe(p(outroLocal))) plano.push({ arquivo: outroLocal, acao: 'CONFLITO', detalhe: `também existe ${REL_LOCAL}; o projeto deve ter só um config local — remova à mão o que não for usado` });

for (const [env, v] of Object.entries(ambientes)) {
  const rel = `config/${env}/config.yaml`;
  const atual = ler(p(rel));
  if (atual !== null) {
    // config.yaml existente: os valores do dev sempre vencem. Só acrescenta chaves que o .j2 usa e faltam.
    plano.push(completarYaml(rel, atual, v));
    continue;
  }
  const clientAPI = valor(v.clientAPI, `${rel} → clientAPI`);
  arquivo(rel, tpl('config/config.yaml', {
    ENV: env,
    CENTRO_CUSTO: r.centroCusto || NOME.split('-')[0],
    VALUE_STREAM: r.valueStream || r.centroCusto || NOME.split('-')[0],
    CLIENTAPI: clientAPI,
    URL_MONITORAMENTO: valor(v.urlMonitoramento, `${rel} → urlMonitoramento (Dynatrace)`),
    DOMAIN_PRECONNECT: v.domainPreConnect || origem(clientAPI) || valor('', `${rel} → domainPreConnect`),
    SHELL_REMOTE_ENTRY: FEDERATION ? valor(v.shellRemoteEntry, `${rel} → shellRemoteEntry`) : '',
  }));
}

function completarYaml(rel, texto, v) {
  const linhas = texto.replace(/\r\n/g, '\n').split('\n');
  const iCfg = linhas.findIndex((l) => /^\s*app_config:\s*$/.test(l));
  if (iCfg < 0) return { arquivo: rel, acao: 'CONFLITO', detalhe: 'sem bloco deploy.app_config — revisar à mão' };
  const indPai = linhas[iCfg].match(/^\s*/)[0].length;
  let fim = iCfg + 1;
  const existentes = {};
  while (fim < linhas.length && (linhas[fim].trim() === '' || linhas[fim].match(/^\s*/)[0].length > indPai)) {
    const m = linhas[fim].match(/^\s*(\w+):\s*['"]?(.*?)['"]?\s*$/);
    if (m) existentes[m[1]] = m[2];
    fim++;
  }
  while (fim > iCfg + 1 && linhas[fim - 1].trim() === '') fim--;
  const ind = ' '.repeat(indPai + 2);
  const desejado = {
    clientAPI: () => valor(v.clientAPI, `${rel} → clientAPI`),
    urlMonitoramento: () => valor(v.urlMonitoramento, `${rel} → urlMonitoramento (Dynatrace)`),
    domainPreConnect: () => v.domainPreConnect || origem(existentes.clientAPI ?? v.clientAPI) || valor('', `${rel} → domainPreConnect`),
    shellRemoteEntry: () => valor(v.shellRemoteEntry, `${rel} → shellRemoteEntry`),
  };
  // Só as chaves que algum .j2 usa: o gerado e o existente (o dev pode manter o dele).
  const j2s = tpl('config/app-config.js.j2') + (ler(p(r.caminhoJ2 || D.caminhoJ2)) ?? '');
  const usadas = [...j2s.matchAll(/deploy\.app_config\.(\w+)/g)].map((m) => m[1]);
  const novas = [...new Set(usadas)].filter((k) => !(k in existentes) && desejado[k]);
  if (!novas.length) return { arquivo: rel, acao: 'IGUAL', detalhe: 'valores existentes preservados' };
  linhas.splice(fim, 0, ...novas.map((k) => `${ind}${k}: '${desejado[k]()}'`));
  return { arquivo: rel, acao: 'ATUALIZAR', detalhe: `acrescenta ${novas.join(', ')} (valores existentes preservados)`, conteudo: linhas.join('\n').replace(/\n*$/, '\n') };
}
arquivo(r.caminhoJ2 || D.caminhoJ2, tpl('config/app-config.js.j2'));

// angular.json: patch idempotente (nunca substitui o arquivo inteiro).
{
  const json = lerJson(p('angular.json')) ?? sair('angular.json não encontrado');
  const proj = projetoAngular(json, r.projetoAngular);
  if (!proj || proj.ambiguo) sair('não identifiquei o projeto no angular.json; informe "projetoAngular" nas respostas');
  const [chave] = proj;
  const novo = structuredClone(json);
  const mud = patchAngular(novo.projects[chave], chave, Number(r.porta ?? D.porta));
  if (mud.length) plano.push({ arquivo: 'angular.json', acao: 'ATUALIZAR', detalhe: mud.join('; '), conteudo: `${JSON.stringify(novo, null, 2)}\n` });
  else plano.push({ arquivo: 'angular.json', acao: 'IGUAL' });
}

// index.html: só acrescenta o <script> do config local, se faltar.
// Com app-config.js (mesmo nome do deploy) o <script> leva id=<nome>: o service acha o id e não busca de novo.
{
  const html = ler(p('src/index.html'));
  const tag = ARQ_LOCAL === 'app-config.js'
    ? `<script id="${NOME}" src="assets/config/app-config.js" type="application/javascript" defer></script>`
    : '<script defer src="assets/config/app.config.js?[[VERSION]]"></script>';
  const carrega = html?.match(/assets\/config\/(app[.-]config\.js)/)?.[1];
  if (html === null) plano.push({ arquivo: 'src/index.html', acao: 'CONFLITO', detalhe: 'não existe; o config local não será carregado' });
  else if (carrega === ARQ_LOCAL) plano.push({ arquivo: 'src/index.html', acao: 'IGUAL', detalhe: `já carrega assets/config/${ARQ_LOCAL}` });
  else if (carrega) plano.push({ arquivo: 'src/index.html', acao: 'CONFLITO', detalhe: `carrega assets/config/${carrega}, mas o config local é ${ARQ_LOCAL} — ajuste à mão` });
  else {
    const ind = html.match(/\n([ \t]*)<\/head>/)?.[1] ?? '';
    const linha = `${ind}  <!-- Load do app config (local) -->\n${ind}  ${tag}\n`;
    const novo = html.replace(/([ \t]*)<\/head>/, `${linha}$1</head>`);
    plano.push({ arquivo: 'src/index.html', acao: 'ATUALIZAR', detalhe: `adiciona ${tag} no <head>`, conteudo: novo });
  }
}

// tsconfig do app: o arquivo exposto não é importado pelo main.ts. Se o tsconfig usa "files",
// ele precisa estar listado, senão o build avisa "not found in TypeScript compilation" e o
// web component é empacotado sem checagem de tipos. (tsconfig.federation.json é gerado pelo build: não mexer.)
{
  const json = lerJson(p('angular.json'));
  const [chave] = projetoAngular(json, r.projetoAngular);
  const ts = tsconfigApp(raiz, json, chave);
  const ALVO = 'src/bootstrap-webcomponent.ts';
  if (!ts.json) plano.push({ arquivo: ts.rel, acao: 'CONFLITO', detalhe: 'não encontrado' });
  else if (tsconfigCobre(ts.json, ALVO)) plano.push({ arquivo: ts.rel, acao: 'IGUAL', detalhe: `já cobre ${ALVO}` });
  else {
    const txt = ler(p(ts.rel));
    const novo = txt.replace(/("files"\s*:\s*\[)([^\]]*?)(\s*\])/, (_, a, itens, b) => `${a}${itens.trimEnd()}${itens.trim() ? ', ' : ''}"${ALVO}"${b}`);
    if (novo === txt) plano.push({ arquivo: ts.rel, acao: 'CONFLITO', detalhe: `não consegui incluir ${ALVO} em "files" — ajuste à mão` });
    else plano.push({ arquivo: ts.rel, acao: 'ATUALIZAR', detalhe: `"files" += ${ALVO}`, conteudo: novo });
  }
}

function patchAngular(proj, chave, porta) {
  const FED = '@angular-architects/native-federation:build';
  const arq = (proj.architect ??= {});
  const mud = [];
  const paraEsbuild = (t) => (typeof t === 'string' ? t.replace(`${chave}:build:`, `${chave}:esbuild:`) : t);

  if (arq.build?.builder !== FED) {
    if (!arq.build) sair('angular.json sem architect.build');
    arq.esbuild = arq.build;
    arq.build = {
      builder: FED,
      options: {},
      configurations: {
        production: { target: `${chave}:esbuild:production` },
        development: { target: `${chave}:esbuild:development`, dev: true },
      },
      defaultConfiguration: 'production',
    };
    mud.push(`build vira native-federation:build e o build original vai para "esbuild" (builder ${arq.esbuild.builder} preservado)`);
    if (arq.serve && arq.serve.builder !== FED) {
      const orig = arq.serve;
      for (const c of Object.values(orig.configurations ?? {})) if (c.buildTarget) c.buildTarget = paraEsbuild(c.buildTarget);
      if (orig.options?.buildTarget) orig.options.buildTarget = paraEsbuild(orig.options.buildTarget);
      orig.options ??= {};
      const proxy = orig.options.proxyConfig;
      delete orig.options.proxyConfig;
      arq['serve-original'] = orig;
      arq.serve = { builder: FED, options: { target: `${chave}:serve-original:development`, ...(proxy ? { proxyConfig: proxy } : {}), rebuildDelay: 0, dev: true, port: 0 } };
      mud.push('serve vira native-federation:build e o dev-server original vai para "serve-original"');
    }
  }

  const app = arq.esbuild;
  if (!app) sair('angular.json: build já é native-federation, mas não existe "esbuild". Configuração fora do padrão — revisar à mão.');
  const o = (app.options ??= {});
  const out = o.outputPath;
  if (!(out && typeof out === 'object' && out.base === 'dist' && out.browser === '')) {
    o.outputPath = { base: 'dist', browser: '' };
    mud.push(`esbuild.outputPath: ${JSON.stringify(out ?? null)} → {base:"dist",browser:""} (remoteEntry.json na raiz do dist)`);
  }
  const poly = Array.isArray(o.polyfills) ? o.polyfills : o.polyfills ? [o.polyfills] : [];
  if (!poly.includes('es-module-shims')) { o.polyfills = [...poly, 'es-module-shims']; mud.push('polyfills += es-module-shims'); }
  const assets = o.assets ?? [];
  const temAssets = assets.some((x) => x === 'src/assets' || (typeof x === 'object' && x.input === 'src/assets'));
  if (!temAssets) { o.assets = [...assets, 'src/assets']; mud.push('assets += src/assets (para servir assets/config/app.config.js)'); }

  const so = arq['serve-original'];
  if (so) {
    for (const c of Object.values(so.configurations ?? {})) {
      if (c.buildTarget && c.buildTarget !== paraEsbuild(c.buildTarget)) { c.buildTarget = paraEsbuild(c.buildTarget); mud.push('serve-original aponta para esbuild'); }
    }
    so.options ??= {};
    if (!so.options.port) { so.options.port = porta; mud.push(`serve-original.port = ${porta}`); }
  }
  return [...new Set(mud)];
}

// ---------- git: avisa se há alterações pendentes (dificulta revisar/reverter) ----------
let gitSujo = null;
try { gitSujo = execFileSync('git', ['status', '--porcelain'], { cwd: raiz, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).split('\n').filter((l) => l && !l.includes(path.basename(arqRespostas))).length; } catch { /* não é repo git */ }

// Pendências só valem para arquivos que serão escritos (um config.yaml já existente e preenchido não conta).
const escreve = new Set(plano.filter((i) => i.acao !== 'IGUAL').map((i) => i.arquivo));
pendencias.splice(0, pendencias.length, ...pendencias.filter((x) => escreve.has(x.split(' → ')[0])));

// ---------- execução ----------
if (a.mostrar) {
  const item = plano.find((i) => i.arquivo === a.mostrar);
  if (!item?.conteudo) sair(`nada proposto para ${a.mostrar}`);
  process.stdout.write(item.conteudo);
  process.exit(0);
}

const sobrescrever = new Set(String(a.sobrescrever ?? '').split(',').map((s) => s.trim()).filter(Boolean));
const podeSobrescrever = (arq) => sobrescrever.has('todos') || sobrescrever.has(arq);

// Os 3 arquivos da variável global andam juntos: trocar só parte deles deixa nomes divergentes
// (o service procura uma global que o script de config não cria).
const GRUPO_GLOBAL = ['src/app/core/config/app-config.service.ts', REL_LOCAL, r.caminhoJ2 || D.caminhoJ2];
const conflitosGrupo = GRUPO_GLOBAL.filter((f) => plano.some((i) => i.arquivo === f && i.acao === 'CONFLITO'));
const escolhidos = conflitosGrupo.filter(podeSobrescrever);
if (a.aplicar && escolhidos.length && escolhidos.length !== conflitosGrupo.length) {
  sair(`sobrescreva os arquivos da variável global juntos ou nenhum: ${conflitosGrupo.join(', ')}`);
}
const linhas = [];

if (!a.aplicar) {
  linhas.push(`PLANO (dry-run, nada foi escrito) — nome=${NOME} tag=<${NOME}> global=${GLOBAL} contextPath=${contextPath} configLocal=${REL_LOCAL} bloco federation no .j2=${FEDERATION ? 'sim' : 'não'}`);
  for (const i of plano) linhas.push(`  ${i.acao.padEnd(9)} ${i.arquivo}${i.detalhe ? ` — ${i.detalhe}` : ''}`);
  if (pendencias.length) linhas.push(`PENDÊNCIAS (vão como "${D.pendente}"): ${pendencias.join(' | ')}`);
  if (gitSujo) linhas.push(`! git: ${gitSujo} arquivo(s) com alteração não commitada. Recomende commit/stash antes para o "git diff" mostrar só o que o agente fez.`);
  if (plano.some((i) => i.acao === 'CONFLITO')) linhas.push('CONFLITO não é escrito sem --sobrescrever <arquivo>. Para ver o proposto: --mostrar <arquivo>.');
  console.log(linhas.join('\n'));
  process.exit(0);
}

const feitos = [];
for (const i of plano) {
  if (i.acao === 'IGUAL') continue;
  if (i.acao === 'CONFLITO' && !podeSobrescrever(i.arquivo)) { feitos.push(`  MANTIDO   ${i.arquivo} (conflito não sobrescrito)`); continue; }
  if (!i.conteudo) { feitos.push(`  PULADO    ${i.arquivo}${i.detalhe ? ` — ${i.detalhe}` : ''}`); continue; }
  escrever(p(i.arquivo), i.conteudo);
  feitos.push(`  ${(i.acao === 'CONFLITO' ? 'SUBSTITUÍ' : i.acao).padEnd(9)} ${i.arquivo}`);
}
fs.rmSync(arqRespostas, { force: true });
const escritos = new Set(feitos.filter((l) => !/MANTIDO|PULADO/.test(l)).map((l) => l.trim().split(/\s+/)[1]));
pendencias.splice(0, pendencias.length, ...pendencias.filter((x) => escritos.has(x.split(' → ')[0])));
console.log(['APLICADO', ...feitos, ...(pendencias.length ? [`PENDÊNCIAS ("${D.pendente}"): ${pendencias.join(' | ')}`] : []), `Respostas removidas: ${path.relative(raiz, arqRespostas)}`].join('\n'));
