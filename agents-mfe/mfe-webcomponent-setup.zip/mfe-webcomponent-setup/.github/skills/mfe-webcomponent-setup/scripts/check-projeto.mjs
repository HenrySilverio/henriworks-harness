#!/usr/bin/env node
// Gate de versão + fatos do projeto, em ~200 tokens. Só lê; não altera nada.
// Uso: node .github/skills/mfe-webcomponent-setup/scripts/check-projeto.mjs [--raiz .] [--projeto <chave angular.json>] [--json]
// Saída: código 0 = LIBERADO, 2 = BLOQUEADO (o agente para e mostra os motivos ao dev).
import fs from 'node:fs';
import path from 'node:path';
import {
  args, ler, existe, lerJson, major, nodeAtende, REGRAS, projetoAngular,
  componenteRaiz, nomeGlobal, validarNome,
} from './lib.mjs';

const a = args();
const raiz = path.resolve(a.raiz ?? '.');
const p = (rel) => path.join(raiz, rel);
const bloqueios = [];
const avisos = [];
const fatos = {};

// ---------- Node ----------
fatos.node = process.version;
if (!nodeAtende(process.version, REGRAS.node)) bloqueios.push(`Node ${process.version} fora do suportado (${REGRAS.node.join(' | ')}).`);

// ---------- package.json (do próprio projeto; nunca é gerado nem alterado) ----------
const pkg = lerJson(p('package.json'));
if (!pkg) {
  bloqueios.push('package.json não encontrado na raiz. Rode o agente na pasta do projeto.');
} else {
  const deps = { ...pkg.devDependencies, ...pkg.dependencies };
  const instalada = (n) => lerJson(p(`node_modules/${n}/package.json`))?.version ?? null;
  fatos.pacote = pkg.name;
  fatos.versoes = {};
  for (const dep of Object.keys(REGRAS.dependenciasObrigatorias)) {
    fatos.versoes[dep] = { declarada: deps[dep] ?? null, instalada: instalada(dep) };
  }
  const ng = major(deps['@angular/core']);
  const nf = major(deps['@angular-architects/native-federation']);
  if (!deps['@angular/core']) bloqueios.push('@angular/core não está no package.json — não é um projeto Angular.');
  else if (!REGRAS.angularMajorsSuportados.includes(ng)) bloqueios.push(`Angular ${ng} não suportado por este agente (suportados: ${REGRAS.angularMajorsSuportados.join(', ')}). Atualize o projeto antes.`);

  const faltando = [];
  const coreRange = deps['@angular/core'] ?? '';
  if (!deps['@angular/elements']) faltando.push(`@angular/elements@${coreRange}`);
  else if (major(deps['@angular/elements']) !== ng) bloqueios.push(`@angular/elements (${deps['@angular/elements']}) com major diferente do @angular/core (${coreRange}).`);
  if (!deps['@angular-architects/native-federation']) faltando.push(`@angular-architects/native-federation@~${ng}`);
  else if (REGRAS.federationMesmoMajorDoAngular && nf !== ng) bloqueios.push(`native-federation ${nf} não casa com Angular ${ng}: o native-federation segue o major do Angular.`);
  if (!deps['@angular-devkit/build-angular']) faltando.push(`-D @angular-devkit/build-angular@${coreRange}`);
  else if (major(deps['@angular-devkit/build-angular']) !== ng) bloqueios.push(`@angular-devkit/build-angular (${deps['@angular-devkit/build-angular']}) com major diferente do @angular/core (${coreRange}).`);
  if (!deps['es-module-shims']) faltando.push(`es-module-shims@${REGRAS.dependenciasObrigatorias['es-module-shims']}`);
  if (faltando.length) {
    const prod = faltando.filter((f) => !f.startsWith('-D ')).join(' ');
    const dev = faltando.filter((f) => f.startsWith('-D ')).map((f) => f.slice(3)).join(' ');
    const cmds = [prod && `npm install ${prod}`, dev && `npm install -D ${dev}`].filter(Boolean).join('\n    ');
    bloqueios.push(`Dependências ausentes no package.json do projeto. O dev instala (o agente não altera o package.json):\n    ${cmds}`);
  }

  for (const [dep, v] of Object.entries(fatos.versoes)) {
    if (v.declarada && !v.instalada) avisos.push(`${dep} declarado mas não instalado — rode npm install antes do build.`);
    else if (v.declarada && v.instalada && major(v.declarada) !== major(v.instalada)) bloqueios.push(`${dep}: package.json pede ${v.declarada}, node_modules tem ${v.instalada}. Rode npm install.`);
  }
  if (pkg.type === 'module') avisos.push('package.json tem "type": "module"; o federation.config.js usa require() e pode falhar. Avalie antes de aplicar.');
}

// ---------- angular.json ----------
const angularJson = lerJson(p('angular.json'));
if (!angularJson) bloqueios.push('angular.json não encontrado.');
else {
  const proj = projetoAngular(angularJson, a.projeto);
  if (!proj) bloqueios.push(a.projeto ? `Projeto "${a.projeto}" não existe no angular.json.` : 'Nenhum projeto application no angular.json.');
  else if (proj.ambiguo) bloqueios.push(`Mais de um projeto no angular.json (${proj.ambiguo.join(', ')}). Rode de novo com --projeto <chave>.`);
  else {
    const [chave, cfg] = proj;
    const arq = cfg.architect ?? {};
    const federado = arq.build?.builder === '@angular-architects/native-federation:build';
    const app = federado ? arq.esbuild : arq.build;
    fatos.angularJson = {
      chave,
      federado,
      builderApp: app?.builder ?? null,
      browser: app?.options?.browser ?? app?.options?.main ?? null,
      polyfills: app?.options?.polyfills ?? [],
      porta: (federado ? arq['serve-original'] : arq.serve)?.options?.port ?? null,
    };
    if (app?.options?.main && !app?.options?.browser) avisos.push('angular.json usa "main" (builder antigo). O agente espera o builder application ("browser").');
  }
}

// ---------- fatos do código ----------
const fed = ler(p('federation.config.js'));
fatos.federationConfig = fed ? { name: fed.match(/name:\s*['"]([^'"]+)['"]/)?.[1] ?? null, exposes: [...fed.matchAll(/['"](\.\/[^'"]+)['"]\s*:/g)].map((m) => m[1]) } : null;

const comp = componenteRaiz(raiz);
fatos.componenteRaiz = comp;
if (!comp) avisos.push('Não achei bootstrapApplication(...) em src/main.ts ou src/bootstrap.ts. Pergunte ao dev qual componente vira o web component.');
if (!existe(p('src/app/app.config.ts'))) bloqueios.push('src/app/app.config.ts não existe. O agente só atende app standalone com appConfig (padrão Angular 17+).');

const wc = ler(p('src/app/web-component.module.ts'));
fatos.webComponent = wc ? { existe: true, guard: /customElements\.get\(/.test(wc), tag: wc.match(/define\(\s*['"]([^'"]+)['"]/)?.[1] ?? wc.match(/TAG\s*=\s*['"]([^'"]+)['"]/)?.[1] ?? null } : { existe: false };

const svc = ler(p('src/app/core/config/app-config.service.ts'));
const urlScript = svc?.match(/MFE_APP_CONFIG_SCRIPT_URL\s*=\s*['"]([^'"]+)['"]/)?.[1] ?? null;
fatos.appConfigService = svc
  ? { existe: true, global: svc.match(/declare\s+(?:let|var|const)\s+(\w+)/)?.[1] ?? null, contextPath: urlScript?.replace(/\/assets\/config\/app-config\.js$/, '') ?? null }
  : { existe: false };

const cfgDir = p('config');
const ambientes = existe(cfgDir) ? fs.readdirSync(cfgDir, { withFileTypes: true }).filter((d) => d.isDirectory() && d.name !== 'all').map((d) => d.name) : [];
const achaJ2 = (dir) => (existe(dir) ? fs.readdirSync(dir, { recursive: true }).map(String).filter((f) => f.endsWith('.j2')).map((f) => path.posix.join('config/all', f.split(path.sep).join('/'))) : []);
fatos.config = { ambientes, j2: achaJ2(p('config/all')) };

const index = ler(p('src/index.html'));
fatos.indexHtmlCarregaConfig = index ? /assets\/config\/app\.config\.js/.test(index) : null;

// ---------- sugestões para o agente confirmar com o dev ----------
const nomeSugerido = fatos.federationConfig?.name ?? fatos.pacote ?? null;
const erroNome = validarNome(nomeSugerido);
fatos.sugestoes = {
  nome: nomeSugerido,
  nomeValido: !erroNome,
  global: nomeSugerido && !erroNome ? nomeGlobal(nomeSugerido) : null,
  contextPath: fatos.appConfigService.contextPath,
  centroCusto: nomeSugerido?.split('-')[0] ?? null,
  ambientes: ambientes.length ? ambientes : REGRAS.padroes.ambientes,
  caminhoJ2: fatos.config.j2[0] ?? REGRAS.padroes.caminhoJ2,
  porta: fatos.angularJson?.porta || REGRAS.padroes.porta,
};
if (erroNome && nomeSugerido) avisos.push(`Nome sugerido "${nomeSugerido}" inválido para custom element: ${erroNome}.`);
if (fatos.appConfigService.global && nomeSugerido && fatos.appConfigService.global !== nomeGlobal(nomeSugerido)) {
  avisos.push(`app-config.service.ts usa a global "${fatos.appConfigService.global}"; o padrão para este nome seria "${nomeGlobal(nomeSugerido)}". Globais copiadas de outro MFE colidem no shell.`);
}

const status = bloqueios.length ? 'BLOQUEADO' : 'LIBERADO';

if (a.json) {
  console.log(JSON.stringify({ status, bloqueios, avisos, fatos }, null, 2));
} else {
  const v = fatos.versoes ?? {};
  const fmt = (d) => (v[d] ? `${v[d].declarada ?? '—'}${v[d].instalada ? ` (inst. ${v[d].instalada})` : ''}` : '—');
  const s = fatos.sugestoes;
  const out = [
    `STATUS: ${status}`,
    `node ${fatos.node} | angular ${fmt('@angular/core')} | elements ${fmt('@angular/elements')} | native-federation ${fmt('@angular-architects/native-federation')} | build-angular ${fmt('@angular-devkit/build-angular')} | es-module-shims ${fmt('es-module-shims')}`,
    `package.json: ${fatos.pacote ?? '—'} | angular.json: ${fatos.angularJson ? `${fatos.angularJson.chave}, federado=${fatos.angularJson.federado ? 'sim' : 'não'}, porta=${fatos.angularJson.porta ?? '—'}` : '—'}`,
    `federation.config.js: ${fatos.federationConfig ? `name=${fatos.federationConfig.name}, exposes=${fatos.federationConfig.exposes.join(',') || '—'}` : 'não existe'}`,
    `componente raiz: ${comp ? `${comp.classe} (${comp.arquivo ?? 'import não resolvido'})` : '—'}`,
    `web-component.module.ts: ${fatos.webComponent.existe ? `existe, guard=${fatos.webComponent.guard ? 'sim' : 'NÃO'}, tag=${fatos.webComponent.tag ?? '—'}` : 'não existe'}`,
    `app-config.service.ts: ${fatos.appConfigService.existe ? `existe, global=${fatos.appConfigService.global}, contextPath=${fatos.appConfigService.contextPath ?? '—'}` : 'não existe'}`,
    `config/: ambientes=${ambientes.join(',') || '—'} | j2=${fatos.config.j2.join(',') || '—'} | index.html carrega app.config.js=${fatos.indexHtmlCarregaConfig ? 'sim' : 'não'}`,
    `SUGESTÕES: nome=${s.nome ?? '—'}${s.nomeValido ? '' : ' (INVÁLIDO)'} | global=${s.global ?? '—'} | contextPath=${s.contextPath ?? '—'} | centro_custo=${s.centroCusto ?? '—'} | ambientes=${s.ambientes.join(',')} | porta=${s.porta}`,
    ...bloqueios.map((b) => `✖ ${b}`),
    ...avisos.map((w) => `! ${w}`),
  ];
  console.log(out.join('\n'));
}
process.exit(bloqueios.length ? 2 : 0);
