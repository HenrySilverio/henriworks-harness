#!/usr/bin/env node
// Verificação determinística do MFE web component.
//   node <skill>/scripts/verify-remote.mjs           → checa o código-fonte (consistência entre arquivos)
//   node <skill>/scripts/verify-remote.mjs --dist    → também checa a saída do build (remoteEntry.json)
// Código de saída 1 se algum item falhar (✖). Avisos (!) não falham.
import fs from 'node:fs';
import path from 'node:path';
import { args, ler, existe, lerJson, REGRAS, projetoAngular, nomeGlobal } from './lib.mjs';

const a = args();
const raiz = path.resolve(a.raiz ?? '.');
const p = (rel) => path.join(raiz, rel);
const res = [];
const ok = (m) => res.push(`✔ ${m}`);
const erro = (m) => res.push(`✖ ${m}`);
const aviso = (m) => res.push(`! ${m}`);
const checa = (cond, msgOk, msgErro) => (cond ? ok(msgOk) : erro(msgErro));

// ---------- federation.config.js ----------
const fed = ler(p('federation.config.js'));
const nome = a.nome ?? fed?.match(/name:\s*['"]([^'"]+)['"]/)?.[1];
if (!fed || !nome) {
  erro('federation.config.js ausente ou sem "name"');
  console.log(res.join('\n'));
  process.exit(1);
}
const GLOBAL = nomeGlobal(nome);
const exposes = [...fed.matchAll(/['"](\.\/[^'"]+)['"]\s*:/g)].map((m) => m[1]);
checa(exposes.includes('./bootstrap-webcomponent'), `federation.config.js expõe ./bootstrap-webcomponent (name=${nome})`, 'federation.config.js não expõe ./bootstrap-webcomponent');
if (exposes.length > 1) aviso(`federation.config.js expõe também: ${exposes.filter((e) => e !== './bootstrap-webcomponent').join(', ')} (o padrão é só o web component)`);
checa(/shared:\s*\{\s*\}/.test(fed), 'shared: {} (remote isolado)', 'shared não está vazio — diverge do padrão de ilha isolada');

// ---------- web component ----------
const wc = ler(p('src/app/web-component.module.ts'));
checa(!!wc, 'src/app/web-component.module.ts existe', 'src/app/web-component.module.ts ausente');
if (wc) {
  const tag = wc.match(/TAG\s*=\s*['"]([^'"]+)['"]/)?.[1] ?? wc.match(/define\(\s*['"]([^'"]+)['"]/)?.[1];
  checa(tag === nome, `tag do custom element = <${nome}>`, `tag do custom element (${tag}) diferente do name da federation (${nome})`);
  checa(/customElements\.get\(/.test(wc), 'guard customElements.get() presente', 'sem guard customElements.get(): segunda carga no shell lança NotSupportedError');
}
const bwc = ler(p('src/bootstrap-webcomponent.ts'));
checa(bwc?.includes('./app/web-component.module'), 'src/bootstrap-webcomponent.ts importa o web-component.module', 'src/bootstrap-webcomponent.ts ausente ou não importa ./app/web-component.module');
checa(/initFederation\s*\(/.test(ler(p('src/main.ts')) ?? ''), 'src/main.ts chama initFederation()', 'src/main.ts não chama initFederation()');

// ---------- variável global de config: mesmo nome nos 3 lugares ----------
const svc = ler(p('src/app/core/config/app-config.service.ts'));
const localCfg = ler(p('src/assets/config/app.config.js'));
const j2Path = existe(p('config/all')) ? fs.readdirSync(p('config/all'), { recursive: true }).map(String).find((f) => f.endsWith('.j2')) : null;
const j2 = j2Path ? ler(p(path.join('config/all', j2Path))) : null;
const gSvc = svc?.match(/declare\s+(?:let|var|const)\s+(\w+)/)?.[1];
const gLocal = localCfg?.match(/var\s+(\w+)\s*=/)?.[1];
const gJ2 = j2?.match(/var\s+(\w+)\s*=/)?.[1];
const globais = { 'app-config.service.ts': gSvc, 'app.config.js (local)': gLocal, [`config/all/${j2Path ?? '*.j2'}`]: gJ2 };
const valores = Object.values(globais);
const consistente = valores.every((g) => g && g === valores[0]);
checa(consistente, `variável global "${valores[0]}" igual no service, no app.config.js e no .j2`, `variável global divergente: ${Object.entries(globais).map(([k, v]) => `${k}=${v ?? 'ausente'}`).join(', ')}`);
if (consistente && valores[0] !== GLOBAL) aviso(`global "${valores[0]}" fora da convenção (${GLOBAL}). Funciona, mas confirme que nenhum outro MFE usa o mesmo nome: no shell todos dividem o window.`);
if (svc && /n[ãa]o encontrado/.test(svc) && gSvc && !svc.includes(`${gSvc} não encontrado`) && /appConfig\w+ não encontrado/.test(svc)) aviso('mensagem de log do service cita outra variável global (copiada de outro MFE?)');
const url = svc?.match(/MFE_APP_CONFIG_SCRIPT_URL\s*=\s*['"]([^'"]+)['"]/)?.[1];
checa(url && /^\/.+\/assets\/config\/app-config\.js$/.test(url), `service busca o config em ${url}`, `MFE_APP_CONFIG_SCRIPT_URL inválida: ${url ?? 'ausente'}`);
if (svc && /this\.info\.urlMonitoramento/.test(svc) && !/if\s*\(\s*!this\.info\.urlMonitoramento/.test(svc)) aviso('service injeta o script do Dynatrace mesmo com URL vazia');

// ---------- config por ambiente ----------
const ambientes = existe(p('config')) ? fs.readdirSync(p('config'), { withFileTypes: true }).filter((d) => d.isDirectory() && d.name !== 'all').map((d) => d.name) : [];
checa(ambientes.length > 0, `config/ por ambiente: ${ambientes.join(', ')}`, 'nenhuma pasta de ambiente em config/');
const chavesJ2 = [...(j2 ?? '').matchAll(/deploy\.app_config\.(\w+)/g)].map((m) => m[1]);
for (const env of ambientes) {
  const y = ler(p(`config/${env}/config.yaml`));
  if (!y) { erro(`config/${env}/config.yaml ausente`); continue; }
  const faltam = [...new Set(chavesJ2)].filter((k) => !new RegExp(`^\\s+${k}:`, 'm').test(y));
  if (faltam.length) erro(`config/${env}/config.yaml sem chave(s) usadas no .j2: ${faltam.join(', ')} — o render no deploy fica vazio ou quebra`);
  if (y.includes(REGRAS.padroes.pendente)) aviso(`config/${env}/config.yaml ainda tem ${REGRAS.padroes.pendente}`);
  if (!new RegExp(`name:\\s*${nome}\\b`).test(y)) aviso(`config/${env}/config.yaml: app.name diferente de ${nome}`);
}

// ---------- index.html e angular.json ----------
checa(/assets\/config\/app\.config\.js/.test(ler(p('src/index.html')) ?? ''), 'index.html carrega assets/config/app.config.js', 'index.html não carrega assets/config/app.config.js (teste local fica sem config)');
const angularJson = lerJson(p('angular.json'));
const proj = projetoAngular(angularJson, a.projeto);
const arq = Array.isArray(proj) ? proj[1].architect : null;
checa(arq?.build?.builder === '@angular-architects/native-federation:build', 'angular.json: build = native-federation', 'angular.json: build não usa native-federation');
const poly = arq?.esbuild?.options?.polyfills ?? [];
checa([].concat(poly).includes('es-module-shims'), 'angular.json: es-module-shims nos polyfills', 'angular.json: es-module-shims fora dos polyfills');

// ---------- saída do build ----------
if (a.dist) {
  const out = arq?.esbuild?.options?.outputPath ?? 'dist';
  const distDir = typeof out === 'string' ? p(out) : p(path.join(out.base ?? 'dist', out.browser ?? 'browser'));
  const re = lerJson(path.join(distDir, 'remoteEntry.json'));
  if (!re) erro(`${path.relative(raiz, distDir) || '.'}/remoteEntry.json não encontrado — rode o build antes`);
  else {
    checa(re.name === nome, `remoteEntry.json name=${re.name}`, `remoteEntry.json name=${re.name}, esperado ${nome}`);
    const exp = (re.exposes ?? []).find((e) => e.key === './bootstrap-webcomponent');
    checa(exp && existe(path.join(distDir, exp.outFileName)), `remoteEntry expõe ./bootstrap-webcomponent → ${exp?.outFileName}`, 'remoteEntry.json sem ./bootstrap-webcomponent ou arquivo do bundle ausente');
    if ((re.shared ?? []).length) aviso(`remoteEntry.json lista ${re.shared.length} shared (esperado 0 com shared: {})`);
    checa(existe(path.join(distDir, 'assets/config/app.config.js')), 'dist contém assets/config/app.config.js', 'dist sem assets/config/app.config.js');
  }
}

console.log(res.join('\n'));
const falhas = res.filter((l) => l.startsWith('✖')).length;
console.log(falhas ? `RESULTADO: ${falhas} falha(s)` : 'RESULTADO: OK');
process.exit(falhas ? 1 : 0);
