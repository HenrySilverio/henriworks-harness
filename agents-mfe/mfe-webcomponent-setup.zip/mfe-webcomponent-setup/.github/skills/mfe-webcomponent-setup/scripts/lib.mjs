// Funções compartilhadas pelos scripts da skill. Só módulos nativos do Node.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const SKILL_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const TEMPLATES = path.join(SKILL_DIR, 'templates');
export const REGRAS = JSON.parse(fs.readFileSync(path.join(SKILL_DIR, 'regras.json'), 'utf8'));

export function args(argv = process.argv.slice(2)) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (!a.startsWith('--')) { out._.push(a); continue; }
    const [k, v] = a.slice(2).split('=');
    if (v !== undefined) out[k] = v;
    else if (argv[i + 1] && !argv[i + 1].startsWith('--')) out[k] = argv[++i];
    else out[k] = true;
  }
  return out;
}

export const ler = (f) => (fs.existsSync(f) ? fs.readFileSync(f, 'utf8') : null);
export const existe = (f) => fs.existsSync(f);
export function lerJson(f) {
  const t = ler(f);
  if (t === null) return null;
  // angular.json às vezes tem linhas comentadas com //. Só remove linhas inteiras:
  // globs como "src/**/*.ts" parecem comentário de bloco e não podem ser tocados.
  try { return JSON.parse(t); } catch { return JSON.parse(t.replace(/^\s*\/\/.*$/gm, '')); }
}

/** Major a partir de um range ou versão: "~21.2.0" -> 21, "^21" -> 21, "21.2.3" -> 21. */
export function major(v) {
  const m = String(v ?? '').match(/(\d+)/);
  return m ? Number(m[1]) : null;
}

function cmp(a, b) {
  const pa = a.split('.').map(Number), pb = b.split('.').map(Number);
  for (let i = 0; i < 3; i++) if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) - (pb[i] || 0);
  return 0;
}

/** Aceita "^20.19.0" (mesmo major, >=) e ">=24.0.0". */
export function nodeAtende(versao, faixas) {
  const v = versao.replace(/^v/, '');
  return faixas.some((f) => {
    if (f.startsWith('>=')) return cmp(v, f.slice(2)) >= 0;
    if (f.startsWith('^')) { const b = f.slice(1); return major(v) === major(b) && cmp(v, b) >= 0; }
    return cmp(v, f) === 0;
  });
}

/** recr-fed-agc-posvenda -> RecrFedAgcPosvenda */
export const pascal = (nome) => nome.split(/[-_]/).filter(Boolean).map((p) => p[0].toUpperCase() + p.slice(1)).join('');
/** Nome da variável global de config. Único por MFE: todos dividem o window do shell. */
export const nomeGlobal = (nome) => `appConfig${pascal(nome)}`;

/** Nome de custom element válido: minúsculo, começa com letra, contém hífen. */
export function validarNome(nome) {
  if (!nome) return 'nome vazio';
  if (!/^[a-z][a-z0-9]*(-[a-z0-9]+)+$/.test(nome)) return 'use kebab-case minúsculo com pelo menos um hífen (ex.: recr-fed-agc-posvenda) — é exigência de custom element';
  return null;
}

/** Projeto de aplicação do angular.json (o primeiro do tipo application, ou o indicado). */
export function projetoAngular(angularJson, preferido) {
  const projs = Object.entries(angularJson?.projects ?? {});
  if (preferido) return projs.find(([k]) => k === preferido) ?? null;
  const apps = projs.filter(([, p]) => (p.projectType ?? 'application') === 'application');
  return apps.length === 1 ? apps[0] : apps.length ? { ambiguo: apps.map(([k]) => k) } : null;
}

/** Descobre o componente raiz pelo bootstrapApplication(X, ...) em bootstrap.ts ou main.ts. */
export function componenteRaiz(raiz) {
  for (const arq of ['src/bootstrap.ts', 'src/main.ts']) {
    const t = ler(path.join(raiz, arq));
    if (!t) continue;
    const m = t.match(/bootstrapApplication\(\s*(\w+)/);
    if (!m) continue;
    const classe = m[1];
    const imp = t.match(new RegExp(`import\\s*\\{[^}]*\\b${classe}\\b[^}]*\\}\\s*from\\s*['"]([^'"]+)['"]`));
    if (!imp) return { classe, arquivo: null };
    const abs = path.resolve(path.dirname(path.join(raiz, arq)), imp[1]);
    const arquivo = path.relative(raiz, abs.endsWith('.ts') ? abs : `${abs}.ts`).split(path.sep).join('/');
    return { classe, arquivo };
  }
  return null;
}

/** Import relativo, sem extensão, a partir de um diretório (posix). */
export function importRelativo(deDir, arquivo) {
  let r = path.posix.relative(deDir, arquivo.replace(/\.ts$/, ''));
  if (!r.startsWith('.')) r = `./${r}`;
  return r;
}

export function origem(url) {
  try { return new URL(url).origin; } catch { return ''; }
}

export function aplicarTokens(texto, tokens) {
  return Object.entries(tokens).reduce((t, [k, v]) => t.split(`__${k}__`).join(String(v)), texto);
}

export const template = (rel) => fs.readFileSync(path.join(TEMPLATES, rel), 'utf8');

export function escrever(arq, conteudo) {
  fs.mkdirSync(path.dirname(arq), { recursive: true });
  fs.writeFileSync(arq, conteudo);
}
