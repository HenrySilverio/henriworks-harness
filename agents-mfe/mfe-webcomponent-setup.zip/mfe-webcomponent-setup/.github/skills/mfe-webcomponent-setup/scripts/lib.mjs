// Funções compartilhadas pelos scripts da skill. Só módulos nativos do Node.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const SKILL_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const TEMPLATES = path.join(SKILL_DIR, 'templates');
export const REGRAS = JSON.parse(fs.readFileSync(path.join(SKILL_DIR, 'regras.json'), 'utf8'));

export function args(argv = process.argv.slice(2)) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (!a.startsWith('--')) { out._.push(a); continue; }
    const [k, v] = a.slice(2).split('=');
    if (v !== undefined) out[k] = v;
    else if (argv[i + 1] && !argv[i + 1].startsWith('--')) out[k] = argv[++i];
    else out[k] = true;
  }
  return out;
}

export const ler = (f) => (fs.existsSync(f) ? fs.readFileSync(f, 'utf8') : null);
export const existe = (f) => fs.existsSync(f);
// Remove comentários de linha e de bloco fora de strings (angular.json/tsconfig aceitam comentários).
export function semComentarios(t) {
  let out = '', i = 0, str = false;
  while (i < t.length) {
    const c = t[i], n = t[i + 1];
    if (str) { out += c; if (c === '\\') { out += n ?? ''; i += 2; continue; } if (c === '"') str = false; i++; continue; }
    if (c === '"') { str = true; out += c; i++; continue; }
    if (c === '/' && n === '/') { while (i < t.length && t[i] !== '\n') i++; continue; }
    if (c === '/' && n === '*') { i += 2; while (i < t.length && !(t[i] === '*' && t[i + 1] === '/')) i++; i += 2; continue; }
    out += c; i++;
  }
  return out.replace(/,(\s*[}\]])/g, '$1');
}
export function lerJson(f) {
  const t = ler(f);
  if (t === null) return null;
  try { return JSON.parse(t); } catch { return JSON.parse(semComentarios(t)); }
}

/** Major a partir de um range ou versão: "~21.2.0" -> 21, "^21" -> 21, "21.2.3" -> 21. */
export function major(v) {
  const m = String(v ?? '').match(/(\d+)/);
  return m ? Number(m[1]) : null;
}

function cmp(a, b) {
  const pa = a.split('.').map(Number), pb = b.split('.').map(Number);
  for (let i = 0; i < 3; i++) if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) - (pb[i] || 0);
  return 0;
}

/** Aceita "^20.19.0" (mesmo major, >=) e ">=24.0.0". */
export function nodeAtende(versao, faixas) {
  const v = versao.replace(/^v/, '');
  return faixas.some((f) => {
    if (f.startsWith('>=')) return cmp(v, f.slice(2)) >= 0;
    if (f.startsWith('^')) { const b = f.slice(1); return major(v) === major(b) && cmp(v, b) >= 0; }
    return cmp(v, f) === 0;
  });
}

/** recr-fed-agc-posvenda -> RecrFedAgcPosvenda */
export const pascal = (nome) => nome.split(/[-_]/).filter(Boolean).map((p) => p[0].toUpperCase() + p.slice(1)).join('');
/** Nome da variável global de config. Único por MFE: todos dividem o window do shell. */
export const nomeGlobal = (nome) => `appConfig${pascal(nome)}`;

/** Nome de custom element válido: minúsculo, começa com letra, contém hífen. */
export function validarNome(nome) {
  if (!nome) return 'nome vazio';
  if (!/^[a-z][a-z0-9]*(-[a-z0-9]+)+$/.test(nome)) return 'use kebab-case minúsculo com pelo menos um hífen (ex.: recr-fed-agc-posvenda) — é exigência de custom element';
  return null;
}

/** Projeto de aplicação do angular.json (o primeiro do tipo application, ou o indicado). */
export function projetoAngular(angularJson, preferido) {
  const projs = Object.entries(angularJson?.projects ?? {});
  if (preferido) return projs.find(([k]) => k === preferido) ?? null;
  const apps = projs.filter(([, p]) => (p.projectType ?? 'application') === 'application');
  return apps.length === 1 ? apps[0] : apps.length ? { ambiguo: apps.map(([k]) => k) } : null;
}

/** Descobre o componente raiz pelo bootstrapApplication(X, ...) em bootstrap.ts ou main.ts. */
export function componenteRaiz(raiz) {
  for (const arq of ['src/bootstrap.ts', 'src/main.ts']) {
    const t = ler(path.join(raiz, arq));
    if (!t) continue;
    const m = t.match(/bootstrapApplication\(\s*(\w+)/);
    if (!m) continue;
    const classe = m[1];
    const imp = t.match(new RegExp(`import\\s*\\{[^}]*\\b${classe}\\b[^}]*\\}\\s*from\\s*['"]([^'"]+)['"]`));
    if (!imp) return { classe, arquivo: null };
    const abs = path.resolve(path.dirname(path.join(raiz, arq)), imp[1]);
    const arquivo = path.relative(raiz, abs.endsWith('.ts') ? abs : `${abs}.ts`).split(path.sep).join('/');
    return { classe, arquivo };
  }
  return null;
}

/** Import relativo, sem extensão, a partir de um diretório (posix). */
export function importRelativo(deDir, arquivo) {
  let r = path.posix.relative(deDir, arquivo.replace(/\.ts$/, ''));
  if (!r.startsWith('.')) r = `./${r}`;
  return r;
}

export function origem(url) {
  try { return new URL(url).origin; } catch { return ''; }
}

export function aplicarTokens(texto, tokens) {
  return Object.entries(tokens).reduce((t, [k, v]) => t.split(`__${k}__`).join(String(v)), texto);
}

export const template = (rel) => fs.readFileSync(path.join(TEMPLATES, rel), 'utf8');

export function escrever(arq, conteudo) {
  fs.mkdirSync(path.dirname(arq), { recursive: true });
  fs.writeFileSync(arq, conteudo);
}

// ---------- detecções compartilhadas por check, scaffold e verify ----------

/** Nome da variável global num script de config ou no service. */
export function globalDe(texto) {
  if (!texto) return null;
  return texto.match(/declare\s+(?:let|var|const)\s+(\w+)/)?.[1] ?? texto.match(/^\s*(?:var|let|const)\s+(\w+)\s*=\s*\{/m)?.[1] ?? null;
}

/**
 * Arquivo de config local. Dois padrões convivem no banco:
 * - "app-config.js" (reneg): mesmo nome do arquivo gerado no deploy; o index.html carrega com id=<nome>,
 *   e o service, achando o id, não busca de novo.
 * - "app.config.js" (posvenda): nome diferente do deploy; o service sempre busca o do contextPath.
 */
export function configLocal(raiz) {
  const html = ler(path.join(raiz, 'src/index.html')) ?? '';
  const noIndex = html.match(/assets\/config\/(app[.-]config\.js)/)?.[1];
  for (const nome of [noIndex, 'app-config.js', 'app.config.js'].filter(Boolean)) {
    if (existe(path.join(raiz, 'src/assets/config', nome))) return { arquivo: nome, existe: true, noIndex: !!noIndex };
  }
  return { arquivo: noIndex ?? REGRAS.padroes.arquivoConfigLocal, existe: false, noIndex: !!noIndex };
}

/** O código lê federation.shellRemoteEntry? (decide se o bloco federation entra no .j2) */
export function leShellRemoteEntry(raiz) {
  const src = path.join(raiz, 'src');
  if (!existe(src)) return false;
  return fs.readdirSync(src, { recursive: true }).map(String)
    .filter((f) => f.endsWith('.ts') && !f.endsWith('.spec.ts'))
    .some((f) => /shellRemoteEntry/.test(ler(path.join(src, f)) ?? ''));
}

/** tsconfig do app (o do esbuild/build no angular.json) e se ele cobre um arquivo. */
export function tsconfigApp(raiz, angularJson, chave) {
  const arq = angularJson?.projects?.[chave]?.architect ?? {};
  const rel = (arq.esbuild ?? arq.build)?.options?.tsConfig ?? 'tsconfig.app.json';
  const json = lerJson(path.join(raiz, rel));
  return { rel, json };
}
export function tsconfigCobre(json, alvo) {
  if (!json) return true;
  if ((json.files ?? []).includes(alvo)) return true;
  const inc = json.include ?? (json.files ? [] : ['**/*']);
  return inc.some((g) => {
    const re = new RegExp(`^${g.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*\*\//g, '(?:.*/)?').replace(/\*/g, '[^/]*')}$`);
    return re.test(alvo);
  });
}

/** Remove/ativa blocos condicionais __SE_X__ ... __FIM_X__ dos templates. */
export function blocos(texto, flags) {
  return Object.entries(flags).reduce((t, [k, on]) =>
    t.replace(new RegExp(`[ \\t]*__SE_${k}__\\n([\\s\\S]*?)[ \\t]*__FIM_${k}__\\n`, 'g'), on ? '$1' : ''), texto);
}
