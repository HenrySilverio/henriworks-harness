---
name: mfe-webcomponent-setup
description: Configura um projeto Angular 21 como MFE exposto via remoteEntry (native-federation) no padrão posvenda/reneg — federation.config.js, bootstrap-webcomponent.ts, web-component.module.ts, angular.json, tsconfig.app.json, app-config.service.ts, config local (app-config.js ou app.config.js) e config/DEV|HOM|PRD + .j2. Use quando pedirem para transformar/expor um app Angular como web component, MFE, remote ou remoteEntry, ou para revisar se essa configuração está certa.
---

# Setup de MFE web component (native-federation)

Toda escrita é feita pelos scripts desta pasta. **Não edite à mão** os arquivos do projeto: o scaffold é determinístico e idempotente, e o verify confere a consistência entre eles. Comandos em Git Bash, a partir da raiz do projeto. `SK=.github/skills/mfe-webcomponent-setup/scripts`.

## Regras

- `package.json` é do projeto: **nunca** crie, peça ou altere. Se faltar dependência, mostre o comando que o check imprime e pare.
- Só o web component é exposto (`./bootstrap-webcomponent`), com `shared: {}`.
- `app-config.service.ts`, o config local e o `.j2` usam a **mesma variável global**. Se o check mostrar uma global existente e consistente ("existente, preservar"), passe-a em `global`: renomear obrigaria trocar os três. Projeto novo: `appConfig<NomeEmPascalCase>`. Sobrescreva os três juntos ou nenhum (o scaffold recusa grupo parcial).
- Config local: o scaffold mantém o nome que o projeto já usa. `app-config.js` (padrão reneg) é o mesmo nome do arquivo do deploy e o `<script>` do index leva `id=<nome>`; `app.config.js` (padrão posvenda) é só local.
- `tsconfig.federation.json` é **gerado pelo native-federation a cada build** (a partir do `tsconfig.app.json`): nunca crie nem edite. Quem precisa listar `src/bootstrap-webcomponent.ts` em `files` é o `tsconfig.app.json`; o scaffold faz isso.
- Escopo: config + build gerando o `remoteEntry`. Não mexa no componente (inputs, template, espera de config), em `postBuild.js`, `mocks/` nem em scripts do `package.json`: isso é de cada projeto.
- O bloco `federation.shellRemoteEntry` só entra no `.j2` se o código lê esse valor (o check diz).
- `config/<AMB>/config.yaml` existente nunca é substituído: o scaffold só acrescenta as chaves que o `.j2` usa e faltam. Valores do dev sempre vencem.
- Valor de URL desconhecido vira `PREENCHER` e entra nas pendências do resumo. Não invente URL.

## Passo 1 — Gate de versão

`node $SK/check-projeto.mjs` (se acusar mais de um projeto no angular.json: `--projeto <chave>`).
- `STATUS: BLOQUEADO` → mostre as linhas `✖` ao dev, como estão, e **pare**.
- `STATUS: LIBERADO` → mostre a 1ª e a 2ª linha (versões) e siga. Repasse os avisos `!`.

## Passo 2 — Nome do projeto (confirmação obrigatória)

Mostre o nome sugerido e o que ele define: `name` da federation, tag `<nome>`, id do script de config e a global. Peça confirmação explícita ou outro nome (kebab-case com hífen). Não siga sem resposta.

## Passo 3 — Respostas (uma pergunta só, com os padrões do check)

Componente que vira web component (padrão: componente raiz) · global (padrão: a existente) · `contextPath` público onde o MFE é publicado (ex.: `/recr/agcposvenda`; o service busca `<contextPath>/assets/config/app-config.js`) · centro de custo/value stream · por ambiente: `clientAPI` e URL do Dynatrace (em branco = `PREENCHER`) · porta local.

Se o check mostrar `contextPath` ou global de outro MFE (ex.: path `agcjrndren` num projeto que não é o reneg), aponte: config copiada de outro MFE carrega a configuração errada no shell.

Grave `.mfe-setup.json` na raiz:

```json
{
  "nome": "recr-fed-agc-exemplo",
  "componente": { "classe": "AppComponent", "arquivo": "src/app/app.component.ts" },
  "contextPath": "/recr/agcexemplo",
  "centroCusto": "recr",
  "valueStream": "recr",
  "porta": 4206,
  "local": { "clientAPI": "http://localhost:3000/", "apiTimeout": 2000 },
  "apiTimeout": 5000,
  "ambientes": {
    "DEV": { "clientAPI": "", "urlMonitoramento": "" },
    "HOM": { "clientAPI": "", "urlMonitoramento": "" },
    "PRD": { "clientAPI": "", "urlMonitoramento": "" }
  }
}
```
Use os ambientes que o check encontrou em `config/` (PRD ou PROD, como estiver). Opcionais: `global` (obrigatório repassar quando o check mostrar uma existente), `arquivoConfigLocal`, `shellRemoteEntry` (true/false; padrão: o que o check detectou), `projetoAngular`, `caminhoJ2`, `domainPreConnect`/`shellRemoteEntry` por ambiente.

## Passo 4 — Plano (dry-run) e confirmação

`node $SK/scaffold.mjs --respostas .mfe-setup.json` → mostre o plano. Para cada `CONFLITO`:
- rode `--mostrar <arquivo>` e compare com o atual. Diga em 1 linha o que muda (ex.: "ganha o guard do customElements", "remove `./component` do exposes");
- em `app-config.service.ts`: liste os campos do `TAppConfig` atual que não existem no padrão. Se houver, recomende **manter** o grupo da global e avise que o código que usa esses campos quebraria.

Se o dry-run avisar alteração não commitada, recomende commit/stash antes. Peça "ok" com a lista final do `--sobrescrever`.

## Passo 5 — Aplicar e verificar

`node $SK/scaffold.mjs --respostas .mfe-setup.json --aplicar [--sobrescrever a,b | --sobrescrever todos]` (apaga o `.mfe-setup.json`).
Depois rode `node $SK/verify-remote.mjs`. Se houver `✖`, explique e corrija pelo scaffold.
Ofereça rodar `npm run build` e, se o dev aceitar, `node $SK/verify-remote.mjs --dist`.

## Passo 6 — Resumo final (sempre, neste formato)

```
## O que foi feito
| Arquivo | Ação | Para que serve |
(uma linha por arquivo CRIAR/ATUALIZAR/MOVER/SUBSTITUÍ; MANTIDO também, dizendo por quê)

Nome/tag: <nome> · Global: <global> · Config no deploy: <contextPath>/assets/config/app-config.js
Pendências: (lista de PREENCHER, ou "nenhuma")

## Como validar
1. node .github/skills/mfe-webcomponent-setup/scripts/verify-remote.mjs  → RESULTADO: OK
2. npm run build && node .github/skills/mfe-webcomponent-setup/scripts/verify-remote.mjs --dist  → remoteEntry.json com ./bootstrap-webcomponent
3. npm start → http://localhost:<porta> abre o app; no console: "Configurações carregadas com sucesso"
4. Teste como o shell (console do navegador, com o npm start rodando):
   const re = await (await fetch('/remoteEntry.json')).json();
   await import('/' + re.exposes.find((e) => e.key === './bootstrap-webcomponent').outFileName);
   typeof customElements.get('<nome>')   // "function"
   document.body.appendChild(document.createElement('<nome>'));   // o componente aparece no fim da página
5. git diff → revise antes de commitar

## Para o time do shell
remoteEntry: <host><contextPath>/remoteEntry.json · módulo: ./bootstrap-webcomponent · tag: <nome>
```
