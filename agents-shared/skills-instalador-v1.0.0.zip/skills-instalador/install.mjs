#!/usr/bin/env node
// Instalador global de skills (Agent Skills / SKILL.md) — zero dependências, Node 18+.
// Instala UMA skill por vez nas pastas pessoais que cada ferramenta lê:
//   copilot      → ~/.copilot/skills      (Copilot no VS Code, Copilot CLI, GitHub Copilot app, Visual Studio)
//   claude       → ~/.claude/skills       (Claude Code: CLI, extensão VS Code, aba Code do Claude desktop)
//   antigravity  → ~/.gemini/config/skills (Antigravity App, IDE e CLI)
// O Claude app (chat) não lê disco: use o .zip pronto em claude-app/ (upload em Skills).

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import readline from 'node:readline/promises';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const PKG_VERSION = '1.0.0';
const MARKER = '.skill-install.json';
const ROOT = path.dirname(fileURLToPath(import.meta.url));
const SKILLS_SRC = path.join(ROOT, 'skills');
const HOME = os.homedir();
// Backups ficam FORA das pastas de skills: uma cópia com o mesmo `name` lá dentro viraria skill duplicada.
const STATE_DIR = path.join(HOME, '.skill-installer');

const USAGE = `
Uso (Git Bash):  ./install.sh [comando] <skill> [opções]
      Windows:   install.cmd [comando] <skill> [opções]
      direto:    node install.mjs [comando] <skill> [opções]

Comandos
  install <skill>     instala/atualiza (padrão quando omitido)
  uninstall <skill>   remove o que este instalador colocou
  status              mostra onde cada skill está instalada
  doctor              verifica Node, Python e dependências opcionais dos scripts

Skills: ${listSkills().join(', ')}   (uma por execução)

Opções
  --targets=copilot,claude,antigravity   destinos (padrão: os três)
  --antigravity-legacy   usa ~/.gemini/antigravity/skills (Antigravity 1.x) em vez de ~/.gemini/config/skills
  --copilot-dir=<dir> --claude-dir=<dir> --antigravity-dir=<dir>   sobrescreve a pasta de um destino
  --force      remove na desinstalação mesmo sem a marca deste instalador
  --dry-run    mostra o que faria, sem gravar
  --yes        não pergunta nada (CI / scripts)
`;

// ---------- utilidades ----------
function listSkills() {
  if (!fs.existsSync(SKILLS_SRC)) return [];
  return fs.readdirSync(SKILLS_SRC).filter((d) => fs.existsSync(path.join(SKILLS_SRC, d, 'SKILL.md'))).sort();
}

function parseArgs(argv) {
  const opts = { _: [] };
  for (const a of argv) {
    if (!a.startsWith('--')) { opts._.push(a); continue; }
    const [k, ...v] = a.slice(2).split('=');
    opts[k] = v.length ? v.join('=') : true;
  }
  return opts;
}

function expandHome(p) {
  return p.startsWith('~') ? path.join(HOME, p.slice(1)) : path.resolve(p);
}

function resolveTargets(opts) {
  const claudeBase = process.env.CLAUDE_CONFIG_DIR ? expandHome(process.env.CLAUDE_CONFIG_DIR) : path.join(HOME, '.claude');
  const agDefault = opts['antigravity-legacy']
    ? path.join(HOME, '.gemini', 'antigravity', 'skills')
    : path.join(HOME, '.gemini', 'config', 'skills');
  const all = {
    copilot: {
      label: 'GitHub Copilot (VS Code, CLI, Copilot app, Visual Studio)',
      dir: opts['copilot-dir'] ? expandHome(opts['copilot-dir']) : path.join(HOME, '.copilot', 'skills'),
      reload: 'VS Code: "Developer: Reload Window" · Copilot CLI: /skills reload · Copilot app: reabrir',
    },
    claude: {
      label: 'Claude Code (CLI, extensão VS Code, aba Code do Claude desktop)',
      dir: opts['claude-dir'] ? expandHome(opts['claude-dir']) : path.join(claudeBase, 'skills'),
      reload: 'Claude Code: abrir nova sessão (as skills são lidas no início)',
    },
    antigravity: {
      label: 'Google Antigravity (App, IDE, CLI)',
      dir: opts['antigravity-dir'] ? expandHome(opts['antigravity-dir']) : agDefault,
      reload: 'Antigravity: reabrir o app/IDE; confira em Customizations no painel do agente',
    },
  };
  const wanted = typeof opts.targets === 'string' ? opts.targets.split(',').map((s) => s.trim()).filter(Boolean) : Object.keys(all);
  const bad = wanted.filter((t) => !all[t]);
  if (bad.length) fail(`Destino desconhecido: ${bad.join(', ')}. Use: ${Object.keys(all).join(', ')}`);
  return wanted.map((id) => ({ id, ...all[id] }));
}

function readFrontmatter(skillDir) {
  const text = fs.readFileSync(path.join(skillDir, 'SKILL.md'), 'utf8').replace(/^﻿/, '');
  const m = text.match(/^---\r?\n([\s\S]*?)\r?\n---/);
  if (!m) return {};
  const fm = {};
  for (const line of m[1].split(/\r?\n/)) {
    const kv = line.match(/^([A-Za-z0-9_-]+):\s*(.*)$/);
    if (kv) fm[kv[1]] = kv[2].trim().replace(/^["']|["']$/g, '');
  }
  return fm;
}

// Mesmas regras do padrão Agent Skills (VS Code, Copilot, Antigravity): nome inválido = skill ignorada em silêncio.
function validateSkill(name) {
  const dir = path.join(SKILLS_SRC, name);
  const fm = readFrontmatter(dir);
  const errors = [];
  if (!fm.name) errors.push('frontmatter sem "name"');
  else {
    if (fm.name !== name) errors.push(`"name" (${fm.name}) diferente da pasta (${name})`);
    if (!/^[a-z0-9]+(-[a-z0-9]+)*$/.test(fm.name) || fm.name.length > 64) errors.push('"name" fora do padrão kebab-case (máx. 64)');
  }
  if (!fm.description) errors.push('frontmatter sem "description"');
  else if (fm.description.length > 1024) errors.push(`"description" com ${fm.description.length} caracteres (máx. 1024)`);
  return { dir, fm, errors };
}

function readMarker(dest) {
  try { return JSON.parse(fs.readFileSync(path.join(dest, MARKER), 'utf8')); } catch { return null; }
}

function stamp() {
  return new Date().toISOString().replace(/[:.]/g, '-');
}

function fail(msg) {
  console.error(`\n✖ ${msg}\n`);
  process.exit(1);
}

// Resolve null se a entrada fechar (pipe/CI sem --yes) em vez de travar esperando.
function ask(question) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    let done = false;
    const finish = (v) => { if (!done) { done = true; rl.close(); resolve(v); } };
    rl.on('close', () => finish(null));
    rl.question(question).then((a) => finish(a.trim()), () => finish(null));
  });
}

async function pickSkill(opts) {
  const skills = listSkills();
  if (opts._.length > 1) fail(`Instale uma skill por vez. Recebido: ${opts._.join(', ')}`);
  if (opts._[0]) {
    if (!skills.includes(opts._[0])) fail(`Skill "${opts._[0]}" não está no pacote. Disponíveis: ${skills.join(', ')}`);
    return opts._[0];
  }
  if (opts.yes) fail(`Informe a skill. Disponíveis: ${skills.join(', ')}`);
  console.log('\nQual skill instalar? (uma por vez)');
  skills.forEach((s, i) => console.log(`  ${i + 1}) ${s}`));
  const a = await ask('Número: ');
  if (a === null) fail(`Sem terminal interativo: informe a skill, ex.: ./install.sh ${skills[0]} --yes`);
  const chosen = skills[Number(a) - 1];
  if (!chosen) fail('Opção inválida.');
  return chosen;
}

// ---------- comandos ----------
async function install(opts) {
  const name = await pickSkill(opts);
  const { dir: src, fm, errors } = validateSkill(name);
  if (errors.length) fail(`SKILL.md de ${name} inválido:\n  - ${errors.join('\n  - ')}`);
  const targets = resolveTargets(opts);
  const dry = Boolean(opts['dry-run']);

  console.log(`\n▸ ${name} v${PKG_VERSION}${dry ? '  (dry-run)' : ''}`);
  if (!opts.yes && !dry) {
    targets.forEach((t) => console.log(`  • ${t.label}\n      ${path.join(t.dir, name)}`));
    const ok = await ask('Confirmar? [S/n] ');
    if (ok !== null && /^n/i.test(ok)) fail('Cancelado.');
  }

  const results = [];
  for (const t of targets) {
    const dest = path.join(t.dir, name);
    try {
      let backup = null;
      if (fs.existsSync(dest)) {
        backup = path.join(STATE_DIR, 'backups', name, `${t.id}-${stamp()}`);
        if (!dry) {
          fs.mkdirSync(path.dirname(backup), { recursive: true });
          fs.cpSync(dest, backup, { recursive: true });
        }
      }
      if (!dry) {
        // Staging na pasta-pai (fora da pasta de skills) para a troca ser quase atômica e sem skill "pela metade".
        const staging = path.join(path.dirname(t.dir), `.skill-staging-${name}-${process.pid}`);
        fs.rmSync(staging, { recursive: true, force: true });
        fs.mkdirSync(t.dir, { recursive: true });
        fs.cpSync(src, staging, { recursive: true });
        fs.writeFileSync(
          path.join(staging, MARKER),
          JSON.stringify({ name, version: PKG_VERSION, target: t.id, installedAt: new Date().toISOString(), installer: 'skills-instalador' }, null, 2),
        );
        fs.rmSync(dest, { recursive: true, force: true });
        fs.renameSync(staging, dest);
      }
      results.push({ t, dest, backup, ok: true });
    } catch (e) {
      results.push({ t, dest, ok: false, error: e.code === 'EPERM' || e.code === 'EBUSY' ? `${e.code}: feche a ferramenta que está usando a pasta e rode de novo` : e.message });
    }
  }

  console.log('');
  for (const r of results) {
    if (r.ok) {
      console.log(`✔ ${r.t.id.padEnd(12)} ${r.dest}`);
      if (r.backup) console.log(`  ${''.padEnd(12)} versão anterior salva em ${r.backup}`);
    } else {
      console.log(`✖ ${r.t.id.padEnd(12)} ${r.error}`);
    }
  }

  const done = results.filter((r) => r.ok);
  if (done.length) {
    console.log('\nPara a ferramenta enxergar a skill:');
    for (const r of done) console.log(`  - ${r.t.reload}`);
  }
  const zip = path.join(ROOT, 'claude-app', `${name}.zip`);
  if (fs.existsSync(zip)) console.log(`\nClaude app (chat): faça upload de ${zip} na área de Skills das configurações.`);
  console.log(`\nTeste: peça algo que case com a descrição, ou chame /${fm.name} onde houver slash command de skill.\n`);
  if (results.some((r) => !r.ok)) process.exit(1);
}

async function uninstall(opts) {
  const name = await pickSkill(opts);
  const targets = resolveTargets(opts);
  const dry = Boolean(opts['dry-run']);
  let failed = false;
  for (const t of targets) {
    const dest = path.join(t.dir, name);
    if (!fs.existsSync(dest)) { console.log(`· ${t.id.padEnd(12)} não instalada`); continue; }
    if (!readMarker(dest) && !opts.force) {
      console.log(`! ${t.id.padEnd(12)} ${dest} não foi instalada por este instalador; mantida (use --force)`);
      failed = true;
      continue;
    }
    if (!dry) fs.rmSync(dest, { recursive: true, force: true });
    console.log(`✔ ${t.id.padEnd(12)} removida ${dest}${dry ? ' (dry-run)' : ''}`);
  }
  if (failed) process.exit(1);
}

function status(opts) {
  const targets = resolveTargets(opts);
  for (const name of listSkills()) {
    console.log(`\n${name}`);
    for (const t of targets) {
      const dest = path.join(t.dir, name);
      const m = fs.existsSync(dest) ? readMarker(dest) : null;
      const state = !fs.existsSync(dest) ? '—' : m ? `v${m.version} (${m.installedAt.slice(0, 10)})` : 'presente, instalada por outro meio';
      console.log(`  ${t.id.padEnd(12)} ${state.padEnd(36)} ${dest}`);
    }
  }
  console.log('');
}

function findPython() {
  const candidates = process.platform === 'win32' ? [['py', ['-3']], ['python', []], ['python3', []]] : [['python3', []], ['python', []]];
  for (const [cmd, pre] of candidates) {
    const r = spawnSync(cmd, [...pre, '--version'], { encoding: 'utf8' });
    if (r.status === 0) return { cmd, pre, version: (r.stdout || r.stderr).trim() };
  }
  return null;
}

function doctor() {
  const major = Number(process.versions.node.split('.')[0]);
  console.log(`\nNode ${process.versions.node} ${major >= 18 ? '✔' : '✖ (precisa 18+)'}`);
  for (const name of listSkills()) {
    const { errors } = validateSkill(name);
    console.log(`SKILL.md ${name}: ${errors.length ? '✖ ' + errors.join('; ') : '✔'}`);
  }
  const py = findPython();
  if (!py) {
    console.log('Python ✖ não encontrado — os scripts das skills (build/validate/render) não vão rodar.');
  } else {
    console.log(`Python ✔ ${py.version} (${[py.cmd, ...py.pre].join(' ')})`);
    for (const [mod, uso] of [
      ['PIL', 'Pillow: APNG/GIF (html-motion record_animation, readme-skins render_apng)'],
      ['playwright', 'Playwright + Chromium: render de SVG e validate_page --run'],
    ]) {
      const r = spawnSync(py.cmd, [...py.pre, '-c', `import ${mod}`], { encoding: 'utf8' });
      console.log(`  ${r.status === 0 ? '✔' : '○'} ${uso}${r.status === 0 ? '' : ' — opcional, ausente'}`);
    }
    console.log('  Geração de SVG, build da página e validação estática usam só a biblioteca padrão.');
  }
  console.log('');
}

// ---------- main ----------
const opts = parseArgs(process.argv.slice(2));
if (opts.help || opts.h) { console.log(USAGE); process.exit(0); }
const commands = { install, uninstall, status, doctor };
const cmd = commands[opts._[0]] ? opts._.shift() : 'install';
if (Number(process.versions.node.split('.')[0]) < 18) fail('Node 18+ é necessário.');
if (!listSkills().length) fail(`Nenhuma skill encontrada em ${SKILLS_SRC}`);
await commands[cmd](opts);
