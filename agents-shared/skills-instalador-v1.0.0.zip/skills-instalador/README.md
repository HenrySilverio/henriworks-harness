# Skills html-motion e readme-skins — instalador global

Instala **uma skill por vez** na sua máquina, em nível de usuário (vale para todos os repositórios),
para GitHub Copilot, Claude Code e Antigravity. O Claude app recebe um `.zip` pronto para upload.

| Skill | O que faz |
|---|---|
| `html-motion` | Página HTML animada autocontida (GSAP real ou engine nativa), segura para SharePoint Online; SVG/APNG animado para README |
| `readme-skins` | README visual com skins (arcade, frontend, harness, terminal, blueprint, corporate) em SVG animado gerado localmente |

## Pré-requisitos

- **Node.js 18+** — só para o instalador (zero dependências, sem `npm install`).
- **Python 3** — para os scripts das skills (gerar SVG, build da página, validar). Opcionais:
  **Pillow** (APNG/GIF) e **Playwright + Chromium** (renderizar e `validate_page --run`).
  Sem eles a skill funciona e avisa que pulou a etapa visual. Rode `./install.sh doctor` para ver o que falta.

## Instalar (Git Bash)

```bash
cd /c/Users/<seu-usuario>/Downloads/skills-instalador
./install.sh html-motion          # pergunta e confirma
./install.sh readme-skins --yes   # sem perguntas
./install.sh                      # menu interativo
```

No `cmd`/duplo clique: `install.cmd` (sem argumentos abre o menu).

### Onde cada ferramenta lê

| Destino (`--targets=`) | Pasta | Ferramentas |
|---|---|---|
| `copilot` | `~/.copilot/skills/<skill>` | Copilot no VS Code, Copilot CLI, GitHub Copilot app, Visual Studio |
| `claude` | `~/.claude/skills/<skill>` (respeita `CLAUDE_CONFIG_DIR`) | Claude Code: CLI, extensão VS Code, aba Code do Claude desktop |
| `antigravity` | `~/.gemini/config/skills/<skill>` | Antigravity App, IDE e CLI |
| Claude app (chat) | upload manual de `claude-app/<skill>.zip` em Skills nas configurações | claude.ai e Claude desktop (chat) |

`~` no Windows é `C:\Users\<seu-usuario>`.

### Depois de instalar

- **VS Code:** `Ctrl+Shift+P` → *Developer: Reload Window*. Digite `/skills` no chat para ver a lista.
- **Copilot CLI:** `/skills reload` · **Copilot app:** reabra.
- **Claude Code:** abra uma sessão nova.
- **Antigravity:** reabra; confira em *Customizations* no painel do agente.

## Outros comandos

```bash
./install.sh status                          # onde cada skill está e qual versão
./install.sh doctor                          # Node, Python, Pillow, Playwright, SKILL.md válido
./install.sh uninstall html-motion           # remove só o que este instalador colocou
./install.sh html-motion --targets=copilot,claude   # escolhe destinos
./install.sh html-motion --dry-run           # mostra o que faria
```

| Opção | Para quê |
|---|---|
| `--targets=copilot,claude,antigravity` | Limitar destinos (padrão: os três) |
| `--antigravity-legacy` | Antigravity 1.x: instala em `~/.gemini/antigravity/skills` **em vez de** `config/skills` |
| `--copilot-dir=` `--claude-dir=` `--antigravity-dir=` | Pasta diferente (perfil corporativo, pasta redirecionada) |
| `--force` | Desinstalar uma cópia que não foi colocada por este instalador |
| `--yes` | Sem perguntas (script/CI) |

## Decisões que evitam problema

- **Uma skill por execução.** Pedir as duas no mesmo comando dá erro de propósito.
- **Backup fora das pastas de skills** (`~/.skill-installer/backups/`). Um backup dentro de
  `~/.copilot/skills` teria o mesmo `name` e apareceria como skill duplicada.
- **Troca via staging na pasta-pai.** Se a cópia falhar no meio, a versão anterior continua lá;
  nenhuma ferramenta lê uma skill pela metade.
- **Marca `.skill-install.json`** dentro da skill instalada. O `uninstall` só apaga o que tem a
  marca; uma skill homônima que você copiou à mão fica intacta sem `--force`.
- **Validação do frontmatter antes de copiar.** VS Code e Antigravity ignoram em silêncio uma skill
  com `name` diferente da pasta, fora do kebab-case ou com `description` acima de 1024 caracteres.
- **Antigravity só em `config/skills`.** Ele também lê a pasta legada; instalar nas duas duplicaria.

## Problemas comuns

| Sintoma | Causa provável | Ação |
|---|---|---|
| Skill aparece duas vezes no VS Code | O harness local do Copilot lê `~/.copilot/skills` **e** `~/.claude/skills` | Conteúdo idêntico, inofensivo. Se não usa Claude Code na máquina: `--targets=copilot,antigravity` |
| `EPERM`/`EBUSY` no Windows | VS Code ou antivírus segurando a pasta | Feche a ferramenta e rode de novo; a versão anterior está no backup |
| Skill não aparece no Copilot | Janela não recarregada ou política da organização desabilitou skills | *Reload Window*; confira as políticas do Copilot da org |
| Script falha com `ModuleNotFoundError: playwright` | Dependência opcional ausente | `./install.sh doctor`; a skill segue sem a etapa de render |

## Conteúdo

```
skills-instalador/
├── install.mjs        instalador (Node, zero dependências)
├── install.sh         atalho Git Bash / macOS / Linux
├── install.cmd        atalho Windows (cmd / duplo clique)
├── skills/
│   ├── html-motion/   SKILL.md, references/, assets/, scripts/
│   └── readme-skins/  SKILL.md, references/, skins/, scripts/
└── claude-app/
    ├── html-motion.zip   upload no Claude app
    └── readme-skins.zip
```

Ajuste em relação à versão do Claude app: no passo 8 da `readme-skins`, a entrega passou a dizer
"no repositório aberto, nas IDEs" — o caminho `/mnt/user-data/outputs` só existe no Claude app.
