#!/usr/bin/env bash
# Git Bash (Windows), macOS e Linux.
set -euo pipefail
command -v node >/dev/null 2>&1 || { echo "Node.js 18+ não encontrado no PATH." >&2; exit 1; }
exec node "$(cd "$(dirname "$0")" && pwd)/install.mjs" "$@"
