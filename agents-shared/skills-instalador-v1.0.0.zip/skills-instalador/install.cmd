@echo off
rem Windows (duplo clique ou cmd). Sem argumentos abre o menu interativo.
setlocal
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 18+ nao encontrado no PATH.
  if "%~1"=="" pause
  exit /b 1
)
node "%~dp0install.mjs" %*
set RC=%ERRORLEVEL%
if "%~1"=="" pause
exit /b %RC%
