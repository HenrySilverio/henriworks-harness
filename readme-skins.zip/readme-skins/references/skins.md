# Catálogo de skins

Cada skin = `skins/<id>.json` (paleta por modo, fontes, `motif`, `radius`). O `motif` escolhe o
banner e ajusta formas de `section`/`stats`/`flow`/`stack`/`cards`.

| Skin | Modos | Quando usar | Quando NÃO usar |
|---|---|---|---|
| `arcade` | escuro | repo com personalidade: CLI interna, hackathon, ferramenta de DX, jogos | documentação oficial, repo de auditoria |
| `frontend` | claro + escuro | MFE, shell, design system, lib de componentes, apps Angular/React | backend puro |
| `harness` | escuro | agents/skills/hooks/prompts/instructions, MCP, tooling de IA, plataformas de agentes | libs sem relação com IA (o grafo de nós não diz nada) |
| `terminal` | claro + escuro | CLIs, scripts, infra, pipelines | produtos voltados a negócio |
| `blueprint` | escuro | arquitetura, BFF, contratos, ADRs, diagramas | repo de UI |
| `corporate` | claro + escuro | repo oficial de squad/tribo, entregas para gestão | quando se quer personalidade |

## Personalizar cor

`--accent '#rrggbb'` troca o acento. Para marca corporativa use `corporate` (neutra por padrão);
não assuma a paleta de nenhuma empresa sem o usuário informar.

## Backlog de motivos (inspirados nos templates do GitSkins; não implementados)

Cada um só vale se o dado que o desenho "mostra" for real e útil num README de repo:

- `metro` (mapa de metrô): linhas = camadas/pipelines, paradas = serviços/MFEs. Bom para arquitetura de MFEs.
- `character-sheet` (ficha de RPG): atributos de uma squad ou de um agente (só se os números forem reais).
- `retro-tv` (canais): 3 a 4 "canais" = visões do projeto (status, roadmap, links).
- `space-shooter` / `code-pet` / `aquarium`: decorativos, reservar para repo pessoal ou de cultura.
- `mixtape`, `solar-system`, `bar-chart-race`: dependem de histórico de commits/repos; exigiriam
  coletar dados do git localmente e gerar o SVG estático (sem consultar serviço externo).
