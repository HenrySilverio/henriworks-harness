# spec.json — campos e limites

Só `project.name` é obrigatório. Cada bloco opcional gera o componente correspondente; bloco ausente
= componente não gerado.

```json
{
  "skin": "harness",
  "accent": "#cc092f",
  "project": {
    "name": "Harness de Engenharia com IA",
    "kicker": "AI Harness",
    "tagline": "Agents, skills, hooks e prompts versionados para entregar com Copilot sem perder governança.",
    "hub": "HARNESS",
    "nodes": ["agents", "skills", "hooks", "prompts", "instructions"],
    "command": "cat README.md",
    "hud": "HI-SCORE 042100",
    "dim": "ESCOPO: SEGUNDA VIA",
    "meta": ["Squad: Pós-Venda", "Rev: 2.1", "Status: Produção"],
    "terminal_title": "terminal"
  },
  "stats":   [{"label": "Agents", "value": "12"}],
  "flow":    [{"label": "Prompt", "sub": "intenção"}, "Agent", "Skill"],
  "terminal": ["$ comando", "# comentário", "ok sucesso", "! aviso", "saída comum"],
  "stack":   ["Angular 21", "NgRx Signals"],
  "cards":   [{"title": "Agents", "desc": "Perfis especializados com escopo explícito."}],
  "sections": ["Como funciona", "Quick start"],
  "extras": ["divider"]
}
```

## Campos

| Campo | Limite | Observação |
|---|---|---|
| `skin` | uma das de `skins/` | `--skin` na CLI sobrescreve |
| `accent` | `#rrggbb` | `--accent` na CLI sobrescreve; troca o acento em todos os modos |
| `project.name` | ~40 caracteres | acima de ~20 quebra em 2 linhas e encolhe |
| `project.tagline` | ~110 caracteres | banner trunca com "…" acima de 2 a 3 linhas; o build avisa |
| `project.kicker` | curto | etiqueta acima do título (`arcade`, `frontend`, `harness`, `corporate`) |
| `project.hub` / `nodes` | até 6 nós | só `harness`: centro e satélites do grafo |
| `project.command` | uma linha | só `terminal`: comando digitado no banner |
| `project.hud` | curto | só `arcade`: texto do canto superior direito |
| `project.dim` / `meta` | até 3 itens `"Chave: valor"` | só `blueprint` (cota e carimbo) e `corporate` (chips) |
| `stats` | até 4 (o banner `harness` mostra só 3) | **valores reais**; sem fonte, omita o bloco |
| `flow` | até 6 nós | string ou `{label, sub}`; rótulo ~14 caracteres, sub ~18 |
| `terminal` | até 12 linhas | prefixos: `$ ` prompt, `# ` comentário, `ok ` verde, `! ` aviso |
| `stack` | até 24 itens | quebra em linhas sozinho |
| `cards` | até 9 | 1 a 3 colunas; `desc` até 3 linhas |
| `sections` | lista de rótulos | cada um vira `section-<slug>.svg` (título com linha desenhando) |
| `extras: ["divider"]` | | gera `divider.svg` sem rótulo |

## Arquivos gerados

`<componente>.svg` (skin de modo único) ou `<componente>-light.svg` + `<componente>-dark.svg`
(skins `frontend`, `terminal`, `corporate`), mais `snippets.md`. Nomes de seção: slug sem acento
(`Visão geral` -> `section-visao-geral.svg`).

## Erros comuns

- Tagline longa demais: encurte o texto em vez de forçar fonte menor.
- `stats` com valor sem fonte: remova.
- `terminal` com linha > ~85 caracteres: vaza da janela. Quebre em duas linhas.
