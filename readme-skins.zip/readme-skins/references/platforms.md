# Plataformas, formatos e tamanho

## Matriz

| Plataforma | SVG animado via `<img>` | APNG | Notas |
|---|---|---|---|
| GitHub / GitHub Enterprise | funciona | funciona | `<picture>` + `prefers-color-scheme` casa com o tema do GitHub |
| GitLab | geralmente funciona em versões recentes | funciona | valide na versão self-hosted do usuário |
| Azure DevOps (Repos) | há relatos de SVG não renderizar no preview do README | funciona | use APNG |
| Bitbucket | não verificado | esperado funcionar (é PNG) | valide |

Estas linhas vêm de relatos e docs públicas, não de teste em cada instância corporativa. Se o
usuário não souber a plataforma ou usar mais de uma: entregue **SVG e APNG** e referencie o APNG.
Só GitHub: referencie o SVG (menor e nítido em qualquer zoom).

## Por que `<picture>` e não media query dentro do SVG

Dentro de uma imagem, `prefers-color-scheme` segue o sistema do visitante, não o tema escolhido no
GitHub. Por isso as skins claro/escuro geram dois arquivos e o README alterna com `<picture>`.

## APNG

```bash
python scripts/render_apng.py docs/assets/banner.svg docs/assets/banner.png --bg '#0a0f1e' --fps 15
```
- Toca uma vez e para no último quadro (o loop infinito decorativo é ignorado no cálculo).
- `--bg` com a cor de fundo da skin habilita a **paleta global** (`--colors 128`), que corta o
  tamanho em 3x ou mais. Sem `--bg`, fundo transparente fica RGBA completo e pesado; o script avisa.
- Skin escura com cantos arredondados + `--bg`: o canto fica com a cor da skin (quadrado escuro
  sobre página clara). Aceitável; se incomodar, referencie o SVG.
- Acima de ~500 KB: `--fps 12`, `--scale 1`, `--colors 64` ou encurte o conteúdo.

## Limites do que README aceita

Markdown de README não executa JavaScript nem `<style>`. Só imagem animada funciona. Por isso a
animação é CSS `@keyframes` dentro do SVG, que o navegador roda ao renderizar `<img>`. Dentro do SVG:
sem `<script>`, `on*`, `<foreignObject>`, `@import`, `@font-face` ou URL externa (o validador falha).
Fonte: pilha de sistema; o gerador deixa folga horizontal porque a largura real do texto depende da
fonte do visitante. A fonte pixel do `arcade` é desenhada em `<rect>`, então é idêntica em qualquer máquina.
