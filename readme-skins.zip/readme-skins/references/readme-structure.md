# Esqueletos de README por tipo de projeto

Ordem geral: **banner -> resumo em 1 parágrafo (markdown) -> [stats] -> seções com título SVG ->
conteúdo em markdown real**. Máximo de 5 imagens além do banner. Cada trecho de imagem vem do
`snippets.md`; abaixo aparece como `[img: componente]`.

## Harness de IA (skin `harness`)

```markdown
[img: banner]

> Uma frase: o que o harness resolve e para quem.

[img: stats]            <- só com contagens reais (ls .github/agents | wc -l ...)

[img: section Como funciona]
[img: flow]             <- Prompt -> Agent -> Skill -> Hook -> PR (o fluxo real do repo)

[img: section Estrutura]
| Pasta | O que contém |  <- tabela markdown, não imagem
|---|---|

[img: section Quick start]
[img: terminal]         <- opcional, ilustra; o comando real vai em bloco de código abaixo
```bash
comando real copiável
```

[img: section Contribuindo]
(guard-rails, como adicionar agent/skill/hook, política de revisão)
```

## Frontend / MFE (skin `frontend`)

banner -> resumo -> `stack` -> section Arquitetura + `flow` (Shell -> Remote -> BFF) -> section
Desenvolvimento (comandos em bloco de código: install, start, test, build) -> section Estrutura
(árvore em bloco de código) -> `cards` para os principais conceitos (opcional).

Para repo de MFE, mantenha contrato/especificação (ex.: OpenAPI) descrito como pertencente a esta
camada; não sugira esquema compartilhado entre MFE e BFF no texto do README.

## Backend / BFF (skin `blueprint` ou `terminal`)

banner -> resumo -> section Contrato (onde fica o OpenAPI e como regenerar) -> `flow`
(MFE -> BFF -> Core) -> section Executando (bloco de código) -> section Observabilidade/Operação.

## CLI / ferramenta interna (skin `arcade` ou `terminal`)

banner -> `terminal` mostrando o uso real -> section Instalação (bloco de código) -> `cards` com os
comandos principais -> section Contribuindo.

## Repo oficial de squad (skin `corporate`)

banner com `meta` (squad, status, versão) -> section Visão geral -> `stats` (se houver métrica real)
-> section Responsáveis e canais -> section Como contribuir.

## Checklist antes de entregar

- [ ] `build_readme.py` sem FAIL; nenhum aviso de truncamento
- [ ] PNG de cada componente conferido visualmente (sem texto vazando)
- [ ] `alt` revisado em toda imagem
- [ ] Nenhuma URL externa de imagem no README (`grep -n "http" README.md | grep -i "img\|!\["`)
- [ ] Comandos e links em markdown, não só na imagem
- [ ] Caminhos relativos à raiz do repo (`docs/assets/...`)
- [ ] Números de `stats` rastreáveis a uma contagem real
