#!/usr/bin/env python3
"""Gera os SVGs animados de um README a partir de um spec JSON e de uma skin.

  python build_readme.py spec.json --out docs/assets [--skin arcade] [--accent '#cc092f']
                                   [--rel docs/assets] [--only banner,stats]

Saidas em --out: <componente>[-light|-dark].svg e snippets.md (markdown pronto para colar).
Skins com dois modos (claro/escuro) geram dois arquivos e o snippet usa <picture>.
"""
import argparse
import json
import re
import sys
import unicodedata
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import components as C  # noqa: E402
from validate_svg import validate  # noqa: E402

SKINS_DIR = HERE.parent / "skins"


def slug(s):
    s = unicodedata.normalize("NFKD", s.lower()).encode("ascii", "ignore").decode()
    s = re.sub(r"[^a-z0-9]+", "-", s).strip("-")
    return s or "x"


def load_skin(name, accent=None):
    f = SKINS_DIR / f"{name}.json"
    if not f.exists():
        avail = ", ".join(sorted(p.stem for p in SKINS_DIR.glob("*.json")))
        sys.exit(f"skin '{name}' nao existe. Disponiveis: {avail}")
    data = json.loads(f.read_text(encoding="utf-8"))
    if accent:
        for pal in data["modes"].values():
            pal["accent"] = accent
    return data


def plan(spec, only):
    items = [("banner", None)]
    if spec.get("stats"):
        items.append(("stats", None))
    if spec.get("flow"):
        items.append(("flow", None))
    if spec.get("terminal"):
        items.append(("terminal", None))
    if spec.get("stack"):
        items.append(("stack", None))
    if spec.get("cards"):
        items.append(("cards", None))
    for label in spec.get("sections", []):
        items.append(("section", label))
    if "divider" in spec.get("extras", []):
        items.append(("section", ""))
    if only:
        items = [i for i in items if i[0] in only or (i[0] == "section" and "section" in only)]
    return items


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("spec")
    ap.add_argument("--out", default="docs/assets")
    ap.add_argument("--rel", help="caminho usado nos snippets (padrao: --out)")
    ap.add_argument("--skin")
    ap.add_argument("--accent")
    ap.add_argument("--only", help="lista separada por virgula: banner,stats,flow,terminal,stack,cards,section")
    a = ap.parse_args()

    spec = json.loads(Path(a.spec).read_text(encoding="utf-8"))
    if not spec.get("project", {}).get("name"):
        sys.exit('spec precisa de "project": {"name": ...}')
    proj = spec["project"]
    if len(proj.get("tagline", "")) > 110:
        print("aviso: project.tagline > 110 caracteres sera truncado no banner")
    if len(proj["name"]) > 42:
        print("aviso: project.name muito longo; considere encurtar (o titulo quebra em 2 linhas e encolhe)")
    skin = load_skin(a.skin or spec.get("skin", "frontend"), a.accent or spec.get("accent"))
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    rel = (a.rel or a.out).rstrip("/")
    modes = list(skin["modes"].keys())
    two = len(modes) == 2
    only = set(a.only.split(",")) if a.only else None

    fns = {"banner": C.banner, "stats": C.stats, "flow": C.flow, "terminal": C.terminal,
           "stack": C.stack, "cards": C.cards}
    snippets, report, failed = [], [], False

    for kind, label in plan(spec, only):
        base = "banner" if kind == "banner" else (
            f"section-{slug(label)}" if kind == "section" and label else
            "divider" if kind == "section" else kind)
        files, alt = {}, ""
        for mode in modes:
            ctx = C.Ctx(spec, skin, mode, skin["modes"][mode])
            svg, alt = (C.section(ctx, label) if kind == "section" else fns[kind](ctx))
            fname = f"{base}-{mode}.svg" if two else f"{base}.svg"
            (out / fname).write_text(svg, encoding="utf-8")
            files[mode] = fname
            errs, warns = validate(out / fname)
            kb = len(svg.encode()) / 1024
            report.append((fname, kb, errs, warns))
            failed |= bool(errs)
        alt = alt.replace('"', "'")
        if two:
            tag = (f'<picture>\n  <source media="(prefers-color-scheme: dark)" srcset="{rel}/{files["dark"]}">\n'
                   f'  <img src="{rel}/{files["light"]}" width="900" alt="{alt}">\n</picture>')
        else:
            tag = f'<img src="{rel}/{files[modes[0]]}" width="900" alt="{alt}">'
        snippets.append(f"<!-- {base} -->\n{tag}\n")

    (out / "snippets.md").write_text("\n".join(snippets), encoding="utf-8")
    print(f"skin: {skin['id']} ({'+'.join(modes)})  ->  {out}/")
    for f, kb, errs, warns in report:
        print(f"  {'FAIL' if errs else 'ok  '} {f:38s} {kb:6.1f} KB")
        for e in errs:
            print("       erro:", e)
        for w in warns:
            print("       aviso:", w)
    print(f"snippets: {out}/snippets.md")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
