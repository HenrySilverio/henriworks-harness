#!/usr/bin/env python3
"""Renderiza um SVG animado (CSS keyframes) em APNG/GIF, quadro a quadro, ou em PNG estatico.

  render_apng.py in.svg out.png             # APNG, toca uma vez e para no quadro final
  render_apng.py in.svg out.gif --bg '#fff' # GIF (precisa fundo solido)
  render_apng.py in.svg out.png --still     # so o estado final (para conferir o layout)

Opcoes: --fps 24  --scale 1.5  --hold 2.0 (segundos no ultimo quadro)  --bg COR
Os quadros sao deterministicos: pausa todas as animacoes (Web Animations API) e avanca currentTime.
Animacoes infinitas (o pulso/cursor decorativo) sao ignoradas no calculo da duracao.
"""
import argparse
import io
import sys
from pathlib import Path

from PIL import Image
from playwright.sync_api import sync_playwright

JS_DUR = """() => {
  let end = 0;
  for (const a of document.getAnimations()) {
    const t = a.effect.getComputedTiming();
    if (Number.isFinite(t.endTime)) end = Math.max(end, t.endTime);
  }
  return end;
}"""
JS_SEEK = """(t) => {
  for (const a of document.getAnimations()) { a.pause(); a.currentTime = t; }
}"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("svg")
    ap.add_argument("out")
    ap.add_argument("--fps", type=int, default=24)
    ap.add_argument("--scale", type=float, default=1.5)
    ap.add_argument("--hold", type=float, default=2.0)
    ap.add_argument("--bg")
    ap.add_argument("--colors", type=int, default=128,
                    help="paleta global (so saida opaca: skin escura ou --bg). 0 desliga. Reduz muito o tamanho")
    ap.add_argument("--still", action="store_true")
    ap.add_argument("--at", type=float, help="PNG de um unico quadro neste instante (segundos)")
    a = ap.parse_args()

    src = Path(a.svg).resolve()
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(device_scale_factor=a.scale)
        pg.goto(src.as_uri())
        size = pg.evaluate("() => { const r = document.documentElement.getBoundingClientRect(); return [r.width, r.height]; }")
        pg.set_viewport_size({"width": int(size[0]), "height": int(size[1])})
        if a.bg:
            pg.evaluate("(c) => { document.documentElement.style.background = c; }", a.bg)
        dur_ms = pg.evaluate(JS_DUR)

        def shot(t):
            pg.evaluate(JS_SEEK, t)
            return Image.open(io.BytesIO(pg.screenshot(omit_background=not a.bg))).convert("RGBA")

        if a.at is not None:
            img = shot(a.at * 1000)
            img.save(a.out)
            print(f"quadro em {a.at}s: {a.out}")
            b.close()
            return
        if a.still:
            img = shot(dur_ms + 50)
            img.save(a.out)
            print(f"still: {a.out} ({img.width}x{img.height})")
            b.close()
            return
        n = max(2, int(dur_ms / 1000 * a.fps) + 1)
        frames = [shot(min(dur_ms, i * 1000 / a.fps)) for i in range(n)]
        frames.append(shot(dur_ms + 50))
        b.close()

    opaque = frames[-1].getchannel("A").getextrema()[0] == 255
    if a.colors and (opaque or a.bg) and not a.out.lower().endswith(".gif"):
        size = frames[0].size
        base = Image.new("RGBA", size, a.bg or "#ffffff")
        rgb = [Image.alpha_composite(base, f).convert("RGB") for f in frames]
        picks = [rgb[-1], rgb[len(rgb) // 2], rgb[len(rgb) // 4]]
        mosaic = Image.new("RGB", (size[0], size[1] * len(picks)))
        for i, s in enumerate(picks):
            mosaic.paste(s, (0, i * size[1]))
        pal = mosaic.quantize(colors=a.colors, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE)
        frames = [f.quantize(palette=pal, dither=Image.Dither.NONE) for f in rgb]
    elif a.colors and not opaque:
        print("aviso: fundo transparente = RGBA completo (maior). Para reduzir: use --bg COR, skin escura ou prefira o SVG.")

    step = int(1000 / a.fps)
    durations = [step] * (len(frames) - 1) + [int(a.hold * 1000)]
    if a.out.lower().endswith(".gif"):
        bg = Image.new("RGBA", frames[0].size, a.bg or "#ffffff")
        frames = [Image.alpha_composite(bg, f).convert("P", palette=Image.ADAPTIVE) for f in frames]
        frames[0].save(a.out, save_all=True, append_images=frames[1:], duration=durations, loop=1, optimize=True)
    else:
        frames[0].save(a.out, format="PNG", save_all=True, append_images=frames[1:],
                       duration=durations, loop=1)
    kb = Path(a.out).stat().st_size / 1024
    print(f"{a.out}: {len(frames)} quadros, {dur_ms / 1000:.1f}s, {kb:.0f} KB" + ("  (acima de 500 KB: reduza --fps/--scale)" if kb > 500 else ""))


if __name__ == "__main__":
    sys.exit(main())
