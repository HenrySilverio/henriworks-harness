"""Componentes SVG para README. Tudo local, sem fonte web, sem rede, sem JS.

Regras de autoria (cobradas por validate_svg.py):
- estado final = estilo base; @keyframes so com 'from'; fill-mode 'both'
- nunca transform como atributo em elemento que tambem anima (o CSS sobrescreve)
- no maximo UMA regra de animacao infinita por arquivo
"""
import html
import math
import random

from pixelfont import pixel_text, text_width

W = 900
EASE = "cubic-bezier(.165,.84,.44,1)"

BASE_CSS = (
    ".rise{animation:rise .7s EASE both}@keyframes rise{from{opacity:0;transform:translateY(14px)}}"
    ".pop{animation:pop .5s EASE both;transform-box:fill-box;transform-origin:center}"
    "@keyframes pop{from{opacity:0;transform:scale(.6)}}"
    ".fade{animation:fade .8s ease both}@keyframes fade{from{opacity:0}}"
    ".draw{animation:draw 1s EASE both}@keyframes draw{from{stroke-dashoffset:var(--L)}}"
    ".type{transform-box:fill-box;transform-origin:right center;transform:scaleX(0);"
    "animation:type 1s steps(10,end) both}@keyframes type{from{transform:scaleX(1)}}"
    "@media (prefers-reduced-motion:reduce){*{animation:none!important}}"
).replace("EASE", EASE)


BLINK_CSS = ".blink{animation:blink 1.1s steps(1) infinite}@keyframes blink{50%{opacity:0}}"


def esc(s):
    return html.escape(str(s), quote=True)


def wrap(text, max_chars, max_lines):
    words, lines, cur = str(text).split(), [], ""
    for w in words:
        if len(cur) + len(w) + (1 if cur else 0) <= max_chars:
            cur = (cur + " " + w).strip()
        else:
            if cur:
                lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    if len(lines) > max_lines:
        lines = lines[:max_lines]
        last = lines[-1]
        lines[-1] = (last[: max_chars - 1].rstrip() + "…") if len(last) >= max_chars else last + "…"
    return lines or [""]


def clip(text, max_chars):
    text = str(text)
    return text if len(text) <= max_chars else text[: max(1, max_chars - 1)].rstrip() + "…"


def fit_title(text, avail, max_fs, min_fs=26, cw=0.6):
    """Retorna (linhas, font-size). Quebra em 2 linhas se nao couber em uma."""
    n = max(1, len(text))
    fs = min(max_fs, avail / (n * cw))
    if fs >= min_fs:
        return [text], int(fs)
    words, best = text.split(), None
    for i in range(1, len(words)):
        a, b = " ".join(words[:i]), " ".join(words[i:])
        m = max(len(a), len(b))
        if best is None or m < best[0]:
            best = (m, a, b)
    if best:
        fs = max(min_fs - 8, min(max_fs, avail / (best[0] * cw)))
        return [best[1], best[2]], int(fs)
    return [clip(text, int(avail / (min_fs * cw)))], min_fs


def dl(t):
    return f'style="animation-delay:{t:.2f}s"'


class Ctx:
    def __init__(self, spec, skin, mode, palette):
        self.spec, self.skin, self.mode, self.c = spec, skin, mode, palette
        self.f = skin["fonts"]
        # skin de modo unico (ex.: so escura) nao tem versao para o outro tema:
        # cada componente pinta o proprio fundo para nunca depender do tema da pagina
        self.solid = len(skin["modes"]) == 1
        self.motif = skin["motif"]
        self.rng = random.Random(spec.get("project", {}).get("name", "x"))
        self.px_css = "".join(
            ".l%d{animation-delay:%.2fs}" % (i, 0.15 + i * 0.045) for i in range(40))

    def doc(self, h, title, desc, body, defs="", css=""):
        if 'class="blink"' in body:
            css += BLINK_CSS
        if self.solid:
            body = (f'<rect width="{W}" height="{h}" rx="{self.skin["radius"]}" fill="{self.c["bg"]}"/>' + body)
        return (
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{h}" '
            f'viewBox="0 0 {W} {h}" role="img" aria-labelledby="t d">\n'
            f'<title id="t">{esc(title)}</title>\n<desc id="d">{esc(desc)}</desc>\n'
            f"<defs>{defs}</defs>\n<style>{BASE_CSS}{self.px_css}{css}</style>\n"
            f"{body}\n</svg>\n"
        )

    def text(self, x, y, s, size=16, fill=None, family="body", weight=None,
             anchor=None, cls="", style="", extra=""):
        fill = fill or self.c["text"]
        a = f' text-anchor="{anchor}"' if anchor else ""
        w = f' font-weight="{weight}"' if weight else ""
        k = f' class="{cls}"' if cls else ""
        st = f' style="{style}"' if style else ""
        return (f'<text x="{x}" y="{y}" font-family="{self.f[family]}" font-size="{size}" '
                f'fill="{fill}"{w}{a}{k}{st}{extra}>{esc(s)}</text>')


# ---------------------------------------------------------------- banners

INVADER = [
    "..#.....#..", "...#...#...", "..#######..", ".##.###.##.",
    "###########", "#.#######.#", "#.#.....#.#", "...##.##...",
]


def sprite(rows, x, y, px, fill, cls="pop", delay=0.5):
    rects = []
    for r, row in enumerate(rows):
        for c, ch in enumerate(row):
            if ch == "#":
                rects.append(f'<rect x="{x + c * px}" y="{y + r * px}" width="{px}" height="{px}"/>')
    return f'<g class="{cls}" {dl(delay)} fill="{fill}">{"".join(rects)}</g>'


def banner_arcade(x):
    c, p = x.c, x.spec["project"]
    H = 300
    name = p["name"]
    avail = 690
    n = len(name)
    px = min(8, avail // (n * 6 - 1)) if n else 6
    lines = [name]
    if px < 5 and " " in name:
        ws = name.split()
        best = min(range(1, len(ws)), key=lambda i: max(len(" ".join(ws[:i])), len(" ".join(ws[i:]))))
        lines = [" ".join(ws[:best]), " ".join(ws[best:])]
        m = max(len(l) for l in lines)
        px = max(3, min(8, avail // (m * 6 - 1)))
    px = max(3, px)
    title_y = 92
    parts, bottom = [], title_y
    for li, line in enumerate(lines):
        ly = title_y + li * (7 * px + px * 2)
        shadow, _ = pixel_text(line, 48 + px, ly + px, px, c["accent"], "rise")
        main, _ = pixel_text(line, 48, ly, px, c["accent2"], "rise")
        parts += [shadow, main]
        bottom = ly + 7 * px
    kicker = ""
    if p.get("kicker"):
        k, _ = pixel_text(p["kicker"], 48, 56, 3, c["accent3"], "rise")
        kicker = k
    tag = "".join(
        x.text(48, bottom + 34 + i * 24, t, 17, c["text"], "mono", cls="rise", style="animation-delay:1.0s")
        for i, t in enumerate(wrap(p.get("tagline", ""), 62, 2)))
    press, _ = pixel_text("> PRESS START", 48, H - 52, 3, c["accent3"])
    hud_l, _ = pixel_text("1UP", 32, 22, 3, c["accent3"])
    hud_r_txt = p.get("hud", "CREDIT 01")
    hud_r, _ = pixel_text(hud_r_txt, W - 32 - text_width(hud_r_txt, 3), 22, 3, c["muted"])
    stars = []
    for i in range(34):
        sx, sy = x.rng.randrange(12, W - 12) // 4 * 4, x.rng.randrange(48, H - 20) // 4 * 4
        if 40 < sx < 740 and 80 < sy < H - 70:
            continue
        col = [c["accent2"], c["accent3"], c["text"], c["accent"]][i % 4]
        stars.append(f'<rect class="fade" {dl(0.1 + i * 0.03)} x="{sx}" y="{sy}" width="4" height="4" '
                     f'fill="{col}" opacity="{0.3 + (i % 3) * 0.2:.2f}"/>')
    defs = ('<pattern id="sl" width="4" height="4" patternUnits="userSpaceOnUse">'
            '<rect width="4" height="1" fill="#000" opacity=".28"/></pattern>')
    body = (
        f'<rect width="{W}" height="{H}" fill="{c["bg"]}"/>'
        + "".join(stars)
        + f'<rect x="2" y="2" width="{W-4}" height="{H-4}" fill="none" stroke="{c["border"]}" stroke-width="4"/>'
        f'<rect x="10" y="10" width="{W-20}" height="{H-20}" fill="none" stroke="{c["accent"]}" stroke-width="2" opacity=".55"/>'
        + hud_l + hud_r + kicker + "".join(parts) + tag
        + f'<g class="blink" style="animation-delay:2s">{press}</g>'
        + sprite(INVADER, 764, 118, 8, c["ok"], "pop", 0.4)
        + f'<rect width="{W}" height="{H}" fill="url(#sl)" pointer-events="none"/>'
    )
    return x.doc(H, f'{name} — banner', p.get("tagline", name), body, defs, ""), f'{name}: {p.get("tagline", "")}'


def banner_frontend(x):
    c, p = x.c, x.spec["project"]
    H = 300
    lines, fs = fit_title(p["name"], 480, 54, 30, 0.58)
    light = x.mode == "light"
    blob = ".22" if light else ".38"
    defs = (
        f'<clipPath id="cp"><rect width="{W}" height="{H}" rx="20"/></clipPath>'
        '<filter id="bl" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="46"/></filter>'
        f'<linearGradient id="tg" x1="0" x2="1"><stop offset="0" stop-color="{c["accent"]}"/>'
        f'<stop offset=".55" stop-color="{c["accent2"]}"/><stop offset="1" stop-color="{c["accent3"]}"/></linearGradient>'
        f'<linearGradient id="hg" x1="0" x2="1"><stop offset="0" stop-color="{c["accent"]}"/>'
        f'<stop offset="1" stop-color="{c["accent2"]}"/></linearGradient>'
    )
    kick = ""
    if p.get("kicker"):
        kw = len(p["kicker"]) * 8 + 32
        kick = (f'<g class="rise" {dl(.1)}><rect x="48" y="44" width="{kw}" height="28" rx="14" fill="none" '
                f'stroke="{c["accent"]}"/>' + x.text(64, 63, p["kicker"].upper(), 12, c["accent"], "mono", "600") + "</g>")
    ty = 130
    title = "".join(
        x.text(48, ty + i * int(fs * 1.12), l, fs, "url(#tg)", "display", "800", cls="rise", style="animation-delay:.25s")
        for i, l in enumerate(lines))
    below = ty + (len(lines) - 1) * int(fs * 1.12)
    tag = "".join(x.text(48, below + 38 + i * 26, t, 18, c["muted"], cls="rise", style="animation-delay:.5s")
                  for i, t in enumerate(wrap(p.get("tagline", ""), 46, 3)))
    chips, cx = [], 48
    ntag = len(wrap(p.get("tagline", ""), 46, 3))
    cy0 = min(H - 40, max(236, below + 38 + (ntag - 1) * 26 + 22))
    for i, s in enumerate(x.spec.get("stack", [])[:4]):
        w = len(s) * 7.6 + 24
        if cx + w > 520:
            break
        chips.append(f'<g class="pop" {dl(.8 + i * .08)}><rect x="{cx}" y="{cy0}" width="{w:.0f}" height="28" rx="14" '
                     f'fill="{c["surface"]}" stroke="{c["border"]}"/>'
                     + x.text(cx + w / 2, cy0 + 19, s, 12.5, c["text"], "mono", anchor="middle") + "</g>")
        cx += w + 8
    win = (
        f'<g class="rise" {dl(.3)}><rect x="570" y="48" width="290" height="204" rx="12" fill="{c["surface"]}" stroke="{c["border"]}"/>'
        f'<rect x="570" y="48" width="290" height="30" rx="12" fill="{c["surface2"]}"/>'
        f'<rect x="570" y="66" width="290" height="12" fill="{c["surface2"]}"/>'
        '<circle cx="588" cy="63" r="4.5" fill="#ff5f57"/><circle cx="604" cy="63" r="4.5" fill="#febc2e"/>'
        '<circle cx="620" cy="63" r="4.5" fill="#28c840"/>'
        f'<rect x="650" y="55" width="190" height="16" rx="8" fill="{c["bg"]}"/></g>'
        f'<rect class="pop" {dl(.7)} x="588" y="94" width="254" height="44" rx="8" fill="url(#hg)"/>'
        f'<rect class="pop" {dl(.85)} x="588" y="150" width="120" height="68" rx="8" fill="{c["surface2"]}" stroke="{c["border"]}"/>'
        f'<rect class="pop" {dl(1.0)} x="722" y="150" width="120" height="68" rx="8" fill="{c["surface2"]}" stroke="{c["border"]}"/>'
        f'<rect class="pop" {dl(1.15)} x="600" y="164" width="48" height="8" rx="4" fill="{c["accent3"]}"/>'
        f'<rect class="pop" {dl(1.25)} x="734" y="164" width="64" height="8" rx="4" fill="{c["accent2"]}"/>'
        f'<rect class="pop" {dl(1.35)} x="600" y="182" width="86" height="6" rx="3" fill="{c["border"]}"/>'
        f'<rect class="pop" {dl(1.45)} x="734" y="182" width="72" height="6" rx="3" fill="{c["border"]}"/>'
        f'<rect class="pop" {dl(1.55)} x="588" y="228" width="72" height="14" rx="7" fill="{c["accent"]}"/>'
    )
    body = (
        f'<rect width="{W}" height="{H}" rx="20" fill="{c["bg"]}"/>'
        f'<g clip-path="url(#cp)"><g filter="url(#bl)" opacity="{blob}">'
        f'<circle cx="110" cy="40" r="110" fill="{c["accent"]}"/><circle cx="520" cy="290" r="120" fill="{c["accent2"]}"/>'
        f'<circle cx="830" cy="60" r="100" fill="{c["accent3"]}"/></g></g>'
        f'<rect x=".5" y=".5" width="{W-1}" height="{H-1}" rx="20" fill="none" stroke="{c["border"]}"/>'
        + kick + title + tag + "".join(chips) + win
    )
    return x.doc(H, f'{p["name"]} — banner', p.get("tagline", ""), body, defs), f'{p["name"]}: {p.get("tagline", "")}'


def banner_harness(x):
    c, p = x.c, x.spec["project"]
    H = 300
    lines, fs = fit_title(p["name"], 470, 50, 28, 0.58)
    defs = (
        f'<pattern id="dots" width="22" height="22" patternUnits="userSpaceOnUse"><circle cx="2" cy="2" r="1" fill="{c["border"]}"/></pattern>'
        f'<linearGradient id="tg" x1="0" x2="1"><stop offset="0" stop-color="{c["accent"]}"/><stop offset="1" stop-color="{c["accent2"]}"/></linearGradient>'
        f'<clipPath id="cp"><rect width="{W}" height="{H}" rx="16"/></clipPath>'
    )
    kick = ""
    if p.get("kicker"):
        kw = len(p["kicker"]) * 8 + 40
        kick = (f'<g class="rise" {dl(.1)}><rect x="48" y="44" width="{kw}" height="26" rx="6" fill="{c["surface"]}" stroke="{c["accent"]}"/>'
                f'<circle cx="63" cy="57" r="3.5" fill="{c["ok"]}"/>' + x.text(74, 62, p["kicker"].upper(), 12, c["accent2"], "mono", "600") + "</g>")
    ty = 128
    title = "".join(
        x.text(48, ty + i * int(fs * 1.12), l, fs, "url(#tg)", "display", "800", cls="rise", style="animation-delay:.25s")
        for i, l in enumerate(lines))
    below = ty + (len(lines) - 1) * int(fs * 1.12)
    tag = "".join(x.text(48, below + 36 + i * 25, t, 17, c["muted"], cls="rise", style="animation-delay:.5s")
                  for i, t in enumerate(wrap(p.get("tagline", ""), 50, 3)))
    stats, sx = [], 48
    cols = [c["ok"], c["accent2"], c["accent3"]]
    for i, s in enumerate(x.spec.get("stats", [])[:3]):
        label = f'{s["value"]} {s["label"].lower()}'
        stats.append(f'<g class="rise" {dl(.9 + i * .1)}><circle cx="{sx + 4}" cy="257" r="4" fill="{cols[i]}"/>'
                     + x.text(sx + 14, 262, label, 13, c["text"], "mono") + "</g>")
        sx += len(label) * 7.9 + 44
    nodes = p.get("nodes") or ["agents", "skills", "hooks", "prompts", "instructions"]
    cx, cy, rx, ry = 700, 150, 120, 84
    graph, lab = [], []
    ncol = [c["accent"], c["accent2"], c["accent3"], c["ok"], c["accent"], c["accent2"]]
    for i, nm in enumerate(nodes[:6]):
        a = -math.pi / 2 + i * 2 * math.pi / len(nodes[:6])
        nx, ny = cx + rx * math.cos(a), cy + ry * math.sin(a)
        L = math.hypot(nx - cx, ny - cy)
        graph.append(f'<line class="draw" style="--L:{L:.0f};stroke-dasharray:{L:.0f};animation-delay:{.5 + i * .12:.2f}s" '
                     f'x1="{cx}" y1="{cy}" x2="{nx:.1f}" y2="{ny:.1f}" stroke="{c["border"]}" stroke-width="2"/>')
        lab.append(f'<g class="pop" {dl(.8 + i * .12)}><circle cx="{nx:.1f}" cy="{ny:.1f}" r="9" fill="{c["surface"]}" '
                   f'stroke="{ncol[i]}" stroke-width="2.5"/><circle cx="{nx:.1f}" cy="{ny:.1f}" r="3.5" fill="{ncol[i]}"/>'
                   + x.text(f"{nx:.1f}", f"{ny + (26 if ny >= cy else -16):.1f}", nm, 12, c["muted"], "mono", anchor="middle") + "</g>")
    hub = (f'<circle class="pulse" cx="{cx}" cy="{cy}" r="34" fill="none" stroke="{c["accent"]}" stroke-width="2"/>'
           f'<g class="pop" {dl(.3)}><circle cx="{cx}" cy="{cy}" r="34" fill="{c["surface2"]}" stroke="{c["accent"]}" stroke-width="2.5"/>'
           + x.text(cx, cy + 4, p.get("hub", "HARNESS"), 11, c["text"], "mono", "700", anchor="middle") + "</g>")
    css = (".pulse{transform-box:fill-box;transform-origin:center;opacity:0;animation:pulse 2.4s ease-out 1.8s infinite}"
           "@keyframes pulse{from{transform:scale(1);opacity:.55}to{transform:scale(1.9);opacity:0}}")
    body = (
        f'<rect width="{W}" height="{H}" rx="16" fill="{c["bg"]}"/>'
        f'<g clip-path="url(#cp)"><rect width="{W}" height="{H}" fill="url(#dots)" opacity=".7"/></g>'
        f'<rect x=".5" y=".5" width="{W-1}" height="{H-1}" rx="16" fill="none" stroke="{c["border"]}"/>'
        + kick + title + tag + "".join(stats) + "".join(graph) + hub + "".join(lab)
    )
    return x.doc(H, f'{p["name"]} — banner', p.get("tagline", ""), body, defs, css), f'{p["name"]}: {p.get("tagline", "")}'


def _window(x, y, w, h, title, x0=24):
    c = x.c
    return (
        f'<rect x="{x0}" y="{y}" width="{w}" height="{h}" rx="10" fill="{c["surface"]}" stroke="{c["border"]}"/>'
        f'<path d="M{x0} {y+36} V{y+10} Q{x0} {y} {x0+10} {y} H{x0+w-10} Q{x0+w} {y} {x0+w} {y+10} V{y+36} Z" fill="{c["surface2"]}"/>'
        f'<circle cx="{x0+22}" cy="{y+18}" r="5.5" fill="#ff5f57"/><circle cx="{x0+42}" cy="{y+18}" r="5.5" fill="#febc2e"/>'
        f'<circle cx="{x0+62}" cy="{y+18}" r="5.5" fill="#28c840"/>'
        + x.text(x0 + w / 2, y + 23, title, 12.5, c["muted"], "mono", anchor="middle")
    )


def _typed(x, tx, ty, s, size, fill, start, per_char=0.028, cover=None, family="mono", weight=None):
    """Linha 'digitada': texto + retangulo de cobertura que recua em steps()."""
    cw = size * 0.6
    n = max(1, len(s))
    wpx = n * cw * 1.06 + 6
    dur = max(0.4, n * per_char)
    cov = (f'<rect class="type" x="{tx - 2}" y="{ty - size}" width="{wpx:.0f}" height="{size * 1.4:.0f}" fill="{cover}" '
           f'style="animation-duration:{dur:.2f}s;animation-timing-function:steps({n},end);animation-delay:{start:.2f}s"/>')
    return x.text(tx, ty, s, size, fill, family, weight) + cov, start + dur


def banner_terminal(x):
    c, p = x.c, x.spec["project"]
    H = 232
    slug = p["name"].lower().replace(" ", "-")
    cmd = p.get("command", "cat README.md")
    t = [_window(x, 20, W - 48, H - 40, f"~/{slug} — zsh")]
    prompt = x.text(52, 96, "$", 16, c["accent"], "mono", "700")
    typed, t1 = _typed(x, 70, 96, cmd, 16, c["text"], 0.3, cover=c["surface"])
    lines, fs = fit_title(p["name"], 780, 44, 26, 0.62)
    title = "".join(x.text(52, 148 + i * int(fs * 1.15), l, fs, c["text"], "mono", "700", cls="rise",
                           style=f"animation-delay:{t1 + .1:.2f}s") for i, l in enumerate(lines))
    below = 148 + (len(lines) - 1) * int(fs * 1.15)
    ty = below + 38
    tl = wrap(p.get("tagline", ""), 78, 2)
    tag, end = [], t1 + 0.5
    for i, l in enumerate(tl):
        s, end = _typed(x, 52, ty + i * 24, l, 16, c["muted"], end, 0.022, c["surface"])
        tag.append(s)
    last = tl[-1]
    cur_x = 52 + len(last) * 9.6 + 8
    cursor = (f'<g class="fade" style="animation-delay:{end:.2f}s"><g class="blink">'
              f'<rect x="{cur_x:.0f}" y="{ty + (len(tl) - 1) * 24 - 14}" width="9" height="18" fill="{c["accent"]}"/></g></g>')
    body = "".join(t) + prompt + typed + title + "".join(tag) + cursor
    return x.doc(H, f'{p["name"]} — banner', p.get("tagline", ""), body), f'{p["name"]}: {p.get("tagline", "")}'


def banner_blueprint(x):
    c, p = x.c, x.spec["project"]
    H = 290
    lines, fs = fit_title(p["name"].upper(), 560, 46, 26, 0.64)
    defs = (
        f'<pattern id="mn" width="20" height="20" patternUnits="userSpaceOnUse"><path d="M20 0H0V20" fill="none" stroke="{c["border"]}" stroke-width=".6" opacity=".5"/></pattern>'
        f'<pattern id="mj" width="100" height="100" patternUnits="userSpaceOnUse"><path d="M100 0H0V100" fill="none" stroke="{c["border"]}" stroke-width="1.2" opacity=".8"/></pattern>'
    )
    ty = 118
    title = "".join(x.text(56, ty + i * int(fs * 1.15), l, fs, c["text"], "display", "700", cls="rise",
                           style="animation-delay:.2s") for i, l in enumerate(lines))
    below = ty + (len(lines) - 1) * int(fs * 1.15)
    tw = min(560, int(max(len(l) for l in lines) * fs * 0.64))
    dy = below + 42
    dim = (f'<g class="draw" style="--L:{tw};stroke-dasharray:{tw};animation-delay:.7s" stroke="{c["accent2"]}" stroke-width="1.5" fill="none">'
           f'<path d="M56 {dy} H{56 + tw}"/></g>'
           f'<g class="fade" {dl(1.4)} stroke="{c["accent2"]}" stroke-width="1.5"><path d="M56 {dy-7} V{dy+7} M{56+tw} {dy-7} V{dy+7}"/></g>'
           + x.text(56 + tw / 2, dy - 8, p.get("dim", "ESCOPO"), 11, c["accent2"], "mono", anchor="middle", cls="fade", style="animation-delay:1.4s"))
    tag = "".join(x.text(56, dy + 34 + i * 22, t, 15, c["muted"], "body", cls="rise", style="animation-delay:.9s")
                  for i, t in enumerate(wrap(p.get("tagline", ""), 58, 3)))
    meta = (p.get("meta") or [])[:3]
    while len(meta) < 3:
        meta.append(["PROJETO: " + p["name"][:18], "REV: 1.0", "STATUS: ATIVO"][len(meta)])
    rows = ""
    for i, m in enumerate(meta):
        k, _, v = m.partition(":")
        yy = 196 + i * 20
        rows += (f'<path d="M610 {yy+3} H866" stroke="{c["accent"]}" stroke-width=".8" opacity=".6"/>'
                 + x.text(620, yy + 16 - 3, k.strip().upper(), 10, c["muted"], "mono")
                 + x.text(700, yy + 16 - 3, clip(v.strip() or k, 22), 11.5, c["text"], "mono", "600"))
    block = (f'<g class="fade" {dl(1.0)}><rect x="610" y="193" width="256" height="66" fill="none" stroke="{c["accent"]}" stroke-width="1.6"/>{rows}</g>')
    cross = (f'<g class="draw" style="--L:276;stroke-dasharray:276;animation-delay:.5s" fill="none" stroke="{c["accent2"]}" stroke-width="1.5">'
             '<circle cx="770" cy="92" r="44" stroke-dasharray="5 5"/></g>'
             f'<g class="fade" {dl(1.1)} stroke="{c["accent2"]}" stroke-width="1.2"><path d="M710 92 H830 M770 32 V152"/></g>')
    marks = "".join(f'<path d="{d}" stroke="{c["accent2"]}" stroke-width="2" fill="none"/>' for d in (
        "M22 40 V22 H40", f"M{W-40} 22 H{W-22} V40", f"M22 {H-40} V{H-22} H40", f"M{W-40} {H-22} H{W-22} V{H-40}"))
    body = (f'<rect width="{W}" height="{H}" fill="{c["bg"]}"/><rect width="{W}" height="{H}" fill="url(#mn)"/>'
            f'<rect width="{W}" height="{H}" fill="url(#mj)"/>'
            f'<rect x="10" y="10" width="{W-20}" height="{H-20}" fill="none" stroke="{c["border"]}" stroke-width="1.5"/>'
            + marks + title + dim + tag + cross + block)
    return x.doc(H, f'{p["name"]} — banner', p.get("tagline", ""), body, defs), f'{p["name"]}: {p.get("tagline", "")}'


def banner_corporate(x):
    c, p = x.c, x.spec["project"]
    H = 230
    lines, fs = fit_title(p["name"], 600, 44, 28, 0.56)
    defs = (f'<linearGradient id="bg2" x1="0" x2="1"><stop offset="0" stop-color="{c["surface"]}"/>'
            f'<stop offset="1" stop-color="{c["surface2"]}"/></linearGradient>')
    ty = 92
    title = "".join(x.text(52, ty + i * int(fs * 1.12), l, fs, c["text"], "display", "800", cls="rise",
                           style="animation-delay:.15s") for i, l in enumerate(lines))
    below = ty + (len(lines) - 1) * int(fs * 1.12)
    tag = "".join(x.text(52, below + 34 + i * 25, t, 18, c["muted"], cls="rise", style="animation-delay:.35s")
                  for i, t in enumerate(wrap(p.get("tagline", ""), 62, 2)))
    kick = x.text(52, 48, p.get("kicker", "").upper(), 12, c["accent"], "mono", "700", cls="rise") if p.get("kicker") else ""
    chips, cx = [], 52
    for i, m in enumerate((p.get("meta") or [])[:3]):
        w = len(m) * 7.4 + 26
        chips.append(f'<g class="pop" {dl(.6 + i * .1)}><rect x="{cx}" y="{H-52}" width="{w:.0f}" height="28" rx="14" fill="{c["bg"]}" stroke="{c["border"]}"/>'
                     + x.text(cx + w / 2, H - 33, m, 12.5, c["text"], anchor="middle") + "</g>")
        cx += w + 10
    mark = (f'<g class="pop" {dl(.3)}><rect x="720" y="52" width="86" height="86" rx="18" fill="{c["accent"]}" opacity=".95"/></g>'
            f'<g class="pop" {dl(.45)}><circle cx="800" cy="132" r="42" fill="{c["accent2"]}" opacity=".85"/></g>'
            f'<g class="pop" {dl(.6)}><rect x="770" y="100" width="64" height="64" rx="10" fill="none" stroke="{c["text"]}" stroke-width="3" opacity=".7"/></g>')
    body = (f'<rect width="{W}" height="{H}" rx="{x.skin["radius"]}" fill="url(#bg2)"/>'
            f'<rect x=".5" y=".5" width="{W-1}" height="{H-1}" rx="{x.skin["radius"]}" fill="none" stroke="{c["border"]}"/>'
            f'<rect class="fade" width="8" height="{H}" fill="{c["accent"]}"/>' + kick + title + tag + "".join(chips) + mark)
    return x.doc(H, f'{p["name"]} — banner', p.get("tagline", ""), body, defs), f'{p["name"]}: {p.get("tagline", "")}'


BANNERS = {"arcade": banner_arcade, "frontend": banner_frontend, "harness": banner_harness,
           "terminal": banner_terminal, "blueprint": banner_blueprint, "corporate": banner_corporate}


def banner(x):
    return BANNERS[x.motif](x)


# ---------------------------------------------------------------- sections

def section(x, label=""):
    c, m = x.c, x.motif
    H = 48 if label else 28
    body = []
    if m == "arcade":
        cx = 8
        if label:
            s, w = pixel_text(label, 8, 12, 3, c["accent2"], "rise")
            body.append(s)
            cx = 8 + w + 18
        i = 0
        while cx < W - 12:
            col = [c["accent"], c["accent3"], c["accent2"]][i % 3]
            body.append(f'<rect class="pop" {dl(.2 + min(i, 40) * .03)} x="{cx}" y="{19 if label else 12}" width="6" height="6" fill="{col}"/>')
            cx += 14
            i += 1
        return x.doc(H, label or "Divisor", label or "Divisor", "".join(body)), label or "—"
    if label:
        if m == "terminal":
            body.append(x.text(8, 32, "$", 18, c["accent"], "mono", "700"))
            body.append(x.text(28, 32, label, 18, c["text"], "mono", "700", cls="rise"))
            x0 = 28 + len(label) * 11 + 14
        elif m == "blueprint":
            body.append(x.text(8, 32, label.upper(), 15, c["accent2"], "mono", "700", cls="rise"))
            x0 = 8 + len(label) * 10 + 14
        else:
            body.append(f'<rect class="pop" x="8" y="12" width="5" height="26" rx="2.5" fill="{c["accent"]}"/>')
            body.append(x.text(24, 33, label, 22, c["text"], "display", "700", cls="rise"))
            x0 = 24 + len(label) * 12.4 + 16
        L = max(10, W - 8 - x0)
        body.append(f'<line class="draw" style="--L:{L:.0f};stroke-dasharray:{L:.0f};animation-delay:.3s" x1="{x0:.0f}" y1="{26 if m != "terminal" else 27}" '
                    f'x2="{W-8}" y2="{26 if m != "terminal" else 27}" stroke="{c["border"]}" stroke-width="2"/>')
    else:
        body.append(f'<line class="draw" style="--L:{W-16};stroke-dasharray:{W-16}" x1="8" y1="14" x2="{W-8}" y2="14" stroke="{c["border"]}" stroke-width="2"/>')
        body.append(f'<rect class="pop" {dl(.6)} x="{W/2-5}" y="9" width="10" height="10" rx="2" fill="{c["accent"]}"/>')
    return x.doc(H, label or "Divisor", label or "Divisor", "".join(body)), label or "—"


# ---------------------------------------------------------------- stats

def stats(x):
    c, items = x.c, x.spec["stats"][:4]
    n, gap, H = len(items), 14, 104
    tw = (W - 16 - gap * (n - 1)) / n
    body = []
    for i, s in enumerate(items):
        tx = 8 + i * (tw + gap)
        r = x.skin["radius"]
        body.append(f'<g class="rise" {dl(.1 + i * .12)}><rect x="{tx:.0f}" y="4" width="{tw:.0f}" height="{H-8}" rx="{r}" fill="{c["surface"]}" stroke="{c["border"]}" stroke-width="{2 if x.motif == "arcade" else 1}"/>')
        if x.motif == "arcade":
            v, _ = pixel_text(str(s["value"]), tx + 18, 24, 5, c["accent3"])
            lb, _ = pixel_text(clip(s["label"], int((tw - 36) // 12)), tx + 18, 70, 2, c["accent2"])
            body.append(v + lb)
        else:
            fam = "mono" if x.motif in ("blueprint", "terminal") else "display"
            body.append(x.text(tx + 20, 56, clip(str(s["value"]), 10), 34, c["accent"], fam, "800"))
            body.append(x.text(tx + 20, 80, clip(s["label"].upper(), int((tw - 32) / 7.6)), 11, c["muted"], "mono", "600"))
        body.append("</g>")
    alt = "; ".join(f'{s["label"]}: {s["value"]}' for s in items)
    return x.doc(H, "Indicadores", alt, "".join(body)), alt


# ---------------------------------------------------------------- flow

def flow(x):
    c, items = x.c, x.spec["flow"][:6]
    nodes = [(i if isinstance(i, dict) else {"label": i}) for i in items]
    n, pad, gap, H = len(nodes), 16, 46, 128
    nw = (W - 2 * pad - gap * (n - 1)) / n
    r = x.skin["radius"]
    body = []
    for i, nd in enumerate(nodes):
        nx = pad + i * (nw + gap)
        col = [c["accent"], c["accent2"], c["accent3"], c["ok"]][i % 4]
        body.append(f'<g class="rise" {dl(.15 + i * .28)}>'
                    f'<rect x="{nx:.0f}" y="40" width="{nw:.0f}" height="72" rx="{r}" fill="{c["surface"]}" stroke="{col}" stroke-width="{3 if x.motif == "arcade" else 2}"/>'
                    + x.text(f"{nx + nw / 2:.0f}", 26, f"{i + 1:02d}", 12, col, "mono", "700", anchor="middle")
                    + x.text(f"{nx + nw / 2:.0f}", 72 if nd.get("sub") else 81, clip(nd["label"], int((nw - 12) / 8.6)), 15, c["text"], "mono" if x.motif in ("arcade", "terminal", "blueprint") else "display", "700", anchor="middle")
                    + (x.text(f"{nx + nw / 2:.0f}", 92, clip(nd["sub"], int((nw - 12) / 6.6)), 11.5, c["muted"], "body", anchor="middle") if nd.get("sub") else "")
                    + "</g>")
        if i < n - 1:
            x1, x2 = nx + nw + 4, nx + nw + gap - 4
            d = 0.3 + i * 0.28
            body.append(f'<line class="draw" style="--L:{x2 - x1 - 8:.0f};stroke-dasharray:{x2 - x1 - 8:.0f};animation-delay:{d:.2f}s;animation-duration:.4s" '
                        f'x1="{x1:.0f}" y1="76" x2="{x2 - 8:.0f}" y2="76" stroke="{c["muted"]}" stroke-width="2"/>'
                        f'<path class="pop" style="animation-delay:{d + .35:.2f}s" d="M{x2 - 9:.0f} 69 L{x2:.0f} 76 L{x2 - 9:.0f} 83 Z" fill="{c["muted"]}"/>')
    alt = "Fluxo: " + " → ".join(nd["label"] for nd in nodes)
    return x.doc(H, "Fluxo", alt, "".join(body)), alt


# ---------------------------------------------------------------- terminal

def terminal(x):
    c, lines = x.c, x.spec["terminal"][:12]
    H = 64 + len(lines) * 26
    body = [_window(x, 6, W - 12, H - 12, x.spec.get("project", {}).get("terminal_title", "terminal"), x0=6)]
    t = 0.3
    for i, ln in enumerate(lines):
        y = 66 + i * 26
        if ln.startswith("$ "):
            body.append(x.text(36, y, "$", 14, c["accent"], "mono", "700"))
            s, t = _typed(x, 54, y, ln[2:], 14, c["text"], t, cover=c["surface"])
        elif ln.startswith("# "):
            s, t = _typed(x, 36, y, ln, 14, c["muted"], t, cover=c["surface"])
        elif ln.startswith(("ok ", "✔ ")):
            s, t = _typed(x, 36, y, ln, 14, c["ok"], t, cover=c["surface"])
        elif ln.startswith("! "):
            s, t = _typed(x, 36, y, ln, 14, c["accent3"], t, cover=c["surface"])
        else:
            s, t = _typed(x, 36, y, ln, 14, c["text"], t, cover=c["surface"])
        body.append(s)
        t += 0.12
    cmds = [l[2:] for l in lines if l.startswith("$ ")]
    alt = "Terminal executando: " + (cmds[0] if cmds else lines[0]) + (f" (+{len(lines) - 1} linhas de saída)" if len(lines) > 1 else "")
    return x.doc(H, "Terminal", alt, "".join(body)), alt


# ---------------------------------------------------------------- stack

def stack(x):
    c, items = x.c, x.spec["stack"][:24]
    rows, cx, cy, H0 = [], 8, 4, 36
    parts = []
    for i, s in enumerate(items):
        w = len(s) * 8.0 + 38
        if cx + w > W - 8:
            cx, cy = 8, cy + H0 + 10
        col = [c["accent"], c["accent2"], c["accent3"], c["ok"]][i % 4]
        r = H0 / 2 if x.motif in ("frontend", "harness", "corporate") else (0 if x.motif == "arcade" else 6)
        parts.append(f'<g class="pop" {dl(.1 + i * .05)}><rect x="{cx:.0f}" y="{cy}" width="{w:.0f}" height="{H0}" rx="{r}" fill="{c["surface"]}" stroke="{c["border"]}" stroke-width="{2 if x.motif == "arcade" else 1}"/>'
                     f'<rect x="{cx + 12:.0f}" y="{cy + 14}" width="8" height="8" rx="{0 if x.motif == "arcade" else 4}" fill="{col}"/>'
                     + x.text(f"{cx + 28:.0f}", cy + 23, s, 13, c["text"], "mono") + "</g>")
        cx += w + 10
    H = cy + H0 + 6
    alt = "Stack: " + ", ".join(items)
    return x.doc(H, "Stack", alt, "".join(parts)), alt


# ---------------------------------------------------------------- cards

def cards(x):
    c, items = x.c, x.spec["cards"][:9]
    n = len(items)
    cols = min(3, n)
    gap = 16
    cw = (W - 16 - gap * (cols - 1)) / cols
    cpl = max(16, int((cw - 40) / (7.9 if x.f['body'] == x.f['mono'] else 6.9)))
    wr = [wrap(i.get("desc", ""), cpl, 3) for i in items]
    rowh = []
    for r0 in range(0, n, cols):
        rowh.append(86 + max(len(w) for w in wr[r0:r0 + cols]) * 18)
    r = x.skin["radius"]
    body, y = [], 4
    for i, it in enumerate(items):
        row, col = divmod(i, cols)
        if col == 0 and row > 0:
            y += rowh[row - 1] + gap
        cx = 8 + col * (cw + gap)
        h = rowh[row]
        acc = [c["accent"], c["accent2"], c["accent3"]][i % 3]
        g = (f'<g class="rise" {dl(.1 + i * .1)}><rect x="{cx:.0f}" y="{y}" width="{cw:.0f}" height="{h}" rx="{r}" fill="{c["surface"]}" stroke="{c["border"]}" stroke-width="{2 if x.motif == "arcade" else 1}"/>'
             f'<rect x="{cx + r:.0f}" y="{y}" width="{cw - 2 * r:.0f}" height="4" rx="{2 if r else 0}" fill="{acc}"/>'
             + x.text(f"{cx + 20:.0f}", y + 36, f"{i + 1:02d}", 12, acc, "mono", "700")
             + x.text(f"{cx + 20:.0f}", y + 62, clip(it["title"], int((cw - 36) / 9.4)), 16.5, c["text"], "mono" if x.motif in ("arcade", "terminal", "blueprint") else "display", "700"))
        for li, l in enumerate(wr[i]):
            g += x.text(f"{cx + 20:.0f}", y + 88 + li * 18, l, 13, c["muted"])
        body.append(g + "</g>")
    H = y + rowh[-1] + 6
    alt = "Cards: " + "; ".join(i["title"] for i in items)
    return x.doc(H, "Cards", alt, "".join(body)), alt
