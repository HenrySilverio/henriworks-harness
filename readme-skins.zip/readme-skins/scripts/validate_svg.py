#!/usr/bin/env python3
"""Valida SVGs de README. Uso: validate_svg.py arquivo.svg [...]  (exit 1 se houver erro)."""
import re
import sys
import xml.etree.ElementTree as ET

MAX_KB = 150


def validate(path):
    errs, warns = [], []
    raw = open(path, encoding="utf-8").read()
    try:
        root = ET.fromstring(raw.encode("utf-8"))
    except ET.ParseError as e:
        return [f"XML invalido: {e}"], []
    ns = "{http://www.w3.org/2000/svg}"
    if root.tag != ns + "svg":
        errs.append("raiz nao e <svg> com xmlns http://www.w3.org/2000/svg")
    for a in ("width", "height", "viewBox"):
        if a not in root.attrib:
            errs.append(f"<svg> sem {a}")
    if root.attrib.get("role") != "img":
        errs.append('<svg> sem role="img"')
    if root.find(ns + "title") is None:
        errs.append("sem <title> (acessibilidade)")
    tags = {el.tag.replace(ns, "") for el in root.iter()}
    for bad in ("script", "foreignObject"):
        if bad in tags:
            errs.append(f"<{bad}> proibido")
    for el in root.iter():
        for k, v in el.attrib.items():
            if k.lower().startswith("on"):
                errs.append(f"atributo {k} proibido")
            if k.endswith("href") and not v.startswith("#"):
                errs.append(f"referencia externa em {k}={v[:40]}")
    if re.search(r"@import|@font-face|url\(\s*['\"]?https?:", raw):
        errs.append("recurso externo (@import/@font-face/url http)")
    if re.search(r"https?://(?!www\.w3\.org)", raw):
        errs.append("URL http(s) no arquivo (so o xmlns do W3C e permitido)")
    css = "".join(el.text or "" for el in root.iter(ns + "style"))
    if "animation" in css:
        if "prefers-reduced-motion" not in css:
            errs.append("tem animacao mas falta bloco prefers-reduced-motion")
        loops = len(re.findall(r"animation:[^;}]*infinite", css))
        if loops > 1:
            errs.append(f"{loops} regras de animacao infinita (maximo 1)")
    for g in root.iter():
        if g.attrib.get("class") and "transform" in g.attrib and re.search(r"\b(rise|pop|type|draw)\b", g.attrib["class"]):
            errs.append("transform como atributo em elemento animado (o CSS sobrescreve)")
    kb = len(raw.encode()) / 1024
    if kb > MAX_KB:
        warns.append(f"{kb:.0f} KB (acima de {MAX_KB} KB)")
    return errs, warns


if __name__ == "__main__":
    bad = 0
    for f in sys.argv[1:]:
        e, w = validate(f)
        print(("FAIL " if e else "ok   ") + f)
        for x in e:
            print("   erro:", x)
        for x in w:
            print("   aviso:", x)
        bad += bool(e)
    sys.exit(1 if bad else 0)
