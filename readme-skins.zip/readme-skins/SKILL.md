---
name: readme-skins
description: Cria README.md visual e animado com "skins" temáticas (arcade, frontend, AI harness, terminal, blueprint, corporate) - banner, títulos de seção, indicadores, fluxo, terminal digitando, stack e cards em SVG animado gerados localmente, no estilo dos templates do GitSkins. Use SEMPRE que o usuário pedir README bonito, colorido, animado, com capa/banner/badges, "README com cara de produto", README arcade, README para repo de harness/agents/skills/hooks de IA, README de MFE/frontend/BFF, perfil do GitHub estilizado ou "tipo gitskins" - mesmo que não diga "skin". Não usa serviços externos (shields.io, github-readme-stats, typing-svg), então serve para repositório corporativo/privado. Para página HTML animada ou SharePoint use html-motion; para README sem apelo visual, escreva direto.
---

# readme-skins

Gera os elementos visuais de um README (SVG animado, versionado no próprio repo) e compõe o
`README.md` em volta deles. Uma **skin** é um conjunto de tokens (paleta, fontes, motivo) em
`skins/*.json`; os mesmos componentes ganham a cara da skin.

Referência de estilo: os templates do GitSkins (Arcade Cabinet, Terminal, Retro TV, Character Sheet...).
A diferença deliberada: o GitSkins serve imagens dinâmicas a partir de dados do GitHub; aqui tudo é
**estático, local e sem rede**, porque em repo corporativo isso quebra no proxy, vaza nome/metadado
do repo na URL de terceiros e cria dependência externa num documento que precisa durar.

## Fluxo

1. **Levante dados reais do repo** antes de desenhar. Leia o README atual, `package.json`/`pom.xml`,
   a árvore de pastas. Números de indicadores (agents, skills, MFEs, cobertura...) vêm de contagem
   real (`ls`, `find | wc -l`) ou do usuário. Sem fonte, **omita `stats`**: número inventado em README
   é pior que ausência, e é o primeiro que alguém confere.
2. **Escolha a skin** pelo tipo de projeto (tabela abaixo). Se estiver realmente ambíguo, pergunte uma
   vez só. Detalhes e backlog: `references/skins.md`.
3. **Escreva o spec** (`spec.json`): schema e exemplos em `references/spec.md`. Taglines até ~110
   caracteres; nome até ~40.
4. **Gere**:
   ```bash
   SK=<caminho desta skill>
   python $SK/scripts/build_readme.py spec.json --out docs/assets
   ```
   Escreve os SVGs, valida cada um (falha com exit 1) e cria `docs/assets/snippets.md` com o
   markdown pronto de cada imagem (`<picture>` para skins claro/escuro, `<img>` para as demais).
5. **Olhe o resultado.** O validador não enxerga texto vazando ou sobreposto:
   ```bash
   python $SK/scripts/render_apng.py docs/assets/banner.svg /tmp/banner.png --still
   python $SK/scripts/render_apng.py docs/assets/banner.svg /tmp/meio.png --at 0.8   # quadro no meio da animação
   ```
   Abra o PNG (`view`) e critique: truncou com "…"? colidiu? Ajuste o spec e gere de novo.
6. **Componha o `README.md`** com `references/readme-structure.md` (esqueleto por tipo de projeto) e
   os snippets. Instruções, comandos e links ficam em **markdown real**.
7. **APNG (opcional)**, só se o README for para Azure DevOps/GitLab ou o usuário pedir:
   ```bash
   python $SK/scripts/render_apng.py docs/assets/banner.svg docs/assets/banner.png --bg '<bg da skin>' --fps 15
   ```
   Veja `references/platforms.md` para a matriz e o orçamento de tamanho.
8. **Entregue** README + `docs/assets/` (em `/mnt/user-data/outputs/<repo>/`), apresentando o
   README primeiro. Diga em uma frase qual skin escolheu e por quê.

## Skins

| Skin | Use para | Marca visual |
|---|---|---|
| `arcade` | jogos, CLIs com personalidade, hackathon, dev experience | título em fonte pixel própria, HUD "1UP", scanlines, sprite |
| `frontend` | MFE, design system, libs de componentes, portais, apps Angular/React | gradiente, janela de navegador, chips de stack |
| `harness` | agents, skills, hooks, prompts, instructions, MCP, tooling de Copilot/Claude | grafo de nós em volta de um hub com pulso |
| `terminal` | CLIs, infra, DevOps, automação | janela de terminal com comando digitando e cursor |
| `blueprint` | arquitetura, BFF/backend, contratos OpenAPI, ADRs | planta técnica: grade, cotas, carimbo de revisão |
| `corporate` | repos oficiais de squad/tribo, gestão e auditoria | sóbrio; `--accent` aceita a cor da marca |

Componentes (todos 900 px de largura, funcionam com qualquer skin): `banner`, `section` (título de
seção ou divisor), `stats`, `flow`, `terminal`, `stack`, `cards`.

## Regras e por quê

- **Nada externo** (shields.io, github-readme-stats, readme-typing-svg, capsule-render, fontes web,
  imagens remotas). Proxy corporativo bloqueia em silêncio e a URL expõe o nome do repo a terceiros.
  Se o usuário pedir badge de CI/versão, use o badge nativo da própria plataforma do repo.
- **Informação essencial nunca só dentro da imagem.** Imagem não é copiável, buscável nem lida por
  todos os leitores. Comando de instalação, links e descrição ficam em markdown; o SVG é a embalagem.
- **`alt` descritivo** em toda imagem (o `snippets.md` já gera um; revise). Descreve o conteúdo, não
  "banner animado".
- **Contenção.** README é documentação, não vitrine: banner + 3 a 5 componentes no máximo. Animação
  é só entrada, mais um único elemento infinito sutil por arquivo (cursor/pulso/"press start").
  Validador cobra: `prefers-reduced-motion`, estado final = estilo base, no máximo 1 loop infinito.
- **Skins de modo único (escuras) pintam o próprio fundo** em todo componente. Sem isso, texto claro
  sobre fundo transparente some no tema claro do GitHub. Skins com `light`+`dark` geram dois arquivos
  e o snippet usa `<picture>`.
- **Orçamento:** SVG até ~150 KB (o gerador fica em 3-8 KB); APNG até ~500 KB.
- **Cor da marca:** `--accent '#rrggbb'` troca o acento de qualquer skin. Não presuma a paleta de
  uma empresa; pergunte ou use a skin `corporate` com o acento que o usuário informar.

## Estendendo

- **Nova skin com motivo existente:** copie um `skins/*.json`, troque id/nome/paleta. Funciona na hora.
- **Novo motivo** (ex.: `retro-tv`, `metro`): crie `banner_<motivo>` em `scripts/components.py`,
  registre em `BANNERS`, e trate o motivo nas ramificações de `section`/`stats`/`flow` se precisar de
  forma própria. Rode o build, olhe o PNG, só então documente em `references/skins.md`.

## Referências

| Arquivo | Quando ler |
|---|---|
| `references/spec.md` | Ao escrever o `spec.json` (campos, limites, exemplos por skin) |
| `references/readme-structure.md` | Ao compor o README.md (esqueleto por tipo de projeto) |
| `references/platforms.md` | GitHub vs GitLab vs Azure DevOps, SVG vs APNG, orçamento de tamanho |
| `references/skins.md` | Catálogo detalhado, quando usar cada uma, backlog de motivos |
