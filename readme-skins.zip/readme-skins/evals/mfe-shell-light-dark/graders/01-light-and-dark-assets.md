---
type: llm
focus: trace
weight: 1
---

The generated assets include both a -light and a -dark SVG for the banner, and README.md references them through a <picture> element with prefers-color-scheme: dark.
