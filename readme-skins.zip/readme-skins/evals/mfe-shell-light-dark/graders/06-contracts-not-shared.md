---
type: llm
focus: trace
weight: 1
---

If the README mentions API contracts or OpenAPI, it describes them as owned per layer (MFE and BFF separately) and does not recommend a single shared contract file or package between MFE and BFF.
