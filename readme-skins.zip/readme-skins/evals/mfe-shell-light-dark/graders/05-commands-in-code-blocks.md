---
type: llm
focus: trace
weight: 1
---

README.md shows the npm commands (start, build, test) in fenced code blocks, not only in images.
