---
type: llm
focus: trace
weight: 1
---

README.md contains no image or badge URL pointing to an external host; every image path is relative.
