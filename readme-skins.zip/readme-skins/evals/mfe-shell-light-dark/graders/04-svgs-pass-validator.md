---
type: llm
focus: trace
weight: 1
---

Every generated SVG passes validate_svg.py.
