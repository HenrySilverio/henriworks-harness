---
type: llm
focus: trace
weight: 1
---

Stack or technology chips/text shown reflect the input package.json (Angular 21, Native Federation, NgRx Signals); no technology absent from the input is presented as part of the stack.
