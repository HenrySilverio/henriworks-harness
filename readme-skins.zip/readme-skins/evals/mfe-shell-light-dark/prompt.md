---
tags: [readme-skins]
max_turns: 30
timeout_seconds: 900
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

Monta um README com cara de frontend moderno pro shell do nosso MFE (Angular 21 + native federation + NgRx Signals, com um BFF Java por trás). Tem que ficar bom no tema claro e no escuro do GitHub.

Input files: files/package.json
