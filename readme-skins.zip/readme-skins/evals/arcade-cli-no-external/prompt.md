---
tags: [readme-skins]
max_turns: 30
timeout_seconds: 900
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

Quero um README estilo arcade pra nossa CLI interna de scaffolding (dev-arcade). Nao pode depender de nenhum servico externo, nosso proxy bloqueia tudo. Pode ser animado.

Input files: files/package.json
