---
type: llm
focus: trace
weight: 1
---

The run rendered at least one SVG to PNG and inspected it before delivering.
