---
type: llm
focus: trace
weight: 1
---

The generated banner uses the arcade skin: pixel-block title built from rects (no web font), and the README renders it.
