---
type: llm
focus: trace
weight: 1
---

Neither README.md nor any generated SVG references an external URL (apart from the W3C xmlns), no web fonts, no remote images, no external badge services.
