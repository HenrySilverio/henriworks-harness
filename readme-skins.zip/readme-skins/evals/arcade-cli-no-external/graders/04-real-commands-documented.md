---
type: llm
focus: trace
weight: 1
---

README.md documents commands that exist in the input package.json (e.g., test via vitest, lint via eslint, the dev-arcade bin) and does not invent commands that are absent.
