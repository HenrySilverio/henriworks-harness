---
type: llm
focus: trace
weight: 1
---

Each generated SVG contains a prefers-reduced-motion block disabling animation and has at most one infinite animation rule.
