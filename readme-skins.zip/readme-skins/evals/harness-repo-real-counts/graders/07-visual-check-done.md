---
type: llm
focus: trace
weight: 1
---

The run rendered at least one SVG to PNG and looked at it (or otherwise checked the layout) before delivering.
