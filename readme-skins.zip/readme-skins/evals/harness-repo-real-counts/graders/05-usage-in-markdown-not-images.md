---
type: llm
focus: trace
weight: 1
---

README.md has quick-start or usage instructions as real markdown text or fenced code blocks, not only inside an image.
