---
type: llm
focus: trace
weight: 1
---

Every image reference in README.md has a non-empty, descriptive alt attribute (not just 'banner' or 'animation').
