---
type: llm
focus: trace
weight: 1
---

README.md contains no image or badge URL pointing to an external host (no shields.io, github-readme-stats, readme-typing-svg, capsule-render, or any http/https image); every image path is relative.
