---
type: llm
focus: trace
weight: 1
---

Any counts of agents, skills, hooks or prompts displayed in the README or SVGs match the input repo exactly (3 agents, 2 skills, 1 hook, 4 prompts); no invented numbers are shown.
