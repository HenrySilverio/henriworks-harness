---
type: llm
focus: trace
weight: 1
---

Every generated SVG passes validate_svg.py (xmlns, role=img, title, prefers-reduced-motion block, no external references, at most one infinite animation).
