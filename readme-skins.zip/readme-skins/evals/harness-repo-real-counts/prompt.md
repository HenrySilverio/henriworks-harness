---
tags: [readme-skins]
max_turns: 30
timeout_seconds: 900
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

Preciso de um README bonito e animado pro repo do nosso harness de IA (agents, skills, hooks e prompts do Copilot no VS Code). Quero pegada de produto, bem colorido, tipo os templates do gitskins. Monta o README e os assets.

Input files: files/
