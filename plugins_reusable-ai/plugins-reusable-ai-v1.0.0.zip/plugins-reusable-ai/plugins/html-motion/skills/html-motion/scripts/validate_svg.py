#!/usr/bin/env python3
"""Check that an animated SVG is safe to embed in a README (GitHub, GitLab, Azure DevOps, Bitbucket).

    python validate_svg.py file.svg [more.svg ...]

Markdown renderers load SVG through <img> (or strip it entirely): scripts never run, external
resources never load, and some platforms sanitize or refuse SVG. This catches what will break.
"""
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

def check(path: Path):
    errs, warns = [], []
    raw = path.read_text(encoding="utf-8")
    try:
        root = ET.fromstring(raw)
    except ET.ParseError as e:
        return [f"invalid XML: {e}"], []
    if not root.tag.endswith("svg"):
        errs.append("root element is not <svg>")
    if 'xmlns="http://www.w3.org/2000/svg"' not in raw:
        errs.append('missing xmlns="http://www.w3.org/2000/svg" (img-loaded SVG will not render)')
    if re.search(r"<script\b", raw, re.I):
        errs.append("<script> never runs in README images and gets the file sanitized/blocked")
    if re.search(r"\son[a-z]+\s*=", raw, re.I):
        errs.append("on* event attributes are stripped/blocked")
    if re.search(r"<foreignObject\b", raw, re.I):
        errs.append("<foreignObject> (HTML inside SVG) is unreliable in img context and sanitized by several platforms")
    if re.search(r'(href|xlink:href)\s*=\s*["\'](https?:)?//', raw, re.I):
        errs.append("external href (images/fonts/use) will not load inside <img>")
    if re.search(r"@import|@font-face|url\(\s*['\"]?(https?:)?//", raw, re.I):
        errs.append("@import/@font-face/external url(): use a system font stack instead")
    if re.search(r"<image\b[^>]*href=\"data:image/(png|jpe?g)", raw, re.I) and len(raw) > 300_000:
        warns.append("large embedded raster: prefer vector shapes")
    if "viewBox" not in raw:
        warns.append("no viewBox: will not scale down on narrow screens")
    if not re.search(r"\bwidth=", raw):
        warns.append("no width attribute: some renderers size it to 100% or 0")
    animated = re.search(r"@keyframes|<animate|<animateTransform|<animateMotion|<set\b", raw)
    if not animated:
        warns.append("no animation found (@keyframes or SMIL)")
    if "@keyframes" in raw and "prefers-reduced-motion" not in raw:
        errs.append("CSS animation without @media (prefers-reduced-motion: reduce) fallback")
    if re.search(r"<animate|<animateTransform|<animateMotion", raw) and "prefers-reduced-motion" not in raw:
        warns.append("SMIL animation ignores prefers-reduced-motion: prefer CSS @keyframes")
    if "<title" not in raw:
        warns.append("no <title>: add one (+ role=\"img\") for screen readers")
    if re.search(r"animation\s*:[^;]*infinite", raw):
        n = len(re.findall(r"animation\s*:[^;]*infinite", raw))
        if n > 1:
            warns.append(f"{n} infinite loops: keep at most one subtle loop (distracting in docs)")
    size = path.stat().st_size
    if size > 500_000:
        warns.append(f"{size/1024:.0f} KB: README images above ~500 KB load slowly")
    if re.search(r"<style>[\s\S]*?(\w|-)*\s*:\s*var\(--", raw) and "@media (prefers-color-scheme" not in raw:
        warns.append("uses CSS variables but no dark-mode override")
    return errs, warns

def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    failed = False
    for f in sys.argv[1:]:
        e, w = check(Path(f))
        for x in w: print(f"WARN  {f}: {x}")
        for x in e: print(f"ERROR {f}: {x}")
        print(f"[validate_svg] {f}: {len(e)} error(s), {len(w)} warning(s)")
        failed |= bool(e)
    sys.exit(1 if failed else 0)

if __name__ == "__main__":
    main()
