#!/usr/bin/env python3
"""Validate a built page (file or split output folder) before delivery.

    python validate_page.py OUT_DIR/index.html [--mode split|single] [--run] [--screenshot shot.png]

Static checks (always):
  ERROR  external script/style/font/image (corporate network + CSP will block them)
  ERROR  split mode: inline <script> body, on* handler attributes, javascript: URLs (CSP)
  ERROR  eval / new Function / setTimeout("string") in shipped JS
  ERROR  .aspx containing '<%' or runat=server
  WARN   no prefers-reduced-motion handling detected
  WARN   CSS hides content by default (opacity:0 / visibility:hidden) outside a JS-gated class
  WARN   total size > 2 MB
--run (needs playwright): loads the page in Chromium (normal + reduced motion),
  fails on JS errors, checks that main text is visible after animations settle,
  and with JS disabled checks that content is still visible (progressive enhancement).
"""
import argparse
import re
import sys
from pathlib import Path

errors, warns = [], []


def err(m): errors.append(m)
def warn(m): warns.append(m)


EXTERNAL = re.compile(r'<(script|link|img|iframe|source|video|audio)\b[^>]*\b(src|href)=["\'](https?:)?//', re.I)
CSS_EXTERNAL = re.compile(r'@import\s+url\(["\']?(https?:)?//|url\(["\']?(https?:)?//', re.I)


def static_checks(page: Path, mode: str):
    root = page.parent
    html = page.read_text(encoding="utf-8")
    js_files = [p for p in root.rglob("*.js")]
    css_files = [p for p in root.rglob("*.css")]
    blobs = [html] + [p.read_text(encoding="utf-8", errors="ignore") for p in js_files + css_files]

    for m in EXTERNAL.finditer(html):
        tag = html[m.start():html.find(">", m.start()) + 1]
        if m.group(1).lower() == "link" and 'rel="stylesheet"' not in tag and "rel='stylesheet'" not in tag and "icon" not in tag:
            continue
        err(f"external resource: {tag[:120]}")
    for p in css_files:
        if CSS_EXTERNAL.search(p.read_text(encoding="utf-8", errors="ignore")):
            err(f"external url()/@import in {p.name}")
    if CSS_EXTERNAL.search(html):
        err("external url()/@import inside <style>")

    if mode == "split":
        if re.search(r"<script(?![^>]*\bsrc=)[^>]*>\s*\S", html, re.I):
            err("inline <script> body (blocked by SharePoint Online CSP)")
        if re.search(r"\son[a-z]+\s*=\s*[\"']", html, re.I):
            err("inline event handler attribute (onclick=... etc.) — blocked by CSP; use addEventListener in app.js")
        if re.search(r"href=[\"']\s*javascript:", html, re.I):
            err("javascript: URL — blocked by CSP")

    app_sources = [p for p in js_files if p.parent.name != "vendor"]
    for p in app_sources:
        s = p.read_text(encoding="utf-8", errors="ignore")
        if re.search(r"\beval\s*\(|new\s+Function\s*\(|set(Timeout|Interval)\s*\(\s*[\"'`]", s):
            err(f"eval-like construct in {p.name}")
    if mode == "single":
        inline = "\n".join(re.findall(r"<script[^>]*>(.*?)</script>", html, re.S | re.I))
        app_part = inline.split("DOMContentLoaded")[-1] if "DOMContentLoaded" in inline else ""
        if re.search(r"\beval\s*\(|new\s+Function\s*\(", app_part):
            err("eval-like construct in app code")

    if page.suffix == ".aspx" and ("<%" in html or "runat=\"server\"" in html.lower()):
        err(".aspx contains '<%' or runat=server")

    joined = "\n".join(blobs)
    if "prefers-reduced-motion" not in joined and "Motion.reducedMotion" not in joined and "motion-lite" not in joined:
        warn("no prefers-reduced-motion handling found (gsap engine: use gsap.matchMedia)")
    css_all = "\n".join(p.read_text(encoding="utf-8", errors="ignore") for p in css_files) + "\n".join(re.findall(r"<style[^>]*>(.*?)</style>", html, re.S | re.I))
    for rule in re.finditer(r"([^{}]+)\{([^{}]*)\}", css_all):
        sel, body = rule.group(1).strip(), rule.group(2)
        if re.search(r"opacity\s*:\s*0\s*[;}]|visibility\s*:\s*hidden", body + "}") and ".motion-ready" not in sel and "@" not in sel and "[aria-hidden" not in sel and "sr-only" not in sel:
            warn(f"CSS hides '{sel[:60]}' without .motion-ready gate — content invisible if JS is blocked")

    size = sum(p.stat().st_size for p in root.rglob("*") if p.is_file()) if mode == "split" else page.stat().st_size
    if size > 2 * 1024 * 1024:
        warn(f"size {size/1024/1024:.1f} MB > 2 MB")
    if '<meta name="viewport"' not in html:
        warn("missing <meta name=\"viewport\">")
    if not re.search(r"<html[^>]*\blang=", html, re.I):
        warn("missing <html lang=...>")


def run_checks(page: Path, screenshot: str | None):
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        warn("playwright not installed: skipped --run")
        return
    url = page.resolve().as_uri()
    with sync_playwright() as p:
        b = p.chromium.launch()
        for label, kw in (("normal", {}), ("reduced-motion", {"reduced_motion": "reduce"}), ("js-disabled", {"java_script_enabled": False})):
            ctx = b.new_context(viewport={"width": 1280, "height": 800}, **kw)
            pg = ctx.new_page()
            js_errs = []
            pg.on("pageerror", lambda e: js_errs.append(str(e)))
            pg.on("console", lambda m: m.type == "error" and js_errs.append(m.text))
            pg.goto(url)
            pg.wait_for_timeout(2500)
            # scroll through the page so scroll-triggered reveals fire, then back up
            h = pg.evaluate("document.documentElement.scrollHeight")
            for y in range(0, h, 400):
                pg.evaluate(f"window.scrollTo(0,{y})")
                pg.wait_for_timeout(60)
            pg.wait_for_timeout(1500)
            hidden = pg.evaluate("""() => [...document.querySelectorAll('h1,h2,h3,p,li,a,button')]
                .filter(e => e.textContent.trim() && !e.closest('[aria-hidden="true"]'))
                .filter(e => { let n=e; while(n && n!==document.documentElement){ const cs=getComputedStyle(n);
                   if(cs.visibility==='hidden'||cs.display==='none'||parseFloat(cs.opacity)<0.05) return true; n=n.parentElement;} return false; })
                .map(e => e.tagName+': '+e.textContent.trim().slice(0,40))""")
            for e in js_errs:
                err(f"[{label}] JS error: {e}")
            if hidden:
                (err if label != "normal" else warn)(f"[{label}] {len(hidden)} text element(s) still hidden after settle, e.g. {hidden[:3]}")
            if screenshot and label == "normal":
                pg.evaluate("window.scrollTo(0,0)")
                pg.wait_for_timeout(300)
                pg.screenshot(path=screenshot, full_page=True)
            ctx.close()
        b.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("page", type=Path)
    ap.add_argument("--mode", choices=["split", "single"], default=None)
    ap.add_argument("--run", action="store_true")
    ap.add_argument("--screenshot")
    a = ap.parse_args()
    mode = a.mode or ("split" if (a.page.parent / "vendor").exists() else "single")
    static_checks(a.page, mode)
    if a.run:
        run_checks(a.page, a.screenshot)
    for w in warns:
        print("WARN ", w)
    for e in errors:
        print("ERROR", e)
    print(f"[validate] {a.page} mode={mode}: {len(errors)} error(s), {len(warns)} warning(s)")
    sys.exit(1 if errors else 0)


if __name__ == "__main__":
    main()
