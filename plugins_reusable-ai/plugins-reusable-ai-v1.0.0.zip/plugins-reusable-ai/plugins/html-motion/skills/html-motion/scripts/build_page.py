#!/usr/bin/env python3
"""Build an animated HTML page from a source folder.

Source folder layout (always authored split, never inline JS):
    index.html   must contain the marker  <!-- @engine -->  where engine scripts go
    style.css    optional, referenced by <link rel="stylesheet" href="style.css">
    app.js       your animation code, referenced by <script src="app.js" defer></script>
    img/...      optional local assets

Modes:
    split   index.(html|aspx) + vendor/*.js + app.js + style.css, ZERO inline <script>.
            Use for SharePoint Online (CSP blocks inline script) and any CSP-protected host.
    single  one self-contained file: CSS, engine, app and local images inlined.
            Use for chat preview, Cowork, e-mail attachment, hosts without CSP.

Engines:
    native  assets/motion-lite.js (zero dependency, MIT)
    gsap    GSAP UMD bundles pinned to GSAP_VERSION; fetched via `npm pack` or --gsap-dir

Usage:
    python build_page.py SRC_DIR OUT_DIR --engine native|gsap [--plugins ScrollTrigger,SplitText]
                         [--mode split|single] [--ext html|aspx] [--gsap-dir PATH]
"""
import argparse
import base64
import mimetypes
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path

GSAP_VERSION = "3.15.0"  # pinned; bump deliberately, never to a release younger than 14 days
SKILL_DIR = Path(__file__).resolve().parent.parent
MOTION_LITE = SKILL_DIR / "assets" / "motion-lite.js"
GSAP_PLUGINS = {
    "ScrollTrigger", "ScrollToPlugin", "SplitText", "DrawSVGPlugin", "Flip", "MotionPathPlugin",
    "TextPlugin", "CustomEase", "ScrambleTextPlugin", "MorphSVGPlugin", "Observer",
}
MARKER = "<!-- @engine -->"


def fetch_gsap(cache: Path) -> Path:
    dist = cache / f"gsap-{GSAP_VERSION}" / "package" / "dist"
    if dist.exists():
        return dist
    cache.mkdir(parents=True, exist_ok=True)
    print(f"[build] npm pack gsap@{GSAP_VERSION} ...")
    r = subprocess.run(["npm", "pack", f"gsap@{GSAP_VERSION}", "--silent"], cwd=cache, capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit("[build] npm pack failed. Corporate network? Use --gsap-dir pointing to node_modules/gsap/dist "
                 "(e.g. installed from the internal Nexus/Artifactory).\n" + r.stderr)
    tgz = cache / r.stdout.strip().splitlines()[-1]
    target = cache / f"gsap-{GSAP_VERSION}"
    with tarfile.open(tgz) as t:
        t.extractall(target, filter="data")
    return dist


def engine_files(engine: str, plugins: list[str], gsap_dir: str | None) -> list[tuple[str, str]]:
    """Return [(filename, js_source)] in load order."""
    if engine == "native":
        return [("motion-lite.js", MOTION_LITE.read_text(encoding="utf-8"))]
    unknown = [p for p in plugins if p not in GSAP_PLUGINS]
    if unknown:
        sys.exit(f"[build] unknown GSAP plugin(s): {unknown}. Valid: {sorted(GSAP_PLUGINS)}")
    dist = Path(gsap_dir) if gsap_dir else fetch_gsap(Path(tempfile.gettempdir()) / "html-motion-cache")
    out = []
    for name in ["gsap"] + plugins:
        f = dist / f"{name}.min.js"
        if not f.exists():
            sys.exit(f"[build] missing {f}")
        out.append((f"{name}.min.js", f.read_text(encoding="utf-8")))
    return out


def safe_inline_js(js: str) -> str:
    # A literal "</script" inside inlined JS would terminate the tag early.
    return js.replace("</script", "<\\/script")


def data_uri(path: Path) -> str:
    mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    return f"data:{mime};base64,{base64.b64encode(path.read_bytes()).decode()}"


def is_local(ref: str) -> bool:
    return not re.match(r"^(https?:)?//|^data:|^#|^mailto:|^tel:", ref)


def build(src: Path, out: Path, engine: str, plugins: list[str], mode: str, ext: str, gsap_dir: str | None):
    html = (src / "index.html").read_text(encoding="utf-8")
    if MARKER not in html:
        sys.exit(f"[build] {src/'index.html'} has no {MARKER} marker")
    if re.search(r"<script(?![^>]*\bsrc=)[^>]*>\s*\S", html, re.I):
        sys.exit("[build] index.html has inline <script> content. Move it to app.js (CSP: SharePoint blocks inline script).")
    if ext == "aspx" and ("<%" in html or 'runat="server"' in html.lower()):
        sys.exit("[build] '<%' or runat=server found: invalid in an .aspx served by SharePoint.")

    engines = engine_files(engine, plugins, gsap_dir)
    out.mkdir(parents=True, exist_ok=True)

    if mode == "split":
        vendor = out / "vendor"
        vendor.mkdir(exist_ok=True)
        tags = []
        for name, js in engines:
            (vendor / name).write_text(js, encoding="utf-8")
            tags.append(f'<script src="vendor/{name}" defer></script>')
        html = html.replace(MARKER, "\n  ".join(tags))
        for item in src.iterdir():
            if item.name == "index.html":
                continue
            dest = out / item.name
            if item.is_dir():
                shutil.copytree(item, dest, dirs_exist_ok=True)
            else:
                shutil.copy2(item, dest)
    else:
        tags = [f"<script>/* {name} */\n{safe_inline_js(js)}\n</script>" for name, js in engines]
        html = html.replace(MARKER, "\n".join(tags))

        def inline_css(m):
            href = m.group(1)
            p = src / href
            if not is_local(href) or not p.exists():
                return m.group(0)
            css = p.read_text(encoding="utf-8")
            css = re.sub(r"url\((['\"]?)([^)'\"]+)\1\)",
                         lambda u: f"url({data_uri(p.parent / u.group(2))})" if is_local(u.group(2)) and (p.parent / u.group(2)).exists() else u.group(0), css)
            return f"<style>\n{css}\n</style>"

        def inline_js(m):
            ref = m.group(1)
            p = src / ref
            if not is_local(ref) or not p.exists():
                return m.group(0)
            # defer is meaningless inline; wrap so it still runs after parsing
            body = safe_inline_js(p.read_text(encoding="utf-8"))
            return f"<script>\ndocument.addEventListener('DOMContentLoaded', function () {{\n{body}\n}});\n</script>"

        def inline_img(m):
            ref = m.group(2)
            p = src / ref
            return f'{m.group(1)}"{data_uri(p)}"' if is_local(ref) and p.exists() else m.group(0)

        html = re.sub(r'<link[^>]+rel=["\']stylesheet["\'][^>]*href=["\']([^"\']+)["\'][^>]*>', inline_css, html, flags=re.I)
        html = re.sub(r'<script[^>]+src=["\']([^"\']+)["\'][^>]*>\s*</script>', inline_js, html, flags=re.I)
        html = re.sub(r'(<img[^>]+src=)["\']([^"\']+)["\']', inline_img, html, flags=re.I)

    target = out / f"index.{ext}"
    target.write_text(html, encoding="utf-8")
    total = sum(f.stat().st_size for f in out.rglob("*") if f.is_file())
    print(f"[build] {mode}/{engine} -> {target} ({total/1024:.1f} KB total)")
    return target


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("src", type=Path)
    ap.add_argument("out", type=Path)
    ap.add_argument("--engine", choices=["native", "gsap"], required=True)
    ap.add_argument("--plugins", default="", help="GSAP plugins, comma separated (gsap engine only)")
    ap.add_argument("--mode", choices=["split", "single"], default="split")
    ap.add_argument("--ext", choices=["html", "aspx"], default="html")
    ap.add_argument("--gsap-dir", help="local gsap/dist folder (offline / internal registry)")
    a = ap.parse_args()
    plugins = [p.strip() for p in a.plugins.split(",") if p.strip()]
    if plugins and a.engine != "gsap":
        sys.exit("[build] --plugins only applies to --engine gsap")
    build(a.src, a.out, a.engine, plugins, a.mode, a.ext, a.gsap_dir)


if __name__ == "__main__":
    main()
