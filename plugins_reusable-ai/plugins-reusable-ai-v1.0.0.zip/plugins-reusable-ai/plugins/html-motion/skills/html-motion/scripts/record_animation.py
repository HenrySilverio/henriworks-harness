#!/usr/bin/env python3
"""Render an animated SVG (or HTML page) into an animated PNG (APNG) or GIF, frame-exact.

    python record_animation.py banner.svg banner.png [--duration 3.5] [--fps 30] [--scale 2]
                               [--format apng|gif] [--bg transparent|#ffffff] [--loop 0] [--dark]

Why APNG by default: it is a .png, so every markdown sanitizer (Azure DevOps, Bitbucket, GitLab,
GitHub) treats it as a plain image, every modern browser animates it, and it keeps 24-bit color + alpha.
GIF is 256 colors with 1-bit alpha: use only when a consumer cannot show APNG.

Frames are captured by pausing every CSS animation (document.getAnimations) and SVG SMIL clock and
seeking them, so the output is deterministic, not a screen recording.
"""
import argparse
import io
import sys
from pathlib import Path

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src", type=Path)
    ap.add_argument("out", type=Path)
    ap.add_argument("--duration", type=float, default=None, help="seconds; default = end of the longest finite animation + 0.6s hold")
    ap.add_argument("--fps", type=int, default=24)
    ap.add_argument("--scale", type=float, default=1.5, help="device pixel ratio: 1 = smallest, 1.5 = default balance, 2 = retina-crisp (~1.8x the size of 1.5)")
    ap.add_argument("--format", choices=["apng", "gif"], default=None)
    ap.add_argument("--bg", default="transparent")
    ap.add_argument("--loop", type=int, default=1, help="1 = play once and rest on the final frame (default, best for docs); 0 = forever")
    ap.add_argument("--dark", action="store_true", help="render with prefers-color-scheme: dark")
    a = ap.parse_args()
    fmt = a.format or ("gif" if a.out.suffix.lower() == ".gif" else "apng")

    from playwright.sync_api import sync_playwright
    from PIL import Image

    svg = a.src.read_text(encoding="utf-8")
    is_svg = a.src.suffix.lower() == ".svg"
    with sync_playwright() as p:
        b = p.chromium.launch()
        ctx = b.new_context(device_scale_factor=a.scale, color_scheme="dark" if a.dark else "light")
        pg = ctx.new_page()
        bg = "transparent" if a.bg == "transparent" else a.bg
        if is_svg:
            pg.set_content(f"<!doctype html><html><body style='margin:0;background:{bg}'>{svg}</body></html>")
            el = pg.locator("svg").first
        else:
            pg.goto(a.src.resolve().as_uri())
            el = pg.locator("body")
        pg.wait_for_timeout(50)
        # Freeze all clocks at t=0
        total = pg.evaluate("""() => {
          const anims = document.getAnimations();
          anims.forEach(x => x.pause());
          document.querySelectorAll('svg').forEach(s => { try { s.pauseAnimations(); s.setCurrentTime(0); } catch(e){} });
          // Infinite decorative loops are ignored: the clip ends when the last finite animation ends.
          let end = 0, loopEnd = 0;
          anims.forEach(x => { const t = x.effect.getComputedTiming();
            if (Number.isFinite(t.endTime)) end = Math.max(end, t.endTime);
            else loopEnd = Math.max(loopEnd, (t.delay||0) + (t.duration||0)); });
          return (end || loopEnd) / 1000;
        }""")
        duration = a.duration or (total + 0.6)
        n = max(2, int(round(duration * a.fps)))
        frames = []
        for i in range(n):
            t = i / a.fps
            pg.evaluate("""(t) => {
              document.getAnimations().forEach(x => { x.currentTime = t * 1000; });
              document.querySelectorAll('svg').forEach(s => { try { s.setCurrentTime(t); } catch(e){} });
            }""", t)
            png = el.screenshot(omit_background=(a.bg == "transparent"))
            frames.append(Image.open(io.BytesIO(png)).convert("RGBA"))
        b.close()

    ms = int(1000 / a.fps)
    if fmt == "apng":
        frames[0].save(a.out, format="PNG", save_all=True, append_images=frames[1:], duration=ms, loop=a.loop, disposal=0, blend=0, optimize=True)  # disposal NONE lets Pillow store only the changed bbox per frame
    else:
        pal = [f.convert("RGBA") for f in frames]
        if a.bg == "transparent":
            print("[record] note: GIF has 1-bit alpha; anti-aliased edges on transparent bg will look jagged. Prefer --bg #ffffff for GIF.")
        pal[0].save(a.out, format="GIF", save_all=True, append_images=pal[1:], duration=ms, loop=a.loop, disposal=2, optimize=True)
    print(f"[record] {a.out} {fmt} {n} frames @ {a.fps}fps, {duration:.2f}s, {a.out.stat().st_size/1024:.0f} KB")
    if a.out.stat().st_size > 2_000_000:
        print("[record] WARN: > 2 MB. Lower --fps (20), --scale (1.5) or --duration, or use --loop 1 with a shorter clip.")

if __name__ == "__main__":
    main()
