# Receitas (equivalentes nativo × GSAP)

Princípio de direção: **um momento orquestrado** (normalmente a abertura) e o resto responde ao
usuário (scroll, clique). Fade-and-slide em toda seção e hover animado em todo card leem como
template genérico. Movimento só em `transform`/`opacity` (e `stroke-dashoffset` em SVG).

## Sumário
1. Abertura com título letra a letra
2. Lista/grade revelada em sequência ao entrar na tela
3. Números que contam
4. Barra de progresso de leitura
5. Traço SVG que se desenha com o scroll
6. Storytelling com seção fixa (pin)
7. Parallax sutil
8. Faixa rolando (ticker) — CSS puro
9. Expandir/recolher com transição de estado
10. Microinteração de botão — CSS puro

## 1. Abertura
```js
// nativo
const s = Motion.splitText('h1', { type: 'words,chars' });
Motion.timeline({ defaults: { ease: 'power3.out', duration: 0.7 } })
  .from(s.chars, { y: 40, opacity: 0, stagger: 0.012 })
  .from('.lede', { opacity: 0, y: 16 }, '-=0.35');
// gsap (+SplitText)
const s = SplitText.create('h1', { type: 'words,chars' });
gsap.timeline({ defaults: { ease: 'power3.out', duration: 0.7 } })
  .from(s.chars, { y: 40, autoAlpha: 0, stagger: 0.012 })
  .from('.lede', { autoAlpha: 0, y: 16 }, '-=0.35');
```
Títulos longos (> 40 caracteres): anime `words`, não `chars`.

## 2. Revelar em sequência
```js
Motion.reveal('.item', { y: 24, opacity: 0, duration: 0.6, ease: 'power2.out' }, { stagger: 0.08 });
// gsap
ScrollTrigger.batch('.item', { start: 'top 85%', once: true,
  onEnter: els => gsap.from(els, { y: 24, autoAlpha: 0, stagger: 0.08, ease: 'power2.out' }) });
```
CSS puro (sem stagger): `animation-timeline: view()` — ver `engine-native.md` §3.

## 3. Números
HTML com o valor final já escrito (legível sem JS): `<span data-count data-to="18450">18.450</span>`.
```js
// nativo: dispare quando visível (IntersectionObserver) e chame
Motion.counter(el, { duration: 1.4, ease: 'power2.out' });   // lê data-to/data-decimals/data-prefix/data-suffix
// gsap
const o = { v: 0 }, fmt = new Intl.NumberFormat('pt-BR');
gsap.to(o, { v: +el.dataset.to, duration: 1.4, ease: 'power2.out',
  scrollTrigger: { trigger: el, start: 'top 85%', once: true },
  onUpdate: () => el.textContent = fmt.format(Math.round(o.v)) });
```

## 4. Progresso de leitura
```js
Motion.scrub('.progress__bar', { scaleX: 0 }, { scaleX: 1 }, { source: 'page' });
gsap.fromTo('.progress__bar', { scaleX: 0 }, { scaleX: 1, ease: 'none', scrollTrigger: { start: 0, end: 'max', scrub: true } });
```
CSS: `transform-origin: left` na barra.

## 5. Traço SVG com scroll
```js
const len = path.getTotalLength(); path.style.strokeDasharray = len + ' ' + len;
Motion.scrub(path, { strokeDashoffset: len }, { strokeDashoffset: 0 }, { trigger: '.wrap', rangeStart: 'entry 30%', rangeEnd: 'exit 60%' });
// gsap (+DrawSVGPlugin)
gsap.from(path, { drawSVG: 0, ease: 'none', scrollTrigger: { trigger: '.wrap', start: 'top 70%', end: 'bottom 40%', scrub: true } });
```
Trilho vertical que estica com o conteúdo: `preserveAspectRatio="none"` + `vector-effect: non-scaling-stroke`.

## 6. Seção fixa (storytelling)
```html
<section class="story" style="height:300vh"><div class="story__stage" style="position:sticky;top:0;height:100vh">…</div></section>
```
```js
// nativo: o palco é sticky (CSS); o conteúdo anima conforme a seção atravessa a tela
Motion.scrub('.story__panel', { x: '0%' }, { x: '-66.66%' }, { trigger: '.story', rangeStart: 'contain 0%', rangeEnd: 'contain 100%' });
// gsap: pin real, sem altura fixa no CSS
gsap.to('.story__panel', { xPercent: -66.66, ease: 'none',
  scrollTrigger: { trigger: '.story', pin: true, scrub: 1, end: '+=200%' } });
```
Fallback do Firefox no nativo usa range `cover`: o efeito começa um pouco antes. Se isso importar, use GSAP.

**Armadilha (testada):** seção pinada perto do fim da página precisa de `min-height: 100vh` no
trigger. Sem isso o documento acaba antes do fim do pin e o scroll máximo não alcança o final da
animação (o último painel nunca aparece inteiro). Aplique a altura só sob a classe que o JS adiciona
(`.motion-ready`), para a versão sem JS continuar uma grade simples. Para trilho horizontal, calcule
a distância com função + `invalidateOnRefresh: true` (muda com resize):
```js
const distance = () => track.scrollWidth - track.parentElement.clientWidth;
gsap.to(track, { x: () => -distance(), ease: 'none',
  scrollTrigger: { trigger: '.road', pin: true, scrub: 1, end: () => '+=' + distance(), invalidateOnRefresh: true } });
```

## 7. Parallax sutil (≤ 10% de deslocamento; mais que isso enjoa)
```js
Motion.scrub('.hero__media', { y: -30 }, { y: 30 });
gsap.fromTo('.hero__media', { y: -30 }, { y: 30, ease: 'none', scrollTrigger: { trigger: '.hero', scrub: true } });
```

## 8. Ticker — CSS puro (duplique o conteúdo uma vez, com `aria-hidden` na cópia)
```css
.ticker__track { display: flex; width: max-content; animation: tick 30s linear infinite; }
.ticker:hover .ticker__track { animation-play-state: paused; }
@keyframes tick { to { translate: -50% 0; } }
@media (prefers-reduced-motion: reduce) { .ticker__track { animation: none; } }
```

## 9. Expandir/recolher (responde a ação → bem-vindo)
Use `<details>/<summary>` (acessível sem JS) e anime o conteúdo ao abrir:
```js
document.querySelectorAll('details').forEach(d => d.addEventListener('toggle', () => {
  if (d.open) Motion.from(d.querySelector('.details__body'), { opacity: 0, y: -8, duration: 0.25 });
}));
```
Reordenar/filtrar listas: View Transitions (`document.startViewTransition(() => render())`) ou GSAP `Flip`.

## 10. Botão — CSS puro
```css
.btn { transition: translate .15s ease-out, box-shadow .15s ease-out; }
.btn:hover { translate: 0 -1px; }
.btn:active { translate: 0 1px; transition-duration: .05s; }
```
