# Alvo: README.md animado

## Sumário
1. O que é possível (e o que não é)
2. Matriz por plataforma e decisão de formato
3. Regras de autoria do SVG
4. Técnicas de animação sem JavaScript
5. Gerar APNG/GIF
6. Snippets de markdown
7. Checklist

## 1. O que é possível

Markdown de README não executa JavaScript nem aceita `<style>` em nenhuma plataforma relevante.
Portanto **GSAP e motion-lite não funcionam em README**. O que funciona é imagem animada:

- **SVG com CSS `@keyframes`** (ou SMIL) carregado via `<img>`/`![]()`: vetorial, leve, nítido.
  Animações CSS internas do SVG rodam porque o browser renderiza a imagem. Scripts não.
- **APNG** (`.png` animado): passa por qualquer sanitizador porque é "só um PNG". Cor 24 bits + alpha.
- **GIF**: universal, mas 256 cores e alpha de 1 bit (bordas serrilhadas em fundo transparente).

O SVG é sempre a **fonte**. APNG/GIF são **renderizados a partir dele** com `record_animation.py`,
quadro a quadro e de forma determinística. Uma fonte, vários formatos: nunca mantenha o GIF à mão.

## 2. Matriz por plataforma

| Plataforma | SVG animado no README | APNG | Observação |
|---|---|---|---|
| GitHub / GitHub Enterprise | Funciona (via `<img>`) | Funciona | `<picture>` + `prefers-color-scheme` suportado para tema claro/escuro |
| GitLab | Geralmente funciona em versões recentes; houve bugs históricos | Funciona | Validar na versão self-hosted do usuário |
| Azure DevOps (Repos) | Há relatos de SVG não renderizado no preview do README | Funciona | Usar APNG |
| Bitbucket | Não verificado | Esperado funcionar (é PNG) | Validar |

**Regra de decisão:**
- README que precisa renderizar igual em mais de uma plataforma → **referencie o APNG**.
- Só GitHub → pode referenciar o SVG (menor, nítido em qualquer zoom); entregue o APNG também.
- Sempre entregue os dois arquivos; o usuário escolhe qual referenciar.

## 3. Regras de autoria do SVG (o validador cobra todas)

- `xmlns="http://www.w3.org/2000/svg"`, `width`, `height` e `viewBox` no `<svg>` raiz.
- `role="img"` + `<title>` (+ `<desc>` se houver informação além do título) para leitores de tela.
- **Nada externo**: sem `@import`, `@font-face`, `<image href="https://...">`, `<use href="externo">`.
  Fonte: stack de sistema (`"Segoe UI", system-ui, -apple-system, "Helvetica Neue", Arial, sans-serif`).
  Texto renderiza com a fonte do visitante: deixe folga horizontal de ~15% nas larguras.
- **Sem** `<script>`, atributos `on*`, `<foreignObject>`.
- **Não escreva `<` dentro de comentários CSS** do `<style>`: o arquivo é XML e quebra o parse.
- **Estado final = estilo base.** Escreva os `@keyframes` só com `from` (ou com `to` igual ao base)
  e use `animation-fill-mode: both`. Assim:
  `@media (prefers-reduced-motion: reduce) { * { animation: none !important; } }`
  mostra a imagem completa e estática. Esse bloco é obrigatório.
- Tema: variáveis CSS no `:root` + `@media (prefers-color-scheme: dark)`. Atenção: dentro de uma
  imagem, essa media query segue a preferência do sistema do visitante, não o tema escolhido no
  GitHub. Para casar com o tema do GitHub, gere duas versões e use `<picture>` (seção 6).
- No máximo um loop infinito, sutil (ex.: um pulso). Documentação não é vitrine.
- Para `transform` em elementos SVG, declare `transform-box: fill-box; transform-origin: center;`
  senão a origem é o canto do viewport do SVG.

## 4. Técnicas sem JavaScript

| Efeito | Como fazer em SVG puro |
|---|---|
| Linha/traço se desenhando | `stroke-dasharray: L; @keyframes { from { stroke-dashoffset: L } to { stroke-dashoffset: 0 } }`. L = comprimento do path (para `<line>`, a distância; para `<path>`, calcule com `getTotalLength()` no Playwright ou estime com folga). |
| Entrada de título | `@keyframes rise { from { opacity: 0; transform: translateY(18px) } }` com easing `cubic-bezier(.165,.84,.44,1)` (equivalente a `power3.out`). |
| Sequência / stagger | Mesma animação, `animation-delay` crescente por classe (`.n1 { animation-delay: .2s }`...). Sincronize com a linha: delay do nó = delay da linha + duração × (posição / comprimento). |
| Efeito "digitando" | Texto dentro de `<clipPath>` com `<rect>` cuja largura anima com `steps(N)` (N = nº de caracteres). Fonte monoespaçada torna o passo exato. |
| Varredura de brilho | `<mask>` com retângulo em gradiente; anime `transform: translateX()` do retângulo da máscara (CSS anima transform; não anime atributos do gradiente). |
| Contador numérico | Não há como mudar texto via CSS. Empilhe 3 a 5 `<text>` com valores intermediários e alterne `opacity` com `steps(1)`. Use com moderação. |
| Pulso/atenção | `@keyframes pulse { 50% { transform: scale(1.6); opacity: .5 } }` com `infinite`, iniciado depois do fim da sequência principal. |

Mapeamento de easings GSAP → CSS: ver tabela em `engine-native.md` (mesmos `cubic-bezier`).

## 5. Gerar APNG/GIF

```bash
python scripts/validate_svg.py docs/assets/banner.svg
python scripts/record_animation.py docs/assets/banner.svg docs/assets/banner.png            # APNG claro
python scripts/record_animation.py docs/assets/banner.svg docs/assets/banner-dark.png --dark # APNG escuro
python scripts/record_animation.py docs/assets/banner.svg docs/assets/banner.gif --bg '#ffffff' --fps 20  # só se pedirem GIF
```

Padrões: 24 fps, escala 1,5×, `--loop 1` (toca uma vez e para no quadro final, que mitiga a
ausência de reduced-motion em imagem raster). A duração é calculada automaticamente pelo fim da
última animação finita; loops infinitos decorativos são ignorados.

Orçamento: até ~500 KB por imagem de README. Acima disso, reduza `--fps` para 20, `--scale` para 1,
ou encurte a sequência. Fundo transparente funciona bem em APNG; em GIF use `--bg` sólido.

## 6. Snippets de markdown

Multiplataforma (APNG):
```markdown
![Pós-venda digital: segunda via em três etapas, sem abrir chamado](docs/assets/banner.png)
```

Só GitHub, com tema claro/escuro:
```html
<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/assets/banner-dark.png">
  <img src="docs/assets/banner.png" width="880" alt="Pós-venda digital: segunda via em três etapas, sem abrir chamado">
</picture>
```

Só GitHub, SVG direto:
```html
<img src="docs/assets/banner.svg" width="880" alt="Pós-venda digital: segunda via em três etapas, sem abrir chamado">
```

O `alt` descreve o conteúdo da imagem, não a animação ("banner animado" não informa nada).

## 7. Checklist

- [ ] `validate_svg.py` sem erros
- [ ] APNG gerado (claro; escuro se o README for para GitHub com `<picture>`)
- [ ] Último quadro conferido (o validador visual é você: abra o PNG/veja o screenshot)
- [ ] Tamanho dentro do orçamento
- [ ] `alt` descritivo no markdown
- [ ] Caminhos relativos à raiz do repositório
