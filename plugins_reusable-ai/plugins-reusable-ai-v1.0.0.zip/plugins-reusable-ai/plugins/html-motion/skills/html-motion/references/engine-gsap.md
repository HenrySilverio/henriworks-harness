# Engine GSAP em páginas HTML puras

Paridade total com o GSAP oficial. Esta página cobre **só o que muda em HTML puro + SharePoint**;
a API completa está nas referências oficiais em `gsap-official/` (cópia das skills oficiais
`greensock/gsap-skills`, MIT; ver `gsap-official/LICENSE-gsap-skills-MIT.txt`).

| Precisa de | Leia |
|---|---|
| tweens, easing, stagger, `gsap.matchMedia`, defaults | `gsap-official/core.md` |
| sequências, position parameter, labels, nesting | `gsap-official/timeline.md` |
| scroll, pin, scrub, `toggleActions`, `refresh` | `gsap-official/scrolltrigger.md` |
| SplitText, DrawSVG, Flip, MotionPath, MorphSVG, ScrambleText, CustomEase, Observer | `gsap-official/plugins.md` |
| `gsap.utils` | `gsap-official/utils.md` |
| jank, will-change, layout thrashing | `gsap-official/performance.md` |

Ignore nessas referências tudo sobre React, Vue, npm `import` e bundlers: aqui não há bundler.

## Carregamento (UMD, sem CDN)

- A engine é **vendorizada** pelo `build_page.py --engine gsap --plugins A,B` (versão pinada no
  script, `GSAP_VERSION`). Nunca aponte `<script src>` para cdnjs/jsdelivr: proxy do banco e CSP.
- Ordem: o marcador `<!-- @engine -->` vem **antes** de `<script src="app.js" defer>` no `<head>`.
  Todos com `defer` executam na ordem do documento, após o parse.
- Plugins válidos no build: `ScrollTrigger, ScrollToPlugin, SplitText, DrawSVGPlugin, Flip,
  MotionPathPlugin, TextPlugin, CustomEase, ScrambleTextPlugin, MorphSVGPlugin, Observer`.
  Inclua só o que o `app.js` usa (cada plugin pesa 5 a 45 KB).
- Em rede sem acesso ao npm público: `--gsap-dir caminho/node_modules/gsap/dist` instalado do
  registry interno (Nexus/Artifactory).

## Esqueleto do app.js

```js
(function () {
  'use strict';
  if (!window.gsap) return;                       // engine bloqueada → página estática legível
  gsap.registerPlugin(ScrollTrigger /*, SplitText, ... */);

  const mm = gsap.matchMedia();
  mm.add({ motion: '(prefers-reduced-motion: no-preference)', reduce: '(prefers-reduced-motion: reduce)' }, (ctx) => {
    if (ctx.conditions.reduce) return;            // estado final = HTML estático
    // ... animações aqui; tudo criado dentro do mm.add é revertido automaticamente
    return () => { /* reverter SplitText etc. */ };
  });

  window.addEventListener('load', () => ScrollTrigger.refresh()); // imagens/fontes mudam o layout
})();
```

## Regras específicas deste contexto

- **Licença**: GSAP usa a licença própria "Standard No Charge" (gratuita, inclusive plugins, mas
  não é MIT/OSI). Em ambiente corporativo, mencione ao usuário que pode exigir aprovação de
  terceiros. A engine nativa não tem essa pendência.
- Prefira `autoAlpha` a `opacity` em `from()`: evita cliques em elementos invisíveis.
- Use `ScrollTrigger` com `markers: true` só durante desenvolvimento; nunca no entregável.
- Página dentro de iframe (web part Embed): o scroller é o `window` do iframe; padrão do
  ScrollTrigger já funciona. Não tente ler o scroll da página pai (cross-origin).
- `pin: true` cria wrapper com `position: fixed` durante o pin: ancestrais com `transform`,
  `filter` ou `contain` quebram o pin. Pinar elementos de nível alto.
- Seção com `pin` perto do fim da página: `min-height: 100vh` no trigger, senão o scroll acaba
  antes do fim do pin (ver `recipes.md` §6).
- Nada de `gsap.ticker` para lógica de negócio ou `onUpdate` pesado: só para estilo.
