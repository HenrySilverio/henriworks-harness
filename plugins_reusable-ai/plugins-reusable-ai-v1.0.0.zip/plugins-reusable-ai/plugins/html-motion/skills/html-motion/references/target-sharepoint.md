# Alvo: SharePoint Online (arquivo em biblioteca de documentos)

Leia inteiro antes de entregar qualquer página destinada ao SharePoint. As regras aqui
derivam de restrições da plataforma que mudam a arquitetura, não de preferência de estilo.

## Sumário
1. Restrições da plataforma
2. Decisão de formato de saída
3. Checklist de deploy
4. Diagnóstico quando não funciona
5. Alternativas mais robustas (para recomendar ao usuário)

## 1. Restrições da plataforma

**`.html` em biblioteca é baixado, não renderizado.** O SharePoint Online serve `.html`/`.htm` de
bibliotecas como download. Por isso a saída para SharePoint usa `--ext aspx`.

**`.aspx` só renderiza com custom script.** O arquivo `.aspx` é executado como página apenas se:
- o site permitia custom script (`DenyAddAndCustomizePages = 0`) **no momento do upload**, e
- quem fez o upload tem a permissão *Add and Customize Pages* (na prática, Owner do site).
Caso contrário o arquivo é marcado como NoExecute e vira download. A Microsoft limita a liberação
de custom script por site a no máximo 24 horas; depois volta ao bloqueio. Relatos da comunidade
indicam que arquivos enviados durante a janela continuam renderizando depois dela. Trate isso como
comportamento observado, não garantido: valide no tenant do usuário.

**CSP aplicada desde 2026.** O SharePoint Online passou a aplicar Content Security Policy para
scripts a partir de 1º de março de 2026 (adiamento máximo por tenant até 1º de junho de 2026).
Consequências:
- `<script>` com corpo inline é bloqueado;
- atributos `on*=` e URLs `javascript:` são bloqueados;
- scripts só carregam de origens em *Trusted script sources*
  (SharePoint Admin Center → Advanced → Script sources).
Não há documentação explícita sobre se o header CSP é aplicado a um `.aspx` bruto servido de uma
biblioteca. **Assuma que sim.** Por isso o modo padrão é `split`: zero script inline, engine e app
como arquivos `.js` na mesma pasta.

**Rede corporativa.** CDNs públicos (cdnjs, jsdelivr, unpkg, Google Fonts) costumam estar bloqueados
no proxy do banco e não estão em Trusted script sources. Nada externo: engine vendorizada, fonte de
sistema, imagens locais ou data URI.

**Script pode simplesmente não rodar.** Por qualquer um dos motivos acima. A página precisa ser
100% legível sem JavaScript (progressive enhancement). Nunca esconda conteúdo por CSS esperando
que o JS revele; o estado inicial "escondido" é aplicado pelo próprio JS (`from()`), que só roda se
a engine carregou.

## 2. Decisão de formato de saída

| Situação | Comando |
|---|---|
| Padrão SharePoint | `build_page.py SRC OUT --engine <e> --mode split --ext aspx` |
| Tenant confirmadamente sem CSP na biblioteca e usuário quer 1 arquivo | `--mode single --ext aspx` |
| Página vai num iframe (web part Embed) hospedada fora do SharePoint | `--mode single --ext html` no host externo |

Entregue sempre a pasta `split` completa: `index.aspx`, `app.js`, `style.css`, `vendor/*.js`, e
assets. Caminhos são relativos; a estrutura de pastas precisa ser preservada no upload.

## 3. Checklist de deploy (inclua na resposta ao usuário, adaptado)

1. Confirmar com o admin do site se custom script está liberado (ou pedir janela de 24 h).
   Não sugerir liberar custom script no tenant inteiro: é configuração de segurança.
2. Fazer upload como **Owner do site**, pelo botão *Upload* da biblioteca, mantendo a pasta
   (`vendor/` junto). Relatos indicam que drag-and-drop e upload por Member geram link de download.
3. Abrir `index.aspx` em janela anônima/InPrivate.
4. Abrir o console do navegador (F12). Procurar mensagens começando com
   `Executing inline script violates...` ou `Loading the script ... violates...`.
5. Testar com `?csp=enforce` na URL para simular a aplicação de CSP, se o tenant ainda estiver em
   modo de relatório.
6. Se os `.js` da própria biblioteca forem bloqueados por CSP: pedir ao admin para incluir a URL
   da biblioteca em *Trusted script sources*. Não existe workaround do lado da página.
7. Conferir que a página continua legível com JS desabilitado (o validador já testa com `--run`).

## 4. Diagnóstico quando não funciona

| Sintoma | Causa provável | Ação |
|---|---|---|
| Clicar no arquivo baixa em vez de abrir | `.html`, ou `.aspx` marcado NoExecute | Usar `.aspx`; reenviar como Owner durante janela de custom script |
| Página abre, sem animação, console com "violates ... Content Security Policy" | CSP | Garantir `--mode split`; pedir Trusted script source para a biblioteca |
| Página abre sem estilo | `style.css` não foi enviado ou caminho mudou | Reenviar a pasta inteira preservando estrutura |
| Animação de scroll dispara no lugar errado | Layout mudou após load (imagens, fontes) | GSAP: `ScrollTrigger.refresh()` no `load`; nativo: já recalcula no scroll |
| Funciona para o autor, baixa para outros | Upload feito por Member, ou arquivo copiado/movido depois | Reenviar como Owner |

## 5. Alternativas mais robustas (apresente os trade-offs ao usuário)

`.aspx` em biblioteca depende de uma configuração de segurança que a Microsoft vem restringindo
ano a ano. É a opção mais frágil. Em ordem de robustez:

1. **Web part SPFx.** Caminho suportado pela Microsoft para código customizado; o próprio deploy
   registra a origem em Trusted script sources. Custo: app catalog, governança, pipeline de build.
   Recomendado se a página for recorrente ou crítica.
2. **Host externo + web part Embed (iframe).** A página roda num domínio controlado pelo time
   (ex.: Azure Static Web Apps interno); o SharePoint só a enquadra. O domínio precisa estar na
   lista *HTML Field Security* do site. Isola totalmente a página das regras de script do
   SharePoint. Custo: um host a mais para operar.
3. **`.aspx` em biblioteca (esta skill, padrão).** Zero infraestrutura nova. Custo: depende de
   custom script e de CSP; pode quebrar em mudança futura da plataforma.
4. **Página moderna nativa + GIF/APNG/vídeo.** Sem script nenhum: as animações viram mídia gravada
   (`record_animation.py` aceita HTML). Perde interatividade e scroll-linking, mas é à prova de
   governança.
