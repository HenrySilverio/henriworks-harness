# Engine nativa: motion-lite + CSS moderno

`assets/motion-lite.js` (~20 KB, MIT, zero dependência) expõe `window.Motion` com API espelhando
o GSAP. Código escrito para ela porta para GSAP trocando `Motion.` por `gsap.` na maioria dos casos.
Por baixo usa Web Animations API, `ViewTimeline`/`ScrollTimeline` nativos quando existem e
fallback por `requestAnimationFrame` quando não (Firefox).

## Sumário
1. API
2. Mapeamento GSAP → nativo
3. CSS puro que dispensa JS
4. Limites conhecidos (quando trocar para GSAP)
5. Easings

## 1. API

```js
// Tweens (duração em segundos, como no GSAP). Retornam objeto "thenable" (await funciona).
Motion.to(targets, { x: 100, y: '2rem', scale: 1.2, rotation: 45, opacity: 1, autoAlpha: 1,
                     duration: 0.5, delay: 0, ease: 'power2.out', stagger: 0.05,
                     repeat: 0, yoyo: false, paused: false, onStart, onComplete, force: false });
Motion.from(targets, vars);            // anima DO estado dado ATÉ o atual
Motion.fromTo(targets, fromVars, toVars);
Motion.set(targets, vars);             // aplica imediatamente
// tween.play() .pause() .reverse() .progress(0..1) .kill()  |  await tween

// Timeline com position parameter igual ao GSAP
const tl = Motion.timeline({ defaults: { duration: 0.6, ease: 'power3.out' }, repeat: 0, yoyo: false, paused: false, onComplete });
tl.to(a, {...})            // no fim
  .to(b, {...}, '<')       // junto com o anterior
  .to(c, {...}, '<0.2')    // 0,2 s após o início do anterior
  .to(d, {...}, '>-0.1')   // 0,1 s antes do fim do anterior
  .to(e, {...}, '-=0.3')   // 0,3 s antes do fim da timeline
  .addLabel('fim')
  .to(f, {...}, 'fim+=0.5')
  .call(fn, 1.2);          // callback em 1,2 s (só reprodução para frente; não reage a seek)
// tl.play() .pause() .reverse() .restart() .seek(s|'label') .progress(p) .duration() .kill() | await tl

// Stagger avançado
{ stagger: { each: 0.05, from: 'center' | 'end' | 'random' | índice } }
{ stagger: { amount: 0.6 } }   // total distribuído entre os elementos

// Scroll
Motion.reveal(targets, fromVars, { stagger: 0.08, threshold: 0.15, rootMargin: '0px 0px -10% 0px', once: true });
Motion.scrub(targets, fromVars, toVars, { source: 'view' | 'page', trigger, rangeStart: 'entry 30%', rangeEnd: 'exit 60%' });

// Texto, números, SVG
const s = Motion.splitText(el, { type: 'words,chars' | 'lines' });  // s.chars, s.words, s.lines, s.revert(); mantém aria-label
Motion.counter(el, { to, from: 0, duration: 1.5, ease, decimals, prefix, suffix, locale: 'pt-BR' }); // ou data-to/data-decimals/data-prefix/data-suffix
Motion.drawSVG(pathOuShape, { duration: 1, ease: 'power1.inOut' });

// Utilitários (assinaturas do gsap.utils; sem o último argumento retornam função)
Motion.utils.toArray / clamp / mapRange / normalize / interpolate / random / snap / wrap / pipe

// Responsivo e acessibilidade
Motion.matchMedia('(min-width: 768px)', () => { /* setup */ return () => { /* cleanup */ }; });
Motion.reducedMotion();                // boolean
Motion.config({ respectReducedMotion: true, defaults: { duration: 0.5, ease: 'power1.out' } });
```

**Reduced motion é automático**: com `prefers-reduced-motion: reduce`, durações viram 0, stagger e
repeat são zerados, `reveal` não esconde nada, `scrub` aplica o estado final e `counter` escreve o
valor final. Use `force: true` só para movimento essencial ao entendimento (raro).

**Propriedades de transform** usam as propriedades CSS individuais `translate`, `scale`, `rotate`
(não `transform`). Elas compõem com um `transform` que o elemento já tenha no CSS. A engine guarda
x/y/scale/rotation por elemento, então tweens consecutivos de `x` preservam `y`.

## 2. Mapeamento GSAP → nativo

| GSAP | motion-lite / nativo |
|---|---|
| `gsap.to/from/fromTo/set` | `Motion.to/from/fromTo/set` (mesma forma) |
| `gsap.timeline()` + position parameter | `Motion.timeline()` (mesmos tokens: `<`, `>`, `+=`, `-=`, labels) |
| `stagger` (número/objeto) | idem (`each`, `amount`, `from`) |
| `ScrollTrigger` com `toggleActions` / once | `Motion.reveal()` |
| `ScrollTrigger` com `scrub: true` | `Motion.scrub()` ou CSS `animation-timeline: view()` |
| `ScrollTrigger` com `pin: true` | CSS `position: sticky` + `Motion.scrub()` no conteúdo (ver receitas) |
| `SplitText` | `Motion.splitText()` (chars/words/lines; sem máscara de linha) |
| `DrawSVGPlugin` | `Motion.drawSVG()` (só 0%→100%; sem segmentos tipo "20% 80%") |
| `Flip` | View Transitions API: `document.startViewTransition(() => mutarDOM())` |
| `ScrollToPlugin` | `el.scrollIntoView({ behavior: 'smooth' })` |
| `gsap.matchMedia()` | `Motion.matchMedia()` |
| `gsap.utils.*` | `Motion.utils.*` (subconjunto) |
| `CustomEase` | string CSS `cubic-bezier(...)` ou `linear(...)` direto em `ease` |
| `MorphSVGPlugin`, `MotionPathPlugin`, `ScrambleText`, `Physics2D`, `Inertia/Draggable` | **sem equivalente**: use GSAP |

## 3. CSS puro que dispensa JS (prefira quando bastar)

```css
/* Reveal ligado ao scroll, sem JavaScript (Chrome/Edge/Safari 26+; Firefox: sem efeito, conteúdo visível) */
@supports (animation-timeline: view()) {
  @media (prefers-reduced-motion: no-preference) {
    .reveal { animation: reveal linear both; animation-timeline: view(); animation-range: entry 0% cover 30%; }
    @keyframes reveal { from { opacity: 0; translate: 0 2rem; } }
  }
}
/* Entrada de elemento que aparece (display none → block, popovers, dialogs) */
.toast { transition: opacity .3s, translate .3s, display .3s allow-discrete; }
@starting-style { .toast { opacity: 0; translate: 0 1rem; } }
/* Barra de progresso de leitura */
.progress__bar { animation: grow linear both; animation-timeline: scroll(root); }
@keyframes grow { from { scale: 0 1; } }
```

Escolha: se o efeito é "algo entra quando aparece" ou "barra acompanha o scroll" e Firefox pode
ficar sem animação (conteúdo continua visível), CSS puro é a melhor resposta: zero JS, imune a CSP.

## 4. Limites conhecidos (sinais para escolher GSAP)

- Pinning real com espaçamento automático (`pin` + `pinSpacing`): só GSAP. Sticky resolve a
  maioria dos casos de storytelling, mas não calcula espaço nem lida com containers com overflow.
- `repeat: -1` dentro de timeline não é permitido (use `timeline({ repeat: -1 })`).
- `repeatDelay`, `yoyoEase`, `keyframes` por array de objetos, `onUpdate` por frame: não suportados.
- `call()` usa relógio de parede: não dispara em `seek`/`reverse`.
- `from()` dentro de timeline lê o estilo computado no momento em que a timeline é montada.
- `scrub` sem suavização (equivale a `scrub: true`, não `scrub: 1`).
- Firefox não tem `ViewTimeline`/`ScrollTimeline`: o fallback por rAF cobre `source: 'page'` e
  range `cover`; `rangeStart/rangeEnd` personalizados são aproximados como `cover 0%..100%`.

## 5. Easings (iguais aos nomes do GSAP)

`none`/`linear`, `power1..4.in/out/inOut` (`power2` = `power2.out`), `expo.*`, `sine.*`, `circ.*`,
`back.*`, `bounce.out`, `elastic.out` (via `linear()` CSS; fallback para `back.out` em browsers
antigos). Qualquer string `cubic-bezier(...)`/`linear(...)` passa direto. Padrão: `power1.out`, 0,5 s,
como no GSAP.
