---
name: "html-motion"
description: Cria páginas HTML animadas autocontidas (sem framework, sem CDN) e READMEs animados, com o poder de animação do GSAP — tweens, timelines, scroll (reveal, scrub, pin), texto letra a letra, contadores, traços SVG — usando o GSAP real vendorizado ou uma engine nativa sem dependências com a mesma API. Publica com segurança no SharePoint Online (CSP, .aspx em biblioteca) e gera SVG animado + APNG/GIF para README no GitHub, GitLab, Azure DevOps e Bitbucket. Use SEMPRE que o usuário pedir animação em página HTML, landing page, comunicado ou relatório interno animado, página para SharePoint, "efeito tipo GSAP", animação de scroll, microinteração, banner animado, README animado, SVG animado, GIF/APNG para documentação, ou quiser portar animações GSAP para HTML puro — mesmo que não diga "GSAP" nem "skill".
---

# html-motion

Animação de nível GSAP em dois alvos com restrições opostas:

- **Página HTML** (SharePoint Online, chat, Cowork, host interno): JS permitido, mas sob CSP e sem rede externa.
- **README.md**: JS e CSS proibidos pelo markdown; só imagem animada (SVG/APNG/GIF).

Os alvos não compartilham código: a página usa engine JS; o README usa SVG com `@keyframes`
renderizado para APNG. Não tente reaproveitar o `app.js` da página no README.

## 1. Decida o alvo

| Pedido | Alvo | Referência obrigatória |
|---|---|---|
| Página para SharePoint | página, `split` + `.aspx` | `references/target-sharepoint.md` |
| Página para ver aqui / Cowork / anexar / host próprio | página, `single` + `.html` | — |
| README, banner de repositório, diagrama animado para docs | README | `references/target-readme.md` |
| Os dois (página + README do mesmo projeto) | ambos, fontes separadas | as duas acima |

Se o destino da página não estiver claro, pergunte uma vez: "Vai para o SharePoint ou outro lugar?"
A resposta muda o formato de saída.

## 2. Decida a engine (só para páginas)

Escolha pelo menor poder que resolve. Diga ao usuário qual escolheu e por quê, em uma frase.

1. **CSS puro** — o efeito é só reveal ao rolar, barra de progresso, hover, ticker. Zero JS, imune a
   CSP. Ver `references/engine-native.md` §3.
2. **native** (`assets/motion-lite.js`, 20 KB, MIT) — padrão. Timelines com position parameter,
   stagger, reveal, scrub, split de texto, contadores, traço SVG. Sem pendência de licença.
3. **gsap** (vendorizado, ~75–130 KB) — quando o pedido exige algo que a nativa não faz: `pin` real
   com espaçamento, `Flip`, `MorphSVG`, `MotionPath`, `ScrambleText`, `Draggable/Inertia`, scrub
   suavizado (`scrub: 1`), sincronia complexa de muitas timelines, ou o usuário pedir GSAP. Avise
   que a licença do GSAP é "Standard No Charge" (gratuita, não-MIT) e pode precisar de aprovação de
   terceiros no banco.

Lista completa do que a nativa não cobre: `references/engine-native.md` §4.

## 3. Fluxo — página

```bash
SK=<caminho desta skill>
cp -r $SK/assets/template ./src
# escolha UM roteiro e apague o outro:
mv src/app.native.js src/app.js && rm src/app.gsap.js      # engine nativa
# ou: mv src/app.gsap.js src/app.js && rm src/app.native.js # engine gsap
```

1. **Conteúdo e design primeiro.** Reescreva `index.html` com o conteúdo real do usuário e ajuste os
   tokens no topo de `style.css`. Se a skill `frontend-design` estiver disponível, leia-a antes de
   desenhar. Sem web fonts (use a stack de sistema do template).
2. **Animação.** Escreva `src/app.js`. Use `references/recipes.md` como catálogo; para GSAP,
   `references/engine-gsap.md` aponta para a referência oficial certa. Um momento orquestrado na
   abertura; o resto responde ao usuário.
3. **Build.**
   ```bash
   # SharePoint (padrão: sem nenhum script inline)
   python $SK/scripts/build_page.py src out/sharepoint --engine native --mode split --ext aspx
   # Preview no chat / Cowork / anexo
   python $SK/scripts/build_page.py src out/preview --engine native --mode single
   # GSAP: --engine gsap --plugins ScrollTrigger,SplitText   (offline: --gsap-dir .../gsap/dist)
   ```
4. **Validar e olhar.**
   ```bash
   python $SK/scripts/validate_page.py out/preview/index.html --run --screenshot shot.png
   python $SK/scripts/validate_page.py out/sharepoint/index.aspx
   ```
   `--run` carrega no Chromium com movimento normal, com reduced-motion e com JS desligado; falha
   se houver erro de JS ou texto invisível. Abra o screenshot e critique antes de entregar.
   Sem Playwright no ambiente, rode só a validação estática e diga isso ao usuário.
5. **Entregar.** No claude.ai, publique/apresente o `single` para preview. Para SharePoint, entregue
   a pasta `split` (zip) + o checklist de deploy de `target-sharepoint.md` §3, adaptado.

## 4. Fluxo — README

1. Parta de `assets/readme/banner.svg` (título + linha) ou `assets/readme/steps.svg` (etapas em
   sequência). Reescreva com o conteúdo real; siga as regras de `references/target-readme.md` §3.
2. `python $SK/scripts/validate_svg.py arquivo.svg`
3. `python $SK/scripts/record_animation.py arquivo.svg arquivo.png` (APNG; `--dark` para versão
   escura; `.gif` como saída só se pedirem GIF).
4. Entregue SVG + APNG + o snippet de markdown adequado às plataformas do usuário (§6 da
   referência). Multiplataforma → o README referencia o **APNG**.

## 5. Regras inegociáveis (e por quê)

- **Nada externo** (CDN, Google Fonts, imagens remotas). Proxy corporativo e CSP bloqueiam, e a
  página quebra em silêncio. O validador falha nisso.
- **Nenhum script inline nem `on*=`** no modo `split`. O SharePoint Online aplica CSP a scripts
  desde 2026. Eventos via `addEventListener` no `app.js`.
- **Legível sem JavaScript.** O HTML já contém o estado final (texto, números finais). Estados
  iniciais "escondidos" são aplicados pelo JS (`from()`), nunca por CSS. Se o script for bloqueado,
  a página continua completa.
- **`prefers-reduced-motion` respeitado.** A nativa trata sozinha; no GSAP use `gsap.matchMedia()`;
  no SVG, o bloco `@media (prefers-reduced-motion: reduce)` com estado final como estilo base.
- **Só `transform`/`opacity`** (e `stroke-dashoffset`) em animação contínua ou de scroll. Animar
  `width`, `top`, `margin` causa reflow e trava em máquinas corporativas modestas.
- **Sem eval / `new Function`.** CSP e revisão de segurança.
- **Versão do GSAP pinada** em `scripts/build_page.py` (`GSAP_VERSION`). Atualize de propósito,
  nunca para uma versão com menos de 14 dias de publicação.

## 6. Referências

| Arquivo | Quando ler |
|---|---|
| `references/target-sharepoint.md` | Toda página com destino SharePoint |
| `references/target-readme.md` | Todo README/SVG/APNG |
| `references/engine-native.md` | Engine nativa ou CSS puro; tabela GSAP→nativo; limites |
| `references/engine-gsap.md` | Engine GSAP; índice para `references/gsap-official/*.md` |
| `references/recipes.md` | Catálogo de efeitos com código nas duas engines |
| `references/gsap-official/` | API oficial completa do GSAP (core, timeline, scrolltrigger, plugins, utils, performance) |

| Script | Função |
|---|---|
| `scripts/build_page.py` | Monta a página: injeta engine, modo split/single, `.html`/`.aspx` |
| `scripts/validate_page.py` | Valida dependências, CSP, acessibilidade; `--run` faz smoke test no Chromium |
| `scripts/validate_svg.py` | Valida SVG para uso em README |
| `scripts/record_animation.py` | Renderiza SVG (ou HTML) animado em APNG/GIF, quadro a quadro |
