/* Engine: GSAP (gsap + ScrollTrigger + SplitText). Mesmo roteiro do app.native.js. */
(function () {
  'use strict';
  if (!window.gsap) return;                          // engine bloqueada: página continua legível
  gsap.registerPlugin(ScrollTrigger, SplitText);

  var mm = gsap.matchMedia();
  mm.add({ motion: '(prefers-reduced-motion: no-preference)', reduce: '(prefers-reduced-motion: reduce)' }, function (ctx) {
    if (ctx.conditions.reduce) return;               // sem movimento: estado final já é o HTML estático

    var split = SplitText.create('[data-split]', { type: 'words,chars' });
    gsap.timeline({ defaults: { ease: 'power3.out', duration: 0.7 } })
      .from(split.chars, { y: 40, autoAlpha: 0, stagger: 0.012 })
      .from('.hero__context', { autoAlpha: 0, y: 8, duration: 0.5 }, '<0.1')
      .from('.hero__lede', { autoAlpha: 0, y: 16 }, '-=0.35');

    gsap.fromTo('.progress__bar', { scaleX: 0 }, {
      scaleX: 1, ease: 'none',
      scrollTrigger: { start: 0, end: 'max', scrub: true }
    });

    gsap.utils.toArray('[data-count]').forEach(function (el) {
      var to = parseFloat(el.dataset.to), dec = +(el.dataset.decimals || 0), suf = el.dataset.suffix || '';
      var fmt = new Intl.NumberFormat('pt-BR', { minimumFractionDigits: dec, maximumFractionDigits: dec });
      var o = { v: 0 };
      gsap.to(o, {
        v: to, duration: 1.4, ease: 'power2.out',
        scrollTrigger: { trigger: el, start: 'top 85%', once: true },
        onUpdate: function () { el.textContent = fmt.format(o.v) + suf; }
      });
    });

    var path = document.querySelector('.steps__path');
    if (path) {
      var len = path.getTotalLength();
      gsap.fromTo(path, { strokeDasharray: len, strokeDashoffset: len }, {
        strokeDashoffset: 0, ease: 'none',
        scrollTrigger: { trigger: '.steps__body', start: 'top 70%', end: 'bottom 40%', scrub: true }
      });
    }
    return function () { split.revert(); };          // cleanup ao trocar de media query
  });

  // Imagens/fontes que mudam layout depois do load deslocam os triggers.
  window.addEventListener('load', function () { ScrollTrigger.refresh(); });
})();
