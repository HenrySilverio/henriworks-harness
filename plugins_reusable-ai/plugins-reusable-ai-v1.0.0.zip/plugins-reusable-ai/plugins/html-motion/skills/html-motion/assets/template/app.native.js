/* Engine: motion-lite (nativo). Um único momento orquestrado no carregamento;
   o resto responde ao scroll do usuário. Reduced-motion é tratado pela engine. */
(function () {
  'use strict';
  var M = window.Motion;
  if (!M) return;                                   // engine bloqueada: página continua legível

  // 1) Carregamento: título letra a letra, depois contexto e lede.
  var split = M.splitText('[data-split]', { type: 'words,chars' });
  M.timeline({ defaults: { ease: 'power3.out', duration: 0.7 } })
    .from(split.chars, { y: 40, opacity: 0, stagger: 0.012 })
    .from('.hero__context', { opacity: 0, y: 8, duration: 0.5 }, '<0.1')
    .from('.hero__lede', { opacity: 0, y: 16 }, '-=0.35');

  // 2) Barra de progresso de leitura, ligada ao scroll da página.
  M.scrub('.progress__bar', { scaleX: 0 }, { scaleX: 1 }, { source: 'page' });

  // 3) Números contam uma vez quando entram na tela.
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (!e.isIntersecting) return;
        M.counter(e.target, { duration: 1.4, ease: 'power2.out' });
        io.unobserve(e.target);
      });
    }, { threshold: 0.6 });
    M.utils.toArray('[data-count]').forEach(function (el) { io.observe(el); });
  }

  // 4) Trilho do processo se desenha conforme o usuário rola (sequência real → numeração faz sentido).
  var path = document.querySelector('.steps__path');
  if (path) {
    var len = path.getTotalLength();
    path.style.strokeDasharray = len + ' ' + len;
    M.scrub(path, { strokeDashoffset: len }, { strokeDashoffset: 0 }, { trigger: '.steps__body', rangeStart: 'entry 30%', rangeEnd: 'exit 60%' });
  }
})();
