# Plugins html-motion e readme-skins — versão para o reusable-ai

Dois plugins **independentes** (instala um sem o outro), cada um com uma skill. A mesma pasta de
plugin serve a três famílias de ferramenta porque cada uma lê seu próprio manifesto:

| Manifesto | Quem lê |
|---|---|
| `plugin.json` (Agent Plugins 1.0, `$schema` agent-plugins.org) | Copilot no VS Code, Copilot CLI, GitHub Copilot app |
| `.claude-plugin/plugin.json` | Claude Code (e o VS Code também aceita esse formato) |
| `.antigravity-plugin/plugin.json` | Antigravity (tem precedência sobre o `plugin.json` da raiz) |

Nenhum manifesto lista as skills: todos descobrem `skills/<nome>/SKILL.md` sozinhos.
O manifesto do Antigravity rejeita chaves desconhecidas, por isso cada ferramenta tem o seu
em vez de um arquivo único com tudo.

```
plugins-reusable-ai/                 ← espelha a raiz do repositório reusable-ai
├── .github/plugin/marketplace.json  catálogo para Copilot (CLI/VS Code/app)
├── .claude-plugin/marketplace.json  mesmo catálogo para Claude Code
└── plugins/
    ├── html-motion/
    │   ├── plugin.json
    │   ├── .claude-plugin/plugin.json
    │   ├── .antigravity-plugin/plugin.json
    │   ├── assets/logo.svg
    │   └── skills/html-motion/…
    └── readme-skins/  (mesma estrutura)
```

Validado com `claude plugin validate` (passa; avisa só a falta de `author`) e instalado de ponta a
ponta no Claude Code a partir deste catálogo.

## Levar para o reusable-ai

1. Copie `plugins/html-motion/` e/ou `plugins/readme-skins/` para a pasta de plugins do repositório.
2. Acrescente a entrada de cada plugin no `marketplace.json` que o repositório já tiver
   (o daqui é exemplo; o `source` é relativo à raiz do repo):
   ```json
   { "name": "html-motion", "description": "…", "version": "1.0.0", "source": "./plugins/html-motion" }
   ```
   Se o reusable-ai ainda não tiver catálogo, use os dois `marketplace.json` deste pacote e troque
   `owner.name` pelo time dono.
3. Antes de publicar, preencha `author` (os três manifestos) e, para o marketplace do Antigravity,
   `homepage`/`license`. São opcionais para uso interno; o `claude plugin validate` só avisa.
4. Suba a versão (`version`) nos três manifestos **e** no `marketplace.json` a cada mudança da
   skill: Copilot CLI e Claude Code usam a versão para decidir se atualizam o cache.

## Instalar a partir do reusable-ai (cada plugin separado)

Troque `<org>/reusable-ai` pelo caminho real. Em GitHub Enterprise, use a URL HTTPS terminada em `.git`.

**Copilot CLI**
```bash
copilot plugin marketplace add <org>/reusable-ai
copilot plugin install html-motion@reusable-ai
```

**VS Code (Copilot)** — `settings.json`:
```json
{ "chat.plugins.marketplaces": ["<org>/reusable-ai"] }
```
Depois `/plugin install html-motion@reusable-ai` no chat ou pela tela *Agent Customizations*.

**Claude Code**
```bash
claude plugin marketplace add <org>/reusable-ai
claude plugin install html-motion@reusable-ai
```

**Antigravity** — a partir do clone local:
```bash
agy plugin install /c/caminho/reusable-ai/plugins/html-motion
```

## Testar localmente antes do PR (Git Bash)

```bash
P=/c/Users/<seu-usuario>/Downloads/plugins-reusable-ai
copilot plugin marketplace add "$P"   && copilot plugin install html-motion@reusable-ai
claude plugin marketplace add "$P"    && claude plugin install html-motion@reusable-ai
agy plugin install "$P/plugins/html-motion"
```
VS Code sem marketplace: em `settings.json`,
`"chat.pluginLocations": { "C:/Users/<seu-usuario>/Downloads/plugins-reusable-ai/plugins/html-motion": true }`.

## Plugin ou instalador?

| | Instalador (`skills-instalador`) | Plugin |
|---|---|---|
| Distribuição | zip + script na máquina | catálogo central, instalação pela ferramenta |
| Atualização | rodar o script de novo | a ferramenta atualiza pela versão |
| Nome da skill | `html-motion` | `html-motion` (no Claude Code aparece como `html-motion:html-motion`) |
| Evite | ter os dois na mesma máquina | — a skill apareceria duas vezes |

Se migrar para o plugin, remova a versão do instalador antes: `./install.sh uninstall html-motion`.

## Dependências das skills

Python 3 para os scripts. Opcionais: Pillow (APNG/GIF) e Playwright + Chromium (render e
validação com navegador). Sem eles a skill avisa e segue sem a etapa visual.
