---
name: configurar
description: "Adjusts .henriworks/verificacao.json and .henriworks/padroes.md to what the repository has. Runs in any agent with a terminal, including Copilot's default agent."
argument-hint: "[verificacao | padroes]"
disable-model-invocation: true
---
# /henriworks:configurar

Adjust `.henriworks/verificacao.json` (what the verifier runs in each layer) and `.henriworks/padroes.md`
(what the review audits) to what this repository has. Runs in any agent with terminal and edit. Reply in
Brazilian Portuguese.

**What this command allows you to edit:** only `.henriworks/estado/verificacao.proposta.json` (when the
developer asks for an adjustment) and `.henriworks/estado/padroes.proposta.md` (the draft). The real files are
written by the script, and only after an explicit "ok" from the developer in this chat. Never edit
`.henriworks/verificacao.json` or `.henriworks/padroes.md` by hand.

No argument: verification, then standards. With `verificacao` or `padroes`: only that one.

## Verification

1. Run `node .henriworks/bin/configurar.mjs verificacao` and show the whole output: what the repository has,
   the proposed layers, the code outside them and the diff to the current file.
2. If there is "Código fora das camadas", ask, in a single message, whether any of those folders should go in
   (mocks and build scripts usually stay out).
3. Run `node .henriworks/bin/configurar.mjs verificacao --provar` and show the output. It may take minutes:
   `tsc` and tests really run.
   - `FALHOU`: state the probable cause in one line, from the message (tsconfig with another name, ESLint
     without config, a different runner), and propose the adjustment.
   - `SEM ARQUIVO`: the layer has no tracked file; propose removing it.
   - Adjustment accepted: edit only `.henriworks/estado/verificacao.proposta.json`, keeping `formato`,
     `classificacao` and the markers `{arquivos}`, `{arquivo}`, `{saida}` and `{raizes}`, which
     `verificar.mjs` reads. Run `--provar` again.
4. All `ok`: ask "Posso gravar o verificacao.json?". Only with a yes, run
   `node .henriworks/bin/configurar.mjs verificacao --gravar`.

A finding in `--provar` is not a problem: it proves the command runs and its output is read.

## Standards

1. Run `node .henriworks/bin/configurar.mjs padroes`. Read only the sources it lists.
2. Write the draft in `.henriworks/estado/padroes.proposta.md`, in Brazilian Portuguese:
   - Title `# Padrões de código auditáveis`, sections by subject, one rule per line, imperative.
   - Only rules that can be checked by reading a diff, without judging intent.
   - Nothing the lint already catches (check `eslint.config`): formatting, import order and style stay out.
   - A map divergence (two ways in use in the same layer): do not choose. Ask the developer the target
     pattern of each, all in one message.
   - Do not mark `[grave]`. List the candidates and ask.
   - Up to about 40 rules: the file goes into every code review.
3. Show the draft and apply what the developer asks. Only with "ok", run
   `node .henriworks/bin/configurar.mjs padroes --gravar`.

The draft is a proposal: a rule the team did not agree on becomes a failure nobody accepts.

## Output

Up to five lines: what was written, where the backup is, what is pending and with whom.
