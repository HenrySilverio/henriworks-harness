#!/usr/bin/env node
// HenriWorks - preparação do repositório a partir do plugin instalado. Sem dependência, Node 20+.
//
//   node "<pasta desta skill>/scripts/init.mjs"
//
// Roda da raiz do repositório (ou de qualquer pasta dentro dele). Faz, sem tocar no código do produto:
//   1. copia o núcleo do plugin para <repo>/.henriworks/bin/ (os agentes chamam um caminho estável);
//   2. cria os arquivos do time que ainda não existem (configuração, padrões, índices);
//   3. copia o contrato e as referências do fluxo para <repo>/.henriworks/referencias/;
//   4. grava .henriworks/versao.json (plugin, versão e onde o plugin está instalado);
//   5. põe .henriworks/ no .git/info/exclude (nunca no .gitignore, que é versionado);
//   6. constrói o mapa, instala os hooks do Git do mapa e roda o "hwk init --corrigir".
// Rodar de novo é seguro: núcleo e referências são do plugin e são substituídos; arquivos do time ficam.

import { spawnSync } from 'node:child_process';
import { copyFileSync, existsSync, mkdirSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { dirname, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const sair = (codigo, msg) => { (codigo ? console.error : console.log)(msg); process.exit(codigo); };
const [maior] = process.versions.node.split('.').map(Number);
if (maior < 20) sair(2, `Node ${process.versions.node} encontrado; o HenriWorks precisa de 20 ou mais. Instale o Node 20+ e rode o init de novo.`);

const AQUI = dirname(fileURLToPath(import.meta.url));
const PLUGIN = resolve(AQUI, '..', '..', '..');
const ASSETS = resolve(AQUI, '..', 'assets');
let manifesto;
try { manifesto = JSON.parse(readFileSync(join(PLUGIN, 'plugin.json'), 'utf8')); } catch { sair(2, `não achei o plugin.json em ${PLUGIN}: reinstale o plugin.`); }

const git = (args, cwd = process.cwd()) => spawnSync('git', args, { cwd, encoding: 'utf8' });
const top = git(['rev-parse', '--show-toplevel']);
if (top.status !== 0) sair(2, 'esta pasta não é um repositório Git: abra a raiz do repositório no VS Code e rode o init de novo.');
const RAIZ = resolve(top.stdout.trim());
const HW = join(RAIZ, '.henriworks');
const rel = (p) => relative(RAIZ, p).split('\\').join('/');

function listar(dir, base = dir) {
  const out = [];
  for (const n of readdirSync(dir)) {
    const p = join(dir, n);
    if (statSync(p).isDirectory()) out.push(...listar(p, base));
    else out.push(relative(base, p));
  }
  return out;
}
function copiar(origem, destino, { sobrescrever }) {
  let n = 0;
  for (const f of listar(origem)) {
    const d = join(destino, f);
    if (!sobrescrever && existsSync(d)) continue;
    mkdirSync(dirname(d), { recursive: true });
    copyFileSync(join(origem, f), d);
    n++;
  }
  return n;
}

// 1. Núcleo: substituído inteiro, para não sobrar script de versão anterior.
const bin = join(HW, 'bin');
try { rmSync(bin, { recursive: true, force: true, maxRetries: 5, retryDelay: 200 }); } catch { /* Windows: arquivo preso; a cópia sobrescreve */ }
const nBin = copiar(join(PLUGIN, 'scripts', 'core'), bin, { sobrescrever: true });

// 2. Arquivos do time: só os que faltam.
const nSem = copiar(join(ASSETS, 'sementes'), HW, { sobrescrever: false });

// 3. Contrato e referências do fluxo: do plugin, substituídos.
const ref = join(HW, 'referencias');
try { rmSync(ref, { recursive: true, force: true, maxRetries: 5, retryDelay: 200 }); } catch { /* idem */ }
const nRef = copiar(join(ASSETS, 'referencias'), ref, { sobrescrever: true });

// 4. Versão: o hook e o init comparam com o plugin instalado para saber se o núcleo está atrasado.
writeFileSync(join(HW, 'versao.json'), `${JSON.stringify({ plugin: manifesto.name, versao: manifesto.version, pluginRoot: PLUGIN, instaladoEm: new Date().toISOString() }, null, 2)}\n`);

// 5. Fora do Git.
let exclude = 'sem caminho do Git: confira o .git/info/exclude';
const pEx = git(['rev-parse', '--git-path', 'info/exclude'], RAIZ);
if (pEx.status === 0) {
  const abs = resolve(RAIZ, pEx.stdout.trim());
  const atual = existsSync(abs) ? readFileSync(abs, 'utf8').replace(/\r\n/g, '\n') : '';
  if (/^\/?\.henriworks\/?$/m.test(atual)) exclude = 'já estava no .git/info/exclude';
  else {
    mkdirSync(dirname(abs), { recursive: true });
    writeFileSync(abs, `${atual}${atual && !atual.endsWith('\n') ? '\n' : ''}# >>> henriworks\n/.henriworks/\n# <<< henriworks\n`);
    exclude = '.henriworks/ acrescentado ao .git/info/exclude';
  }
}

console.log(`HenriWorks ${manifesto.version} preparado em ${RAIZ.split(/[\\/]/).pop()}`);
console.log(`  núcleo       ${nBin} arquivo(s) em ${rel(bin)}/`);
console.log(`  do time      ${nSem ? `${nSem} arquivo(s) criado(s) em ${rel(HW)}/` : 'nenhum novo (os existentes ficaram)'}`);
console.log(`  referências  ${nRef} arquivo(s) em ${rel(ref)}/`);
console.log(`  Git          ${exclude}`);
// Sobra da versão de sondagem do plugin: não atrapalha, mas o dev apaga.
if (existsSync(join(RAIZ, '.henriworks-probe'))) console.log('  sondagem     sobra da versão de sondagem: apague a pasta .henriworks-probe/ do repositório e ~/.henriworks-probe/ da sua pasta de usuário');
console.log('');

// 6. Mapa, hooks do Git e conferência com correções seguras.
const rodar = (args) => spawnSync(process.execPath, [join(bin, 'hwk.mjs'), ...args], { cwd: RAIZ, encoding: 'utf8', timeout: 6 * 60 * 1000 });
const pos = rodar(['pos-instalacao']);
if ((pos.stdout || pos.stderr || '').trim()) console.log((pos.stdout || pos.stderr).trim(), '\n');
const ini = rodar(['init', '--corrigir']);
process.stdout.write(ini.stdout || '');
if (ini.stderr) process.stderr.write(ini.stderr);
process.exit(ini.status ?? 1);
