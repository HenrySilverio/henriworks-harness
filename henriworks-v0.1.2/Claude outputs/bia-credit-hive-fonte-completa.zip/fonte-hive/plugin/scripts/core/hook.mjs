#!/usr/bin/env node
// HenriWorks - hook único do plugin. Sem dependência, Node 20+.
//
//   node "${PLUGIN_ROOT}/scripts/core/hook.mjs" <evento> [--agente <nome>]
//
// Roda em TODO chat do harness Copilot onde o plugin está instalado, com ou sem o fluxo no
// repositório. Nunca derruba a sessão: qualquer erro termina com "{}" e código 0 (sem decisão).
// O processo do hook não roda na pasta do repositório: a pasta certa vem no payload (cwd).
//
// Duas responsabilidades, separadas:
//   1. Coleta de uso (sempre): sessão, turno do agente principal ou de subagente, comando (só o nome),
//      skill (só o nome), ferramenta (nome e categoria), subagente, repositório, branch e ticket.
//      Grava em ~/.henriworks/uso/ (fora de qualquer repositório).
//   2. Guardas (só onde o repositório tem .henriworks/): veredito e archive imutáveis, portões humanos,
//      pacote literal do revisor, trava de arquivo entre fatias, mapa antes de busca.
//
// Nunca grava prompt, resposta, argumento de ferramenta, resultado nem texto de comando de terminal.

import { readFileSync, existsSync, statSync } from 'node:fs';
import { spawn, spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { join, basename, dirname, isAbsolute, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { USO_DIR, HW, config, lerJson, gravarJson, anexarJsonl, linhasDe, promptDoPacote, tocaParaTeste, barra, ticketDaBranch, versaoInstalada, PLUGIN_PADRAO } from './lib/comum.mjs';

const AQUI = dirname(fileURLToPath(import.meta.url));
const evento = process.argv[2] || '';
const agenteEscopo = process.argv.includes('--agente') ? process.argv[process.argv.indexOf('--agente') + 1] : null;
let saiu = false;
// Teste (init e smoke): nada de processo em segundo plano disputando os arquivos do teste.
const semFilhos = Boolean(process.env.HENRIWORKS_HOOK_TESTE);
const responder = (obj) => { if (!saiu) { saiu = true; process.stdout.write(JSON.stringify(obj)); } };
let ctx = null;
const negar = (motivo, tag) => {
  registrar({ decisao: 'negar', motivo: tag });
  responder({ permissionDecision: 'deny', permissionDecisionReason: `HenriWorks: ${motivo}` });
};

// Nome curto e seguro: comando, skill, agente. Qualquer outra coisa vira null (nunca conteúdo).
const nomeCurto = (v) => (typeof v === 'string' && /^[\w:.\-/]{1,100}$/.test(v) ? v : null);
const comandoDe = (texto) => {
  const m = typeof texto === 'string' ? texto.trimStart().match(/^\/([\w.\-]+(?::[\w.\-]+)?)(?=\s|$)/) : null;
  return m ? `/${m[1]}` : null;
};

// Comando "/<plugin>:<x>" deste plugin (nome no plugin.json do PLUGIN_ROOT, ou o padrão).
function comandoDoPlugin(cmd) {
  const raizP = process.env.PLUGIN_ROOT || process.env.CLAUDE_PLUGIN_ROOT;
  const nome = (raizP && lerJson(join(raizP, 'plugin.json'))?.name) || PLUGIN_PADRAO;
  return cmd.startsWith(`/${nome}:`);
}

function textos(v, out = []) {
  if (typeof v === 'string') out.push(v);
  else if (Array.isArray(v)) v.forEach((x) => textos(x, out));
  else if (v && typeof v === 'object') Object.values(v).forEach((x) => textos(x, out));
  return out;
}

function registrar(extra = {}) {
  if (!ctx || ctx.cfg.uso.coletar === false) return;
  try {
    const t = new Date().toISOString();
    const base = { t, ev: ctx.ev, sid: ctx.sid, repo: ctx.repo, branch: ctx.branch, ticket: ctx.ticket, ...(ctx.trace ? { trace: ctx.trace } : {}), ...(ctx.agente ? { agente: ctx.agente } : {}), ...(ctx.sub ? { sub: ctx.sub } : {}) };
    anexarJsonl(join(USO_DIR, 'eventos', `${t.slice(0, 7)}.jsonl`), { ...base, ...extra });
  } catch { /* coleta nunca atrapalha */ }
}

function sessao(sid) {
  const p = join(USO_DIR, 'sessoes', `${String(sid).replace(/[^\w.-]/g, '_')}.json`);
  return { p, s: lerJson(p, {}) };
}

function categoria(nome, args) {
  const n = nome.toLowerCase();
  if (/^skill$|load_skill|read_skill/.test(n)) return 'skill';
  if (/task|runsubagent|subagent|^agent$/.test(n)) return 'subagente';
  if (/^mcp[_:]|__/.test(n)) return 'mcp';
  if (/edit|create|write|patch|replace|insert|delete|remove|rename|move/.test(n)) return 'escrita';
  if (/bash|powershell|shell|terminal|execute|run_in|runin|command/.test(n)) {
    // Só o comando de terminal do próprio fluxo muda a categoria; o texto nunca é gravado.
    const tx = textos(args).join(' ');
    if (/henrimap\.mjs/.test(tx)) return 'mapa';
    if (/hwk\.mjs/.test(tx)) return 'hwk';
    return 'terminal';
  }
  if (/search|grep|find|codebase|semantic|glob|usages|list_code|^rg$/.test(n)) return 'busca';
  if (/read|view|open|fetch_file|get_file/.test(n)) return 'leitura';
  return 'outra';
}

const caminhoAlvo = (args) => {
  for (const k of ['filePath', 'file_path', 'path', 'target_file', 'uri', 'file']) if (typeof args?.[k] === 'string') return args[k];
  return null;
};

function gitEm(cwd, a) {
  const r = spawnSync('git', a, { cwd, encoding: 'utf8', timeout: 3000 });
  return r.status === 0 ? (r.stdout || '').trim() : null;
}

async function principal() {
  let bruto = '';
  try { if (!process.stdin.isTTY) bruto = readFileSync(0, 'utf8'); } catch { /* sem stdin */ }
  const e = JSON.parse(bruto || '{}');
  const cwdBruto = typeof e.cwd === 'string' && e.cwd ? e.cwd : process.cwd();
  const cwd = existsSync(cwdBruto) ? resolve(cwdBruto) : process.cwd();
  process.chdir(cwd);
  const raiz = gitEm(cwd, ['rev-parse', '--show-toplevel']);
  const base = raiz ? resolve(raiz) : cwd;
  const comFluxo = existsSync(join(base, HW));
  if (comFluxo && base !== cwd) process.chdir(base);

  const sid = e.session_id || e.sessionId || 'sem-sessao';
  const nome = String(e.tool_name || e.toolName || '');
  let args = e.tool_input ?? e.toolArgs ?? {};
  if (typeof args === 'string') { try { args = JSON.parse(args); } catch { args = { texto: args }; } }
  const cfg = config(base);

  // Repositório, branch e ticket: lidos uma vez por sessão, no sessionStart (ou no primeiro evento).
  const { p: pSes, s: ses } = sessao(sid);
  let { repo, branch, ticket } = ses;
  if (!repo || evento === 'sessionStart') {
    repo = basename(base);
    // symbolic-ref funciona também em repositório sem commit; HEAD destacado cai para null.
    branch = raiz ? gitEm(base, ['symbolic-ref', '--short', '-q', 'HEAD']) : null;
    ticket = ticketDaBranch(branch, cfg.ticket.padrao);
  }
  const sub = e.agentId || e.agent_id || e.parentAgentId ? { id: nomeCurto(e.agentId || e.agent_id), pai: nomeCurto(e.parentAgentId), tipo: nomeCurto(e.agentType || e.agent_type) } : null;
  const trace = (String(e.traceparent || '').match(/^[\da-f]{2}-([\da-f]{32})-/) || [])[1] || null;
  ctx = { ev: evento, sid, repo, branch, ticket, cfg, trace, agente: agenteEscopo, sub, agenteId: e.agent_id || e.agentId || null };

  // Canário: enquanto preparado e não conferido, registra o formato real dos eventos.
  const can = comFluxo ? lerJson(join(base, HW, 'estado', 'canario.json')) : null;
  const canAtivo = can && !can.conferidoEm && !process.env.HENRIWORKS_HOOK_TESTE;
  const regCanario = (dados) => { if (canAtivo) anexarJsonl(join(base, HW, 'estado', 'canario-hooks.jsonl'), { t: new Date().toISOString(), ev: evento, ...dados }); };

  if (evento === 'sessionStart') {
    gravarJson(pSes, { ...ses, inicio: ses.inicio || new Date().toISOString(), repo, branch, ticket, fluxo: comFluxo, origem: nomeCurto(e.source) });
    const raizP = process.env.PLUGIN_ROOT || process.env.CLAUDE_PLUGIN_ROOT;
    registrar({ origem: nomeCurto(e.source), comando: comandoDe(e.initialPrompt), fluxo: comFluxo, plugin: nomeCurto(raizP ? lerJson(join(raizP, 'plugin.json'))?.name : null) });
    regCanario({ campos: Object.keys(e) });
    // Núcleo copiado no repositório atrás da versão do plugin: o init copia de novo.
    const raizPlugin = process.env.PLUGIN_ROOT || process.env.CLAUDE_PLUGIN_ROOT;
    const inst = comFluxo ? versaoInstalada(base) : null;
    const doPlugin = raizPlugin ? lerJson(join(raizPlugin, 'plugin.json')) : null;
    // Contexto curto para qualquer agente (substitui o bloco que ficava no AGENTS.md): mapa antes de busca.
    const avisos = [];
    if (inst && doPlugin?.version && inst.versao !== doPlugin.version) avisos.push(`HenriWorks: the core copied into ${HW}/bin is ${inst.versao} and the installed plugin is ${doPlugin.version}. Tell the developer to run /${doPlugin.name || 'henriworks'}:init once to update it.`);
    if (comFluxo && existsSync(join(base, HW, 'mapa', 'graph.json'))) avisos.push(`This repository has a code map. Before searching or opening files to locate code, query it: node ${HW}/bin/henrimap.mjs query "<terms>" (also: explain <symbol>, affected <file>).`);
    if (avisos.length) responder({ additionalContext: avisos.join('\n') });
    // Envio diário e selo do dia anterior: em segundo plano, nunca segura o chat.
    try {
      if (semFilhos) throw new Error('teste'); const filho = spawn(process.execPath, [join(AQUI, 'uso.mjs'), 'selar'], { cwd: base, detached: true, stdio: 'ignore', windowsHide: true });
      filho.unref();
    } catch { /* sem selo agora; tenta na próxima sessão */ }
    return;
  }

  if (evento === 'userPromptSubmitted') {
    const turno = sub ? 'subagente' : 'principal';
    const comando = comandoDe(e.prompt);
    if (agenteEscopo || comando) {
      // Agente do fluxo nesta sessão: liga o "mapa antes de busca".
      const doFluxo = /^hwk/.test(agenteEscopo || '') || Boolean(comando && comandoDoPlugin(comando));
      gravarJson(pSes, { ...ses, repo, branch, ticket, ...(doFluxo ? { hwk: true } : {}), agentes: [...new Set([...(ses.agentes || []), ...(agenteEscopo ? [agenteEscopo] : [])])] });
    }
    registrar({ turno, ...(comando ? { comando } : {}) });
    return;
  }

  if (evento === 'subagentStart') {
    registrar({ subagente: nomeCurto(e.agentName || e.agent_name || e.agentType || e.agent_type), turno: 'inicio-subagente' });
    regCanario({ campos: Object.keys(e) });
    return;
  }

  if (evento === 'sessionEnd') {
    registrar({ motivo: nomeCurto(e.reason) });
    try {
      if (semFilhos) throw new Error('teste'); const filho = spawn(process.execPath, [join(AQUI, 'uso.mjs'), 'importar'], { cwd: base, detached: true, stdio: 'ignore', windowsHide: true });
      filho.unref();
    } catch { /* importa na próxima */ }
    return;
  }

  if (evento === 'postToolUse') {
    const cat = categoria(nome, args);
    const alvo = caminhoAlvo(args);
    if (comFluxo && cat === 'escrita' && alvo && existsSync(join(base, HW, 'mapa', 'graph.json'))) {
      const rel = barra(isAbsolute(alvo) ? relative(base, alvo) : alvo);
      if (!rel.startsWith('..') && !rel.startsWith(`${HW}/`) && !semFilhos) {
        const filho = spawn(process.execPath, [join(AQUI, 'henrimap.mjs'), 'atualizar', rel], { cwd: base, detached: true, stdio: 'ignore', windowsHide: true });
        filho.unref();
      }
    }
    return;
  }

  if (evento !== 'preToolUse') return;

  const cat = categoria(nome, args);
  const texto = textos(args).join('\n').replace(/\\/g, '/');
  const skill = cat === 'skill' ? nomeCurto(args?.name || args?.skill || args?.skillName || args?.skill_name) : null;
  const subTipo = cat === 'subagente' ? nomeCurto(args?.agent_type || args?.agentType || args?.subagent_type || args?.agentName) : null;
  const mcp = cat === 'mcp' ? nomeCurto((nome.match(/^mcp[_:]+([^_:]+)|^([^_]+)__/) || []).slice(1).find(Boolean)) : null;
  registrar({ ferramenta: nomeCurto(nome), cat, ...(skill ? { skill } : {}), ...(subTipo ? { chama: subTipo } : {}), ...(mcp ? { mcp } : {}) });
  if (!comFluxo) return;
  if (cat === 'mapa' || cat === 'hwk' || /^hwk/.test(agenteEscopo || '')) {
    if (!ses.hwk) gravarJson(pSes, { ...lerJson(pSes, {}), hwk: true });
  }

  // Canário: formato real da chamada de subagente, para a conferência do pacote.
  if (cat === 'subagente') {
    const strs = Object.entries(args || {}).filter(([, v]) => typeof v === 'string');
    const campoPrompt = strs.sort((a, b) => b[1].length - a[1].length)[0]?.[0] || null;
    regCanario({ subagente: true, ferramenta: nome, campos: Object.keys(args || {}), campoPrompt });
  } else regCanario({});

  // 1. Registros imutáveis: veredito, revisão de spec e mudança arquivada.
  const imutavel = /\.henriworks\/changes\/(?:[^\s"'`]*\/(?:revisao|revisao-spec)\/|archive\/)/;
  const escreveNoTerminal = /(>|\brm\b|\bmv\b|\bcp\b|sed\s+-i|\btee\b|Set-Content|Add-Content|Out-File|Remove-Item|Move-Item|Copy-Item|\bdel\b)/i;
  if (cat === 'escrita' && imutavel.test(texto)) return negar('verdicts, spec reviews and archived changes are never edited. A new verdict goes through: node .henriworks/bin/hwk.mjs gravar-veredito.', 'imutavel');
  if (['terminal', 'hwk', 'mapa'].includes(cat) && imutavel.test(texto) && escreveNoTerminal.test(texto)) return negar('the terminal does not write into verdicts or archived changes.', 'imutavel');

  // 1b. Descartar apaga a mudança: decisão do dev, no terminal dele.
  if (['terminal', 'hwk'].includes(cat) && /hwk\.mjs["']?\s+descartar\b[^\n]*--aplicar/.test(texto)) {
    return negar('discarding deletes the change and its state: only the developer runs --aplicar, in their own terminal. Show the preview and stop.', 'descartar');
  }

  // 1c. Portões humanos: aprovar a spec, aceitar revisão reprovada, rodada além do teto, OK do QA.
  if (['terminal', 'hwk'].includes(cat) && (/hwk\.mjs["']?\s+(aprovar-spec|aceitar-revisao|rodada-extra|qa-ok)\b/.test(texto) || /(hwk|licoes)\.mjs["']?\s+(licoes\s+)?aprovar\b/.test(texto))) {
    return negar('approving the spec, accepting a failed review, releasing an extra review round, recording the QA sign-off and approving a lesson are human decisions: show the command and let the developer run it in their own terminal.', 'portao');
  }

  // 2. Git no agente, quando o time pede trava técnica.
  if (['terminal', 'hwk', 'mapa'].includes(cat) && cfg.bloquearGitNoAgente === true && /\bgit\s+(-\S+\s+)*(commit|push|merge|rebase|reset|cherry-pick|revert|tag|checkout\s+-b|switch\s+(-c|--create)|branch\s+(-[dDmM]|--delete|--move))\b/.test(texto)) {
    return negar('this flow does not write to Git. The developer reviews the diff and commits.', 'git');
  }

  // 3. Pacote literal do revisor (isolamento C). O revisor chega pelo nome completo (<plugin>:hwk-gf).
  if (cat === 'subagente' && cfg.revisaoIsolada.conferirPacote === 'negar') {
    const alvoGf = (subTipo && /(^|:)hwk-gf$/.test(subTipo)) || /(^|[\s:"'`])hwk-gf\b/.test(texto);
    if (alvoGf) {
      const campo = cfg.revisaoIsolada.campoPrompt;
      const prompt = (campo && typeof args[campo] === 'string' ? args[campo] : Object.values(args || {}).filter((v) => typeof v === 'string').sort((a, b) => b.length - a.length)[0] || '').trim();
      const m = prompt.match(/^Review package: (\S+?)\. Read that file/);
      const pReg = join(base, HW, 'estado', 'pacotes.jsonl');
      const reg = linhasDe(existsSync(pReg) ? readFileSync(pReg, 'utf8') : '').filter(Boolean).map((l) => JSON.parse(l));
      const r = m && reg.filter((x) => x.arquivo === m[1]).pop();
      const hAtual = r && existsSync(join(base, r.arquivo)) ? createHash('sha256').update(readFileSync(join(base, r.arquivo), 'utf8')).digest('hex') : null;
      if (!m || prompt !== promptDoPacote(m[1]) || !r || hAtual !== r.hash) {
        return negar('the reviewer only receives the literal prompt printed by "node .henriworks/bin/hwk.mjs pacote-revisao", with nothing added, and the package must not have been edited.', 'pacote');
      }
    }
  }

  // 4. Trava de arquivo entre fatias (opcional): só subagente com fatia reivindicada.
  if (ctx.agenteId) {
    const pAg = join(base, HW, 'estado', 'agentes.json');
    const mapa = lerJson(pAg, {});
    const rv = texto.match(/hwk\.mjs\s+reivindicar\s+([A-Za-z0-9-]+)\s+(\d{2})/);
    if (cat === 'hwk' && rv) {
      mapa[ctx.agenteId] = { change: rv[1], fatia: rv[2] };
      gravarJson(pAg, mapa);
    }
    const alvo = caminhoAlvo(args);
    const minha = mapa[ctx.agenteId];
    if (cat === 'escrita' && alvo && minha) {
      const rel = barra(isAbsolute(alvo) ? relative(base, alvo) : alvo);
      anexarJsonl(join(base, HW, 'estado', 'edicoes.jsonl'), { t: new Date().toISOString(), change: minha.change, fatia: minha.fatia, arquivo: rel });
      if (cfg.sobreposicao.travaArquivo === 'negar') {
        const ativas = lerJson(join(base, HW, 'estado', 'reivindicacoes.json'), { ativas: [] }).ativas;
        const outra = ativas.find((a) => a.change === minha.change && a.fatia !== minha.fatia && a.toca.some((t) => tocaParaTeste(t)(rel)));
        if (outra) return negar(`${rel} belongs to slice ${outra.fatia}, which is in progress. Continue with the other tasks and record the dependency; the coordinator opens the decision card.`, 'trava');
      }
    }
  }

  // 5. Mapa antes de busca, numa sessão do fluxo.
  const sesAtual = lerJson(pSes, {});
  if (cat === 'busca' && sesAtual.hwk && cfg.mapa.primeiroAntesDeBusca === 'negar-uma-vez' && !sesAtual.mapaNegado) {
    const marca = join(base, HW, 'estado', 'mapa-consultado');
    const consultou = existsSync(marca) && sesAtual.inicio && statSync(marca).mtimeMs >= Date.parse(sesAtual.inicio);
    if (!consultou) {
      gravarJson(pSes, { ...sesAtual, mapaNegado: true });
      return negar('query the map before scanning files: node .henriworks/bin/henrimap.mjs query "<term>" (or explain, affected). This denial happens once per session.', 'mapa-primeiro');
    }
  }
}

try {
  await principal();
} catch {
  /* sem decisão */
}
if (!saiu) process.stdout.write('{}');
process.exit(0);
