## HenriWorks Engineering Harness

Pedido simples se resolve direto, sem briefing nem mudança: teste quebrado, documentação, configuração,
lint, texto, correção pequena em poucos arquivos.

Quando o pedido tiver comportamento novo visível para o usuário, mexer em mais de uma camada, mudar
contrato entre camadas, envolver requisito regulatório ou de segurança, ou tocar muitos arquivos,
sugira o HenriWorks **uma vez, sem bloquear**: `/hwk-start` com o pedido diz o próximo passo. Se o dev
pedir para fazer direto, faça.

Os agentes `hwk-*` só agem quando selecionados. Fora deles, `.henriworks/` é só consulta: não crie nem
edite arquivos ali, a não ser o que um comando `/hwk-*` chamado pelo dev autorize por escrito. Se o repositório também tem o HenriSpec, `.sdd/` continua dele: o HenriWorks só lê
`.sdd/specs` e `.sdd/decisoes`, nunca escreve.

Antes de varrer arquivos para achar onde algo está, consulte o mapa:
`node .henriworks/bin/henrimap.mjs query "<termos>"`.

Antes de criar ou editar um arquivo, veja se alguma instrução em `.github/instructions/` cobre o caminho
dele (`applyTo`). Se cobrir e ela ainda não estiver no contexto, leia a instrução antes de escrever.

Marcador de teste do HenriWorks: hwk-sentinela-agents.
