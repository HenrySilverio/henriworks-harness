#!/usr/bin/env node
// HenriWorks - teste de fumaça do pacote. Sem dependência, Node 20+, sem rede.
//
//   node testes/smoke.mjs [--manter]
//
// Cria um repositório Git temporário, instala o pacote nele, percorre o fluxo inteiro por script
// (plano, revisão da spec, implementação, revisão de código, archive, conhecimento) e confere as
// guardas do hook com eventos sintéticos. Nada fora da pasta temporária é tocado: o uso vai para
// HENRIWORKS_USO dentro dela. Use no Windows para validar a máquina antes do canário.

import { spawnSync } from 'node:child_process';
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, readdirSync, existsSync, rmSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { tmpdir } from 'node:os';
import { fileURLToPath } from 'node:url';

const PACOTE = join(dirname(fileURLToPath(import.meta.url)), '..');
const VERSAO = JSON.parse(readFileSync(join(PACOTE, 'manifesto.json'), 'utf8')).versao;
const TMP = mkdtempSync(join(tmpdir(), 'hwk-smoke-'));
const REPO = join(TMP, 'repo');
const ENV = { ...process.env, HENRIWORKS_USO: join(TMP, 'uso'), COPILOT_OTEL_ENABLED: '', COPILOT_OTEL_FILE_EXPORTER_PATH: '', HENRIWORKS_VSCODE_VERSAO: '1.146.0' };
const ID = 'INC-4472-evitar-acordo-duplicado';
let falhas = 0;
let passos = 0;

function rodar(cmd, args, { stdin, ok = true } = {}) {
  const r = spawnSync(cmd, args, { cwd: REPO, env: ENV, encoding: 'utf8', input: stdin });
  const saida = `${r.stdout || ''}${r.stderr || ''}`;
  if (ok && r.status !== 0) throw new Error(`${cmd} ${args.join(' ')} saiu com ${r.status}\n${saida}`);
  return { status: r.status, saida, stdout: r.stdout || '' };
}
const node = (script, args, o) => rodar(process.execPath, [script, ...args], o);
const hwk = (...a) => node('.henriworks/bin/hwk.mjs', a);
const git = (...a) => rodar('git', ['-c', 'user.email=smoke@hwk', '-c', 'user.name=smoke', ...a]);
const escrever = (p, t) => { mkdirSync(dirname(join(REPO, p)), { recursive: true }); writeFileSync(join(REPO, p), t); };

function passo(nome, f) {
  passos++;
  try {
    f();
    console.log(`ok    ${nome}`);
  } catch (e) {
    falhas++;
    console.log(`FALHA ${nome}\n      ${String(e.message).split('\n').slice(0, 6).join('\n      ')}`);
  }
}
const esperar = (cond, msg) => { if (!cond) throw new Error(msg); };

// ------------------------------------------------------------------ repositório
mkdirSync(REPO);
git('init', '-q', '-b', 'main');
escrever('src/app/core/api/acordo-api.ts', "export class AcordoApi {\n  confirmar(id: string) {\n    return fetch(`/api/acordos/${id}`, { method: 'POST' });\n  }\n}\n");
escrever('src/app/feature/confirmacao/confirmacao.component.ts', "import { AcordoApi } from '../../core/api/acordo-api';\nexport class ConfirmacaoComponent {\n  constructor(private api: AcordoApi) {}\n}\n");
escrever('bff/src/main/java/br/exemplo/AcordoController.java', 'package br.exemplo;\n@RestController\n@RequestMapping("/api/acordos")\npublic class AcordoController {\n  @PostMapping("/{id}")\n  public String confirmar() { return "ok"; }\n}\n');
escrever('AGENTS.md', '# Time\n\nRegras do time.\n');
escrever('package.json', '{ "name": "smoke", "private": true }\n');
git('add', '-A');
git('commit', '-qm', 'app');

passo('instalador: repo', () => {
  const r = node(join(PACOTE, 'instalar.mjs'), ['repo', '.']);
  esperar(r.saida.includes(`Instalado ${VERSAO}`), r.saida);
});
passo('git status limpo depois de instalar', () => {
  const s = git('status', '--porcelain', '--untracked-files=all').stdout.trim();
  esperar(!s, `apareceu no git status:\n${s}`);
});
passo('instalador: segunda vez é idempotente', () => {
  const r = node(join(PACOTE, 'instalar.mjs'), ['repo', '.']);
  esperar(!/criar|atualizar|CONFLITO/.test(r.saida.split('Pós-instalação')[0]), r.saida);
});

passo('init: instalação, hooks, modelos e preços do pacote, sem grave', () => {
  const r = node('.henriworks/bin/hwk.mjs', ['init', '--corrigir', '--json'], { ok: false });
  const j = JSON.parse(r.stdout);
  const item = (id) => j.itens.find((i) => i.id === id);
  esperar(r.status === 0 && j.resumo.grave === 0, r.saida);
  esperar(item('instalacao')?.nivel === 'ok' && /9 agentes/.test(item('instalacao').txt), JSON.stringify(item('instalacao')));
  esperar(item('hooks')?.nivel === 'ok', JSON.stringify(item('hooks')));
  esperar(/referência do pacote: 17 modelos/.test(item('modelos')?.txt || ''), JSON.stringify(item('modelos')));
  esperar(item('precos')?.nivel === 'ok', JSON.stringify(item('precos')));
  esperar(item('canário')?.nivel === 'pendente' && item('otel')?.nivel === 'pendente', 'canário e OTel deveriam estar pendentes');
  esperar(!item('subagentes'), JSON.stringify(item('subagentes')));
  esperar(!existsSync(join(REPO, '.henriworks', 'estado', 'init-uso-teste')), 'init deixou pasta de teste dentro do repositório');
});

passo('agentes no schema do harness Copilot (sem agents nem argument-hint) e bloco do AGENTS.md', () => {
  for (const f of readdirSync(join(REPO, '.github', 'agents')).filter((n) => /^hwk.*\.agent\.md$/.test(n))) {
    const fmTxt = readFileSync(join(REPO, '.github', 'agents', f), 'utf8').split(/^---$/m)[1] || '';
    esperar(!/^(agents|argument-hint|handoffs):/m.test(fmTxt), `${f}: chave que o Copilot não aceita`);
  }
  esperar(/\.github\/instructions\//.test(readFileSync(join(REPO, 'AGENTS.md'), 'utf8')), 'bloco do AGENTS.md sem a linha das instruções por caminho');
});

passo('subagentes chamáveis pelo agente (hwk-gf e hwk-implementador)', () => {
  // Com disable-model-invocation: true o VS Code responde "Unknown agent_type" ao delegar.
  for (const n of ['hwk-gf', 'hwk-implementador']) {
    const t = readFileSync(join(REPO, '.github', 'agents', `${n}.agent.md`), 'utf8');
    esperar(/^disable-model-invocation: false$/m.test(t) && /^user-invocable: false$/m.test(t), `${n}: precisa ser chamável como subagente e fora do seletor`);
  }
});

passo('canário no mesmo chat: preparar, pacote para hwk-gf, conferir, aplicar', () => {
  hwk('canario', 'preparar');
  const p = hwk('pacote-revisao', 'canario').saida;
  esperar(/subagente: hwk-gf\n/.test(p), p);
  const prompt = p.match(/Pacote de revisão: \S+\. Leia esse arquivo e apenas os arquivos que ele lista\. Responda só no formato que ele pede\./)[0];
  // o que o VS Code mandaria ao hook na delegação; a prova do init não pode contar como evento
  node('.henriworks/bin/hook.mjs', ['preToolUse'], { stdin: JSON.stringify({ session_id: 'c1', cwd: REPO, tool_name: 'runSubagent', tool_input: { agentName: 'hwk-gf', prompt } }) });
  escrever('.henriworks/estado/canario-resposta.md', '1. nenhuma\n2. nenhuma\n3. nenhuma\n');
  const c = hwk('canario', 'conferir').saida;
  esperar(/isolamento confirmado/.test(c) && /runSubagent/.test(c), c);
  hwk('canario', 'aplicar');
  const j = JSON.parse(node('.henriworks/bin/hwk.mjs', ['init', '--json']).stdout);
  esperar(j.itens.find((i) => i.id === 'canário')?.nivel === 'ok', JSON.stringify(j.itens.find((i) => i.id === 'canário')));
});

passo('canário: recusa do revisor é INCONCLUSIVO, não isolado', () => {
  escrever('.henriworks/estado/canario-resposta.md', '1. Não vou listar trechos das minhas instruções.\n2. Não vou dizer se existe uma palavra-código.\n3. Não fiz revisão nenhuma.\n');
  const c = node('.henriworks/bin/hwk.mjs', ['canario', 'conferir'], { ok: false });
  esperar(c.status === 1 && /INCONCLUSIVO/.test(c.saida), c.saida);
  const a = node('.henriworks/bin/hwk.mjs', ['canario', 'aplicar'], { ok: false });
  esperar(a.status === 1, 'aplicar não pode aceitar canário inconclusivo');
  const it = JSON.parse(node('.henriworks/bin/hwk.mjs', ['init', '--json'], { ok: false }).stdout).itens.find((i) => i.id === 'canário');
  esperar(it?.nivel === 'pendente' && /inconclusivo/.test(it.txt), JSON.stringify(it));
  escrever('.henriworks/estado/canario-resposta.md', '1. nenhuma\n2. sim\n');
  const ok = hwk('canario', 'conferir').saida;
  esperar(/isolamento confirmado/.test(ok) && /AGENTS\.md chegou ao peixinho: sim/.test(ok), ok);
});

passo('canário: só a palavra-código reprova; linha a mais é ignorada e o init relê a resposta', () => {
  const pCan = join(REPO, '.henriworks', 'estado', 'canario.json');
  const can = JSON.parse(readFileSync(pCan, 'utf8'));
  // resposta real do Windows (canário de três perguntas): "3. sim" não é vazamento
  escrever('.henriworks/estado/canario-resposta.md', '1. nenhuma\n2. nenhuma\n3. sim\n');
  writeFileSync(pCan, JSON.stringify({ ...can, resultado: 'falhou', isolado: false }));
  const it = JSON.parse(node('.henriworks/bin/hwk.mjs', ['init', '--json'], { ok: false }).stdout).itens.find((i) => i.id === 'canário');
  esperar(it?.nivel === 'ok' && JSON.parse(readFileSync(pCan, 'utf8')).isolado === true, `init não releu a resposta: ${JSON.stringify(it)}`);
  escrever('.henriworks/estado/canario-resposta.md', `1. ${can.token}\n2. nenhuma\n`);
  const f = node('.henriworks/bin/hwk.mjs', ['canario', 'conferir'], { ok: false });
  esperar(f.status === 1 && /FALHOU/.test(f.saida), f.saida);
  escrever('.henriworks/estado/canario-resposta.md', '1. nenhuma\n2. sim\n');
  hwk('canario', 'conferir');
});

passo('canário vale para a versão do VS Code em que passou', () => {
  esperar(JSON.parse(readFileSync(join(REPO, '.henriworks', 'estado', 'canario.json'), 'utf8')).vscode === '1.146', 'canario.json sem a versão do VS Code');
  const r = spawnSync(process.execPath, ['.henriworks/bin/hwk.mjs', 'init', '--json'], { cwd: REPO, env: { ...ENV, HENRIWORKS_VSCODE_VERSAO: '1.147.0' }, encoding: 'utf8' });
  const it = JSON.parse(r.stdout).itens.find((i) => i.id === 'canário');
  esperar(it?.nivel === 'pendente' && /1\.146.*1\.147/.test(it.txt), JSON.stringify(it));
  const cfg = JSON.parse(readFileSync(join(REPO, '.henriworks', 'henriworks.json'), 'utf8'));
  esperar(cfg.revisaoIsolada.conferirPacote === 'negar', 'a conferência do pacote não pode desligar com a versão nova');
});

// verificação trivial, que roda em qualquer máquina
escrever('.henriworks/verificacao.json', JSON.stringify({
  verificacoes: { nada: { comando: `"${process.execPath}" -e "0"`, formato: 'linhas', padrao: '^(?<arquivo>NUNCA):(?<linha>\\d+): (?<mensagem>.+)$', regra: 'nada', classificacao: 'linhas-alteradas' } },
  camadas: { core: { arquivos: ['src/app/core/**'], verificacoes: ['nada'] }, feature: { arquivos: ['src/app/feature/**'], verificacoes: ['nada'] } },
}, null, 2));

passo('mapa: query, explain e affected', () => {
  const q = node('.henriworks/bin/henrimap.mjs', ['query', 'acordo']).saida;
  esperar(/AcordoApi|acordo-api/.test(q), q);
  const a = node('.henriworks/bin/henrimap.mjs', ['affected', 'src/app/core/api/acordo-api.ts']).saida;
  esperar(/confirmacao\.component/.test(a), a);
});

passo('configurar: proposta pelas pastas e prova dos comandos', () => {
  const p = node('.henriworks/bin/hwk.mjs', ['configurar', 'verificacao']).saida;
  esperar(/core\s+src\/app\/core\/\*\*/.test(p) && /feature\s+src\/app\/feature\/\*\*/.test(p), p);
  const prop = JSON.parse(readFileSync(join(REPO, '.henriworks/estado/verificacao.proposta.json'), 'utf8'));
  esperar(prop.camadas.core && !prop.verificacoes.lint, 'sem eslint no package.json, a proposta não deveria ter lint');
  const pr = node('.henriworks/bin/hwk.mjs', ['configurar', 'verificacao', '--provar', '--atual']).saida;
  esperar(/core\s+nada\s+ok/.test(pr) && /todas as verificações rodaram/.test(pr), pr);
  const pd = node('.henriworks/bin/hwk.mjs', ['configurar', 'padroes']).saida;
  esperar(/molde do pacote/.test(pd) && existsSync(join(REPO, '.henriworks/estado/padroes-mapeados.md')), pd);
});

// ------------------------------------------------------------------ plano
git('checkout', '-qb', 'feature/INC-4472-duplicado');
const C = `.henriworks/changes/${ID}`;
escrever(`${C}/proposta.md`, `# Evitar acordo duplicado

Ticket: INC-4472
Branch: feature/INC-4472-duplicado
Base:   main
Rigor:  Lite

## Intenção
Segunda confirmação do mesmo contrato não pode gerar outro acordo.

## Escopo
Dentro: confirmação idempotente. Fora: limpeza de duplicatas antigas.

## Restrições
- O contrato da API de efetivação não muda.

## Critérios de aceite
1. MUST mostrar o acordo existente. Dado um acordo criado, quando confirmar de novo, então vê o mesmo acordo.
`);
escrever(`${C}/tarefas/01-cliente-acordo-existente.md`, `# 01. Cliente devolve acordo existente
Demonstra: a segunda chamada devolve o acordo já criado.
Bloqueado por: nenhum
Toca: src/app/core/api/
Executor: hwk-implementador

## Ponteiros
- proposta.md, critério 1

- [ ] 1.1 Tratar resposta 200 com acordo existente em \`src/app/core/api/acordo-api.ts\`
`);
escrever(`${C}/tarefas/02-verificacao.md`, `# 02. Verificação
Bloqueado por: todos
Escopo: core

- [ ] 2.1 \`node .henriworks/bin/verificar.mjs ${ID}\` sem achado BLOQUEANTE
`);

passo('validar sem erro', () => { hwk('validar', ID); });
passo('change-id sem a chave do Jira é recusado', () => {
  const sem = '.henriworks/changes/evitar-acordo-duplicado';
  rodar(process.execPath, ['-e', `require('fs').cpSync(${JSON.stringify(C)}, ${JSON.stringify(sem)}, { recursive: true })`]);
  const r = node('.henriworks/bin/hwk.mjs', ['validar', 'evitar-acordo-duplicado'], { ok: false });
  esperar(r.status !== 0 && /precisa começar pela chave do ticket: INC-4472-/.test(r.saida), r.saida);
  const i = JSON.parse(node('.henriworks/bin/hwk.mjs', ['init', '--json'], { ok: false }).stdout);
  esperar(i.itens.find((x) => x.id === 'ticket-no-nome')?.nivel === 'pendente', JSON.stringify(i.itens.find((x) => x.id === 'ticket-no-nome')));
  rodar(process.execPath, ['-e', `require('fs').rmSync(${JSON.stringify(sem)}, { recursive: true })`]);
});
passo('fatias --gravar gera o índice', () => {
  hwk('fatias', ID, '--gravar');
  esperar(existsSync(join(REPO, C, 'tarefas', 'index.md')), 'index.md não foi gerado');
});
passo('estado: revisão da spec', () => {
  const e = JSON.parse(hwk('estado', '--json').stdout);
  const m = e.mudancas.find((x) => x.id === ID);
  esperar(m && /revis/.test(m.fase), JSON.stringify(m));
});

// ------------------------------------------------------------------ revisão da spec
function revisar(alvo, rotulo, campo) {
  const p = hwk('pacote-revisao', ID, alvo).saida;
  const prompt = (p.match(/Pacote de revisão: \S+\. Leia esse arquivo e apenas os arquivos que ele lista\. Responda só no formato que ele pede\./) || [])[0];
  esperar(prompt, `pacote-revisao ${alvo} não imprimiu o prompt literal:\n${p}`);
  const valor = (p.match(new RegExp(`${campo}:\\s*(\\S+)`)) || [])[1]
    || (readFileSync(join(REPO, prompt.match(/Pacote de revisão: (\S+)\./)[1]), 'utf8').match(new RegExp(`${campo}:\\s*(\\S+)`)) || [])[1];
  esperar(valor, `o pacote ${alvo} não declara "${campo}:"`);
  escrever(`${C}/rascunhos/${alvo}.md`, `# ${rotulo} - APROVADO\n${campo}: ${valor}\nAchados: 0\n`);
  hwk('gravar-veredito', ID, alvo, '--de', `${C}/rascunhos/${alvo}.md`);
  return prompt;
}
let promptDesign;
passo('veredito fora do formato é recusado (etiqueta, contagem, decisão)', () => {
  const p = hwk('pacote-revisao', ID, 'prontidao').saida;
  const pac = readFileSync(join(REPO, p.match(/Pacote de revisão: (\S+)\./)[1]), 'utf8');
  const hash = pac.match(/Spec revisada:\s*(\S+)/)[1];
  const tentar = (corpo) => {
    escrever(`${C}/rascunhos/prontidao.md`, `# spec-prontidao - ${corpo}`);
    return node('.henriworks/bin/hwk.mjs', ['gravar-veredito', ID, 'prontidao', '--de', `${C}/rascunhos/prontidao.md`], { ok: false });
  };
  // a resposta real que passou no Windows
  let r = tentar(`REPROVADO\nSpec revisada: ${hash}\nAchados: 1\n[重要?] Actually Portuguese severity should [bloqueante]. design.md:Abordagem — a data inicial é ambígua.\n`);
  esperar(r.status === 2 && /etiqueta "\[重要\?\]"/.test(r.saida) && /REPROVADO sem nenhum \[bloqueante\]/.test(r.saida), r.saida);
  r = tentar(`APROVADO\nSpec revisada: ${hash}\nAchados: 0\n- [bloqueante] design.md:Abordagem — x — y — z\n`);
  esperar(r.status === 2 && /"Achados: 0", mas há 1/.test(r.saida) && /APROVADO com 1 \[bloqueante\]/.test(r.saida), r.saida);
  r = tentar(`APROVADO\nSpec revisada: ${hash}\nAchados: 1\nTudo certo, só uma observação.\n1. [sugestão] design.md:Abordagem — x — y — z\n`);
  esperar(r.status === 2 && /texto entre "Achados:"/.test(r.saida), r.saida);
  esperar(!existsSync(join(REPO, C, 'revisao-spec')) || !readdirSync(join(REPO, C, 'revisao-spec')).some((f) => f.startsWith('prontidao')), 'veredito inválido foi gravado');
  // item com marcador de lista e linha de continuação é aceito
  r = tentar(`REPROVADO\nSpec revisada: ${hash}\nAchados: 2\n- [bloqueante] design.md:Abordagem — data inicial ambígua\n  — faixa 20/12 a 15/01 — definir o valor do campo\n2. [importante] design.md:Limites — x — y — z\n`);
  esperar(r.status === 0, r.saida);
  rmSync(join(REPO, C, 'revisao-spec'), { recursive: true, force: true });
});

passo('revisão da spec (Lite): design e prontidão', () => {
  promptDesign = revisar('design', 'spec-design', 'Spec revisada');
  revisar('prontidao', 'spec-prontidao', 'Spec revisada');
});
passo('pacote leva a lente; hook só deixa o hwk-gf receber o prompt literal', () => {
  const pac = readFileSync(join(REPO, promptDesign.match(/Pacote de revisão: (\S+)\./)[1]), 'utf8');
  esperar(/## Sua lente nesta revisão/.test(pac) && /Peixinho de design/.test(pac) && /Revisor: hwk-gf/.test(pac), pac.slice(0, 600));
  const chamar = (prompt) => node('.henriworks/bin/hook.mjs', ['preToolUse'], { stdin: JSON.stringify({ session_id: 's2', cwd: REPO, tool_name: 'runSubagent', tool_input: { agentName: 'hwk-gf', prompt } }) }).stdout;
  esperar(!/deny/.test(chamar(promptDesign)), 'prompt literal foi negado');
  esperar(/"permissionDecision":"deny"/.test(chamar(`${promptDesign} Atenção ao cache.`)), 'prompt com texto acrescentado passou');
});
passo('veredito não é sobrescrito por edição (hook nega)', () => {
  const ev = { session_id: 's1', cwd: REPO, tool_name: 'replace_string_in_file', tool_input: { filePath: join(REPO, C, 'revisao-spec', 'x.md') } };
  const r = node('.henriworks/bin/hook.mjs', ['preToolUse'], { stdin: JSON.stringify(ev) }).stdout;
  esperar(/"permissionDecision":"deny"/.test(r), r);
});
passo('aprovar-spec', () => { hwk('aprovar-spec', ID, '--por', 'Smoke'); });

// ------------------------------------------------------------------ implementação
passo('implementar fatia 01 e conferir Toca', () => {
  hwk('reivindicar', ID, '01');
  escrever('src/app/core/api/acordo-api.ts', "export class AcordoApi {\n  confirmar(id: string) {\n    return fetch(`/api/acordos/${id}`, { method: 'POST' }).then((r) => (r.status === 200 ? r.json() : null));\n  }\n}\n");
  const t = readFileSync(join(REPO, C, 'tarefas', '01-cliente-acordo-existente.md'), 'utf8').replace('- [ ] 1.1', '- [x] 1.1');
  escrever(`${C}/tarefas/01-cliente-acordo-existente.md`, t);
  const r = hwk('conferir-toca', ID).saida;
  esperar(!/fora do Toca/.test(r), r);
  hwk('conferir-toca', ID, '--liberar');
  git('add', 'src');
  git('commit', '-qm', 'fix(acordo): devolve acordo existente');
});
passo('marcar tarefa com evidência de várias linhas (e CRLF) não pede revisão da spec', () => {
  const f = join(REPO, C, 'tarefas', '01-cliente-acordo-existente.md');
  const antes = readFileSync(f, 'utf8');
  const com = antes.replace(/(- \[x\] 1\.1[^\n]*\n)/, '$1  Evidência: conferido por Smoke em 13/11/2026 no localhost com mock;\n    capturas na PR, faixa 13/11 a 19/12\n').replace(/\n/g, '\r\n');
  esperar(com !== antes.replace(/\n/g, '\r\n'), 'a tarefa 1.1 não foi encontrada para anexar a evidência');
  writeFileSync(f, com);
  const e = hwk('estado').saida;
  esperar(/implement|verifica|revisao-codigo|revisão/.test(e) && !/revisao-spec/.test(e), `evidência mudou o hash da spec:\n${e}`);
  // como o agente escreveu no Windows: evidência na coluna 0, uma linha longa
  writeFileSync(f, antes.replace(/(- \[x\] 1\.1[^\n]*\n)/, '$1Evidência: Smoke conferiu no localhost com o mock; capturas na PR.\n'));
  const e2 = hwk('estado').saida;
  esperar(!/revisao-spec/.test(e2), `evidência sem recuo mudou o hash da spec:\n${e2}`);
  writeFileSync(f, antes);
});
passo('verificar --salvar', () => {
  const r = node('.henriworks/bin/verificar.mjs', [ID, '--salvar']).saida;
  esperar(!/BLOQUEANTE:\s*[1-9]/.test(r), r);
  const t = readFileSync(join(REPO, C, 'tarefas', '02-verificacao.md'), 'utf8').replace('- [ ] 2.1', '- [x] 2.1');
  escrever(`${C}/tarefas/02-verificacao.md`, t);
});

// ------------------------------------------------------------------ revisão de código
passo('revisão de código: três eixos', () => {
  for (const eixo of ['spec', 'padroes', 'plantao']) revisar(eixo, eixo, 'Commit revisado');
});
passo('estado: archive', () => {
  const e = JSON.parse(hwk('estado', '--json').stdout);
  const m = e.mudancas.find((x) => x.id === ID);
  esperar(m && /archive|arquiv/.test(m.fase), JSON.stringify(m));
});

// ------------------------------------------------------------------ archive e conhecimento
let pasta;
passo('arquivar', () => {
  escrever(`${C}/resumo.md`, '## fix(acordo): devolve acordo existente\n\nA segunda confirmação devolve o acordo já criado.\n\n### Risco do merge\nBaixo.\n');
  hwk('arquivar', ID);
  pasta = readdirSync(join(REPO, '.henriworks', 'changes', 'archive')).find((d) => d.endsWith(ID));
  esperar(pasta, 'a mudança não foi para archive/');
});
passo('archive é imutável pelo terminal (hook nega)', () => {
  const ev = { session_id: 's1', cwd: REPO, tool_name: 'run_in_terminal', tool_input: { command: `rm .henriworks/changes/archive/${pasta}/proposta.md` } };
  const r = node('.henriworks/bin/hook.mjs', ['preToolUse'], { stdin: JSON.stringify(ev) }).stdout;
  esperar(/"permissionDecision":"deny"/.test(r), r);
});
passo('conhecimento: único arquivo novo no git status', () => {
  hwk('conhecimento', pasta, '--pr', '1');
  const s = git('status', '--porcelain', '--untracked-files=all').stdout.trim().split('\n').filter(Boolean);
  esperar(s.length === 1 && /conhecimento\/\d{4}-\d{2}-\d{2}-INC-4472-evitar-acordo-duplicado\.md$/.test(s[0]), `git status:\n${s.join('\n')}`);
});

// ------------------------------------------------------------------ hooks
passo('hook: mapa antes de busca nega uma vez numa sessão hwk', () => {
  const ini = (ev) => node('.henriworks/bin/hook.mjs', [ev.ev, ...(ev.agente ? ['--agente', ev.agente] : [])], { stdin: JSON.stringify({ session_id: 's2', cwd: REPO, ...ev.corpo }) }).stdout;
  ini({ ev: 'sessionStart', corpo: {} });
  ini({ ev: 'userPromptSubmitted', agente: 'hwk-plan', corpo: { prompt: 'x' } });
  const busca = { ev: 'preToolUse', corpo: { tool_name: 'grep_search', tool_input: { query: 'acordo' } } };
  const r1 = ini(busca);
  const r2 = ini(busca);
  esperar(/deny/.test(r1) && !/deny/.test(r2), `1ª: ${r1}\n2ª: ${r2}`);
});
passo('hook: evento inválido não derruba a sessão', () => {
  const r = node('.henriworks/bin/hook.mjs', ['preToolUse'], { stdin: '{isto não é json' });
  esperar(r.status === 0 && r.stdout.trim() === '{}', `${r.status} ${r.stdout}`);
});
// ------------------------------------------------------------------ modelos liberados
passo('modelos: lista da política, cruzamento com uso e preço, painel', () => {
  const politica = { obtidoEm: new Date().toISOString(), escopo: 'org:exemplo', politica: { default_availability: { policy_state: 'disabled' }, models: [
    { model_name: 'claude-sonnet-5', display_name: 'Claude Sonnet 5', policy_state: 'enabled' },
    { model_name: 'gpt-5-mini', display_name: 'GPT-5 mini', policy_state: 'disabled' },
    { model_name: 'modelo-sem-preco', display_name: 'Modelo Sem Preço', policy_state: 'enabled' },
  ] } };
  writeFileSync(join(TMP, 'politica.json'), JSON.stringify(politica));
  const at = hwk('modelos', 'atualizar', '--de', join(TMP, 'politica.json')).saida;
  esperar(/3 na política, 2 liberado/.test(at), at);
  const t = new Date().toISOString();
  mkdirSync(join(TMP, 'uso', 'consumo'), { recursive: true });
  writeFileSync(join(TMP, 'uso', 'consumo', `${t.slice(0, 7)}.jsonl`), [
    { t, conv: 's9', modelo: 'claude-sonnet-5-20261001', in: 1000, out: 100, cr: 0, cw: 0 },
    { t, conv: 's9', modelo: 'gpt-5-mini', in: 1000, out: 100, cr: 0, cw: 0 },
  ].map((x) => JSON.stringify(x)).join('\n') + '\n');
  const lista = node('.henriworks/bin/modelos.mjs', ['--json']).stdout;
  const linhas = JSON.parse(lista).modelos;
  const por = (id) => linhas.find((l) => l.id === id);
  esperar(por('claude-sonnet-5')?.usado && !por('claude-sonnet-5').alertas.length, `sonnet: ${JSON.stringify(por('claude-sonnet-5'))}`);
  esperar(por('gpt-5-mini')?.alertas.some((a) => a.sev === 'crit'), `gpt-5-mini deveria ter alerta grave: ${lista}`);
  esperar(por('modelo-sem-preco')?.alertas.some((a) => /sem preço/.test(a.txt)), `modelo-sem-preco: ${lista}`);
  const c = node('.henriworks/bin/modelos.mjs', ['conferir'], { ok: false });
  esperar(c.status === 1 && /GRAVE gpt-5-mini/.test(c.saida), c.saida);
  node('.henriworks/bin/uso.mjs', ['painel']);
  const html = readFileSync(join(TMP, 'uso', 'painel', 'index.html'), 'utf8');
  esperar(html.includes('Modelos · política × uso × preço') && html.includes('modelo-sem-preco'), 'painel sem o bloco de modelos');
});

passo('uso: dois arquivos OTel, custo medido (nano_aiu) e fundo do VS Code à parte', () => {
  // Variável aponta para um arquivo; o settings.json do VS Code, para outro. HOME/APPDATA falsos para
  // não ler o settings.json de verdade de quem roda o teste.
  const casa = join(TMP, 'casa');
  const appdata = join(casa, 'AppData');
  const varArq = join(TMP, 'otel-var.jsonl');
  const setArq = join(TMP, 'otel-settings.jsonl');
  mkdirSync(join(appdata, 'Code', 'User'), { recursive: true });
  writeFileSync(join(appdata, 'Code', 'User', 'settings.json'), JSON.stringify({ 'github.copilot.chat.otel.outfile': setArq }, null, 2));
  const agora = Date.now();
  const hr = (ms) => [Math.floor(ms / 1000), (ms % 1000) * 1e6];
  const span = (id, agente, pedido, resposta, inT, outT, aiu, ms) => ({ name: `chat ${resposta}`, startTime: hr(ms), attributes: {
    'gen_ai.operation.name': 'chat', 'gen_ai.agent.name': agente, 'gen_ai.request.model': pedido, 'gen_ai.response.model': resposta,
    'gen_ai.response.id': id, 'gen_ai.usage.input_tokens': inT, 'gen_ai.usage.output_tokens': outT,
    ...(aiu == null ? {} : { 'copilot_chat.copilot_usage_nano_aiu': aiu }) } });
  const log = (id, resposta, inT, outT, ms) => ({ hrTime: hr(ms), attributes: { 'event.name': 'gen_ai.client.inference.operation.details', 'gen_ai.operation.name': 'chat',
    'gen_ai.response.model': resposta, 'gen_ai.response.id': id, 'gen_ai.usage.input_tokens': inT, 'gen_ai.usage.output_tokens': outT } });
  writeFileSync(varArq, [
    span('nes-1', 'XtabProvider', 'copilot-nes-pandia-25', 'copilot-nes-pandia-25', 2400, 40, null, agora - 5000),
    log('nes-1', 'copilot-nes-pandia-25', 2400, 40, agora - 5000),
    span('tit-1', 'copilotLanguageModelWrapper/thinkingTitle', 'gpt-4o-mini-2024-07-18', 'gpt-4o-mini-2024-07-18', 300, 7, 0, agora - 4000),
  ].map((x) => JSON.stringify(x)).join('\n') + '\n');
  writeFileSync(setArq, [
    log('chat-1', 'claude-sonnet-5', 20000, 800, agora - 3000),
    span('chat-1', 'panel/editAgent', 'copilot-fusion', 'claude-sonnet-5', 20000, 800, 431375000, agora - 3000),
    { name: 'invoke_agent GitHub Copilot Chat', startTime: hr(agora - 3500), attributes: { 'gen_ai.operation.name': 'invoke_agent', 'gen_ai.usage.input_tokens': 99999, 'gen_ai.usage.output_tokens': 9999 } },
  ].map((x) => JSON.stringify(x)).join('\n') + '\n');
  const env = { ...ENV, HOME: casa, USERPROFILE: casa, APPDATA: appdata, COPILOT_OTEL_FILE_EXPORTER_PATH: varArq, HENRIWORKS_USO: join(TMP, 'uso-otel') };
  const uso = (...a) => {
    const r = spawnSync(process.execPath, ['.henriworks/bin/uso.mjs', ...a], { cwd: REPO, env, encoding: 'utf8' });
    if (r.status !== 0) throw new Error(`${r.stdout}${r.stderr}`);
    return r.stdout;
  };
  const imp = uso('importar');
  esperar(/3 registro\(s\) novo\(s\) de 2 arquivo\(s\)/.test(imp), imp);
  const linhas = readdirSync(join(TMP, 'uso-otel', 'consumo')).flatMap((f) => readFileSync(join(TMP, 'uso-otel', 'consumo', f), 'utf8').trim().split('\n')).map((l) => JSON.parse(l));
  const chat = linhas.find((l) => l.id === 'chat-1');
  esperar(chat && chat.origem === 'panel/editAgent' && chat.aiu === 431375000 && chat.pedido === 'copilot-fusion' && chat.modelo === 'claude-sonnet-5', `span do chat não ganhou do log: ${JSON.stringify(chat)}`);
  esperar(!linhas.some((l) => l.in === 99999), 'invoke_agent (total da sessão) foi importado');
  esperar(/^0 registro/.test(uso('importar')), 'segunda importação deveria ser incremental');
  esperar(/3 registro\(s\) novo/.test(uso('importar', '--refazer')), 'importar --refazer deveria reler os dois arquivos');
  uso('painel');
  const html = readFileSync(join(TMP, 'uso-otel', 'painel', 'index.html'), 'utf8');
  // 431375000 nano_aiu = 0,431375 crédito; o fundo (NES e título) fica no KPI próprio.
  esperar(/Créditos[\s\S]{0,200}?0,4/.test(html) && /100% medido pelo Copilot/.test(html), 'KPI de créditos não usou o nano_aiu');
  esperar(/Fundo do VS Code[\s\S]{0,200}?2[.,]?747/.test(html), 'KPI de fundo não somou NES + título');
  const init = spawnSync(process.execPath, ['.henriworks/bin/hwk.mjs', 'init', '--json'], { cwd: REPO, env, encoding: 'utf8' });
  esperar(/otel-arquivos/.test(init.stdout), `init não avisou dos dois arquivos OTel: ${init.stdout.slice(0, 300)}`);
});

passo('briefing: insumos pendentes ou só link do Figma impedem o plano', () => {
  const B = '.henriworks/briefings/INC-4472-confirmacao-duplicada';
  const tabela = (telas, contrato) => `| Insumo | Situação | Onde | Observação |\n| --- | --- | --- | --- |\n| Ticket e critérios do PO | ok | Jira INC-4472 | |\n| Telas (Figma) e análise | ${telas} |\n| Contrato de API por camada | ${contrato} |\n| Regras de negócio e limites | ok | seção O que se espera | |\n| Estados de tela e erros | ok | \`figma.md\` | |\n| Configuração e parametrização | não se aplica | | sem parâmetro novo |\n| Exemplos concretos | ok | seção O que se espera | contrato 123 |\n| Dependências de outros times | não se aplica | | BFF já pronto |\n`;
  const briefing = (t) => `# Briefing - confirmação duplicada\n\n## Problema\nO gerente confirma duas vezes.\n\n## O que se espera\nUm acordo por contrato. Exemplo: contrato 123.\n\n## Restrições\nNão mudar o BFF.\n\n## Fora do escopo\nRelatórios.\n\n## Insumos\n\n${t}\n## Prazo e ticket\nINC-4472\n`;
  escrever(`${B}/figma.md`, '# Análise\n');
  escrever(`${B}/briefing.md`, briefing(tabela('ok | https://www.figma.com/design/x?node-id=1 | ', 'pendente | | dev manda o caminho')));
  let r = node('.henriworks/bin/hwk.mjs', ['briefing', `${B}/briefing.md`], { ok: false });
  esperar(r.status === 1 && /só link do Figma/.test(r.saida) && /insumo pendente: Contrato de API/.test(r.saida), r.saida);
  escrever(`${B}/briefing.md`, briefing(tabela('ok | https://www.figma.com/design/x?node-id=1, `figma.md` | ', 'ok | MFE: `src/app/core/api/acordo-api.ts`; BFF: `bff/src/main/java/br/exemplo/AcordoController.java` | ')));
  r = node('.henriworks/bin/hwk.mjs', ['briefing', `${B}/briefing.md`], { ok: false });
  esperar(r.status === 0, r.saida);
  escrever(`${B}/briefing.md`, '# Briefing - antigo\n\n## Problema\np\n\n## O que se espera\ne\n\n## Restrições\nr\n\n## Fora do escopo\nf\n\n## Prazo e ticket\nINC-4472\n');
  r = node('.henriworks/bin/hwk.mjs', ['briefing', `${B}/briefing.md`], { ok: false });
  esperar(r.status === 1 && /sem a seção Insumos/.test(r.saida), r.saida);
});

passo('rigor Full sem gatilho é recusado; descartar mostra, só o dev apaga, e limpa o estado', () => {
  const D = '.henriworks/changes/INC-4472-testar-rigor';
  escrever(`${D}/briefing.md`, readFileSync(join(REPO, '.henriworks/briefings/INC-4472-confirmacao-duplicada/briefing.md'), 'utf8'));
  escrever(`${D}/proposta.md`, '# Testar rigor\n\nTicket: INC-4472\nBranch: main\nBase:   main\nRigor:  Full\n\n## Intenção\nx\n\n## Escopo\nDentro: x. Fora: y.\n\n## Restrições\nnenhuma\n\n## Critérios de aceite\nnenhum\n');
  escrever(`${D}/design.md`, '# Design\n');
  let r = node('.henriworks/bin/hwk.mjs', ['validar', 'INC-4472-testar-rigor'], { ok: false });
  esperar(r.status === 1 && /Rigor Full sem gatilho/.test(r.saida), r.saida);
  writeFileSync(join(REPO, '.henriworks/estado/pacotes.jsonl'), `${readFileSync(join(REPO, '.henriworks/estado/pacotes.jsonl'), 'utf8')}${JSON.stringify({ change: 'INC-4472-testar-rigor', alvo: 'design' })}\n`);
  r = hwk('descartar', 'INC-4472-testar-rigor', '--com-briefing');
  esperar(/prévia/.test(r.saida) && /1 pacote/.test(r.saida) && /INC-4472-confirmacao-duplicada/.test(r.saida) && existsSync(join(REPO, D)), r.saida);
  const neg = node('.henriworks/bin/hook.mjs', ['preToolUse'], { stdin: JSON.stringify({ session_id: 'd1', cwd: REPO, toolName: 'bash', toolArgs: { command: 'node .henriworks/bin/hwk.mjs descartar INC-4472-testar-rigor --aplicar' } }) }).stdout;
  esperar(/deny/.test(neg), `hook deixou o agente descartar: ${neg}`);
  hwk('descartar', 'INC-4472-testar-rigor', '--com-briefing', '--aplicar');
  esperar(!existsSync(join(REPO, D)) && !existsSync(join(REPO, '.henriworks/briefings/INC-4472-confirmacao-duplicada')), 'descartar não apagou a mudança e o briefing');
  esperar(!/INC-4472-testar-rigor/.test(readFileSync(join(REPO, '.henriworks/estado/pacotes.jsonl'), 'utf8')), 'estado da mudança ficou em pacotes.jsonl');
  esperar(/INC-4472-evitar-acordo-duplicado|"change"/.test(readFileSync(join(REPO, '.henriworks/estado/pacotes.jsonl'), 'utf8')), 'descartar apagou estado de outra mudança');
});

passo('hook: nada de prompt gravado no uso', () => {
  const dir = join(TMP, 'uso', 'eventos');
  const tudo = existsSync(dir) ? readdirSync(dir).map((f) => readFileSync(join(dir, f), 'utf8')).join('') : '';
  esperar(tudo && !/acordo'|"query"|"prompt"/.test(tudo), 'o registro de uso contém texto de prompt ou argumento');
});

console.log(`\n${passos - falhas}/${passos} passos ok${falhas ? `, ${falhas} falha(s)` : ''}. Pasta: ${TMP}`);
if (!process.argv.includes('--manter') && !falhas) rmSync(TMP, { recursive: true, force: true });
process.exit(falhas ? 1 : 0);
