---
name: hwk-grill
description: "Entrevista uma necessidade crua até virar briefing e atualiza o glossário. Roda no agente hwk-discovery."
argument-hint: "<a necessidade em uma ou duas frases>"
disable-model-invocation: true
---
# /hwk-grill

Transformar uma dor em briefing, perguntando. Nada é inferido.

Roda no agente `hwk-discovery`. Se as instruções deste chat não começam com a linha `# Agente hwk-discovery`, não leia nem execute nada: responda em uma linha que é para selecionar o agente `hwk-discovery` num chat novo e enviar `/hwk-grill` de novo. O agente define as ferramentas que estes passos precisam.

## Entradas

A **necessidade** é a primeira mensagem do dev neste chat. As seguintes são as respostas das rodadas:
esta sessão é a entrevista inteira, do começo à gravação.

## Passo 0 - Contrato

Leia `.github/skills/henriworks-fluxo/SKILL.md`. As seções desta fase são a 1, a 3 e a 4.

Necessidade vazia: pergunte o que está incomodando hoje e pare. Não ofereça exemplo de necessidade:
exemplo oferecido vira a resposta.

Este agente não tem ferramenta de busca, de propósito, e não lê código. Entrevista que varre o
repositório vira arqueologia e enviesa a conversa para o que já existe. O estado atual é pergunta para
o humano.

## Passo 1 - Preparar

Leia `.github/skills/henriworks-fluxo/references/tecnica-grilling.md` e `.henriworks/glossario.md`. Monte a fronteira: as perguntas cujos
pré-requisitos já estão respondidos. Descarte o que a necessidade já respondeu.

## Passo 2 - Conduzir

Limite de quatro rodadas, cinco perguntas cada (seção 4 do contrato).

- Na primeira rodada, pergunte a chave do Jira (ex.: `GPCNLS-10019`), se ela não veio na necessidade.
  Ela vai para `Prazo e ticket` e para o nome da pasta. É obrigatória: sem ela, nada é gravado, porque
  tudo da mudança se liga à task pelo nome. Sem ticket aberto, diga ao dev para abrir um e pare.
- Termo do domínio ambíguo, ou com dois nomes, vira pergunta. Resolvido, anote o termo e a definição
  para o glossário.
- Resposta vaga é lacuna, não resposta. Vaga de novo: classifique como bloqueante ou de borda.

Encerre antes do limite nos casos da seção 4.


## Passo 3 - Insumos

Leia a seção Insumos de `.github/skills/henriworks-fluxo/references/molde-briefing.md`. Com o problema e o esperado entendidos, dedique uma
rodada aos insumos: para cada um dos oito, decida com o dev se se aplica. Para cada um que se aplica e
não veio, **peça**, dizendo o que e em que forma. Não suponha conteúdo, não invente nome de campo:

- **Telas**: os links do Figma e a análise. Se o dev não tiver a análise, dê a ele este pedido para um
  chat com o `design-to-code` (ou o agente de Figma do time) e peça que salve a resposta em `figma.md`
  na pasta do briefing: "Só análise, sem gerar código. Para cada node: componentes do design system,
  estados (habilitado, desabilitado, erro, vazio, carregando), textos exatos, tokens e o comportamento
  de cada interação."
- **Contrato de API**: o caminho do tipo ou OpenAPI que o MFE consome e o do contrato que o BFF expõe,
  cada camada o seu. Arquivo que o dev apontar é material entregue: leia para transcrever os nomes de
  campo com a grafia exata, com origem. Não busque outros.
- **Exemplos**: pelo menos um caso com valores reais.
- **Regras e limites, estados e erros, configuração, dependências**: pergunte o que falta; o que não
  se aplica leva o motivo.

O dev não tem o insumo agora: grave como `pendente`, com quem fornece. O briefing é gravado, mas o plano
não começa até o insumo chegar; diga isso na saída.

## Passo 4 - Gravar

Leia `.github/skills/henriworks-fluxo/references/molde-briefing.md` e grave `.henriworks/briefings/<TICKET>-<assunto>/briefing.md` (ex.:
`.henriworks/briefings/GPCNLS-10019-saldo-projetado/briefing.md`), no molde, com as convenções de lacuna e
de origem.

Acrescente os termos novos ao fim da tabela de `.henriworks/glossario.md`. Não reescreva linha que já
existe sem o dev pedir.

Antes de gravar, confira os portões do briefing da seção 4, com atenção a dois: toda linha tem rastro
numa resposta desta conversa, e nenhuma seção contém critério de aceite.

## Saída

O formato de saída do molde, mais uma linha com os termos acrescentados ao glossário, uma com os
insumos (ok, não se aplica, pendente) e a próxima ação: com insumo pendente, o que falta e quem
fornece; sem pendência, num chat novo, agente `hwk-plan`, com o caminho do briefing.
