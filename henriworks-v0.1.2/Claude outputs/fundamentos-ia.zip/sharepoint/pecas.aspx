<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Agents, subagents, skills, hooks e MCP · Fundamentos de IA</title>
  <meta name="description" content="As peças que personalizam o agente, os conectores MCP, o que cada um faz e quando usar.">
  <link rel="icon" type="image/svg+xml" href="img/simbolo-bia.svg">
  <link rel="stylesheet" href="style.css">
  <script src="vendor/motion-lite.js" defer></script>
  <script src="app.js" defer></script>
</head>
<body>
<a class="pular" href="#conteudo">Pular para o conteúdo</a>
<div class="colmeia" aria-hidden="true">
<svg class="colmeia__favo" aria-hidden="true" focusable="false"><defs><pattern id="bchive-favo" width="48.497" height="84" patternUnits="userSpaceOnUse"><path d="M24.25,0.00 L48.50,14.00 L48.50,42.00 L24.25,56.00 L-0.00,42.00 L0.00,14.00 Z"/><path d="M0.00,42.00 L24.25,56.00 L24.25,84.00 L0.00,98.00 L-24.25,84.00 L-24.25,56.00 Z"/><path d="M48.50,42.00 L72.75,56.00 L72.75,84.00 L48.50,98.00 L24.25,84.00 L24.25,56.00 Z"/><path d="M0.00,-42.00 L24.25,-28.00 L24.25,-0.00 L0.00,14.00 L-24.25,-0.00 L-24.25,-28.00 Z"/><path d="M48.50,-42.00 L72.75,-28.00 L72.75,-0.00 L48.50,14.00 L24.25,-0.00 L24.25,-28.00 Z"/></pattern></defs><rect width="100%" height="100%" fill="url(#bchive-favo)"/></svg>
<svg class="colmeia__cacho colmeia__cacho--a" viewBox="0 0 227.9 207.0" aria-hidden="true" focusable="false"><path d="M61.98,7.80 L86.40,21.90 L86.40,50.10 L61.98,64.20 L37.56,50.10 L37.56,21.90 Z" class="vazio"/><path d="M113.94,7.80 L138.36,21.90 L138.36,50.10 L113.94,64.20 L89.52,50.10 L89.52,21.90 Z" class="vazio"/><path d="M165.90,7.80 L190.33,21.90 L190.33,50.10 L165.90,64.20 L141.48,50.10 L141.48,21.90 Z" class="vazio"/><path d="M36.00,52.80 L60.42,66.90 L60.42,95.10 L36.00,109.20 L11.58,95.10 L11.58,66.90 Z" class="vazio"/><path d="M87.96,52.80 L112.38,66.90 L112.38,95.10 L87.96,109.20 L63.54,95.10 L63.54,66.90 Z" class="mel"/><path d="M139.92,52.80 L164.34,66.90 L164.34,95.10 L139.92,109.20 L115.50,95.10 L115.50,66.90 Z" class="mel"/><path d="M191.88,52.80 L216.31,66.90 L216.31,95.10 L191.88,109.20 L167.46,95.10 L167.46,66.90 Z" class="vazio"/><path d="M61.98,97.80 L86.40,111.90 L86.40,140.10 L61.98,154.20 L37.56,140.10 L37.56,111.90 Z" class="mel"/><path d="M113.94,97.80 L138.36,111.90 L138.36,140.10 L113.94,154.20 L89.52,140.10 L89.52,111.90 Z" class="mel"/><path d="M165.90,97.80 L190.33,111.90 L190.33,140.10 L165.90,154.20 L141.48,140.10 L141.48,111.90 Z" class="vazio"/><path d="M139.92,142.80 L164.34,156.90 L164.34,185.10 L139.92,199.20 L115.50,185.10 L115.50,156.90 Z" class="vazio"/><path d="M36.00,142.80 L60.42,156.90 L60.42,185.10 L36.00,199.20 L11.58,185.10 L11.58,156.90 Z" class="vazio"/><path d="M87.96,142.80 L112.38,156.90 L112.38,185.10 L87.96,199.20 L63.54,185.10 L63.54,156.90 Z" class="vazio"/></svg>
<svg class="colmeia__cacho colmeia__cacho--b" viewBox="0 0 197.5 140.4" aria-hidden="true" focusable="false"><path d="M53.72,6.76 L74.88,18.98 L74.88,43.42 L53.72,55.64 L32.55,43.42 L32.55,18.98 Z" class="vazio"/><path d="M98.75,6.76 L119.92,18.98 L119.92,43.42 L98.75,55.64 L77.58,43.42 L77.58,18.98 Z" class="mel"/><path d="M143.78,6.76 L164.95,18.98 L164.95,43.42 L143.78,55.64 L122.62,43.42 L122.62,18.98 Z" class="vazio"/><path d="M31.20,45.76 L52.37,57.98 L52.37,82.42 L31.20,94.64 L10.03,82.42 L10.03,57.98 Z" class="vazio"/><path d="M76.23,45.76 L97.40,57.98 L97.40,82.42 L76.23,94.64 L55.07,82.42 L55.07,57.98 Z" class="vazio"/><path d="M121.27,45.76 L142.43,57.98 L142.43,82.42 L121.27,94.64 L100.10,82.42 L100.10,57.98 Z" class="vazio"/><path d="M166.30,45.76 L187.47,57.98 L187.47,82.42 L166.30,94.64 L145.13,82.42 L145.13,57.98 Z" class="mel"/><path d="M53.72,84.76 L74.88,96.98 L74.88,121.42 L53.72,133.64 L32.55,121.42 L32.55,96.98 Z" class="vazio"/><path d="M98.75,84.76 L119.92,96.98 L119.92,121.42 L98.75,133.64 L77.58,121.42 L77.58,96.98 Z" class="vazio"/><path d="M143.78,84.76 L164.95,96.98 L164.95,121.42 L143.78,133.64 L122.62,121.42 L122.62,96.98 Z" class="mel"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="left:1%;top:14%" aria-hidden="true" focusable="false"><path d="M10 100 C 40 20, 90 110, 130 50 S 180 20, 195 40"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="right:1%;top:70%;transform:scaleX(-1)" aria-hidden="true" focusable="false"><path d="M10 90 C 50 10, 80 100, 120 40 S 170 30, 195 60"/></svg>
<svg class="abelha ab1" style="left:2.5%;top:20%;--d:13s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab1"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab1)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab2" style="right:3%;top:34%;--d:16s;--x:-16px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab2"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab2)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab3" style="left:4%;top:62%;--d:15s;--x:14px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab3"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab3)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab4" style="right:5%;top:76%;--d:12s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab4"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab4)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab5" style="right:22%;top:12%;--d:18s;--x:-12px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab5"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab5)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
</div>

<div class="progresso" aria-hidden="true"><div class="progresso__barra"></div></div>
<header class="topo">
  <div class="conteudo topo__linha">
    <a class="marca" href="index.aspx" aria-label="Fundamentos de IA, início">
      <img class="mlogo mlogo--c" src="img/logo-bia.svg" alt="b.IA Credit" height="28"><img class="mlogo mlogo--e" src="img/logo-bia-escuro.svg" alt="" height="28"><span class="marca__produto">Fundamentos de IA</span>
    </a>
    <nav aria-label="Páginas" class="nav"><ul class="menu"><li><a href="index.aspx">Início</a></li><li><a href="tokens.aspx">Tokens e custo</a></li><li><a href="contexto.aspx">Janela de contexto</a></li><li><a href="modelo-agente.aspx">Modelo × agente</a></li><li><a href="pecas.aspx" aria-current="page">Agents, skills, MCP</a></li><li><a href="harness.aspx">Harness</a></li></ul></nav>
    <div class="controles" data-controles></div>
  </div>
</header>
<main id="conteudo">
<section class="hero hero--pagina conteudo" data-slide>
  <div>
    <p class="eyebrow">4 · As peças</p>
    <h1 class="titulo-abertura">Agents, subagents, skills, hooks e MCP</h1>
    <p class="lede">O agente do Copilot vem genérico. Estas são as peças que o transformam no agente do <strong>seu time</strong>:
      todas são arquivos de texto que o VS Code carrega.</p>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="ouro-t">
  <h2 id="ouro-t" class="visualmente-oculto">A regra de ouro</h2>
  <p class="regra-ouro revelar">Instrução <span>pede</span>. Skill <span>ensina</span>. Agente <span>delimita</span>. Hook <span>garante</span>. MCP <span>conecta</span>.</p>
</section>

<section class="secao conteudo" data-slide aria-labelledby="pc-t">
  <div class="secao__cab"><p class="eyebrow">Uma por uma</p><h2 id="pc-t">O que é, onde fica e um exemplo real</h2></div>
  <div class="pecas revelar-grupo">
    <article class="peca-card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>I</span></span>Instructions</h3>
      <p class="frase">Regras que o agente lê sempre que o assunto bate.</p>
      <dl><dt>No VS Code</dt><dd><code>.github/instructions/*.instructions.md</code> com <code>applyTo</code> (pastas), ou <code>AGENTS.md</code></dd>
        <dt>Exemplo</dt><dd>"Em <code>src/app/**</code>, componentes usam signals e testes ficam ao lado do componente."</dd>
        <dt>Limite</dt><dd>É um pedido: o modelo pode esquecer ou interpretar.</dd></dl></article>
    <article class="peca-card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>A</span></span>Agent</h3>
      <p class="frase">Um papel: instruções próprias e só as ferramentas daquele papel.</p>
      <dl><dt>No VS Code</dt><dd><code>*.agent.md</code>, aparece no seletor de agente do chat</dd>
        <dt>Exemplo</dt><dd><code>bchive-plan</code> planeja e não implementa; <code>bchive-review</code> orquestra a revisão.</dd>
        <dt>Quando</dt><dd>Quando muda o que pode ser feito ou visto, não só o procedimento.</dd></dl></article>
    <article class="peca-card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>S</span></span>Subagent</h3>
      <p class="frase">Um agente chamado por outro, que nasce com contexto limpo.</p>
      <dl><dt>No VS Code</dt><dd>Um <code>*.agent.md</code> que o agente principal chama pela ferramenta de delegação</dd>
        <dt>Exemplo</dt><dd><code>bchive-gf</code>, o revisor que não viu a conversa; <code>bchive-implementador</code>, que executa uma fatia.</dd>
        <dt>Quando</dt><dd>Tarefa isolada, revisão imparcial, trabalho em paralelo.</dd></dl></article>
    <article class="peca-card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>K</span></span>Skill</h3>
      <p class="frase">Um procedimento carregado só quando é chamado.</p>
      <dl><dt>No VS Code</dt><dd><code>skills/&lt;nome&gt;/SKILL.md</code>, chamado por <code>/comando</code> ou pelo próprio agente</dd>
        <dt>Exemplo</dt><dd><code>/bia-credit-hive:init</code> prepara o repositório; <code>/bia-credit-hive:squad-audit</code> audita as instruções.</dd>
        <dt>Por que</dt><dd>Não pesa na janela enquanto não é usado.</dd></dl></article>
    <article class="peca-card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>H</span></span>Hook</h3>
      <p class="frase">Um script que roda em eventos do agente, sempre, sem depender do modelo.</p>
      <dl><dt>No VS Code</dt><dd><code>hooks.json</code>: início de sessão, antes e depois de cada ferramenta, fim</dd>
        <dt>Exemplo</dt><dd>O hook do Hive nega ao agente o comando de aprovar a spec: só a pessoa aprova.</dd>
        <dt>Quando</dt><dd>Para o que não pode falhar: segurança, portões, medição.</dd></dl></article>
    <article class="peca-card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>M</span></span>MCP</h3>
      <p class="frase">Um conector padrão entre o agente e um sistema de fora: Jira, Figma, GitHub, banco de dados.</p>
      <dl><dt>No VS Code</dt><dd>Servidor MCP configurado em <code>mcp.json</code> (do perfil ou do workspace) ou trazido por um plugin; as ferramentas dele aparecem para o agente</dd>
        <dt>Exemplo</dt><dd>"Leia o ticket GPCNLS-10019": com um servidor MCP do Jira, o agente busca o ticket sem você colar o texto.</dd>
        <dt>Cuidado</dt><dd>Só use os servidores liberados pela política do banco. Cada servidor ligado soma as descrições das ferramentas dele a todo pedido: ligue só o que usa.</dd></dl></article>
    <article class="peca-card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>P</span></span>Plugin</h3>
      <p class="frase">O pacote que instala tudo isso junto.</p>
      <dl><dt>No VS Code</dt><dd>Instalado pelo marketplace do Copilot</dd>
        <dt>Exemplo</dt><dd>O b.IA Credit Hive: 9 agentes, 18 skills e os hooks, numa instalação só.</dd>
        <dt>Por que</dt><dd>Todo mundo usa a mesma versão, atualizada num lugar.</dd></dl></article>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="ped-t">
  <div class="secao__cab"><p class="eyebrow">Um pedido, por dentro</p><h2 id="ped-t">Quem age em cada momento</h2>
    <p>Exemplo: você pede, no agente de plano, para planejar uma mudança.</p></div>
  <ol class="trilha revelar-grupo">
    <li class="trilha__passo"><span class="trilha__n">1</span><div><h3>Hook de início de sessão</h3><p>Antes de qualquer resposta, o hook confere a versão e acrescenta um lembrete curto ao contexto.</p></div></li>
    <li class="trilha__passo"><span class="trilha__n">2</span><div><h3>Agent + instructions</h3><p>O agente <code>bchive-plan</code> entra com as instruções dele; as instructions do time entram quando o arquivo tocado bate com o <code>applyTo</code>.</p></div></li>
    <li class="trilha__passo"><span class="trilha__n">3</span><div><h3>Skill</h3><p><code>/bia-credit-hive:plan</code> carrega o procedimento de planejar só agora, quando é usado.</p></div></li>
    <li class="trilha__passo"><span class="trilha__n">4</span><div><h3>Hook antes da ferramenta</h3><p>O agente tenta uma busca ampla; o hook pede para consultar o mapa do projeto primeiro, que custa menos tokens.</p></div></li>
    <li class="trilha__passo"><span class="trilha__n">5</span><div><h3>Subagent</h3><p>Plano pronto, o revisor <code>bchive-gf</code> nasce sem a conversa e julga só o que está escrito.</p></div></li>
    <li class="trilha__passo"><span class="trilha__n">6</span><div><h3>Você</h3><p>Aprova a spec no terminal. Se o agente tentar aprovar sozinho, o hook nega.</p></div></li>
  </ol>
</section>

<section class="secao conteudo" data-slide aria-labelledby="qual-t">
  <div class="secao__cab"><p class="eyebrow">Qual usar</p><h2 id="qual-t">Para cada necessidade, uma peça</h2></div>
  <div class="tabela-wrap revelar"><table>
    <thead><tr><th>Eu quero…</th><th>Use</th><th>Por quê</th></tr></thead>
    <tbody>
      <tr><td>que todo componente Angular siga o padrão do time</td><td>Instruction com <code>applyTo</code></td><td>Entra só quando o assunto bate</td></tr>
      <tr><td>um passo a passo que o time repete</td><td>Skill</td><td>Não ocupa a janela até ser chamada</td></tr>
      <tr><td>um papel que só lê e nunca edita</td><td>Agent</td><td>As ferramentas ficam no próprio arquivo</td></tr>
      <tr><td>uma revisão sem viés de quem escreveu</td><td>Subagent</td><td>Contexto limpo</td></tr>
      <tr><td>garantir que algo nunca aconteça</td><td>Hook</td><td>Roda sempre, não depende de o modelo lembrar</td></tr>
      <tr><td>consultar o Jira ou o Figma de dentro do chat</td><td>MCP</td><td>O agente usa o sistema como ferramenta, sem copiar e colar</td></tr>
      <tr><td>levar tudo isso para outras pessoas</td><td>Plugin</td><td>Instala e atualiza num lugar só</td></tr>
    </tbody></table></div>
</section>

<div class="conteudo">
  <nav class="passagem" aria-label="Navegação entre páginas">
    <a href="modelo-agente.aspx" data-anterior><small>← Anterior</small><strong>Modelo × agente</strong></a>
    <a class="prox" href="harness.aspx" data-proxima><small>Próxima →</small><strong>Harness</strong></a>
  </nav>
  <footer class="rodape"><span>Engenharia com IA · fundamentos · BU Crédito</span><span><kbd>P</kbd> apresentação · <kbd>←</kbd> <kbd>→</kbd> navegar · <kbd>Esc</kbd> sair</span></footer>
</div>
</main>
<div class="slide-contador" aria-live="polite"></div>
</body>
</html>
