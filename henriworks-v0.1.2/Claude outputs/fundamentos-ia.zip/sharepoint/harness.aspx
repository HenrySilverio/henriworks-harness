<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Harness engineering · Fundamentos de IA</title>
  <meta name="description" content="O carro em volta do motor: o que é harness e como ele se monta do GitHub Copilot ao b.IA Credit Hive.">
  <link rel="icon" type="image/svg+xml" href="img/simbolo-bia.svg">
  <link rel="stylesheet" href="style.css">
  <script src="vendor/motion-lite.js" defer></script>
  <script src="fundamentos.js" defer></script>
  <script src="app.js" defer></script>
</head>
<body>
<a class="pular" href="#conteudo">Pular para o conteúdo</a>
<div class="colmeia" aria-hidden="true">
<svg class="colmeia__favo" aria-hidden="true" focusable="false"><defs><pattern id="bchive-favo" width="48.497" height="84" patternUnits="userSpaceOnUse"><path d="M24.25,0.00 L48.50,14.00 L48.50,42.00 L24.25,56.00 L-0.00,42.00 L0.00,14.00 Z"/><path d="M0.00,42.00 L24.25,56.00 L24.25,84.00 L0.00,98.00 L-24.25,84.00 L-24.25,56.00 Z"/><path d="M48.50,42.00 L72.75,56.00 L72.75,84.00 L48.50,98.00 L24.25,84.00 L24.25,56.00 Z"/><path d="M0.00,-42.00 L24.25,-28.00 L24.25,-0.00 L0.00,14.00 L-24.25,-0.00 L-24.25,-28.00 Z"/><path d="M48.50,-42.00 L72.75,-28.00 L72.75,-0.00 L48.50,14.00 L24.25,-0.00 L24.25,-28.00 Z"/></pattern></defs><rect width="100%" height="100%" fill="url(#bchive-favo)"/></svg>
<svg class="colmeia__cacho colmeia__cacho--a" viewBox="0 0 227.9 207.0" aria-hidden="true" focusable="false"><path d="M61.98,7.80 L86.40,21.90 L86.40,50.10 L61.98,64.20 L37.56,50.10 L37.56,21.90 Z" class="vazio"/><path d="M113.94,7.80 L138.36,21.90 L138.36,50.10 L113.94,64.20 L89.52,50.10 L89.52,21.90 Z" class="vazio"/><path d="M165.90,7.80 L190.33,21.90 L190.33,50.10 L165.90,64.20 L141.48,50.10 L141.48,21.90 Z" class="vazio"/><path d="M36.00,52.80 L60.42,66.90 L60.42,95.10 L36.00,109.20 L11.58,95.10 L11.58,66.90 Z" class="vazio"/><path d="M87.96,52.80 L112.38,66.90 L112.38,95.10 L87.96,109.20 L63.54,95.10 L63.54,66.90 Z" class="mel"/><path d="M139.92,52.80 L164.34,66.90 L164.34,95.10 L139.92,109.20 L115.50,95.10 L115.50,66.90 Z" class="mel"/><path d="M191.88,52.80 L216.31,66.90 L216.31,95.10 L191.88,109.20 L167.46,95.10 L167.46,66.90 Z" class="vazio"/><path d="M61.98,97.80 L86.40,111.90 L86.40,140.10 L61.98,154.20 L37.56,140.10 L37.56,111.90 Z" class="mel"/><path d="M113.94,97.80 L138.36,111.90 L138.36,140.10 L113.94,154.20 L89.52,140.10 L89.52,111.90 Z" class="mel"/><path d="M165.90,97.80 L190.33,111.90 L190.33,140.10 L165.90,154.20 L141.48,140.10 L141.48,111.90 Z" class="vazio"/><path d="M139.92,142.80 L164.34,156.90 L164.34,185.10 L139.92,199.20 L115.50,185.10 L115.50,156.90 Z" class="vazio"/><path d="M36.00,142.80 L60.42,156.90 L60.42,185.10 L36.00,199.20 L11.58,185.10 L11.58,156.90 Z" class="vazio"/><path d="M87.96,142.80 L112.38,156.90 L112.38,185.10 L87.96,199.20 L63.54,185.10 L63.54,156.90 Z" class="vazio"/></svg>
<svg class="colmeia__cacho colmeia__cacho--b" viewBox="0 0 197.5 140.4" aria-hidden="true" focusable="false"><path d="M53.72,6.76 L74.88,18.98 L74.88,43.42 L53.72,55.64 L32.55,43.42 L32.55,18.98 Z" class="vazio"/><path d="M98.75,6.76 L119.92,18.98 L119.92,43.42 L98.75,55.64 L77.58,43.42 L77.58,18.98 Z" class="mel"/><path d="M143.78,6.76 L164.95,18.98 L164.95,43.42 L143.78,55.64 L122.62,43.42 L122.62,18.98 Z" class="vazio"/><path d="M31.20,45.76 L52.37,57.98 L52.37,82.42 L31.20,94.64 L10.03,82.42 L10.03,57.98 Z" class="vazio"/><path d="M76.23,45.76 L97.40,57.98 L97.40,82.42 L76.23,94.64 L55.07,82.42 L55.07,57.98 Z" class="vazio"/><path d="M121.27,45.76 L142.43,57.98 L142.43,82.42 L121.27,94.64 L100.10,82.42 L100.10,57.98 Z" class="vazio"/><path d="M166.30,45.76 L187.47,57.98 L187.47,82.42 L166.30,94.64 L145.13,82.42 L145.13,57.98 Z" class="mel"/><path d="M53.72,84.76 L74.88,96.98 L74.88,121.42 L53.72,133.64 L32.55,121.42 L32.55,96.98 Z" class="vazio"/><path d="M98.75,84.76 L119.92,96.98 L119.92,121.42 L98.75,133.64 L77.58,121.42 L77.58,96.98 Z" class="vazio"/><path d="M143.78,84.76 L164.95,96.98 L164.95,121.42 L143.78,133.64 L122.62,121.42 L122.62,96.98 Z" class="mel"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="left:1%;top:14%" aria-hidden="true" focusable="false"><path d="M10 100 C 40 20, 90 110, 130 50 S 180 20, 195 40"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="right:1%;top:70%;transform:scaleX(-1)" aria-hidden="true" focusable="false"><path d="M10 90 C 50 10, 80 100, 120 40 S 170 30, 195 60"/></svg>
<svg class="abelha ab1" style="left:2.5%;top:20%;--d:13s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab1"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab1)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab2" style="right:3%;top:34%;--d:16s;--x:-16px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab2"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab2)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab3" style="left:4%;top:62%;--d:15s;--x:14px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab3"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab3)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab4" style="right:5%;top:76%;--d:12s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab4"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab4)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab5" style="right:22%;top:12%;--d:18s;--x:-12px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab5"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab5)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
</div>

<div class="progresso" aria-hidden="true"><div class="progresso__barra"></div></div>
<header class="topo">
  <div class="conteudo topo__linha">
    <a class="marca" href="index.aspx" aria-label="Fundamentos de IA, início">
      <img class="mlogo mlogo--c" src="img/logo-bia.svg" alt="b.IA Credit" height="28"><img class="mlogo mlogo--e" src="img/logo-bia-escuro.svg" alt="" height="28"><span class="marca__produto">Fundamentos de IA</span>
    </a>
    <nav aria-label="Páginas" class="nav"><ul class="menu"><li><a href="index.aspx">Início</a></li><li><a href="tokens.aspx">Tokens e custo</a></li><li><a href="contexto.aspx">Janela de contexto</a></li><li><a href="modelo-agente.aspx">Modelo × agente</a></li><li><a href="pecas.aspx">Agents, skills, MCP</a></li><li><a href="harness.aspx" aria-current="page">Harness</a></li></ul></nav>
    <div class="controles" data-controles></div>
  </div>
</header>
<main id="conteudo">
<section class="hero hero--pagina conteudo" data-slide>
  <div>
    <p class="eyebrow">5 · Harness engineering</p>
    <h1 class="titulo-abertura">O motor sozinho não leva ninguém a lugar nenhum</h1>
    <p class="lede"><strong>Harness</strong> é tudo o que montamos em volta do modelo para ele entregar de forma previsível: contexto, ferramentas,
      regras, verificações, portões e medição. <strong>Harness engineering</strong> é projetar isso de propósito.</p>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="ana-t">
  <div class="secao__cab"><p class="eyebrow">A analogia</p><h2 id="ana-t">O modelo é o motor. O harness é o carro.</h2>
    <p>Equipes de corrida podem usar o mesmo motor e terminar em posições muito diferentes. A diferença está no chassi, nos freios, na estratégia e na equipe de box.
      Com IA é igual: o mesmo modelo entrega resultados diferentes conforme o harness.</p></div>
  <div class="carro-grade">
    <div>
      <div class="camadas fx-botoes" data-camadas data-sem-js aria-hidden="true" role="group" aria-label="Camadas">
        <button type="button" data-camada="tudo" aria-pressed="true">O carro inteiro</button>
        <button type="button" data-camada="copilot" aria-pressed="false">GitHub Copilot</button>
        <button type="button" data-camada="vscode" aria-pressed="false">VS Code</button>
        <button type="button" data-camada="hive" aria-pressed="false">b.IA Credit Hive</button>
      </div>
      <figure class="diagrama carro revelar" data-carro><svg viewBox="0 112 900 316" role="img" aria-labelledby="car-t car-d"><title id="car-t">O carro do harness</title><desc id="car-d">Um carro de lado com doze peças numeradas: motor, tanque, carroceria, volante, rodas, manual, GPS, freio, painel, vistoria, equipe de box e motorista. A tabela abaixo do desenho explica cada uma.</desc>
<defs><linearGradient id="car-ceu" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--mel-bg)" stop-opacity=".0"/><stop offset="1" stop-color="var(--mel-bg)" stop-opacity=".9"/></linearGradient></defs>
<rect x="0" y="250" width="900" height="130" fill="url(#car-ceu)"/>
<line x1="20" y1="380" x2="880" y2="380" class="car-chao"/>
<path d="M60 392 H190 M260 392 H420 M490 392 H660 M730 392 H860" class="car-faixa"/>
<g class="car-veiculo">
<g class="peca" data-peca="carroceria" tabindex="0" role="button" aria-label="3. Carroceria e chassi: o harness">
  <path d="M130 334 L130 276 Q134 250 168 243 L300 232 L360 162 Q370 151 392 151 L560 151 Q586 151 602 167 L664 232 L742 244 Q778 250 782 280 L782 334 Z" class="car-corpo"/>
  <path d="M316 228 L370 166 L452 166 L452 228 Z M466 228 L466 166 L556 166 Q574 166 586 179 L632 228 Z" class="car-vidro"/>
  <path d="M459 166 V330 M300 262 H760" class="car-linha"/>
</g>
<g class="peca" data-peca="motor" tabindex="0" role="button" aria-label="1. Motor: o modelo">
  <rect x="636" y="246" width="112" height="70" rx="8" class="car-corte"/>
  <rect x="650" y="262" width="84" height="40" rx="5" class="car-motor"/>
  <path d="M664 262 V250 M684 262 V250 M704 262 V250 M724 262 V250" class="car-cil"/>
  <path d="M658 282 H726" class="car-cil"/>
</g>
<g class="peca" data-peca="tanque" tabindex="0" role="button" aria-label="2. Tanque e combustível: janela de contexto e tokens">
  <rect x="296" y="292" width="118" height="34" rx="8" class="car-corte"/>
  <rect x="304" y="298" width="102" height="22" rx="4" class="car-tanque"/>
  <rect x="304" y="306" width="68" height="14" rx="3" class="car-comb"/>
</g>
<g class="peca" data-peca="manual" tabindex="0" role="button" aria-label="6. Manual do motorista: instructions">
  <rect x="404" y="192" width="40" height="32" rx="3" class="car-manual"/>
  <path d="M410 202 H438 M410 209 H438 M410 216 H430" class="car-manual-l"/>
</g>
<g class="peca" data-peca="motorista" tabindex="0" role="button" aria-label="12. Motorista: você">
  <circle cx="506" cy="187" r="15" class="car-pessoa"/>
  <path d="M484 232 Q486 206 506 204 Q526 206 528 232 Z" class="car-pessoa"/>
</g>
<g class="peca" data-peca="volante" tabindex="0" role="button" aria-label="4. Volante e câmbio: o agente">
  <circle cx="548" cy="206" r="16" class="car-volante"/>
  <path d="M532 206 H564 M548 206 V222" class="car-volante-r"/>
</g>
<g class="peca" data-peca="gps" tabindex="0" role="button" aria-label="7. GPS e rota: spec e plano">
  <rect x="574" y="178" width="40" height="28" rx="5" class="car-gps"/>
  <path d="M580 199 Q590 186 598 193 T610 184" class="car-rota"/>
  <circle cx="610" cy="184" r="2.6" class="car-ponto"/>
</g>
<g class="peca" data-peca="painel" tabindex="0" role="button" aria-label="9. Painel de instrumentos: telemetria e uso">
  <rect x="566" y="212" width="40" height="18" rx="4" class="car-painel"/>
  <path d="M574 226 A8 8 0 0 1 590 226" class="car-gauge"/><path d="M582 226 L587 218" class="car-agulha"/>
  <circle cx="598" cy="221" r="3" class="car-ponto"/>
</g>
<g class="peca" data-peca="rodas" tabindex="0" role="button" aria-label="5. Rodas: as ferramentas">
  <circle cx="240" cy="334" r="46" class="car-pneu"/><circle cx="240" cy="334" r="24" class="car-roda"/>
  <path d="M240 312 V356 M218 334 H262" class="car-raio"/>
  <circle cx="680" cy="334" r="46" class="car-pneu"/><circle cx="680" cy="334" r="24" class="car-roda"/>
  <path d="M680 312 V356 M658 334 H702" class="car-raio"/>
</g>
<g class="peca" data-peca="freios" tabindex="0" role="button" aria-label="8. Freio e ABS: hooks">
  <circle cx="680" cy="334" r="16" class="car-disco"/>
  <path d="M694 314 A24 24 0 0 1 702 330" class="car-pinca"/>
</g>
</g>
<g class="peca" data-peca="vistoria" tabindex="0" role="button" aria-label="10. Vistoria: revisor independente">
  <rect x="816" y="250" width="6" height="130" rx="3" class="car-poste"/>
  <circle cx="819" cy="232" r="32" class="car-selo"/>
  <path d="M804 232 L815 243 L835 221" class="car-check"/>
</g>
<g class="peca" data-peca="box" tabindex="0" role="button" aria-label="11. Equipe de box: subagentes e skills">
  <rect x="26" y="318" width="74" height="50" rx="6" class="car-caixa"/>
  <path d="M26 334 H100 M52 318 V310 H74 V318" class="car-caixa-l"/>
  <path d="M42 300 L66 276 M62 272 a8 8 0 1 0 8 8 l-6 -2 l-2 -6 Z" class="car-chave"/>
  <g transform="translate(86 262)"><g class="car-abelha"><ellipse cx="-3" cy="-10" rx="7" ry="9" class="ab-asa"/><ellipse cx="6" cy="-9" rx="6" ry="8" class="ab-asa"/><ellipse cx="0" cy="0" rx="13" ry="9" class="ab-corpo"/><path d="M-4 -8.6 V8.6 M3 -8.9 V8.9" class="ab-listra"/><circle cx="14" cy="-1" r="5.5" class="ab-cabeca"/></g></g>
</g>
<g class="car-numeros" aria-hidden="true">
  <g class="car-n" data-n="motor"><polygon points="692,214 706,222 706,238 692,246 678,238 678,222"/><text x="692" y="234">1</text></g>
  <g class="car-n" data-n="tanque"><polygon points="356,262 370,270 370,286 356,294 342,286 342,270"/><text x="356" y="282">2</text></g>
  <g class="car-n" data-n="carroceria"><polygon points="250,226 264,234 264,250 250,258 236,250 236,234"/><text x="250" y="246">3</text></g>
  <g class="car-n" data-n="volante"><polygon points="548,232 562,240 562,256 548,264 534,256 534,240"/><text x="548" y="252">4</text></g>
  <g class="car-n" data-n="rodas"><polygon points="240,388 254,396 254,412 240,420 226,412 226,396"/><text x="240" y="408">5</text></g>
  <g class="car-n" data-n="manual"><polygon points="424,150 438,158 438,174 424,182 410,174 410,158"/><text x="424" y="170">6</text></g>
  <g class="car-n" data-n="gps"><polygon points="616,132 630,140 630,156 616,164 602,156 602,140"/><text x="616" y="152">7</text></g>
  <g class="car-n" data-n="freios"><polygon points="728,382 742,390 742,406 728,414 714,406 714,390"/><text x="728" y="402">8</text></g>
  <g class="car-n" data-n="painel"><polygon points="580,252 594,260 594,276 580,284 566,276 566,260" /><text x="580" y="272">9</text></g>
  <g class="car-n" data-n="vistoria"><polygon points="860,180 874,188 874,204 860,212 846,204 846,188"/><text x="860" y="200">10</text></g>
  <g class="car-n" data-n="box"><polygon points="62,386 76,394 76,410 62,418 48,410 48,394"/><text x="62" y="406">11</text></g>
  <g class="car-n" data-n="motorista"><polygon points="490,130 504,138 504,154 490,162 476,154 476,138"/><text x="490" y="150">12</text></g>
</g>
</svg></figure>

      <p class="camada-desc" data-camada-desc aria-live="polite">Clique numa peça do carro, ou escolha uma camada acima para ver quem fornece cada parte.</p>
    </div>
    <aside class="peca-painel" data-peca-painel data-sem-js aria-hidden="true" aria-live="polite"></aside>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="tab-t">
  <div class="secao__cab"><p class="eyebrow">Peça por peça</p><h2 id="tab-t">O que cada parte do carro é no harness</h2></div>
  <div class="tabela-wrap revelar"><table data-pecas>
    <thead><tr><th>No carro</th><th>No harness</th><th>Onde fica</th></tr></thead>
    <tbody>
      <tr data-peca="motor" data-n="1" data-camada="copilot"><th scope="row">1 · Motor</th><td><strong>O modelo (LLM).</strong> Gera a potência: texto. Sozinho, não sai do lugar.</td><td>GitHub Copilot: GPT-6 Luna, Claude Opus 5.5 e outros, escolhidos no seletor de modelo.</td></tr>
      <tr data-peca="tanque" data-n="2" data-camada="copilot"><th scope="row">2 · Tanque e combustível</th><td><strong>Janela de contexto e tokens.</strong> A capacidade é limitada, e cada instrução, arquivo e turno de conversa gasta.</td><td>GitHub Copilot: limites de cada modelo e cobrança em créditos por token.</td></tr>
      <tr data-peca="carroceria" data-n="3" data-camada="vscode"><th scope="row">3 · Carroceria e chassi</th><td><strong>O harness em si.</strong> A estrutura que liga o motor ao volante, às rodas e aos freios.</td><td>VS Code: o chat em modo agente, no harness Copilot.</td></tr>
      <tr data-peca="volante" data-n="4" data-camada="vscode"><th scope="row">4 · Volante e câmbio</th><td><strong>O agente.</strong> O ciclo que decide a próxima ação: ler, planejar, agir, verificar.</td><td>VS Code: seletor de agente. No Hive: <code>bchive-plan</code>, <code>bchive-implement</code>, <code>bchive-review</code>…</td></tr>
      <tr data-peca="rodas" data-n="5" data-camada="vscode"><th scope="row">5 · Rodas</th><td><strong>As ferramentas.</strong> O que toca o mundo real: ler e buscar arquivos, editar, rodar o terminal.</td><td>VS Code: ferramentas do agente, liberadas por permissão.</td></tr>
      <tr data-peca="manual" data-n="6" data-camada="vscode"><th scope="row">6 · Manual do motorista</th><td><strong>As instructions.</strong> As regras do time e do projeto que o agente lê antes de agir.</td><td>VS Code carrega <code>.instructions.md</code> e <code>AGENTS.md</code>; o conteúdo é do time.</td></tr>
      <tr data-peca="gps" data-n="7" data-camada="hive"><th scope="row">7 · GPS e rota</th><td><strong>Spec e plano.</strong> Destino e caminho definidos antes de sair; cada fatia é um trecho da viagem.</td><td>Hive: briefing, proposta com critérios de aceite e fatias.</td></tr>
      <tr data-peca="freios" data-n="8" data-camada="hive"><th scope="row">8 · Freio e ABS</th><td><strong>Hooks.</strong> Agem sempre, sem depender de o modelo lembrar: seguram a ação perigosa.</td><td>Hive: nega ao agente os portões humanos e pede o mapa antes de busca ampla.</td></tr>
      <tr data-peca="painel" data-n="9" data-camada="hive"><th scope="row">9 · Painel de instrumentos</th><td><strong>Telemetria.</strong> Velocidade, consumo e alertas: saber como a viagem está indo.</td><td>Hive: relatório de uso com sessões, comandos e tokens, nunca o conteúdo.</td></tr>
      <tr data-peca="vistoria" data-n="10" data-camada="hive"><th scope="row">10 · Vistoria</th><td><strong>Revisão independente.</strong> Quem inspeciona não é quem dirigiu.</td><td>Hive: o revisor <code>bchive-gf</code>, que não viu a conversa e só lê.</td></tr>
      <tr data-peca="box" data-n="11" data-camada="hive"><th scope="row">11 · Equipe de box</th><td><strong>Subagentes e skills.</strong> Especialistas chamados para uma tarefa, cada um com a sua ferramenta.</td><td>Hive: executor de fatia, agentes da sua stack (Java, Angular, COBOL) e os comandos <code>/bia-credit-hive:*</code>.</td></tr>
      <tr data-peca="motorista" data-n="12" data-camada="todas"><th scope="row">12 · Motorista</th><td><strong>Você.</strong> Escolhe o destino, aprova a rota e decide o que é de gente.</td><td>Todas as camadas: aprovar a spec, aceitar risco, dar o OK do QA, commitar e abrir a PR.</td></tr>
    </tbody></table></div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="cam-t">
  <div class="secao__cab"><p class="eyebrow">Três camadas</p><h2 id="cam-t">Do GitHub Copilot ao nosso harness</h2>
    <p>Cada camada se apoia na de baixo. Nenhuma substitui a outra.</p></div>
  <div class="pilha-copilot revelar-grupo">
    <div class="pc-1"><strong>GitHub Copilot</strong><p data-camada-txt="copilot">O <strong>motor e o combustível</strong>: os modelos, a cobrança em créditos por token e as políticas da empresa (quais modelos e recursos estão liberados).</p></div>
    <div class="pc-2"><strong>VS Code</strong><p data-camada-txt="vscode">O <strong>carro</strong>: o chat em modo agente, as ferramentas e o lugar onde agents, skills, hooks e instructions são carregados.</p></div>
    <div class="pc-3"><strong>b.IA Credit Hive</strong><p data-camada-txt="hive">O <strong>regulamento e a equipe</strong>: rota (spec e fatias), freios calibrados (hooks), vistoria (revisor sem contexto), box (executores da stack) e painel de uso. É um plugin: instala por cima das camadas de baixo.</p></div>
  </div>
  <p class="visualmente-oculto" data-camada-txt="tudo">O carro inteiro: o motor vem do GitHub Copilot, o carro é o VS Code, e o regulamento e a equipe são do b.IA Credit Hive.</p>
</section>

<section class="secao conteudo" data-slide aria-labelledby="ad-t">
  <div class="secao__cab"><p class="eyebrow">Por que vale o esforço</p><h2 id="ad-t">Sem harness e com harness</h2></div>
  <div class="tabela-wrap revelar"><table>
    <thead><tr><th></th><th>Só o modelo, no chat solto</th><th>Com harness</th></tr></thead>
    <tbody>
      <tr><td>Rota</td><td>Decide no caminho o que faltou</td><td>Plano revisado antes da primeira linha de código</td></tr>
      <tr><td>Contexto</td><td>Uma conversa que cresce até esquecer o começo</td><td>Uma fase por chat; subagentes com contexto limpo</td></tr>
      <tr><td>Segurança</td><td>Depende de o modelo seguir a instrução</td><td>Hooks garantem o que não pode falhar</td></tr>
      <tr><td>Qualidade</td><td>Quem escreveu revisa o próprio trabalho</td><td>Revisor independente e verificação por script</td></tr>
      <tr><td>Gestão</td><td>Uso e custo invisíveis</td><td>Painel com contagens e tokens</td></tr>
      <tr><td>Decisão</td><td>Misturada à conversa</td><td>Portões humanos com nome e motivo</td></tr>
    </tbody></table></div>
  <p class="regra-ouro revelar" style="margin-top:22px">Bom modelo é condição. <span>Harness é o que transforma em entrega.</span></p>
</section>

<div class="conteudo">
  <nav class="passagem" aria-label="Navegação entre páginas">
    <a href="pecas.aspx" data-anterior><small>← Anterior</small><strong>Agents, skills, MCP</strong></a>
    
  </nav>
  <footer class="rodape"><span>Engenharia com IA · fundamentos · BU Crédito</span><span><kbd>P</kbd> apresentação · <kbd>←</kbd> <kbd>→</kbd> navegar · <kbd>Esc</kbd> sair</span></footer>
</div>
</main>
<div class="slide-contador" aria-live="polite"></div>
</body>
</html>
