<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Engenharia com IA · fundamentos</title>
  <meta name="description" content="Tokens, janela de contexto, modelo e agente, as peças de um harness e por que ele existe.">
  <link rel="icon" type="image/svg+xml" href="img/simbolo-bia.svg">
  <link rel="stylesheet" href="style.css">
  <script src="vendor/motion-lite.js" defer></script>
  <script src="app.js" defer></script>
</head>
<body>
<a class="pular" href="#conteudo">Pular para o conteúdo</a>
<div class="colmeia" aria-hidden="true">
<svg class="colmeia__favo" aria-hidden="true" focusable="false"><defs><pattern id="bchive-favo" width="48.497" height="84" patternUnits="userSpaceOnUse"><path d="M24.25,0.00 L48.50,14.00 L48.50,42.00 L24.25,56.00 L-0.00,42.00 L0.00,14.00 Z"/><path d="M0.00,42.00 L24.25,56.00 L24.25,84.00 L0.00,98.00 L-24.25,84.00 L-24.25,56.00 Z"/><path d="M48.50,42.00 L72.75,56.00 L72.75,84.00 L48.50,98.00 L24.25,84.00 L24.25,56.00 Z"/><path d="M0.00,-42.00 L24.25,-28.00 L24.25,-0.00 L0.00,14.00 L-24.25,-0.00 L-24.25,-28.00 Z"/><path d="M48.50,-42.00 L72.75,-28.00 L72.75,-0.00 L48.50,14.00 L24.25,-0.00 L24.25,-28.00 Z"/></pattern></defs><rect width="100%" height="100%" fill="url(#bchive-favo)"/></svg>
<svg class="colmeia__cacho colmeia__cacho--a" viewBox="0 0 227.9 207.0" aria-hidden="true" focusable="false"><path d="M61.98,7.80 L86.40,21.90 L86.40,50.10 L61.98,64.20 L37.56,50.10 L37.56,21.90 Z" class="vazio"/><path d="M113.94,7.80 L138.36,21.90 L138.36,50.10 L113.94,64.20 L89.52,50.10 L89.52,21.90 Z" class="vazio"/><path d="M165.90,7.80 L190.33,21.90 L190.33,50.10 L165.90,64.20 L141.48,50.10 L141.48,21.90 Z" class="vazio"/><path d="M36.00,52.80 L60.42,66.90 L60.42,95.10 L36.00,109.20 L11.58,95.10 L11.58,66.90 Z" class="vazio"/><path d="M87.96,52.80 L112.38,66.90 L112.38,95.10 L87.96,109.20 L63.54,95.10 L63.54,66.90 Z" class="mel"/><path d="M139.92,52.80 L164.34,66.90 L164.34,95.10 L139.92,109.20 L115.50,95.10 L115.50,66.90 Z" class="mel"/><path d="M191.88,52.80 L216.31,66.90 L216.31,95.10 L191.88,109.20 L167.46,95.10 L167.46,66.90 Z" class="vazio"/><path d="M61.98,97.80 L86.40,111.90 L86.40,140.10 L61.98,154.20 L37.56,140.10 L37.56,111.90 Z" class="mel"/><path d="M113.94,97.80 L138.36,111.90 L138.36,140.10 L113.94,154.20 L89.52,140.10 L89.52,111.90 Z" class="mel"/><path d="M165.90,97.80 L190.33,111.90 L190.33,140.10 L165.90,154.20 L141.48,140.10 L141.48,111.90 Z" class="vazio"/><path d="M139.92,142.80 L164.34,156.90 L164.34,185.10 L139.92,199.20 L115.50,185.10 L115.50,156.90 Z" class="vazio"/><path d="M36.00,142.80 L60.42,156.90 L60.42,185.10 L36.00,199.20 L11.58,185.10 L11.58,156.90 Z" class="vazio"/><path d="M87.96,142.80 L112.38,156.90 L112.38,185.10 L87.96,199.20 L63.54,185.10 L63.54,156.90 Z" class="vazio"/></svg>
<svg class="colmeia__cacho colmeia__cacho--b" viewBox="0 0 197.5 140.4" aria-hidden="true" focusable="false"><path d="M53.72,6.76 L74.88,18.98 L74.88,43.42 L53.72,55.64 L32.55,43.42 L32.55,18.98 Z" class="vazio"/><path d="M98.75,6.76 L119.92,18.98 L119.92,43.42 L98.75,55.64 L77.58,43.42 L77.58,18.98 Z" class="mel"/><path d="M143.78,6.76 L164.95,18.98 L164.95,43.42 L143.78,55.64 L122.62,43.42 L122.62,18.98 Z" class="vazio"/><path d="M31.20,45.76 L52.37,57.98 L52.37,82.42 L31.20,94.64 L10.03,82.42 L10.03,57.98 Z" class="vazio"/><path d="M76.23,45.76 L97.40,57.98 L97.40,82.42 L76.23,94.64 L55.07,82.42 L55.07,57.98 Z" class="vazio"/><path d="M121.27,45.76 L142.43,57.98 L142.43,82.42 L121.27,94.64 L100.10,82.42 L100.10,57.98 Z" class="vazio"/><path d="M166.30,45.76 L187.47,57.98 L187.47,82.42 L166.30,94.64 L145.13,82.42 L145.13,57.98 Z" class="mel"/><path d="M53.72,84.76 L74.88,96.98 L74.88,121.42 L53.72,133.64 L32.55,121.42 L32.55,96.98 Z" class="vazio"/><path d="M98.75,84.76 L119.92,96.98 L119.92,121.42 L98.75,133.64 L77.58,121.42 L77.58,96.98 Z" class="vazio"/><path d="M143.78,84.76 L164.95,96.98 L164.95,121.42 L143.78,133.64 L122.62,121.42 L122.62,96.98 Z" class="mel"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="left:1%;top:14%" aria-hidden="true" focusable="false"><path d="M10 100 C 40 20, 90 110, 130 50 S 180 20, 195 40"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="right:1%;top:70%;transform:scaleX(-1)" aria-hidden="true" focusable="false"><path d="M10 90 C 50 10, 80 100, 120 40 S 170 30, 195 60"/></svg>
<svg class="abelha ab1" style="left:2.5%;top:20%;--d:13s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab1"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab1)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab2" style="right:3%;top:34%;--d:16s;--x:-16px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab2"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab2)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab3" style="left:4%;top:62%;--d:15s;--x:14px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab3"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab3)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab4" style="right:5%;top:76%;--d:12s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab4"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab4)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab5" style="right:22%;top:12%;--d:18s;--x:-12px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab5"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab5)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
</div>

<div class="progresso" aria-hidden="true"><div class="progresso__barra"></div></div>
<header class="topo">
  <div class="conteudo topo__linha">
    <a class="marca" href="index.aspx" aria-label="Fundamentos de IA, início">
      <img class="mlogo mlogo--c" src="img/logo-bia.svg" alt="b.IA Credit" height="28"><img class="mlogo mlogo--e" src="img/logo-bia-escuro.svg" alt="" height="28"><span class="marca__produto">Fundamentos de IA</span>
    </a>
    <nav aria-label="Páginas" class="nav"><ul class="menu"><li><a href="index.aspx" aria-current="page">Início</a></li><li><a href="tokens.aspx">Tokens e custo</a></li><li><a href="contexto.aspx">Janela de contexto</a></li><li><a href="modelo-agente.aspx">Modelo × agente</a></li><li><a href="pecas.aspx">Agents, skills, MCP</a></li><li><a href="harness.aspx">Harness</a></li></ul></nav>
    <div class="controles" data-controles></div>
  </div>
</header>
<main id="conteudo">
<section class="hero conteudo" data-slide>
  <div>
    <p class="eyebrow">Onboarding · BU Crédito</p>
    <h1 class="titulo-abertura">Engenharia com <span class="mel">IA</span></h1>
    <p class="lede">Antes de usar qualquer ferramenta, cinco ideias que explicam <strong>por que a IA às vezes acerta e às vezes inventa</strong>,
      quanto ela custa e o que separa um modelo de um time que entrega com ele.</p>
    <div class="acoes">
      <a class="btn btn--sinal" href="tokens.aspx">Começar pelos tokens →</a>
      <a class="btn" href="harness.aspx">Ir direto ao carro</a>
    </div>
  </div>
  <figure class="hero__marca" aria-hidden="true">
    <svg class="favo-hero" viewBox="0 0 303.8 276.0" aria-hidden="true" focusable="false"><path d="M117.28,70.40 L149.84,89.20 L149.84,126.80 L117.28,145.60 L84.72,126.80 L84.72,89.20 Z" class="mel"/><path d="M186.56,70.40 L219.13,89.20 L219.13,126.80 L186.56,145.60 L154.00,126.80 L154.00,89.20 Z" class="vazio"/><path d="M82.64,130.40 L115.20,149.20 L115.20,186.80 L82.64,205.60 L50.08,186.80 L50.08,149.20 Z" class="vazio"/><path d="M151.92,130.40 L184.49,149.20 L184.49,186.80 L151.92,205.60 L119.36,186.80 L119.36,149.20 Z" class="vazio"/><path d="M221.21,130.40 L253.77,149.20 L253.77,186.80 L221.21,205.60 L188.64,186.80 L188.64,149.20 Z" class="mel"/><path d="M117.28,190.40 L149.84,209.20 L149.84,246.80 L117.28,265.60 L84.72,246.80 L84.72,209.20 Z" class="mel"/><path d="M186.56,190.40 L219.13,209.20 L219.13,246.80 L186.56,265.60 L154.00,246.80 L154.00,209.20 Z" class="vazio"/><path d="M221.21,10.40 L253.77,29.20 L253.77,66.80 L221.21,85.60 L188.64,66.80 L188.64,29.20 Z" class="vazio"/><path d="M48.00,190.40 L80.56,209.20 L80.56,246.80 L48.00,265.60 L15.44,246.80 L15.44,209.20 Z" class="vazio"/><path d="M255.85,70.40 L288.41,89.20 L288.41,126.80 L255.85,145.60 L223.28,126.80 L223.28,89.20 Z" class="vazio"/></svg>
    <img class="hero__simbolo" src="img/simbolo-bia.svg" alt="">
  </figure>
</section>

<section class="secao conteudo" data-slide aria-labelledby="trilha-t">
  <div class="secao__cab"><p class="eyebrow">A trilha</p><h2 id="trilha-t">Cinco passos, do menor pedaço ao carro inteiro</h2>
    <p>Cada página tem uma parte para mexer. Use o seletor <strong>Gestão | Técnico</strong> no topo para ajustar a profundidade.</p></div>
  <ol class="trilha revelar-grupo">
    <li class="trilha__passo"><span class="trilha__n">1</span><div><h3><a href="tokens.aspx">Tokens e custo</a></h3>
      <p>O modelo não lê palavras, lê pedaços. Digite um prompt e veja o texto virar tokens, e os tokens virarem custo no Claude Opus 5.5 e no GPT-6 Luna.</p></div></li>
    <li class="trilha__passo"><span class="trilha__n">2</span><div><h3><a href="contexto.aspx">Janela de contexto</a></h3>
      <p>A memória de trabalho do modelo: o que cabe, como ela enche numa conversa longa e como organizar o uso no Copilot. E o Vault, a memória de longo prazo, e o RAG, o jeito de consultá-la.</p></div></li>
    <li class="trilha__passo"><span class="trilha__n">3</span><div><h3><a href="modelo-agente.aspx">Modelo × agente</a></h3>
      <p>O modelo responde texto. O agente do Copilot lê arquivos, roda comandos e confere o próprio trabalho. A mesma pergunta, dois resultados.</p></div></li>
    <li class="trilha__passo"><span class="trilha__n">4</span><div><h3><a href="pecas.aspx">Agents, subagents, skills, hooks e MCP</a></h3>
      <p>As peças que transformam o agente genérico no agente do seu time, os conectores para sistemas de fora e quando usar cada um.</p></div></li>
    <li class="trilha__passo"><span class="trilha__n">5</span><div><h3><a href="harness.aspx">Harness engineering</a></h3>
      <p>O carro em volta do motor. Clique em cada peça e veja como ele se monta do GitHub Copilot ao VS Code e ao nosso harness.</p></div></li>
  </ol>
</section>

<section class="secao conteudo" data-slide aria-labelledby="ideia-t">
  <div class="secao__cab"><p class="eyebrow">A ideia que amarra tudo</p><h2 id="ideia-t">O modelo é o motor. Quem entrega é o carro.</h2></div>
  <p class="regra-ouro revelar">Um motor de corrida solto no chão não leva ninguém a lugar nenhum.<br><span>O resultado vem de tudo o que montamos em volta do modelo.</span></p>
  <div class="grade revelar-grupo" style="margin-top:22px">
    <div class="card" data-nivel="gestao"><h3>Para a gestão</h3><p>Trocar de modelo muda custo e velocidade. O que muda previsibilidade, qualidade e risco é o processo em volta dele: rota, freios, vistoria e painel.</p></div>
    <div class="card" data-nivel="tecnico"><h3>Para o time técnico</h3><p>Contexto bem montado, ferramentas certas, instruções curtas, verificação determinística e revisão isolada pesam mais na qualidade do que a diferença entre dois modelos de ponta.</p></div>
  </div>
</section>

<div class="conteudo">
  <nav class="passagem" aria-label="Navegação entre páginas">
    <span></span>
    <a class="prox" href="tokens.aspx" data-proxima><small>Próxima →</small><strong>Tokens e custo</strong></a>
  </nav>
  <footer class="rodape"><span>Engenharia com IA · fundamentos · BU Crédito</span><span><kbd>P</kbd> apresentação · <kbd>←</kbd> <kbd>→</kbd> navegar · <kbd>Esc</kbd> sair</span></footer>
</div>
</main>
<div class="slide-contador" aria-live="polite"></div>
</body>
</html>
