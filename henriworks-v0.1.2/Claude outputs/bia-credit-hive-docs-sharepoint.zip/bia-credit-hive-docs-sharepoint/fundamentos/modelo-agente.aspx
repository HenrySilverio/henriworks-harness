<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Modelo e agente · Fundamentos de IA</title>
  <meta name="description" content="A diferença entre o modelo de linguagem e o agente do GitHub Copilot no VS Code.">
  <link rel="icon" type="image/svg+xml" href="img/simbolo-bia.svg">
  <link rel="stylesheet" href="style.css">
  <script src="vendor/motion-lite.js" defer></script>
  <script src="app.js" defer></script>
</head>
<body>
<a class="pular" href="#conteudo">Pular para o conteúdo</a>
<div class="colmeia" aria-hidden="true">
<svg class="colmeia__favo" aria-hidden="true" focusable="false"><defs><pattern id="bchive-favo" width="48.497" height="84" patternUnits="userSpaceOnUse"><path d="M24.25,0.00 L48.50,14.00 L48.50,42.00 L24.25,56.00 L-0.00,42.00 L0.00,14.00 Z"/><path d="M0.00,42.00 L24.25,56.00 L24.25,84.00 L0.00,98.00 L-24.25,84.00 L-24.25,56.00 Z"/><path d="M48.50,42.00 L72.75,56.00 L72.75,84.00 L48.50,98.00 L24.25,84.00 L24.25,56.00 Z"/><path d="M0.00,-42.00 L24.25,-28.00 L24.25,-0.00 L0.00,14.00 L-24.25,-0.00 L-24.25,-28.00 Z"/><path d="M48.50,-42.00 L72.75,-28.00 L72.75,-0.00 L48.50,14.00 L24.25,-0.00 L24.25,-28.00 Z"/></pattern></defs><rect width="100%" height="100%" fill="url(#bchive-favo)"/></svg>
<svg class="colmeia__cacho colmeia__cacho--a" viewBox="0 0 227.9 207.0" aria-hidden="true" focusable="false"><path d="M61.98,7.80 L86.40,21.90 L86.40,50.10 L61.98,64.20 L37.56,50.10 L37.56,21.90 Z" class="vazio"/><path d="M113.94,7.80 L138.36,21.90 L138.36,50.10 L113.94,64.20 L89.52,50.10 L89.52,21.90 Z" class="vazio"/><path d="M165.90,7.80 L190.33,21.90 L190.33,50.10 L165.90,64.20 L141.48,50.10 L141.48,21.90 Z" class="vazio"/><path d="M36.00,52.80 L60.42,66.90 L60.42,95.10 L36.00,109.20 L11.58,95.10 L11.58,66.90 Z" class="vazio"/><path d="M87.96,52.80 L112.38,66.90 L112.38,95.10 L87.96,109.20 L63.54,95.10 L63.54,66.90 Z" class="mel"/><path d="M139.92,52.80 L164.34,66.90 L164.34,95.10 L139.92,109.20 L115.50,95.10 L115.50,66.90 Z" class="mel"/><path d="M191.88,52.80 L216.31,66.90 L216.31,95.10 L191.88,109.20 L167.46,95.10 L167.46,66.90 Z" class="vazio"/><path d="M61.98,97.80 L86.40,111.90 L86.40,140.10 L61.98,154.20 L37.56,140.10 L37.56,111.90 Z" class="mel"/><path d="M113.94,97.80 L138.36,111.90 L138.36,140.10 L113.94,154.20 L89.52,140.10 L89.52,111.90 Z" class="mel"/><path d="M165.90,97.80 L190.33,111.90 L190.33,140.10 L165.90,154.20 L141.48,140.10 L141.48,111.90 Z" class="vazio"/><path d="M139.92,142.80 L164.34,156.90 L164.34,185.10 L139.92,199.20 L115.50,185.10 L115.50,156.90 Z" class="vazio"/><path d="M36.00,142.80 L60.42,156.90 L60.42,185.10 L36.00,199.20 L11.58,185.10 L11.58,156.90 Z" class="vazio"/><path d="M87.96,142.80 L112.38,156.90 L112.38,185.10 L87.96,199.20 L63.54,185.10 L63.54,156.90 Z" class="vazio"/></svg>
<svg class="colmeia__cacho colmeia__cacho--b" viewBox="0 0 197.5 140.4" aria-hidden="true" focusable="false"><path d="M53.72,6.76 L74.88,18.98 L74.88,43.42 L53.72,55.64 L32.55,43.42 L32.55,18.98 Z" class="vazio"/><path d="M98.75,6.76 L119.92,18.98 L119.92,43.42 L98.75,55.64 L77.58,43.42 L77.58,18.98 Z" class="mel"/><path d="M143.78,6.76 L164.95,18.98 L164.95,43.42 L143.78,55.64 L122.62,43.42 L122.62,18.98 Z" class="vazio"/><path d="M31.20,45.76 L52.37,57.98 L52.37,82.42 L31.20,94.64 L10.03,82.42 L10.03,57.98 Z" class="vazio"/><path d="M76.23,45.76 L97.40,57.98 L97.40,82.42 L76.23,94.64 L55.07,82.42 L55.07,57.98 Z" class="vazio"/><path d="M121.27,45.76 L142.43,57.98 L142.43,82.42 L121.27,94.64 L100.10,82.42 L100.10,57.98 Z" class="vazio"/><path d="M166.30,45.76 L187.47,57.98 L187.47,82.42 L166.30,94.64 L145.13,82.42 L145.13,57.98 Z" class="mel"/><path d="M53.72,84.76 L74.88,96.98 L74.88,121.42 L53.72,133.64 L32.55,121.42 L32.55,96.98 Z" class="vazio"/><path d="M98.75,84.76 L119.92,96.98 L119.92,121.42 L98.75,133.64 L77.58,121.42 L77.58,96.98 Z" class="vazio"/><path d="M143.78,84.76 L164.95,96.98 L164.95,121.42 L143.78,133.64 L122.62,121.42 L122.62,96.98 Z" class="mel"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="left:1%;top:14%" aria-hidden="true" focusable="false"><path d="M10 100 C 40 20, 90 110, 130 50 S 180 20, 195 40"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="right:1%;top:70%;transform:scaleX(-1)" aria-hidden="true" focusable="false"><path d="M10 90 C 50 10, 80 100, 120 40 S 170 30, 195 60"/></svg>
<svg class="abelha ab1" style="left:2.5%;top:20%;--d:13s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab1"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab1)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab2" style="right:3%;top:34%;--d:16s;--x:-16px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab2"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab2)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab3" style="left:4%;top:62%;--d:15s;--x:14px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab3"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab3)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab4" style="right:5%;top:76%;--d:12s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab4"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab4)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab5" style="right:22%;top:12%;--d:18s;--x:-12px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab5"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab5)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
</div>

<div class="progresso" aria-hidden="true"><div class="progresso__barra"></div></div>
<header class="topo">
  <div class="conteudo topo__linha">
    <a class="marca" href="index.aspx" aria-label="Fundamentos de IA, início">
      <img class="mlogo mlogo--c" src="img/logo-bia.svg" alt="b.IA Credit" height="28"><img class="mlogo mlogo--e" src="img/logo-bia-escuro.svg" alt="" height="28">
    </a>
    <nav class="sites" aria-label="Documentações"><a href="index.aspx" aria-current="true">Fundamentos de IA</a><a href="../hive/index.aspx">b.IA Credit Hive</a></nav>
    <nav aria-label="Páginas" class="nav"><ul class="menu"><li><a href="index.aspx">Início</a></li><li><a href="tokens.aspx">Tokens e custo</a></li><li><a href="contexto.aspx">Janela de contexto</a></li><li><a href="modelo-agente.aspx" aria-current="page">Modelo × agente</a></li><li><a href="pecas.aspx">Agents, skills, MCP</a></li><li><a href="harness.aspx">Harness</a></li></ul></nav>
    <div class="controles" data-controles></div>
  </div>
</header>
<main id="conteudo">
<section class="hero hero--pagina conteudo" data-slide>
  <div>
    <p class="eyebrow">3 · Modelo × agente</p>
    <h1 class="titulo-abertura">O modelo responde. O agente trabalha.</h1>
    <p class="lede">No VS Code você escolhe duas coisas diferentes: o <strong>modelo</strong> (GPT-6 Luna, Claude Opus 5.5…) e o <strong>agente</strong>.
      Confundir os dois é a origem de metade das frustrações com IA.</p>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="dif-t">
  <div class="secao__cab"><p class="eyebrow">A diferença</p><h2 id="dif-t">Um cérebro e um profissional com ferramentas</h2></div>
  <div class="compara">
    <div class="card caixa-modelo revelar"><h3>O modelo (LLM)</h3>
      <div class="fluxo-simples"><span>texto</span><i>→</i><span class="cerebro">modelo</span><i>→</i><span>texto</span></div>
      <p>Prevê o próximo token a partir do que recebeu. Não abre seus arquivos, não roda nada, não confere o que escreveu e não lembra da conversa anterior.</p></div>
    <div class="revelar"><figure class="diagrama diagrama--loop revelar"><svg viewBox="0 0 480 490" role="img" aria-labelledby="dl-t dl-d"><title id="dl-t">Ciclo do agente</title><desc id="dl-d">Ler, planejar, agir, verificar e registrar, num ciclo curto; o portão humano interrompe o ciclo quando a decisão é de uma pessoa.</desc><circle cx="240" cy="235" r="160" class="dg-anel"/><circle cx="240" cy="235" r="160" class="dg-anel dg-anel--vivo desenhar"/><g class="dg-no" style="--i:0"><path d="M240.0,21.0 L286.8,48.0 L286.8,102.0 L240.0,129.0 L193.2,102.0 L193.2,48.0 Z" class="dg-hex dg-hex--no"/><text x="240.0" y="73.0" class="dg-t dg-t--forte" text-anchor="middle">Ler</text><text x="240.0" y="89.0" class="dg-t dg-t--peq" text-anchor="middle">contexto mínimo</text></g><g class="dg-no" style="--i:1"><path d="M392.2,131.6 L438.9,158.6 L438.9,212.6 L392.2,239.6 L345.4,212.6 L345.4,158.6 Z" class="dg-hex dg-hex--no"/><text x="392.2" y="183.6" class="dg-t dg-t--forte" text-anchor="middle">Planejar</text><text x="392.2" y="199.6" class="dg-t dg-t--peq" text-anchor="middle">fase e fatia</text></g><g class="dg-no" style="--i:2"><path d="M334.0,310.4 L380.8,337.4 L380.8,391.4 L334.0,418.4 L287.3,391.4 L287.3,337.4 Z" class="dg-hex dg-hex--no"/><text x="334.0" y="362.4" class="dg-t dg-t--forte" text-anchor="middle">Agir</text><text x="334.0" y="378.4" class="dg-t dg-t--peq" text-anchor="middle">uma fatia</text></g><g class="dg-no" style="--i:3"><path d="M146.0,310.4 L192.7,337.4 L192.7,391.4 L146.0,418.4 L99.2,391.4 L99.2,337.4 Z" class="dg-hex dg-hex--no"/><text x="146.0" y="362.4" class="dg-t dg-t--forte" text-anchor="middle">Verificar</text><text x="146.0" y="378.4" class="dg-t dg-t--peq" text-anchor="middle">script prova</text></g><g class="dg-no" style="--i:4"><path d="M87.8,131.6 L134.6,158.6 L134.6,212.6 L87.8,239.6 L41.1,212.6 L41.1,158.6 Z" class="dg-hex dg-hex--no"/><text x="87.8" y="183.6" class="dg-t dg-t--forte" text-anchor="middle">Registrar</text><text x="87.8" y="199.6" class="dg-t dg-t--peq" text-anchor="middle">artefato</text></g><g class="voo"><circle r="7" class="dg-ponto"/><animateMotion dur="7.5s" repeatCount="indefinite" path="M240,75 a160,160 0 1,1 -0.1,0"/></g><path d="M240.0,173.0 L293.7,204.0 L293.7,266.0 L240.0,297.0 L186.3,266.0 L186.3,204.0 Z" class="dg-hex dg-hex--humano"/><text x="240" y="231" class="dg-t dg-t--forte" text-anchor="middle">Portão</text><text x="240" y="249" class="dg-t dg-t--peq" text-anchor="middle">humano decide</text><text x="240" y="484" class="dg-t dg-t--peq" text-anchor="middle">cada volta termina com uma prova, não com a memória do chat</text></svg></figure>

      <p class="nota" style="text-align:center">O agente: um ciclo em volta do modelo, com ferramentas e permissões.</p></div>
  </div>
  <div class="tabela-wrap revelar" style="margin-top:22px"><table>
    <thead><tr><th></th><th>Modelo</th><th>Agente do Copilot no VS Code</th></tr></thead>
    <tbody>
      <tr><td>O que é</td><td>Uma rede treinada que gera texto</td><td>Um programa que usa o modelo num ciclo: entende, planeja, age, verifica e repete</td></tr>
      <tr><td>Vê o seu projeto?</td><td>Só o que for colado no pedido</td><td>Lê e busca arquivos do repositório quando precisa</td></tr>
      <tr><td>Executa?</td><td>Não</td><td>Edita arquivos e roda comandos no terminal, com a sua permissão</td></tr>
      <tr><td>Confere o resultado?</td><td>Não</td><td>Roda o teste, lê o erro e tenta de novo</td></tr>
      <tr><td>Quem escolhe</td><td>Seletor de modelo do chat</td><td>Seletor de agente do chat (os do Copilot e os personalizados, como os do Hive)</td></tr>
      <tr><td>Troca para quê</td><td>Custo, velocidade, raciocínio mais profundo</td><td>Papel, ferramentas permitidas, instruções e processo</td></tr>
    </tbody></table></div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="ex-t">
  <div class="secao__cab"><p class="eyebrow">O mesmo pedido, duas vezes</p><h2 id="ex-t">"O teste do cálculo de parcela está falhando"</h2></div>
  <div class="abas revelar" data-abas>
    <div class="abas__lista" role="tablist" aria-label="Comparação">
      <button role="tab" aria-selected="true" aria-controls="ma-1" id="mt-1">Só o modelo</button>
      <button role="tab" aria-selected="false" aria-controls="ma-2" id="mt-2">Modelo + agente</button>
    </div>
    <div class="abas__painel" role="tabpanel" id="ma-1" aria-labelledby="mt-1">
      <div class="conversa">
        <div class="msg msg--voce">O teste do cálculo de parcela está falhando. Corrige?</div>
        <div class="msg msg--ia msg--risco">Provavelmente é arredondamento. Troque o cálculo por <code>Math.round(valor * 100) / 100</code> na função de parcela.<small>Ele nunca viu o teste, o código nem o erro: chutou a causa mais comum. Pode estar certo; pode quebrar outra coisa.</small></div>
      </div>
    </div>
    <div class="abas__painel" role="tabpanel" id="ma-2" aria-labelledby="mt-2">
      <div class="conversa">
        <div class="msg msg--voce">O teste do cálculo de parcela está falhando. Corrige?</div>
        <div class="msg msg--acao"><b>buscar</b> "parcela" → <code>calculo-parcela.spec.ts</code>, <code>calculo-parcela.ts</code></div>
        <div class="msg msg--acao"><b>terminal</b> npm test calculo-parcela → esperado 189,05, recebido 189,04</div>
        <div class="msg msg--acao"><b>ler</b> calculo-parcela.ts → divide antes de arredondar os juros</div>
        <div class="msg msg--acao"><b>editar</b> calculo-parcela.ts (2 linhas)</div>
        <div class="msg msg--acao"><b>terminal</b> npm test calculo-parcela → 14 testes passando</div>
        <div class="msg msg--ia">Os juros eram arredondados depois da divisão. Mudei a ordem; os 14 testes passam. Quer que eu rode a suíte inteira?<small>Mesmo modelo. A diferença é o ciclo: olhar, agir, conferir.</small></div>
      </div>
    </div>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="qual-t">
  <div class="secao__cab"><p class="eyebrow">Na prática</p><h2 id="qual-t">Quando trocar o modelo e quando trocar o agente</h2></div>
  <div class="grade grade--2 revelar-grupo">
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>M</span></span>Troque o modelo quando…</h3><ul class="lista">
      <li>a tarefa é simples e o modelo grande está caro e lento;</li>
      <li>o problema exige raciocínio longo (arquitetura, bug difícil);</li>
      <li>o contexto é muito grande e o custo dispara.</li></ul></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>A</span></span>Troque o agente quando…</h3><ul class="lista">
      <li>você quer outro papel (planejar, implementar, revisar);</li>
      <li>precisa limitar ferramentas (um revisor que só lê);</li>
      <li>quer seguir um processo do time, não o padrão genérico.</li></ul></div>
  </div>
  <p class="regra-ouro revelar" style="margin-top:22px">O mesmo modelo, com outro agente em volta, <span>entrega outro resultado.</span></p>
</section>

<div class="conteudo">
  <nav class="passagem" aria-label="Navegação entre páginas">
    <a href="contexto.aspx" data-anterior><small>← Anterior</small><strong>Janela de contexto</strong></a>
    <a class="prox" href="pecas.aspx" data-proxima><small>Próxima →</small><strong>Agents, skills, MCP</strong></a>
  </nav>
  <footer class="rodape"><span>Engenharia com IA · fundamentos · BU Crédito</span><span><kbd>P</kbd> apresentação · <kbd>←</kbd> <kbd>→</kbd> navegar · <kbd>Esc</kbd> sair</span></footer>
</div>
</main>
<div class="slide-contador" aria-live="polite"></div>
</body>
</html>
