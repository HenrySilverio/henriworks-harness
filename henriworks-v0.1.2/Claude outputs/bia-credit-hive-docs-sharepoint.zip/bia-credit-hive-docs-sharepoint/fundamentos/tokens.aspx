<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Tokens e custo · Fundamentos de IA</title>
  <meta name="description" content="Como o texto vira tokens e como os tokens viram custo, por modelo.">
  <link rel="icon" type="image/svg+xml" href="img/simbolo-bia.svg">
  <link rel="stylesheet" href="style.css">
  <script src="vendor/motion-lite.js" defer></script>
  <script src="vendor/tokenizador.js" defer></script>
  <script src="fundamentos.js" defer></script>
  <script src="app.js" defer></script>
</head>
<body>
<a class="pular" href="#conteudo">Pular para o conteúdo</a>
<div class="colmeia" aria-hidden="true">
<svg class="colmeia__favo" aria-hidden="true" focusable="false"><defs><pattern id="bchive-favo" width="48.497" height="84" patternUnits="userSpaceOnUse"><path d="M24.25,0.00 L48.50,14.00 L48.50,42.00 L24.25,56.00 L-0.00,42.00 L0.00,14.00 Z"/><path d="M0.00,42.00 L24.25,56.00 L24.25,84.00 L0.00,98.00 L-24.25,84.00 L-24.25,56.00 Z"/><path d="M48.50,42.00 L72.75,56.00 L72.75,84.00 L48.50,98.00 L24.25,84.00 L24.25,56.00 Z"/><path d="M0.00,-42.00 L24.25,-28.00 L24.25,-0.00 L0.00,14.00 L-24.25,-0.00 L-24.25,-28.00 Z"/><path d="M48.50,-42.00 L72.75,-28.00 L72.75,-0.00 L48.50,14.00 L24.25,-0.00 L24.25,-28.00 Z"/></pattern></defs><rect width="100%" height="100%" fill="url(#bchive-favo)"/></svg>
<svg class="colmeia__cacho colmeia__cacho--a" viewBox="0 0 227.9 207.0" aria-hidden="true" focusable="false"><path d="M61.98,7.80 L86.40,21.90 L86.40,50.10 L61.98,64.20 L37.56,50.10 L37.56,21.90 Z" class="vazio"/><path d="M113.94,7.80 L138.36,21.90 L138.36,50.10 L113.94,64.20 L89.52,50.10 L89.52,21.90 Z" class="vazio"/><path d="M165.90,7.80 L190.33,21.90 L190.33,50.10 L165.90,64.20 L141.48,50.10 L141.48,21.90 Z" class="vazio"/><path d="M36.00,52.80 L60.42,66.90 L60.42,95.10 L36.00,109.20 L11.58,95.10 L11.58,66.90 Z" class="vazio"/><path d="M87.96,52.80 L112.38,66.90 L112.38,95.10 L87.96,109.20 L63.54,95.10 L63.54,66.90 Z" class="mel"/><path d="M139.92,52.80 L164.34,66.90 L164.34,95.10 L139.92,109.20 L115.50,95.10 L115.50,66.90 Z" class="mel"/><path d="M191.88,52.80 L216.31,66.90 L216.31,95.10 L191.88,109.20 L167.46,95.10 L167.46,66.90 Z" class="vazio"/><path d="M61.98,97.80 L86.40,111.90 L86.40,140.10 L61.98,154.20 L37.56,140.10 L37.56,111.90 Z" class="mel"/><path d="M113.94,97.80 L138.36,111.90 L138.36,140.10 L113.94,154.20 L89.52,140.10 L89.52,111.90 Z" class="mel"/><path d="M165.90,97.80 L190.33,111.90 L190.33,140.10 L165.90,154.20 L141.48,140.10 L141.48,111.90 Z" class="vazio"/><path d="M139.92,142.80 L164.34,156.90 L164.34,185.10 L139.92,199.20 L115.50,185.10 L115.50,156.90 Z" class="vazio"/><path d="M36.00,142.80 L60.42,156.90 L60.42,185.10 L36.00,199.20 L11.58,185.10 L11.58,156.90 Z" class="vazio"/><path d="M87.96,142.80 L112.38,156.90 L112.38,185.10 L87.96,199.20 L63.54,185.10 L63.54,156.90 Z" class="vazio"/></svg>
<svg class="colmeia__cacho colmeia__cacho--b" viewBox="0 0 197.5 140.4" aria-hidden="true" focusable="false"><path d="M53.72,6.76 L74.88,18.98 L74.88,43.42 L53.72,55.64 L32.55,43.42 L32.55,18.98 Z" class="vazio"/><path d="M98.75,6.76 L119.92,18.98 L119.92,43.42 L98.75,55.64 L77.58,43.42 L77.58,18.98 Z" class="mel"/><path d="M143.78,6.76 L164.95,18.98 L164.95,43.42 L143.78,55.64 L122.62,43.42 L122.62,18.98 Z" class="vazio"/><path d="M31.20,45.76 L52.37,57.98 L52.37,82.42 L31.20,94.64 L10.03,82.42 L10.03,57.98 Z" class="vazio"/><path d="M76.23,45.76 L97.40,57.98 L97.40,82.42 L76.23,94.64 L55.07,82.42 L55.07,57.98 Z" class="vazio"/><path d="M121.27,45.76 L142.43,57.98 L142.43,82.42 L121.27,94.64 L100.10,82.42 L100.10,57.98 Z" class="vazio"/><path d="M166.30,45.76 L187.47,57.98 L187.47,82.42 L166.30,94.64 L145.13,82.42 L145.13,57.98 Z" class="mel"/><path d="M53.72,84.76 L74.88,96.98 L74.88,121.42 L53.72,133.64 L32.55,121.42 L32.55,96.98 Z" class="vazio"/><path d="M98.75,84.76 L119.92,96.98 L119.92,121.42 L98.75,133.64 L77.58,121.42 L77.58,96.98 Z" class="vazio"/><path d="M143.78,84.76 L164.95,96.98 L164.95,121.42 L143.78,133.64 L122.62,121.42 L122.62,96.98 Z" class="mel"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="left:1%;top:14%" aria-hidden="true" focusable="false"><path d="M10 100 C 40 20, 90 110, 130 50 S 180 20, 195 40"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="right:1%;top:70%;transform:scaleX(-1)" aria-hidden="true" focusable="false"><path d="M10 90 C 50 10, 80 100, 120 40 S 170 30, 195 60"/></svg>
<svg class="abelha ab1" style="left:2.5%;top:20%;--d:13s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab1"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab1)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab2" style="right:3%;top:34%;--d:16s;--x:-16px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab2"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab2)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab3" style="left:4%;top:62%;--d:15s;--x:14px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab3"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab3)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab4" style="right:5%;top:76%;--d:12s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab4"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab4)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab5" style="right:22%;top:12%;--d:18s;--x:-12px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab5"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab5)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
</div>

<div class="progresso" aria-hidden="true"><div class="progresso__barra"></div></div>
<header class="topo">
  <div class="conteudo topo__linha">
    <a class="marca" href="index.aspx" aria-label="Fundamentos de IA, início">
      <img class="mlogo mlogo--c" src="img/logo-bia.svg" alt="b.IA Credit" height="28"><img class="mlogo mlogo--e" src="img/logo-bia-escuro.svg" alt="" height="28">
    </a>
    <nav class="sites" aria-label="Documentações"><a href="index.aspx" aria-current="true">Fundamentos de IA</a><a href="../hive/index.aspx">b.IA Credit Hive</a></nav>
    <nav aria-label="Páginas" class="nav"><ul class="menu"><li><a href="index.aspx">Início</a></li><li><a href="tokens.aspx" aria-current="page">Tokens e custo</a></li><li><a href="contexto.aspx">Janela de contexto</a></li><li><a href="modelo-agente.aspx">Modelo × agente</a></li><li><a href="pecas.aspx">Agents, skills, MCP</a></li><li><a href="harness.aspx">Harness</a></li></ul></nav>
    <div class="controles" data-controles></div>
  </div>
</header>
<main id="conteudo">
<section class="hero hero--pagina conteudo" data-slide>
  <div>
    <p class="eyebrow">1 · Tokens e custo</p>
    <h1 class="titulo-abertura">O modelo não lê palavras. Lê pedaços.</h1>
    <p class="lede">Todo texto que entra ou sai de um modelo é cortado em <strong>tokens</strong>. É neles que o modelo pensa,
      é por eles que a janela enche e é por eles que se paga.</p>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="oque-t">
  <div class="secao__cab"><p class="eyebrow">O que é um token</p><h2 id="oque-t">Um pedaço de texto com número de série</h2></div>
  <div class="grade grade--2 revelar-grupo">
    <div class="card" data-nivel="gestao"><h3>Em uma frase</h3><p>Um token é um pedaço de palavra, mais ou menos como uma sílaba. Palavras comuns viram um token; palavras raras, nomes e outras línguas viram vários. Em português, conte em média <strong>pouco mais de um token por palavra</strong>.</p></div>
    <div class="card" data-nivel="tecnico"><h3>Por dentro</h3><p>O tokenizador usa um vocabulário fixo (o <code>o200k_base</code>, da família GPT-4o/GPT-5, tem cerca de 200 mil pedaços) aprendido por BPE. O texto vira uma lista de números (ids); o modelo só vê esses números. Cada fabricante tem o seu vocabulário: o mesmo texto dá contagens um pouco diferentes no Claude e no GPT.</p></div>
  </div>
  <div class="tok-par revelar" style="margin-top:22px">
    <div><h4>Português <span>12 tokens</span></h4><div class="tok-saida"><span class="tk tk--0" title="token 23665">Implement</span><span class="tk tk--1" title="token 277">ar</span><span class="tk tk--2" title="token 261">·a</span><span class="tk tk--3" title="token 9089">·fat</span><span class="tk tk--4" title="token 535">ia</span><span class="tk tk--5" title="token 220">·</span><span class="tk tk--0" title="token 2290">01</span><span class="tk tk--1" title="token 621">·do</span><span class="tk tk--2" title="token 27809">·acordo</span><span class="tk tk--3" title="token 25761">·duplic</span><span class="tk tk--4" title="token 1064">ado</span><span class="tk tk--5" title="token 13">.</span></div></div>
    <div><h4>Inglês <span>9 tokens</span></h4><div class="tok-saida"><span class="tk tk--0" title="token 23665">Implement</span><span class="tk tk--1" title="token 30288">·slice</span><span class="tk tk--2" title="token 220">·</span><span class="tk tk--3" title="token 2290">01</span><span class="tk tk--4" title="token 328">·of</span><span class="tk tk--5" title="token 290">·the</span><span class="tk tk--0" title="token 107680">·duplicated</span><span class="tk tk--1" title="token 15072">·agreement</span><span class="tk tk--2" title="token 13">.</span></div></div>
  </div>
  <p class="nota">O ponto (<code>·</code>) marca um espaço: ele viaja colado no token seguinte. Palavras em português se partem mais, porque o vocabulário foi montado com mais texto em inglês.</p>
</section>

<section class="secao conteudo" data-slide aria-labelledby="sim-t">
  <div class="secao__cab"><p class="eyebrow">Experimente</p><h2 id="sim-t">Escreva um prompt e veja os tokens</h2>
    <p>Tokenizador real (<code>o200k_base</code>), rodando no seu navegador: nada sai da página.</p></div>
  <div class="fx-caixa revelar" data-tok>
    <div data-tok-controles data-sem-js aria-hidden="true">
      <p class="fx-rotulo">Exemplos</p>
      <div class="fx-botoes">
        <button type="button" aria-pressed="false" data-tok-exemplo="Crie um endpoint que liste os acordos do cliente e devolva o saldo projetado de cada um.">Pedido em português</button>
        <button type="button" aria-pressed="false" data-tok-exemplo="Create an endpoint that lists the customer's agreements and returns the projected balance of each one.">O mesmo em inglês</button>
        <button type="button" aria-pressed="false" data-tok-exemplo="export function saldoProjetado(acordo: Acordo): number {\n  return acordo.parcelas.reduce((s, p) => s + p.valor, 0);\n}">Código TypeScript</button>
        <button type="button" aria-pressed="false" data-tok-exemplo='{"cliente": "123", "acordos": [{"id": 7, "parcelas": 12, "valor": 1890.5}]}'>JSON</button>
        <button type="button" aria-pressed="false" data-tok-exemplo="/bia-credit-hive:plan .bchive/briefings/GPCNLS-10019-saldo-projetado/briefing.md">Comando do Hive</button>
        <button type="button" aria-pressed="false" data-tok-exemplo="Ação, atenção, exceção, informação, renegociação 🐝">Acentos e emoji</button>
      </div>
      <label class="fx-rotulo" for="tok-in">Seu texto</label>
      <textarea id="tok-in" class="tok-entrada" data-tok-entrada spellcheck="false">Revise a fatia 02 e diga se o critério de aceite 3 está coberto pelos testes.</textarea>
    </div>
    <p class="fx-rotulo" style="margin-top:14px">Como o modelo enxerga</p>
    <div class="tok-saida" data-tok-saida aria-live="polite"><span class="tk tk--0" title="token 46580">Rev</span><span class="tk tk--1" title="token 1096">ise</span><span class="tk tk--2" title="token 261">·a</span><span class="tk tk--3" title="token 9089">·fat</span><span class="tk tk--4" title="token 535">ia</span><span class="tk tk--5" title="token 220">·</span><span class="tk tk--0" title="token 3286">02</span><span class="tk tk--1" title="token 319">·e</span><span class="tk tk--2" title="token 96515">·diga</span><span class="tk tk--3" title="token 458">·se</span><span class="tk tk--4" title="token 293">·o</span><span class="tk tk--5" title="token 6709">·crit</span><span class="tk tk--0" title="token 32658">ério</span><span class="tk tk--1" title="token 334">·de</span><span class="tk tk--2" title="token 61451">·aceite</span><span class="tk tk--3" title="token 220">·</span><span class="tk tk--4" title="token 18">3</span><span class="tk tk--5" title="token 5541">·está</span><span class="tk tk--0" title="token 20638">·cob</span><span class="tk tk--1" title="token 14859">erto</span><span class="tk tk--2" title="token 27740">·pelos</span><span class="tk tk--3" title="token 96699">·testes</span><span class="tk tk--4" title="token 13">.</span></div>
    <div class="tok-numeros">
      <div class="destaque"><strong data-tok-n>23</strong><span>tokens</span></div>
      <div><strong data-tok-car>77</strong><span>caracteres</span></div>
      <div><strong data-tok-pal>16</strong><span>palavras</span></div>
      <div><strong data-tok-razao>1,44</strong><span>tokens por palavra</span></div>
    </div>
  </div>
  <p class="nota">Um ▯ aparece quando um caractere (emoji, por exemplo) foi partido em mais de um token: cada pedaço sozinho não é um caractere válido.</p>
</section>

<section class="secao conteudo" data-slide aria-labelledby="custo-t">
  <div class="secao__cab"><p class="eyebrow">De token para dinheiro</p><h2 id="custo-t">Três preços: o que entra, o que sai e o que se repete</h2>
    <p>Todo modelo publica um preço por <strong>1 milhão de tokens</strong>, separado em três tipos.</p></div>
  <div class="grade revelar-grupo">
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>E</span></span>Entrada</h3><p>Tudo o que vai para o modelo ler: seu pedido, as instruções, os arquivos e o histórico da conversa.</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>S</span></span>Saída</h3><p>O que o modelo escreve. É <strong>5 vezes mais cara</strong> que a entrada nos dois modelos abaixo, porque é gerada um token de cada vez.</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>C</span></span>Cache</h3><p>O começo do pedido que se repete igual (instruções do agente, por exemplo) é lido com <strong>desconto de 90% a 95%</strong>. Gravar no cache pela primeira vez custa um pouco mais.</p></div>
  </div>
  <pre class="formula revelar"><code>custo = <span class="f-e">entrada nova</span> × preço de entrada
      + <span class="f-c">entrada em cache</span> × preço de cache
      + <span class="f-s">saída</span> × preço de saída          (tudo ÷ 1.000.000)</code></pre>
  <div class="tabela-wrap revelar" style="margin-top:18px"><table class="fx-tabela"><thead><tr><th scope="col">Modelo</th><th scope="col">Entrada</th><th scope="col">Entrada em cache</th><th scope="col">Escrita no cache</th><th scope="col">Saída</th><th scope="col">Janela</th></tr></thead><tbody><tr><th scope="row">Claude Opus 5.5<small>Anthropic</small></th><td>US$ 4,00</td><td>US$ 0,20</td><td>US$ 5,00</td><td>US$ 20,00</td><td>1.000 mil</td></tr><tr><th scope="row">GPT-6 Luna<small>OpenAI</small></th><td>US$ 0,10</td><td>US$ 0,01</td><td>US$ 0,13</td><td>US$ 0,50</td><td>1.050 mil</td></tr></tbody></table></div>
  <p class="nota">Preços de tabela em dólar por 1 milhão de tokens, lidos nas páginas oficiais da Anthropic, da OpenAI e do GitHub em 23/11/2026.
    No GPT-6 Luna, pedido com mais de 272 mil tokens de entrada custa 2× na entrada e no cache e 1,5× na saída.</p>
  <div class="grade grade--2 revelar-grupo" style="margin-top:18px">
    <div class="card"><h3>E no GitHub Copilot?</h3><p>Desde 1º de junho de 2026 o Copilot cobra por uso: cada pedido consome <strong>AI Credits</strong> pelos tokens de entrada, saída e cache, nas tarifas de API de cada modelo. <strong>1 crédito = US$ 0,01.</strong> O plano Business inclui US$ 19 em créditos por usuário por mês, somados na organização.</p></div>
    <div class="card"><h3>O que isso quer dizer</h3><p>O mesmo trabalho pode custar dezenas de vezes mais conforme o <strong>modelo escolhido</strong> e o <strong>tamanho do contexto</strong> enviado a cada turno. Os valores em reais e o contrato do banco ficam com o FinOps.</p></div>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="calc-t">
  <div class="secao__cab"><p class="eyebrow">Experimente</p><h2 id="calc-t">Quanto custa cada cena, em cada modelo</h2>
    <p>As instruções do Hive são números reais do plugin; o resto é ilustrativo e você pode mexer.</p></div>
  <div class="fx-caixa revelar" data-calc data-hive="{&quot;fixos&quot;:61,&quot;gf&quot;:485,&quot;implementador&quot;:1021,&quot;plan&quot;:2165,&quot;review&quot;:1316,&quot;contrato&quot;:6539}" data-sem-js aria-hidden="true">
    <div class="fx-botoes" data-calc-cenas></div>
    <div class="calc-grade">
      <div>
        <div class="calc-campo"><label for="c-ent">Tokens de entrada <strong data-calc-entrada-v></strong></label><input id="c-ent" type="range" min="0" data-calc-entrada></div>
        <div class="calc-campo"><label for="c-sai">Tokens de saída <strong data-calc-saida-v></strong></label><input id="c-sai" type="range" min="0" data-calc-saida></div>
        <div class="calc-campo"><label for="c-cac">Parte da entrada em cache <strong data-calc-cache-v></strong></label><input id="c-cac" type="range" min="0" data-calc-cache></div>
        <p class="nota" data-calc-pedidos></p>
        <p class="nota" data-calc-nota></p>
      </div>
      <div aria-live="polite"><div data-calc-resultado></div><p class="calc-razao" data-calc-razao></p></div>
    </div>
  </div>
  <div class="tabela-wrap revelar" style="margin-top:18px"><table class="fx-tabela"><thead><tr><th scope="col">Cena</th><th scope="col">Entrada</th><th scope="col">Saída</th><th scope="col">Cache</th><th scope="col">Claude Opus 5.5</th><th scope="col">GPT-6 Luna</th></tr></thead><tbody><tr><th scope="row">Pergunta rápida no chat<small>Uma pergunta e uma resposta curta. Valores ilustrativos.</small></th><td>3.000</td><td>500</td><td>0%</td><td><strong>US$ 0,02</strong><small>2,2 créditos</small></td><td><strong>US$ 0,0005</strong><small>0,05 créditos</small></td></tr><tr><th scope="row">Revisão isolada do Hive<small>Instruções do revisor bchive-gf (485 tokens, reais) + pacote e arquivos lidos (12 mil, ilustrativo).</small></th><td>12.485</td><td>1.500</td><td>0%</td><td><strong>US$ 0,08</strong><small>7,99 créditos</small></td><td><strong>US$ 0,0020</strong><small>0,2 créditos</small></td></tr><tr><th scope="row">Plano de uma mudança no Hive<small>Agente bchive-plan e contrato do fluxo (8.704 tokens, reais) + 20 mil de código lido (ilustrativo), em 6 pedidos com cache.</small></th><td>172.224</td><td>6.000</td><td>70%</td><td><strong>US$ 0,35</strong><small>35 créditos</small></td><td><strong>US$ 0,0094</strong><small>0,94 créditos</small></td></tr><tr><th scope="row">Chat solto com 30 turnos<small>Cada turno reenvia a conversa inteira: 30 pedidos de ~60 mil tokens. Valores ilustrativos.</small></th><td>1.800.000</td><td>24.000</td><td>80%</td><td><strong>US$ 2,21</strong><small>221 créditos</small></td><td><strong>US$ 0,06</strong><small>6,24 créditos</small></td></tr></tbody></table></div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="lic-t">
  <div class="secao__cab"><p class="eyebrow">O que levar daqui</p><h2 id="lic-t">Quatro regras de economia</h2></div>
  <div class="grade revelar-grupo">
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>1</span></span>O histórico é o maior custo</h3><p>Cada turno reenvia a conversa inteira. Num chat de 30 turnos, quase tudo o que se paga é o passado sendo relido.</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>2</span></span>Escrever custa mais que ler</h3><p>Peça respostas objetivas. Um plano de 6 mil tokens custa o mesmo que ler 30 mil.</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>3</span></span>Começo fixo, cache barato</h3><p>Instruções estáveis no começo do pedido entram no cache. É por isso que agentes com instruções curtas e fixas custam menos.</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>4</span></span>Modelo do tamanho da tarefa</h3><p>Tarefa simples em modelo enorme é pagar caro por nada. Tarefa difícil em modelo pequeno é retrabalho.</p></div>
  </div>
  <p class="nota" style="margin-top:14px">No Hive: fora do fluxo, o plugin acrescenta só 61 tokens fixos por pedido; o revisor carrega 485 tokens de instruções e o plano, o maior, 2.165 mais o contrato de 6.539.</p>
</section>

<div class="conteudo">
  <nav class="passagem" aria-label="Navegação entre páginas">
    <a href="index.aspx" data-anterior><small>← Anterior</small><strong>Início</strong></a>
    <a class="prox" href="contexto.aspx" data-proxima><small>Próxima →</small><strong>Janela de contexto</strong></a>
  </nav>
  <footer class="rodape"><span>Engenharia com IA · fundamentos · BU Crédito</span><span><kbd>P</kbd> apresentação · <kbd>←</kbd> <kbd>→</kbd> navegar · <kbd>Esc</kbd> sair</span></footer>
</div>
</main>
<div class="slide-contador" aria-live="polite"></div>
</body>
</html>
