<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Painel de uso · b.IA Credit Hive</title>
  <meta name="description" content="Exemplo do relatório de uso que a gestão vai ver: por dev, squad e todas as squads, por dia, semana e mês.">
  <link rel="icon" type="image/svg+xml" href="img/simbolo-bia.svg">
  <link rel="stylesheet" href="style.css">
  <script src="vendor/motion-lite.js" defer></script>
  <script src="painel.js" defer></script>
  <script src="app.js" defer></script>
</head>
<body>
<a class="pular" href="#conteudo">Pular para o conteúdo</a>
<div class="colmeia" aria-hidden="true">
<svg class="colmeia__favo" aria-hidden="true" focusable="false"><defs><pattern id="bchive-favo" width="48.497" height="84" patternUnits="userSpaceOnUse"><path d="M24.25,0.00 L48.50,14.00 L48.50,42.00 L24.25,56.00 L-0.00,42.00 L0.00,14.00 Z"/><path d="M0.00,42.00 L24.25,56.00 L24.25,84.00 L0.00,98.00 L-24.25,84.00 L-24.25,56.00 Z"/><path d="M48.50,42.00 L72.75,56.00 L72.75,84.00 L48.50,98.00 L24.25,84.00 L24.25,56.00 Z"/><path d="M0.00,-42.00 L24.25,-28.00 L24.25,-0.00 L0.00,14.00 L-24.25,-0.00 L-24.25,-28.00 Z"/><path d="M48.50,-42.00 L72.75,-28.00 L72.75,-0.00 L48.50,14.00 L24.25,-0.00 L24.25,-28.00 Z"/></pattern></defs><rect width="100%" height="100%" fill="url(#bchive-favo)"/></svg>
<svg class="colmeia__cacho colmeia__cacho--a" viewBox="0 0 227.9 207.0" aria-hidden="true" focusable="false"><path d="M61.98,7.80 L86.40,21.90 L86.40,50.10 L61.98,64.20 L37.56,50.10 L37.56,21.90 Z" class="vazio"/><path d="M113.94,7.80 L138.36,21.90 L138.36,50.10 L113.94,64.20 L89.52,50.10 L89.52,21.90 Z" class="vazio"/><path d="M165.90,7.80 L190.33,21.90 L190.33,50.10 L165.90,64.20 L141.48,50.10 L141.48,21.90 Z" class="vazio"/><path d="M36.00,52.80 L60.42,66.90 L60.42,95.10 L36.00,109.20 L11.58,95.10 L11.58,66.90 Z" class="vazio"/><path d="M87.96,52.80 L112.38,66.90 L112.38,95.10 L87.96,109.20 L63.54,95.10 L63.54,66.90 Z" class="mel"/><path d="M139.92,52.80 L164.34,66.90 L164.34,95.10 L139.92,109.20 L115.50,95.10 L115.50,66.90 Z" class="mel"/><path d="M191.88,52.80 L216.31,66.90 L216.31,95.10 L191.88,109.20 L167.46,95.10 L167.46,66.90 Z" class="vazio"/><path d="M61.98,97.80 L86.40,111.90 L86.40,140.10 L61.98,154.20 L37.56,140.10 L37.56,111.90 Z" class="mel"/><path d="M113.94,97.80 L138.36,111.90 L138.36,140.10 L113.94,154.20 L89.52,140.10 L89.52,111.90 Z" class="mel"/><path d="M165.90,97.80 L190.33,111.90 L190.33,140.10 L165.90,154.20 L141.48,140.10 L141.48,111.90 Z" class="vazio"/><path d="M139.92,142.80 L164.34,156.90 L164.34,185.10 L139.92,199.20 L115.50,185.10 L115.50,156.90 Z" class="vazio"/><path d="M36.00,142.80 L60.42,156.90 L60.42,185.10 L36.00,199.20 L11.58,185.10 L11.58,156.90 Z" class="vazio"/><path d="M87.96,142.80 L112.38,156.90 L112.38,185.10 L87.96,199.20 L63.54,185.10 L63.54,156.90 Z" class="vazio"/></svg>
<svg class="colmeia__cacho colmeia__cacho--b" viewBox="0 0 197.5 140.4" aria-hidden="true" focusable="false"><path d="M53.72,6.76 L74.88,18.98 L74.88,43.42 L53.72,55.64 L32.55,43.42 L32.55,18.98 Z" class="vazio"/><path d="M98.75,6.76 L119.92,18.98 L119.92,43.42 L98.75,55.64 L77.58,43.42 L77.58,18.98 Z" class="mel"/><path d="M143.78,6.76 L164.95,18.98 L164.95,43.42 L143.78,55.64 L122.62,43.42 L122.62,18.98 Z" class="vazio"/><path d="M31.20,45.76 L52.37,57.98 L52.37,82.42 L31.20,94.64 L10.03,82.42 L10.03,57.98 Z" class="vazio"/><path d="M76.23,45.76 L97.40,57.98 L97.40,82.42 L76.23,94.64 L55.07,82.42 L55.07,57.98 Z" class="vazio"/><path d="M121.27,45.76 L142.43,57.98 L142.43,82.42 L121.27,94.64 L100.10,82.42 L100.10,57.98 Z" class="vazio"/><path d="M166.30,45.76 L187.47,57.98 L187.47,82.42 L166.30,94.64 L145.13,82.42 L145.13,57.98 Z" class="mel"/><path d="M53.72,84.76 L74.88,96.98 L74.88,121.42 L53.72,133.64 L32.55,121.42 L32.55,96.98 Z" class="vazio"/><path d="M98.75,84.76 L119.92,96.98 L119.92,121.42 L98.75,133.64 L77.58,121.42 L77.58,96.98 Z" class="vazio"/><path d="M143.78,84.76 L164.95,96.98 L164.95,121.42 L143.78,133.64 L122.62,121.42 L122.62,96.98 Z" class="mel"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="left:1%;top:14%" aria-hidden="true" focusable="false"><path d="M10 100 C 40 20, 90 110, 130 50 S 180 20, 195 40"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="right:1%;top:70%;transform:scaleX(-1)" aria-hidden="true" focusable="false"><path d="M10 90 C 50 10, 80 100, 120 40 S 170 30, 195 60"/></svg>
<svg class="abelha ab1" style="left:2.5%;top:20%;--d:13s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab1"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab1)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab2" style="right:3%;top:34%;--d:16s;--x:-16px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab2"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab2)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab3" style="left:4%;top:62%;--d:15s;--x:14px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab3"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab3)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab4" style="right:5%;top:76%;--d:12s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab4"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab4)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab5" style="right:22%;top:12%;--d:18s;--x:-12px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab5"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab5)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
</div>

<div class="progresso" aria-hidden="true"><div class="progresso__barra"></div></div>
<header class="topo">
  <div class="conteudo topo__linha">
    <a class="marca" href="index.aspx" aria-label="b.IA Credit Hive, início">
      <img class="mlogo mlogo--c" src="img/logo-bia.svg" alt="b.IA Credit" height="28"><img class="mlogo mlogo--e" src="img/logo-bia-escuro.svg" alt="" height="28">
    </a>
    <nav class="sites" aria-label="Documentações"><a href="../fundamentos/index.aspx">Fundamentos de IA</a><a href="index.aspx" aria-current="true">b.IA Credit Hive</a></nav>
    <nav aria-label="Páginas da documentação" class="nav"><ul class="menu"><li><a href="index.aspx">Início</a></li><li><a href="por-dentro.aspx">Por dentro</a></li><li><a href="fluxo.aspx">Fluxo</a></li><li><a href="camadas.aspx">Camadas</a></li><li><a href="instalacao.aspx">Instalação</a></li><li><a href="cenarios.aspx">Cenários</a></li><li><a href="governanca.aspx">Governança</a></li><li><a href="painel.aspx" aria-current="page">Painel</a></li><li><a href="referencia.aspx">Referência</a></li></ul></nav>
    <div class="controles" data-controles></div>
  </div>
</header>
<main id="conteudo">
<section class="hero hero--pagina conteudo" data-slide>
  <div>
    <p class="eyebrow">Painel de uso · exemplo</p>
    <h1 class="titulo-abertura">O que a gestão vai ver</h1>
    <p class="lede">Adoção, tempo e entregas por <strong>dev, squad e todas as squads</strong>, por <strong>dia, semana e mês</strong>.
      Só contagens e tokens: nunca conversa, código ou valor em dinheiro.</p>
    <p><span class="selo selo--mel">Dados fictícios</span> <span class="selo">Destino central em definição</span></p>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="painel-t">
  <div class="secao__cab"><p class="eyebrow">Experimente</p><h2 id="painel-t">Troque a visão e o período</h2>
    <p>Quatro squads fictícias, uma delas em COBOL no mainframe usando o agente que o time já tinha como executor das fatias.
      O Hive entrou em cada squad numa data diferente, por isso a adoção cresce em degraus.</p></div>
  <div class="painel revelar" data-painel>
    <div class="pn-filtros" data-pn-filtros data-sem-js aria-hidden="true"></div>
    <div data-pn-corpo aria-live="polite"><p class="pn-contexto"><strong>Todas as squads</strong> · Semana de 09/11 a 13/11</p><div class="pn-kpis"><div class="pn-kpi"><div class="pn-kpi__r">Sessões com o Hive</div><div class="pn-kpi__v">55%</div><div class="pn-kpi__d pn-kpi__d--sobe"><span aria-hidden="true">▲</span> +1 p.p. <span class="pn-kpi__vs">vs semana anterior</span></div><div class="pn-kpi__n">200 de 365 sessões</div></div><div class="pn-kpi"><div class="pn-kpi__r">Sessões no Copilot</div><div class="pn-kpi__v">365</div><div class="pn-kpi__d pn-kpi__d--sobe"><span aria-hidden="true">▲</span> +12% <span class="pn-kpi__vs">vs semana anterior</span></div><div class="pn-kpi__n">18 dev(s) com uso</div></div><div class="pn-kpi"><div class="pn-kpi__r">Tempo ativo</div><div class="pn-kpi__v">163 h</div><div class="pn-kpi__d pn-kpi__d--sobe"><span aria-hidden="true">▲</span> +15% <span class="pn-kpi__vs">vs semana anterior</span></div><div class="pn-kpi__n">pausas longas não contam</div></div><div class="pn-kpi"><div class="pn-kpi__r">Entregas fechadas</div><div class="pn-kpi__v">12</div><div class="pn-kpi__d pn-kpi__d--igual"><span aria-hidden="true">■</span> 0% <span class="pn-kpi__vs">vs semana anterior</span></div><div class="pn-kpi__n">com OK do QA e registro</div></div><div class="pn-kpi"><div class="pn-kpi__r">Replanejamentos</div><div class="pn-kpi__v">25%</div><div class="pn-kpi__d pn-kpi__d--sobe"><span aria-hidden="true">▲</span> +6 p.p. <span class="pn-kpi__vs">vs semana anterior</span></div><div class="pn-kpi__n">dos planos do período</div></div><div class="pn-kpi"><div class="pn-kpi__r">Tokens</div><div class="pn-kpi__v">29,1 mi</div><div class="pn-kpi__d pn-kpi__d--sobe"><span aria-hidden="true">▲</span> +12% <span class="pn-kpi__vs">vs semana anterior</span></div><div class="pn-kpi__n">entrada + saída, sem custo</div></div></div><figure class="pn-graf"><figcaption class="pn-graf__t">Sessões por semana (8 semanas), por tipo de uso</figcaption><ul class="pn-leg" aria-label="Legenda"><li><i class="pn-seg--hive"></i>Com o Hive (fluxo)</li><li><i class="pn-seg--outros"></i>Outros plugins sozinhos</li><li><i class="pn-seg--solto"></i>Chat solto</li></ul><div class="pn-cols" role="list"><div class="pn-col" tabindex="0" role="listitem" aria-label="Semana de 21/09 a 25/09: 314 sessões · Hive 133 (42%) · outros plugins 37 · chat solto 144" data-tip="Semana de 21/09 a 25/09: 314 sessões · Hive 133 (42%) · outros plugins 37 · chat solto 144"><div class="pn-pilha" style="--h:86.03%"><span class="pn-seg pn-seg--solto" style="flex-grow:144"></span><span class="pn-seg pn-seg--outros" style="flex-grow:37"></span><span class="pn-seg pn-seg--hive" style="flex-grow:133"></span></div><span class="pn-col__x">21/09</span></div><div class="pn-col" tabindex="0" role="listitem" aria-label="Semana de 28/09 a 02/10: 296 sessões · Hive 140 (47%) · outros plugins 30 · chat solto 126" data-tip="Semana de 28/09 a 02/10: 296 sessões · Hive 140 (47%) · outros plugins 30 · chat solto 126"><div class="pn-pilha" style="--h:81.10%"><span class="pn-seg pn-seg--solto" style="flex-grow:126"></span><span class="pn-seg pn-seg--outros" style="flex-grow:30"></span><span class="pn-seg pn-seg--hive" style="flex-grow:140"></span></div><span class="pn-col__x">28/09</span></div><div class="pn-col" tabindex="0" role="listitem" aria-label="Semana de 05/10 a 09/10: 285 sessões · Hive 137 (48%) · outros plugins 26 · chat solto 122" data-tip="Semana de 05/10 a 09/10: 285 sessões · Hive 137 (48%) · outros plugins 26 · chat solto 122"><div class="pn-pilha" style="--h:78.08%"><span class="pn-seg pn-seg--solto" style="flex-grow:122"></span><span class="pn-seg pn-seg--outros" style="flex-grow:26"></span><span class="pn-seg pn-seg--hive" style="flex-grow:137"></span></div><span class="pn-col__x">05/10</span></div><div class="pn-col" tabindex="0" role="listitem" aria-label="Semana de 12/10 a 16/10: 317 sessões · Hive 165 (52%) · outros plugins 24 · chat solto 128" data-tip="Semana de 12/10 a 16/10: 317 sessões · Hive 165 (52%) · outros plugins 24 · chat solto 128"><div class="pn-pilha" style="--h:86.85%"><span class="pn-seg pn-seg--solto" style="flex-grow:128"></span><span class="pn-seg pn-seg--outros" style="flex-grow:24"></span><span class="pn-seg pn-seg--hive" style="flex-grow:165"></span></div><span class="pn-col__x">12/10</span></div><div class="pn-col" tabindex="0" role="listitem" aria-label="Semana de 19/10 a 23/10: 317 sessões · Hive 161 (51%) · outros plugins 26 · chat solto 130" data-tip="Semana de 19/10 a 23/10: 317 sessões · Hive 161 (51%) · outros plugins 26 · chat solto 130"><div class="pn-pilha" style="--h:86.85%"><span class="pn-seg pn-seg--solto" style="flex-grow:130"></span><span class="pn-seg pn-seg--outros" style="flex-grow:26"></span><span class="pn-seg pn-seg--hive" style="flex-grow:161"></span></div><span class="pn-col__x">19/10</span></div><div class="pn-col" tabindex="0" role="listitem" aria-label="Semana de 26/10 a 30/10: 318 sessões · Hive 167 (53%) · outros plugins 22 · chat solto 129" data-tip="Semana de 26/10 a 30/10: 318 sessões · Hive 167 (53%) · outros plugins 22 · chat solto 129"><div class="pn-pilha" style="--h:87.12%"><span class="pn-seg pn-seg--solto" style="flex-grow:129"></span><span class="pn-seg pn-seg--outros" style="flex-grow:22"></span><span class="pn-seg pn-seg--hive" style="flex-grow:167"></span></div><span class="pn-col__x">26/10</span></div><div class="pn-col" tabindex="0" role="listitem" aria-label="Semana de 02/11 a 06/11: 326 sessões · Hive 174 (53%) · outros plugins 27 · chat solto 125" data-tip="Semana de 02/11 a 06/11: 326 sessões · Hive 174 (53%) · outros plugins 27 · chat solto 125"><div class="pn-pilha" style="--h:89.32%"><span class="pn-seg pn-seg--solto" style="flex-grow:125"></span><span class="pn-seg pn-seg--outros" style="flex-grow:27"></span><span class="pn-seg pn-seg--hive" style="flex-grow:174"></span></div><span class="pn-col__x">02/11</span></div><div class="pn-col pn-col--atual" tabindex="0" role="listitem" aria-label="Semana de 09/11 a 13/11: 365 sessões · Hive 200 (55%) · outros plugins 23 · chat solto 142" data-tip="Semana de 09/11 a 13/11: 365 sessões · Hive 200 (55%) · outros plugins 23 · chat solto 142"><div class="pn-pilha" style="--h:100.00%"><span class="pn-seg pn-seg--solto" style="flex-grow:142"></span><span class="pn-seg pn-seg--outros" style="flex-grow:23"></span><span class="pn-seg pn-seg--hive" style="flex-grow:200"></span></div><span class="pn-col__pct">55% Hive</span><span class="pn-col__x">09/11</span></div></div><details class="pn-tab-graf"><summary>Ver os números do gráfico</summary><div class="tabela-wrap"><table><thead><tr><th>Período</th><th>Sessões</th><th>Com o Hive</th><th>Outros plugins</th><th>Chat solto</th><th>% Hive</th></tr></thead><tbody><tr><td>Semana de 21/09 a 25/09</td><td>314</td><td>133</td><td>37</td><td>144</td><td>42%</td></tr><tr><td>Semana de 28/09 a 02/10</td><td>296</td><td>140</td><td>30</td><td>126</td><td>47%</td></tr><tr><td>Semana de 05/10 a 09/10</td><td>285</td><td>137</td><td>26</td><td>122</td><td>48%</td></tr><tr><td>Semana de 12/10 a 16/10</td><td>317</td><td>165</td><td>24</td><td>128</td><td>52%</td></tr><tr><td>Semana de 19/10 a 23/10</td><td>317</td><td>161</td><td>26</td><td>130</td><td>51%</td></tr><tr><td>Semana de 26/10 a 30/10</td><td>318</td><td>167</td><td>22</td><td>129</td><td>53%</td></tr><tr><td>Semana de 02/11 a 06/11</td><td>326</td><td>174</td><td>27</td><td>125</td><td>53%</td></tr><tr><td>Semana de 09/11 a 13/11</td><td>365</td><td>200</td><td>23</td><td>142</td><td>55%</td></tr></tbody></table></div></details></figure><div class="pn-bloco"><h3 class="pn-bloco__t">Squads · Semana de 09/11 a 13/11</h3><div class="tabela-wrap"><table class="pn-tabela"><thead><tr><th scope="col">Squad</th><th scope="col">Devs com uso</th><th scope="col">Sessões</th><th scope="col">% com o Hive</th><th scope="col">Tempo ativo (h)</th><th scope="col">Entregas fechadas</th><th scope="col">Replanejamentos</th><th scope="col">Tokens</th></tr></thead><tbody><tr><th scope="row">Acordos<small>MFE Angular + BFF Java</small></th><td>5 de 5</td><td>98</td><td><span class="pn-barrinha" style="--v:67%"></span>67%</td><td>49</td><td>4</td><td>0%</td><td>8,8 mi</td></tr><tr><th scope="row">Renegociação<small>MFE React + BFF Java</small></th><td>4 de 4</td><td>88</td><td><span class="pn-barrinha" style="--v:63%"></span>63%</td><td>40</td><td>3</td><td>60%</td><td>7,2 mi</td></tr><tr><th scope="row">Cobrança Digital<small>BFF Java + Kotlin</small></th><td>5 de 5</td><td>98</td><td><span class="pn-barrinha" style="--v:52%"></span>52%</td><td>44</td><td>2</td><td>27%</td><td>7,7 mi</td></tr><tr><th scope="row">Crédito Mainframe<small>COBOL, JCL e DB2 no z/OS</small></th><td>4 de 4</td><td>81</td><td><span class="pn-barrinha" style="--v:35%"></span>35%</td><td>30</td><td>3</td><td>0%</td><td>5,5 mi</td></tr></tbody></table></div></div><div class="pn-dupla"><div class="pn-bloco"><h3 class="pn-bloco__t">Comandos do Hive mais usados <small>nas 8 semanas</small></h3><div class="grafico__linha"><span class="grafico__nome">/bia-credit-hive:implement</span><div class="grafico__trilho"><div class="grafico__barra" style="--v:100.0%"></div></div><span class="grafico__v">399</span></div><div class="grafico__linha"><span class="grafico__nome">/bia-credit-hive:review</span><div class="grafico__trilho"><div class="grafico__barra" style="--v:70.4%"></div></div><span class="grafico__v">281</span></div><div class="grafico__linha"><span class="grafico__nome">/bia-credit-hive:plan</span><div class="grafico__trilho"><div class="grafico__barra" style="--v:40.9%"></div></div><span class="grafico__v">163</span></div><div class="grafico__linha"><span class="grafico__nome">/bia-credit-hive:fechar</span><div class="grafico__trilho"><div class="grafico__barra" style="--v:22.6%"></div></div><span class="grafico__v">90</span></div><div class="grafico__linha"><span class="grafico__nome">/bia-credit-hive:archive</span><div class="grafico__trilho"><div class="grafico__barra" style="--v:21.6%"></div></div><span class="grafico__v">86</span></div><div class="grafico__linha"><span class="grafico__nome">/bia-credit-hive:triagem</span><div class="grafico__trilho"><div class="grafico__barra" style="--v:17.5%"></div></div><span class="grafico__v">70</span></div><div class="grafico__linha"><span class="grafico__nome">/bia-credit-hive:mapa</span><div class="grafico__trilho"><div class="grafico__barra" style="--v:16.0%"></div></div><span class="grafico__v">64</span></div><div class="grafico__linha"><span class="grafico__nome">/bia-credit-hive:grill</span><div class="grafico__trilho"><div class="grafico__barra" style="--v:13.8%"></div></div><span class="grafico__v">55</span></div><div class="grafico__linha"><span class="grafico__nome">/bia-credit-hive:lembrar</span><div class="grafico__trilho"><div class="grafico__barra" style="--v:6.3%"></div></div><span class="grafico__v">25</span></div><div class="grafico__linha"><span class="grafico__nome">/bia-credit-hive:squad-audit</span><div class="grafico__trilho"><div class="grafico__barra" style="--v:3.3%"></div></div><span class="grafico__v">13</span></div></div><div class="pn-bloco"><h3 class="pn-bloco__t">Quem executou as fatias <small>nas 8 semanas</small></h3><p class="nota">O Hive planeja e revisa; a fatia vai para o executor da stack. Agente de outro plugin entra como executor quando o dev confirma no plano.</p><div class="grafico__linha grafico__linha--exec"><span class="grafico__nome">bchive-implementador</span><div class="grafico__trilho"><div class="grafico__barra" style="--v:50.0%"></div></div><span class="grafico__v">200</span></div><div class="grafico__linha grafico__linha--exec"><span class="grafico__nome">java-plugin:spring-dev</span><div class="grafico__trilho"><div class="grafico__barra" style="--v:38.0%"></div></div><span class="grafico__v">152</span></div><div class="grafico__linha grafico__linha--exec"><span class="grafico__nome">mf-plugin:cobol-dev</span><div class="grafico__trilho"><div class="grafico__barra" style="--v:12.0%"></div></div><span class="grafico__v">48</span></div></div></div></div>
  </div>
  <p class="nota">Sem JavaScript, o painel mostra todas as squads na última semana. Passe o mouse ou o foco nas barras para ver os números de cada período.</p>
</section>

<section class="secao conteudo" data-slide aria-labelledby="origem-t">
  <div class="secao__cab"><p class="eyebrow">De onde vêm os números</p><h2 id="origem-t">Da máquina do dev ao painel</h2>
    <p>O plugin já coleta e exporta por dev. A visão por squad depende do destino central, que ainda está sendo decidido.</p></div>
  <div class="pilha" role="list">
    <div class="pilha__item" role="listitem" style="--n:4"><span class="pilha__num">1</span><div><h3>Hooks do plugin</h3><p>Em todo chat do harness Copilot, gravam contagens em <code>~/.bchive/uso/</code>, fora de qualquer repositório. Cada dia fechado é selado numa cadeia de hash.</p></div><span class="selo selo--ok">pronto</span></div>
    <div class="pilha__item" role="listitem" style="--n:5"><span class="pilha__num">2</span><div><h3>Exportação</h3><p><code>node .bchive/bin/uso.mjs exportar --de 2026-11-01 --ate 2026-11-30</code> gera o JSON agregado do período: totais, comandos, agentes, por repositório, ticket e dia.</p></div><span class="selo selo--ok">pronto</span></div>
    <div class="pilha__item" role="listitem" style="--n:6"><span class="pilha__num">3</span><div><h3>Destino central</h3><p>Recebe os JSONs dos devs e o cadastro dev → squad. Onde fica e como o JSON chega lá ainda está em definição.</p></div><span class="selo selo--aviso">em definição</span></div>
    <div class="pilha__item" role="listitem" style="--n:7"><span class="pilha__num">4</span><div><h3>Painel</h3><p>Soma os dias em semanas e meses e mostra as três visões. Esta página é o modelo da tela.</p></div><span class="selo selo--aviso">modelo</span></div>
  </div>
  <div class="tabela-wrap revelar" style="margin-top:18px"><table>
    <thead><tr><th>No painel</th><th>Campo do <code>uso.mjs exportar</code></th></tr></thead>
    <tbody>
      <tr><td>Sessões com o Hive</td><td><code>totais.sessoesFluxo</code> ÷ <code>totais.sessoes</code></td></tr>
      <tr><td>Outros plugins sozinhos e chat solto</td><td><code>totais.sessoesOutrosPlugins</code>, <code>totais.sessoesDoDev</code>, <code>totais.sessoesSoltas</code></td></tr>
      <tr><td>Tempo ativo</td><td><code>totais.ativoMin</code> (pausas longas não contam)</td></tr>
      <tr><td>Entregas fechadas</td><td><code>comandos["bia-credit-hive:fechar"]</code>: só roda depois do OK do QA</td></tr>
      <tr><td>Replanejamentos</td><td><code>versoesDaSpec</code> com mais de uma versão ÷ planos do período</td></tr>
      <tr><td>Tokens</td><td><code>totais.tokensEntrada</code> + <code>totais.tokensSaida</code>, quando a TI liga a telemetria do Agent Host</td></tr>
      <tr><td>Quem executou as fatias</td><td><code>agentesChamados</code> (executor do Hive ou agente de outro plugin)</td></tr>
      <tr><td>Dia, semana e mês</td><td><code>porDia</code>, somado pelo painel</td></tr>
      <tr><td>Dev</td><td><code>dev</code> (usuário da máquina)</td></tr>
      <tr><td>Squad</td><td>cadastro dev → squad no destino central (em definição)</td></tr>
    </tbody></table></div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="ler-t">
  <div class="secao__cab"><p class="eyebrow">Como ler</p><h2 id="ler-t">Quatro cuidados antes de tirar conclusão</h2></div>
  <div class="grade revelar-grupo">
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>1</span></span>Não é ranking de produtividade</h3><p>Sessões e tempo medem uso da ferramenta, não entrega nem esforço. A visão por dev serve para o dev e a liderança direta entenderem onde o fluxo ajuda ou atrapalha.</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>2</span></span>Chat solto não é erro</h3><p>Ajuste pequeno, dúvida e investigação ficam fora do fluxo de propósito. Adoção de 100% seria sinal de fluxo usado onde não precisa.</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>3</span></span>Tokens não são custo</h3><p>O painel mostra volume. Valor em dinheiro, crédito ou preço de modelo fica com o FinOps e não entra no relatório.</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>4</span></span>Compare com a mesma base</h3><p>O mês corrente é parcial: as variações dele são por dia útil. Squad que entrou há pouco ainda está na curva de adoção.</p></div>
  </div>
</section>

<div class="conteudo">
  <nav class="passagem" aria-label="Navegação entre páginas">
    <a href="governanca.aspx" data-anterior><small>← Anterior</small><strong>Governança</strong></a>
    <a class="prox" href="referencia.aspx" data-proxima><small>Próxima →</small><strong>Referência</strong></a>
  </nav>
  <footer class="rodape"><span>b.IA Credit Hive · documentação da versão 1.1 do plugin <code>bia-credit-hive</code></span><span><kbd>P</kbd> apresentação · <kbd>←</kbd> <kbd>→</kbd> navegar · <kbd>Esc</kbd> sair</span></footer>
</div>
</main>
<div class="slide-contador" aria-live="polite"></div>
</body>
</html>
