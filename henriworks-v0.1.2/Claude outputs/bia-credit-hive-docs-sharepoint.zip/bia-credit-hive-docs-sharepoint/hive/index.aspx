<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>b.IA Credit Hive · documentação</title>
  <meta name="description" content="Do ticket do Jira até a PR, com método: plano revisado, fatias, revisão isolada e OK do QA.">
  <link rel="icon" type="image/svg+xml" href="img/simbolo-bia.svg">
  <link rel="stylesheet" href="style.css">
  <script src="vendor/motion-lite.js" defer></script>
  <script src="app.js" defer></script>
</head>
<body>
<a class="pular" href="#conteudo">Pular para o conteúdo</a>
<div class="colmeia" aria-hidden="true">
<svg class="colmeia__favo" aria-hidden="true" focusable="false"><defs><pattern id="bchive-favo" width="48.497" height="84" patternUnits="userSpaceOnUse"><path d="M24.25,0.00 L48.50,14.00 L48.50,42.00 L24.25,56.00 L-0.00,42.00 L0.00,14.00 Z"/><path d="M0.00,42.00 L24.25,56.00 L24.25,84.00 L0.00,98.00 L-24.25,84.00 L-24.25,56.00 Z"/><path d="M48.50,42.00 L72.75,56.00 L72.75,84.00 L48.50,98.00 L24.25,84.00 L24.25,56.00 Z"/><path d="M0.00,-42.00 L24.25,-28.00 L24.25,-0.00 L0.00,14.00 L-24.25,-0.00 L-24.25,-28.00 Z"/><path d="M48.50,-42.00 L72.75,-28.00 L72.75,-0.00 L48.50,14.00 L24.25,-0.00 L24.25,-28.00 Z"/></pattern></defs><rect width="100%" height="100%" fill="url(#bchive-favo)"/></svg>
<svg class="colmeia__cacho colmeia__cacho--a" viewBox="0 0 227.9 207.0" aria-hidden="true" focusable="false"><path d="M61.98,7.80 L86.40,21.90 L86.40,50.10 L61.98,64.20 L37.56,50.10 L37.56,21.90 Z" class="vazio"/><path d="M113.94,7.80 L138.36,21.90 L138.36,50.10 L113.94,64.20 L89.52,50.10 L89.52,21.90 Z" class="vazio"/><path d="M165.90,7.80 L190.33,21.90 L190.33,50.10 L165.90,64.20 L141.48,50.10 L141.48,21.90 Z" class="vazio"/><path d="M36.00,52.80 L60.42,66.90 L60.42,95.10 L36.00,109.20 L11.58,95.10 L11.58,66.90 Z" class="vazio"/><path d="M87.96,52.80 L112.38,66.90 L112.38,95.10 L87.96,109.20 L63.54,95.10 L63.54,66.90 Z" class="mel"/><path d="M139.92,52.80 L164.34,66.90 L164.34,95.10 L139.92,109.20 L115.50,95.10 L115.50,66.90 Z" class="mel"/><path d="M191.88,52.80 L216.31,66.90 L216.31,95.10 L191.88,109.20 L167.46,95.10 L167.46,66.90 Z" class="vazio"/><path d="M61.98,97.80 L86.40,111.90 L86.40,140.10 L61.98,154.20 L37.56,140.10 L37.56,111.90 Z" class="mel"/><path d="M113.94,97.80 L138.36,111.90 L138.36,140.10 L113.94,154.20 L89.52,140.10 L89.52,111.90 Z" class="mel"/><path d="M165.90,97.80 L190.33,111.90 L190.33,140.10 L165.90,154.20 L141.48,140.10 L141.48,111.90 Z" class="vazio"/><path d="M139.92,142.80 L164.34,156.90 L164.34,185.10 L139.92,199.20 L115.50,185.10 L115.50,156.90 Z" class="vazio"/><path d="M36.00,142.80 L60.42,156.90 L60.42,185.10 L36.00,199.20 L11.58,185.10 L11.58,156.90 Z" class="vazio"/><path d="M87.96,142.80 L112.38,156.90 L112.38,185.10 L87.96,199.20 L63.54,185.10 L63.54,156.90 Z" class="vazio"/></svg>
<svg class="colmeia__cacho colmeia__cacho--b" viewBox="0 0 197.5 140.4" aria-hidden="true" focusable="false"><path d="M53.72,6.76 L74.88,18.98 L74.88,43.42 L53.72,55.64 L32.55,43.42 L32.55,18.98 Z" class="vazio"/><path d="M98.75,6.76 L119.92,18.98 L119.92,43.42 L98.75,55.64 L77.58,43.42 L77.58,18.98 Z" class="mel"/><path d="M143.78,6.76 L164.95,18.98 L164.95,43.42 L143.78,55.64 L122.62,43.42 L122.62,18.98 Z" class="vazio"/><path d="M31.20,45.76 L52.37,57.98 L52.37,82.42 L31.20,94.64 L10.03,82.42 L10.03,57.98 Z" class="vazio"/><path d="M76.23,45.76 L97.40,57.98 L97.40,82.42 L76.23,94.64 L55.07,82.42 L55.07,57.98 Z" class="vazio"/><path d="M121.27,45.76 L142.43,57.98 L142.43,82.42 L121.27,94.64 L100.10,82.42 L100.10,57.98 Z" class="vazio"/><path d="M166.30,45.76 L187.47,57.98 L187.47,82.42 L166.30,94.64 L145.13,82.42 L145.13,57.98 Z" class="mel"/><path d="M53.72,84.76 L74.88,96.98 L74.88,121.42 L53.72,133.64 L32.55,121.42 L32.55,96.98 Z" class="vazio"/><path d="M98.75,84.76 L119.92,96.98 L119.92,121.42 L98.75,133.64 L77.58,121.42 L77.58,96.98 Z" class="vazio"/><path d="M143.78,84.76 L164.95,96.98 L164.95,121.42 L143.78,133.64 L122.62,121.42 L122.62,96.98 Z" class="mel"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="left:1%;top:14%" aria-hidden="true" focusable="false"><path d="M10 100 C 40 20, 90 110, 130 50 S 180 20, 195 40"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="right:1%;top:70%;transform:scaleX(-1)" aria-hidden="true" focusable="false"><path d="M10 90 C 50 10, 80 100, 120 40 S 170 30, 195 60"/></svg>
<svg class="abelha ab1" style="left:2.5%;top:20%;--d:13s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab1"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab1)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab2" style="right:3%;top:34%;--d:16s;--x:-16px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab2"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab2)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab3" style="left:4%;top:62%;--d:15s;--x:14px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab3"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab3)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab4" style="right:5%;top:76%;--d:12s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab4"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab4)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab5" style="right:22%;top:12%;--d:18s;--x:-12px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab5"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab5)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
</div>

<div class="progresso" aria-hidden="true"><div class="progresso__barra"></div></div>
<header class="topo">
  <div class="conteudo topo__linha">
    <a class="marca" href="index.aspx" aria-label="b.IA Credit Hive, início">
      <img class="mlogo mlogo--c" src="img/logo-bia.svg" alt="b.IA Credit" height="28"><img class="mlogo mlogo--e" src="img/logo-bia-escuro.svg" alt="" height="28">
    </a>
    <nav class="sites" aria-label="Documentações"><a href="../fundamentos/index.aspx">Fundamentos de IA</a><a href="index.aspx" aria-current="true">b.IA Credit Hive</a></nav>
    <nav aria-label="Páginas da documentação" class="nav"><ul class="menu"><li><a href="index.aspx" aria-current="page">Início</a></li><li><a href="por-dentro.aspx">Por dentro</a></li><li><a href="fluxo.aspx">Fluxo</a></li><li><a href="camadas.aspx">Camadas</a></li><li><a href="instalacao.aspx">Instalação</a></li><li><a href="cenarios.aspx">Cenários</a></li><li><a href="governanca.aspx">Governança</a></li><li><a href="painel.aspx">Painel</a></li><li><a href="referencia.aspx">Referência</a></li></ul></nav>
    <div class="controles" data-controles></div>
  </div>
</header>
<main id="conteudo">
<section class="hero conteudo" data-slide>
  <div>
    <p class="eyebrow">Plugin do GitHub Copilot · melhor uso hoje: VS Code (harness Copilot) ou GitHub Copilot app</p>
    <h1 class="titulo-abertura">b.IA Credit <span class="mel">Hive</span></h1>
    <p class="lede">Leva uma demanda do <strong>ticket do Jira até a PR</strong> com método: entende o problema, planeja em fatias,
      implementa com o agente certo para cada stack, revisa com quem não viu a conversa e só fecha <strong>depois do OK do QA</strong>.
      Funciona em front-end, BFF, backend e legado (COBOL, mainframe), em qualquer framework.</p>
    <p class="onde-usar"><span class="selo selo--sinal">Onde usar</span> O melhor uso hoje é no <strong>VS Code com o chat no harness Copilot</strong> ou no <strong>GitHub Copilot app</strong>. Outras superfícies ainda não foram validadas com o fluxo.</p>
    <div class="acoes">
      <a class="btn btn--sinal" href="instalacao.aspx">Começar a usar →</a>
      <a class="btn" href="por-dentro.aspx">Como funciona por dentro</a>
    </div>
  </div>
  <figure class="hero__marca" aria-hidden="true">
    <svg class="favo-hero" viewBox="0 0 303.8 276.0" aria-hidden="true" focusable="false"><path d="M117.28,70.40 L149.84,89.20 L149.84,126.80 L117.28,145.60 L84.72,126.80 L84.72,89.20 Z" class="mel"/><path d="M186.56,70.40 L219.13,89.20 L219.13,126.80 L186.56,145.60 L154.00,126.80 L154.00,89.20 Z" class="vazio"/><path d="M82.64,130.40 L115.20,149.20 L115.20,186.80 L82.64,205.60 L50.08,186.80 L50.08,149.20 Z" class="vazio"/><path d="M151.92,130.40 L184.49,149.20 L184.49,186.80 L151.92,205.60 L119.36,186.80 L119.36,149.20 Z" class="vazio"/><path d="M221.21,130.40 L253.77,149.20 L253.77,186.80 L221.21,205.60 L188.64,186.80 L188.64,149.20 Z" class="mel"/><path d="M117.28,190.40 L149.84,209.20 L149.84,246.80 L117.28,265.60 L84.72,246.80 L84.72,209.20 Z" class="mel"/><path d="M186.56,190.40 L219.13,209.20 L219.13,246.80 L186.56,265.60 L154.00,246.80 L154.00,209.20 Z" class="vazio"/><path d="M221.21,10.40 L253.77,29.20 L253.77,66.80 L221.21,85.60 L188.64,66.80 L188.64,29.20 Z" class="vazio"/><path d="M48.00,190.40 L80.56,209.20 L80.56,246.80 L48.00,265.60 L15.44,246.80 L15.44,209.20 Z" class="vazio"/><path d="M255.85,70.40 L288.41,89.20 L288.41,126.80 L255.85,145.60 L223.28,126.80 L223.28,89.20 Z" class="vazio"/></svg>
    <img class="hero__simbolo" src="img/simbolo-bia.svg" alt="">
  </figure>
</section>

<div class="conteudo">
  <div class="numeros revelar-grupo" aria-label="O Hive em números">
    <div class="numero"><div class="numero__v" data-count data-to="9">9</div><div class="numero__t">agentes, cada um com só as permissões do seu papel</div></div>
    <div class="numero"><div class="numero__v" data-count data-to="18">18</div><div class="numero__t">comandos <code>/bia-credit-hive:*</code></div></div>
    <div class="numero"><div class="numero__v" data-count data-to="5">5</div><div class="numero__t">portões humanos: spec, revisão aceita, rodada extra, OK do QA e lição aprovada</div></div>
    <div class="numero"><div class="numero__v sinal" data-count data-to="1">1</div><div class="numero__t">pasta vai para o Git: <code>conhecimento/</code>, com o registro da entrega e as lições aprovadas</div></div>
    <div class="numero"><div class="numero__v" data-count data-to="47" data-suffix="/47">47/47</div><div class="numero__t">passos ok no teste de fumaça do núcleo</div></div>
  </div>
</div>

<div class="ticker" aria-hidden="true"><div class="ticker__trilho">
  <span>/bia-credit-hive:init</span><span>/bia-credit-hive:triagem GPCNLS-10019</span><span>/bia-credit-hive:plan .bchive/briefings/GPCNLS-10019-saldo-projetado/briefing.md</span><span>/bia-credit-hive:review spec GPCNLS-10019-mostrar-saldo-projetado</span><span>node .bchive/bin/bchive.mjs aprovar-spec GPCNLS-10019-mostrar-saldo-projetado --por "Fulana"</span><span>/bia-credit-hive:implement GPCNLS-10019-mostrar-saldo-projetado</span><span>/bia-credit-hive:archive GPCNLS-10019-mostrar-saldo-projetado</span><span>node .bchive/bin/bchive.mjs qa-ok 2026-11-20-GPCNLS-10019-mostrar-saldo-projetado --por "QA" --ambiente TU --resultado "..."</span>
  <span>/bia-credit-hive:init</span><span>/bia-credit-hive:triagem GPCNLS-10019</span><span>/bia-credit-hive:plan .bchive/briefings/GPCNLS-10019-saldo-projetado/briefing.md</span><span>/bia-credit-hive:review spec GPCNLS-10019-mostrar-saldo-projetado</span><span>node .bchive/bin/bchive.mjs aprovar-spec GPCNLS-10019-mostrar-saldo-projetado --por "Fulana"</span><span>/bia-credit-hive:implement GPCNLS-10019-mostrar-saldo-projetado</span><span>/bia-credit-hive:archive GPCNLS-10019-mostrar-saldo-projetado</span><span>node .bchive/bin/bchive.mjs qa-ok 2026-11-20-GPCNLS-10019-mostrar-saldo-projetado --por "QA" --ambiente TU --resultado "..."</span>
</div></div>

<section class="secao conteudo" data-slide aria-labelledby="pq-t">
  <div class="secao__cab">
    <p class="eyebrow">Por que existe</p>
    <h2 id="pq-t">IA ajuda muito. Sem método, ela também erra com confiança.</h2>
    <p>O Copilot sozinho responde bem a pedidos curtos. Numa entrega de verdade, quatro problemas aparecem sempre. O Hive existe para cada um deles.</p>
  </div>
  <div class="tabela-wrap revelar">
    <table>
      <thead><tr><th>O que acontece sem método</th><th>O que o Hive faz</th><th>Onde ver</th></tr></thead>
      <tbody>
        <tr><td>A conversa cresce, o modelo esquece o começo e decide sozinho o que faltou.</td><td>Uma fase por chat; o estado mora em arquivos, não na memória da conversa.</td><td><a href="por-dentro.aspx#loop">Ciclo do agente</a></td></tr>
        <tr><td>Quem escreveu o código revisa o próprio código e não vê a suposição que fez.</td><td>Um revisor sem contexto, provado por teste, com régua de severidade.</td><td><a href="por-dentro.aspx#revisao">Revisão isolada</a></td></tr>
        <tr><td>Ninguém sabe por que uma decisão foi tomada nem o que foi testado.</td><td>Proposta, fatias, vereditos e o OK do QA registrados; um resumo pronto para a PR.</td><td><a href="fluxo.aspx">O fluxo</a></td></tr>
        <tr><td>Custo e uso invisíveis: quanto do trabalho passou pela IA, e onde.</td><td>Contagem por sessão, agente, ticket e branch; tokens quando a TI liga a telemetria. Nunca o conteúdo.</td><td><a href="governanca.aspx#uso">Uso e privacidade</a></td></tr>
      </tbody>
    </table>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="colmeia-t">
  <div class="secao__cab">
    <p class="eyebrow">A colmeia em 30 segundos</p>
    <h2 id="colmeia-t">Uma rainha que coordena, operárias que executam, um revisor que não ouviu a conversa</h2>
    <p>A metáfora é literal: cada papel tem só o contexto e as ferramentas de que precisa. É isso que deixa o trabalho previsível e barato.</p>
  </div>
  <figure class="diagrama diagrama--colmeia revelar"><svg viewBox="0 0 900 400" role="img" aria-labelledby="dc-t dc-d"><title id="dc-t">Orquestração da colmeia</title><desc id="dc-d">A rainha coordena e despacha cada fatia para uma operária num contexto limpo; o peixinho revisa sem a conversa; o humano decide nos portões.</desc><path d="M260,200 C 410,200 400,80 512,80" class="dg-rota desenhar"/><path d="M260,200 C 410,200 490,160 602,160" class="dg-rota desenhar"/><path d="M260,200 C 410,200 400,240 512,240" class="dg-rota desenhar"/><path d="M260,200 C 410,200 490,320 602,320" class="dg-rota desenhar"/><path d="M190.0,122.0 L257.5,161.0 L257.5,239.0 L190.0,278.0 L122.5,239.0 L122.5,161.0 Z" class="dg-hex dg-hex--rainha"/><text x="190" y="192" class="dg-t dg-t--forte" text-anchor="middle">Rainha</text><text x="190" y="214" class="dg-t dg-t--peq" text-anchor="middle">agente de fase</text><text x="190" y="232" class="dg-t dg-t--peq" text-anchor="middle">coordena</text><g class="dg-fatia" style="--i:0"><path d="M560.0,34.0 L599.8,57.0 L599.8,103.0 L560.0,126.0 L520.2,103.0 L520.2,57.0 Z" class="dg-hex dg-hex--fatia"/><path d="M560.0,34.0 L599.8,57.0 L599.8,103.0 L560.0,126.0 L520.2,103.0 L520.2,57.0 Z" class="dg-mel"/><text x="560" y="76" class="dg-t dg-t--forte" text-anchor="middle">Fatia 01</text><text x="560" y="94" class="dg-t dg-t--mono" text-anchor="middle">feature/</text></g><g class="dg-fatia" style="--i:1"><path d="M650.0,114.0 L689.8,137.0 L689.8,183.0 L650.0,206.0 L610.2,183.0 L610.2,137.0 Z" class="dg-hex dg-hex--fatia"/><path d="M650.0,114.0 L689.8,137.0 L689.8,183.0 L650.0,206.0 L610.2,183.0 L610.2,137.0 Z" class="dg-mel"/><text x="650" y="156" class="dg-t dg-t--forte" text-anchor="middle">Fatia 02</text><text x="650" y="174" class="dg-t dg-t--mono" text-anchor="middle">core/api/</text></g><g class="dg-fatia" style="--i:2"><path d="M560.0,194.0 L599.8,217.0 L599.8,263.0 L560.0,286.0 L520.2,263.0 L520.2,217.0 Z" class="dg-hex dg-hex--fatia"/><path d="M560.0,194.0 L599.8,217.0 L599.8,263.0 L560.0,286.0 L520.2,263.0 L520.2,217.0 Z" class="dg-mel"/><text x="560" y="236" class="dg-t dg-t--forte" text-anchor="middle">Fatia 03</text><text x="560" y="254" class="dg-t dg-t--mono" text-anchor="middle">bff/</text></g><g class="dg-fatia" style="--i:3"><path d="M650.0,274.0 L689.8,297.0 L689.8,343.0 L650.0,366.0 L610.2,343.0 L610.2,297.0 Z" class="dg-hex dg-hex--fatia"/><path d="M650.0,274.0 L689.8,297.0 L689.8,343.0 L650.0,366.0 L610.2,343.0 L610.2,297.0 Z" class="dg-mel"/><text x="650" y="316" class="dg-t dg-t--forte" text-anchor="middle">Fatia 04</text><text x="650" y="334" class="dg-t dg-t--mono" text-anchor="middle">Verificação</text></g><g class="voo"><g class="mini-abelha"><ellipse cx="0" cy="0" rx="7" ry="5" class="ma-corpo"/><path d="M-2,-5 v10 M2,-5 v10" class="ma-listra"/><ellipse cx="-2" cy="-7" rx="4" ry="5" class="ma-asa"/><ellipse cx="3" cy="-7" rx="3.5" ry="4.5" class="ma-asa"/></g><animateMotion dur="3.20s" begin="0.0s" repeatCount="indefinite" rotate="auto" keyPoints="0;1;1" keyTimes="0;0.8;1" calcMode="linear" path="M260,200 C 410,200 400,80 512,80"/></g><g class="voo"><g class="mini-abelha"><ellipse cx="0" cy="0" rx="7" ry="5" class="ma-corpo"/><path d="M-2,-5 v10 M2,-5 v10" class="ma-listra"/><ellipse cx="-2" cy="-7" rx="4" ry="5" class="ma-asa"/><ellipse cx="3" cy="-7" rx="3.5" ry="4.5" class="ma-asa"/></g><animateMotion dur="3.55s" begin="0.8s" repeatCount="indefinite" rotate="auto" keyPoints="0;1;1" keyTimes="0;0.8;1" calcMode="linear" path="M260,200 C 410,200 490,160 602,160"/></g><g class="voo"><g class="mini-abelha"><ellipse cx="0" cy="0" rx="7" ry="5" class="ma-corpo"/><path d="M-2,-5 v10 M2,-5 v10" class="ma-listra"/><ellipse cx="-2" cy="-7" rx="4" ry="5" class="ma-asa"/><ellipse cx="3" cy="-7" rx="3.5" ry="4.5" class="ma-asa"/></g><animateMotion dur="3.90s" begin="1.6s" repeatCount="indefinite" rotate="auto" keyPoints="0;1;1" keyTimes="0;0.8;1" calcMode="linear" path="M260,200 C 410,200 400,240 512,240"/></g><g class="voo"><g class="mini-abelha"><ellipse cx="0" cy="0" rx="7" ry="5" class="ma-corpo"/><path d="M-2,-5 v10 M2,-5 v10" class="ma-listra"/><ellipse cx="-2" cy="-7" rx="4" ry="5" class="ma-asa"/><ellipse cx="3" cy="-7" rx="3.5" ry="4.5" class="ma-asa"/></g><animateMotion dur="4.25s" begin="2.4s" repeatCount="indefinite" rotate="auto" keyPoints="0;1;1" keyTimes="0;0.8;1" calcMode="linear" path="M260,200 C 410,200 490,320 602,320"/></g><g class="dg-papel"><rect x="760" y="40" width="124" height="74" rx="12" class="dg-caixa dg-caixa--humano"/><text x="822" y="72" class="dg-t dg-t--forte" text-anchor="middle">Humano</text><text x="822" y="92" class="dg-t dg-t--peq" text-anchor="middle">decide e commita</text></g><g class="dg-papel"><rect x="760" y="200" width="124" height="74" rx="12" class="dg-caixa dg-caixa--peixe"/><text x="822" y="232" class="dg-t dg-t--forte" text-anchor="middle">Peixinho</text><text x="822" y="252" class="dg-t dg-t--peq" text-anchor="middle">revisa isolado</text></g><path d="M700,200 C 725,205 735,235 760,237" class="dg-seta desenhar"/><path d="M822,200 L822,114" class="dg-seta desenhar"/><text x="832" y="162" class="dg-t dg-t--peq">veredito</text><text x="728" y="196" class="dg-t dg-t--peq" text-anchor="middle">diff</text><text x="190" y="376" class="dg-t dg-t--peq" text-anchor="middle">conhece o projeto, não executa</text><text x="605" y="392" class="dg-t dg-t--peq" text-anchor="middle">cada operária vê só a sua fatia e os ponteiros</text></svg></figure>

  <div class="grade revelar-grupo" style="margin-top:22px">
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>R</span></span>Rainha</h3><p>Os agentes de fase (<code>bchive-plan</code>, <code>bchive-implement</code>, <code>bchive-review</code>…). Conhecem o projeto, planejam e coordenam. Não revisam o próprio trabalho.</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>O</span></span>Operárias</h3><p>Executam uma fatia por vez, num contexto limpo: só a fatia e os ponteiros dela. Podem ser o executor do Hive ou o agente da sua stack (Java, Angular…).</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>P</span></span>Peixinho</h3><p>O revisor sem memória da conversa. Recebe um pacote gerado por script e julga só o que está escrito.</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>H</span></span>Humano</h3><p>Decide o que é do humano: aprovar a spec, aceitar risco, dar o OK do QA, commitar e abrir a PR.</p></div>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="dia-t">
  <div class="secao__cab">
    <p class="eyebrow">O que muda no dia a dia</p>
    <h2 id="dia-t">Para cada papel do time</h2>
  </div>
  <div class="grade revelar-grupo">
    <div class="card"><h3>Dev</h3><p>Pede no chat o que precisa e recebe um plano revisado antes da primeira linha de código. Implementa uma fatia por sessão, revisa e commita.</p></div>
    <div class="card"><h3>Tech lead</h3><p>Aprova uma spec curta em vez de ler um diff gigante. Vê os achados de revisão por eixo e os pontos que pedem decisão humana.</p></div>
    <div class="card"><h3>QA</h3><p>Recebe na PR um "Como testar" escrito a partir dos critérios. O registro da entrega só nasce depois do seu OK.</p></div>
    <div class="card"><h3>Gestão</h3><p>Acompanha adoção por time, ticket e período, com contagens auditáveis. Entende onde a IA entrou na entrega, sem expor conversa.</p></div>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="mapa-t">
  <div class="secao__cab">
    <p class="eyebrow">Nesta documentação</p>
    <h2 id="mapa-t">Escolha por onde começar</h2>
    <p>Use <kbd>P</kbd> para o modo apresentação e as setas para avançar. O seletor <strong>Gestão | Técnico</strong> no topo ajusta a profundidade das explicações.</p>
  </div>
  <div class="grade revelar-grupo">
    <a class="card card--link" href="../fundamentos/index.aspx"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>0</span></span>Primeira vez com IA? Fundamentos</h3><p>Tokens e custo, janela de contexto, modelo × agente, agents, skills, hooks, MCP e harness, antes do Hive.</p></a>
    <a class="card card--link" href="por-dentro.aspx"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>1</span></span>Como funciona por dentro</h3><p>Ciclo do agente, subagentes, economia de tokens, revisão e qualidade, em linguagem de gestão e técnica.</p></a>
    <a class="card card--link" href="fluxo.aspx"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>2</span></span>O fluxo</h3><p>As fases, quem faz cada uma e um exemplo de ponta a ponta com os artefatos reais.</p></a>
    <a class="card card--link" href="camadas.aspx"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>3</span></span>Camadas</h3><p>As sete camadas, o que é modelo e o que é script, e o que vai para o Git.</p></a>
    <a class="card card--link" href="instalacao.aspx"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>4</span></span>Instalação e configuração</h3><p>Do marketplace ao primeiro pedido, inclusive como preparar o agente da sua stack.</p></a>
    <a class="card card--link" href="cenarios.aspx"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>5</span></span>Cenários de uso</h3><p>Do ajuste pequeno à mudança em vários repositórios ao mesmo tempo, em qualquer stack.</p></a>
    <a class="card card--link" href="governanca.aspx"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>6</span></span>Governança</h3><p>Papéis, portões, privacidade, indicadores do piloto e limitações conhecidas.</p></a>
    <a class="card card--link" href="painel.aspx"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>7</span></span>Painel de uso</h3><p>Exemplo do relatório que a gestão vai ver: por dev, squad e todas as squads, por dia, semana e mês.</p></a>
    <a class="card card--link" href="referencia.aspx"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>8</span></span>Referência rápida</h3><p>Comandos, agentes, glossário e perguntas frequentes, com busca.</p></a>
  </div>
</section>

<div class="conteudo">
  <nav class="passagem" aria-label="Navegação entre páginas">
    <a href="../fundamentos/harness.aspx" data-anterior><small>← Antes</small><strong>Fundamentos de IA</strong></a>
    <a class="prox" href="por-dentro.aspx" data-proxima><small>Próxima →</small><strong>Por dentro</strong></a>
  </nav>
  <footer class="rodape"><span>b.IA Credit Hive · documentação da versão 1.1 do plugin <code>bia-credit-hive</code></span><span><kbd>P</kbd> apresentação · <kbd>←</kbd> <kbd>→</kbd> navegar · <kbd>Esc</kbd> sair</span></footer>
</div>
</main>
<div class="slide-contador" aria-live="polite"></div>
</body>
</html>
