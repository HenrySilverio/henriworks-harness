<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Como funciona por dentro · b.IA Credit Hive</title>
  <meta name="description" content="Ciclo do agente, subagentes, economia de tokens, revisão isolada e qualidade.">
  <link rel="icon" type="image/svg+xml" href="img/simbolo-bia.svg">
  <link rel="stylesheet" href="style.css">
  <script src="vendor/motion-lite.js" defer></script>
  <script src="app.js" defer></script>
</head>
<body>
<a class="pular" href="#conteudo">Pular para o conteúdo</a>
<div class="colmeia" aria-hidden="true">
<svg class="colmeia__favo" aria-hidden="true" focusable="false"><defs><pattern id="bchive-favo" width="48.497" height="84" patternUnits="userSpaceOnUse"><path d="M24.25,0.00 L48.50,14.00 L48.50,42.00 L24.25,56.00 L-0.00,42.00 L0.00,14.00 Z"/><path d="M0.00,42.00 L24.25,56.00 L24.25,84.00 L0.00,98.00 L-24.25,84.00 L-24.25,56.00 Z"/><path d="M48.50,42.00 L72.75,56.00 L72.75,84.00 L48.50,98.00 L24.25,84.00 L24.25,56.00 Z"/><path d="M0.00,-42.00 L24.25,-28.00 L24.25,-0.00 L0.00,14.00 L-24.25,-0.00 L-24.25,-28.00 Z"/><path d="M48.50,-42.00 L72.75,-28.00 L72.75,-0.00 L48.50,14.00 L24.25,-0.00 L24.25,-28.00 Z"/></pattern></defs><rect width="100%" height="100%" fill="url(#bchive-favo)"/></svg>
<svg class="colmeia__cacho colmeia__cacho--a" viewBox="0 0 227.9 207.0" aria-hidden="true" focusable="false"><path d="M61.98,7.80 L86.40,21.90 L86.40,50.10 L61.98,64.20 L37.56,50.10 L37.56,21.90 Z" class="vazio"/><path d="M113.94,7.80 L138.36,21.90 L138.36,50.10 L113.94,64.20 L89.52,50.10 L89.52,21.90 Z" class="vazio"/><path d="M165.90,7.80 L190.33,21.90 L190.33,50.10 L165.90,64.20 L141.48,50.10 L141.48,21.90 Z" class="vazio"/><path d="M36.00,52.80 L60.42,66.90 L60.42,95.10 L36.00,109.20 L11.58,95.10 L11.58,66.90 Z" class="vazio"/><path d="M87.96,52.80 L112.38,66.90 L112.38,95.10 L87.96,109.20 L63.54,95.10 L63.54,66.90 Z" class="mel"/><path d="M139.92,52.80 L164.34,66.90 L164.34,95.10 L139.92,109.20 L115.50,95.10 L115.50,66.90 Z" class="mel"/><path d="M191.88,52.80 L216.31,66.90 L216.31,95.10 L191.88,109.20 L167.46,95.10 L167.46,66.90 Z" class="vazio"/><path d="M61.98,97.80 L86.40,111.90 L86.40,140.10 L61.98,154.20 L37.56,140.10 L37.56,111.90 Z" class="mel"/><path d="M113.94,97.80 L138.36,111.90 L138.36,140.10 L113.94,154.20 L89.52,140.10 L89.52,111.90 Z" class="mel"/><path d="M165.90,97.80 L190.33,111.90 L190.33,140.10 L165.90,154.20 L141.48,140.10 L141.48,111.90 Z" class="vazio"/><path d="M139.92,142.80 L164.34,156.90 L164.34,185.10 L139.92,199.20 L115.50,185.10 L115.50,156.90 Z" class="vazio"/><path d="M36.00,142.80 L60.42,156.90 L60.42,185.10 L36.00,199.20 L11.58,185.10 L11.58,156.90 Z" class="vazio"/><path d="M87.96,142.80 L112.38,156.90 L112.38,185.10 L87.96,199.20 L63.54,185.10 L63.54,156.90 Z" class="vazio"/></svg>
<svg class="colmeia__cacho colmeia__cacho--b" viewBox="0 0 197.5 140.4" aria-hidden="true" focusable="false"><path d="M53.72,6.76 L74.88,18.98 L74.88,43.42 L53.72,55.64 L32.55,43.42 L32.55,18.98 Z" class="vazio"/><path d="M98.75,6.76 L119.92,18.98 L119.92,43.42 L98.75,55.64 L77.58,43.42 L77.58,18.98 Z" class="mel"/><path d="M143.78,6.76 L164.95,18.98 L164.95,43.42 L143.78,55.64 L122.62,43.42 L122.62,18.98 Z" class="vazio"/><path d="M31.20,45.76 L52.37,57.98 L52.37,82.42 L31.20,94.64 L10.03,82.42 L10.03,57.98 Z" class="vazio"/><path d="M76.23,45.76 L97.40,57.98 L97.40,82.42 L76.23,94.64 L55.07,82.42 L55.07,57.98 Z" class="vazio"/><path d="M121.27,45.76 L142.43,57.98 L142.43,82.42 L121.27,94.64 L100.10,82.42 L100.10,57.98 Z" class="vazio"/><path d="M166.30,45.76 L187.47,57.98 L187.47,82.42 L166.30,94.64 L145.13,82.42 L145.13,57.98 Z" class="mel"/><path d="M53.72,84.76 L74.88,96.98 L74.88,121.42 L53.72,133.64 L32.55,121.42 L32.55,96.98 Z" class="vazio"/><path d="M98.75,84.76 L119.92,96.98 L119.92,121.42 L98.75,133.64 L77.58,121.42 L77.58,96.98 Z" class="vazio"/><path d="M143.78,84.76 L164.95,96.98 L164.95,121.42 L143.78,133.64 L122.62,121.42 L122.62,96.98 Z" class="mel"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="left:1%;top:14%" aria-hidden="true" focusable="false"><path d="M10 100 C 40 20, 90 110, 130 50 S 180 20, 195 40"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="right:1%;top:70%;transform:scaleX(-1)" aria-hidden="true" focusable="false"><path d="M10 90 C 50 10, 80 100, 120 40 S 170 30, 195 60"/></svg>
<svg class="abelha ab1" style="left:2.5%;top:20%;--d:13s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab1"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab1)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab2" style="right:3%;top:34%;--d:16s;--x:-16px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab2"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab2)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab3" style="left:4%;top:62%;--d:15s;--x:14px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab3"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab3)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab4" style="right:5%;top:76%;--d:12s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab4"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab4)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab5" style="right:22%;top:12%;--d:18s;--x:-12px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab5"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab5)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
</div>

<div class="progresso" aria-hidden="true"><div class="progresso__barra"></div></div>
<header class="topo">
  <div class="conteudo topo__linha">
    <a class="marca" href="index.aspx" aria-label="b.IA Credit Hive, início">
      <img class="mlogo mlogo--c" src="img/logo-bia.svg" alt="b.IA Credit" height="28"><img class="mlogo mlogo--e" src="img/logo-bia-escuro.svg" alt="" height="28">
    </a>
    <nav class="sites" aria-label="Documentações"><a href="../fundamentos/index.aspx">Fundamentos de IA</a><a href="index.aspx" aria-current="true">b.IA Credit Hive</a></nav>
    <nav aria-label="Páginas da documentação" class="nav"><ul class="menu"><li><a href="index.aspx">Início</a></li><li><a href="por-dentro.aspx" aria-current="page">Por dentro</a></li><li><a href="fluxo.aspx">Fluxo</a></li><li><a href="camadas.aspx">Camadas</a></li><li><a href="instalacao.aspx">Instalação</a></li><li><a href="cenarios.aspx">Cenários</a></li><li><a href="governanca.aspx">Governança</a></li><li><a href="painel.aspx">Painel</a></li><li><a href="referencia.aspx">Referência</a></li></ul></nav>
    <div class="controles" data-controles></div>
  </div>
</header>
<main id="conteudo">
<section class="hero hero--pagina conteudo" data-slide>
  <div>
    <p class="eyebrow">Como funciona por dentro</p>
    <h1 class="titulo-abertura">O que está por trás do resultado</h1>
    <p class="lede">Cinco ideias sustentam o Hive. Cada uma tem uma leitura para <strong>gestão</strong> (risco, previsibilidade, custo) e uma para o
      <strong>time técnico</strong> (o mecanismo). Use o seletor no topo para mostrar uma, outra ou as duas.</p>
  </div>
</section>

<section class="secao conteudo" id="loop" data-slide aria-labelledby="loop-t">
  <div class="secao__cab">
    <p class="eyebrow">1 · Ciclo do agente (agent loop)</p>
    <h2 id="loop-t">Ciclos curtos, cada um com prova, em vez de uma conversa longa</h2>
  </div>
  <div class="duas-col">
    <figure class="diagrama diagrama--loop revelar"><svg viewBox="0 0 480 490" role="img" aria-labelledby="dl-t dl-d"><title id="dl-t">Ciclo do agente</title><desc id="dl-d">Ler, planejar, agir, verificar e registrar, num ciclo curto; o portão humano interrompe o ciclo quando a decisão é de uma pessoa.</desc><circle cx="240" cy="235" r="160" class="dg-anel"/><circle cx="240" cy="235" r="160" class="dg-anel dg-anel--vivo desenhar"/><g class="dg-no" style="--i:0"><path d="M240.0,21.0 L286.8,48.0 L286.8,102.0 L240.0,129.0 L193.2,102.0 L193.2,48.0 Z" class="dg-hex dg-hex--no"/><text x="240.0" y="73.0" class="dg-t dg-t--forte" text-anchor="middle">Ler</text><text x="240.0" y="89.0" class="dg-t dg-t--peq" text-anchor="middle">contexto mínimo</text></g><g class="dg-no" style="--i:1"><path d="M392.2,131.6 L438.9,158.6 L438.9,212.6 L392.2,239.6 L345.4,212.6 L345.4,158.6 Z" class="dg-hex dg-hex--no"/><text x="392.2" y="183.6" class="dg-t dg-t--forte" text-anchor="middle">Planejar</text><text x="392.2" y="199.6" class="dg-t dg-t--peq" text-anchor="middle">fase e fatia</text></g><g class="dg-no" style="--i:2"><path d="M334.0,310.4 L380.8,337.4 L380.8,391.4 L334.0,418.4 L287.3,391.4 L287.3,337.4 Z" class="dg-hex dg-hex--no"/><text x="334.0" y="362.4" class="dg-t dg-t--forte" text-anchor="middle">Agir</text><text x="334.0" y="378.4" class="dg-t dg-t--peq" text-anchor="middle">uma fatia</text></g><g class="dg-no" style="--i:3"><path d="M146.0,310.4 L192.7,337.4 L192.7,391.4 L146.0,418.4 L99.2,391.4 L99.2,337.4 Z" class="dg-hex dg-hex--no"/><text x="146.0" y="362.4" class="dg-t dg-t--forte" text-anchor="middle">Verificar</text><text x="146.0" y="378.4" class="dg-t dg-t--peq" text-anchor="middle">script prova</text></g><g class="dg-no" style="--i:4"><path d="M87.8,131.6 L134.6,158.6 L134.6,212.6 L87.8,239.6 L41.1,212.6 L41.1,158.6 Z" class="dg-hex dg-hex--no"/><text x="87.8" y="183.6" class="dg-t dg-t--forte" text-anchor="middle">Registrar</text><text x="87.8" y="199.6" class="dg-t dg-t--peq" text-anchor="middle">artefato</text></g><g class="voo"><circle r="7" class="dg-ponto"/><animateMotion dur="7.5s" repeatCount="indefinite" path="M240,75 a160,160 0 1,1 -0.1,0"/></g><path d="M240.0,173.0 L293.7,204.0 L293.7,266.0 L240.0,297.0 L186.3,266.0 L186.3,204.0 Z" class="dg-hex dg-hex--humano"/><text x="240" y="231" class="dg-t dg-t--forte" text-anchor="middle">Portão</text><text x="240" y="249" class="dg-t dg-t--peq" text-anchor="middle">humano decide</text><text x="240" y="484" class="dg-t dg-t--peq" text-anchor="middle">cada volta termina com uma prova, não com a memória do chat</text></svg></figure>

    <div>
      <div class="nivel">
        <div data-nivel="gestao"><span class="nivel__tag">Gestão</span>
          <p>Um agente de IA trabalha em ciclos: lê, decide, age e confere. O risco está nos ciclos longos sem conferência, em que um erro pequeno vira retrabalho grande.
          No Hive, cada fase é um ciclo curto que termina com uma <strong>prova verificável</strong> (um arquivo, um teste, um veredito) e, quando o assunto é decisão, com uma pessoa.</p>
          <p>Resultado: dá para interromper, retomar e auditar qualquer entrega sem depender de quem estava na conversa.</p></div>
        <div data-nivel="tecnico"><span class="nivel__tag">Técnico</span>
          <p><strong>Uma fase por chat.</strong> Cada agente de fase recebe só o contrato da sua fase e os artefatos da mudança. O estado não fica no chat:
          <code>node .bchive/bin/bchive.mjs estado</code> deriva a fase de cada mudança a partir dos arquivos em <code>.bchive/changes/</code>.</p>
          <p>Cada passo do ciclo é fechado por script (<code>validar</code>, <code>fatias</code>, <code>conferir-toca</code>, <code>verificar.mjs</code>, <code>gravar-veredito</code>),
          e os hooks do plugin barram o que o agente não pode fazer (editar veredito, rodar portão humano).</p></div>
      </div>
    </div>
  </div>
</section>

<section class="secao conteudo" id="subagentes" data-slide aria-labelledby="sub-t">
  <div class="secao__cab">
    <p class="eyebrow">2 · Orquestração de subagentes</p>
    <h2 id="sub-t">Quem coordena não executa; quem executa vê só a sua tarefa</h2>
  </div>
  <figure class="diagrama diagrama--colmeia revelar"><svg viewBox="0 0 900 400" role="img" aria-labelledby="dc-t dc-d"><title id="dc-t">Orquestração da colmeia</title><desc id="dc-d">A rainha coordena e despacha cada fatia para uma operária num contexto limpo; o peixinho revisa sem a conversa; o humano decide nos portões.</desc><path d="M260,200 C 410,200 400,80 512,80" class="dg-rota desenhar"/><path d="M260,200 C 410,200 490,160 602,160" class="dg-rota desenhar"/><path d="M260,200 C 410,200 400,240 512,240" class="dg-rota desenhar"/><path d="M260,200 C 410,200 490,320 602,320" class="dg-rota desenhar"/><path d="M190.0,122.0 L257.5,161.0 L257.5,239.0 L190.0,278.0 L122.5,239.0 L122.5,161.0 Z" class="dg-hex dg-hex--rainha"/><text x="190" y="192" class="dg-t dg-t--forte" text-anchor="middle">Rainha</text><text x="190" y="214" class="dg-t dg-t--peq" text-anchor="middle">agente de fase</text><text x="190" y="232" class="dg-t dg-t--peq" text-anchor="middle">coordena</text><g class="dg-fatia" style="--i:0"><path d="M560.0,34.0 L599.8,57.0 L599.8,103.0 L560.0,126.0 L520.2,103.0 L520.2,57.0 Z" class="dg-hex dg-hex--fatia"/><path d="M560.0,34.0 L599.8,57.0 L599.8,103.0 L560.0,126.0 L520.2,103.0 L520.2,57.0 Z" class="dg-mel"/><text x="560" y="76" class="dg-t dg-t--forte" text-anchor="middle">Fatia 01</text><text x="560" y="94" class="dg-t dg-t--mono" text-anchor="middle">feature/</text></g><g class="dg-fatia" style="--i:1"><path d="M650.0,114.0 L689.8,137.0 L689.8,183.0 L650.0,206.0 L610.2,183.0 L610.2,137.0 Z" class="dg-hex dg-hex--fatia"/><path d="M650.0,114.0 L689.8,137.0 L689.8,183.0 L650.0,206.0 L610.2,183.0 L610.2,137.0 Z" class="dg-mel"/><text x="650" y="156" class="dg-t dg-t--forte" text-anchor="middle">Fatia 02</text><text x="650" y="174" class="dg-t dg-t--mono" text-anchor="middle">core/api/</text></g><g class="dg-fatia" style="--i:2"><path d="M560.0,194.0 L599.8,217.0 L599.8,263.0 L560.0,286.0 L520.2,263.0 L520.2,217.0 Z" class="dg-hex dg-hex--fatia"/><path d="M560.0,194.0 L599.8,217.0 L599.8,263.0 L560.0,286.0 L520.2,263.0 L520.2,217.0 Z" class="dg-mel"/><text x="560" y="236" class="dg-t dg-t--forte" text-anchor="middle">Fatia 03</text><text x="560" y="254" class="dg-t dg-t--mono" text-anchor="middle">bff/</text></g><g class="dg-fatia" style="--i:3"><path d="M650.0,274.0 L689.8,297.0 L689.8,343.0 L650.0,366.0 L610.2,343.0 L610.2,297.0 Z" class="dg-hex dg-hex--fatia"/><path d="M650.0,274.0 L689.8,297.0 L689.8,343.0 L650.0,366.0 L610.2,343.0 L610.2,297.0 Z" class="dg-mel"/><text x="650" y="316" class="dg-t dg-t--forte" text-anchor="middle">Fatia 04</text><text x="650" y="334" class="dg-t dg-t--mono" text-anchor="middle">Verificação</text></g><g class="voo"><g class="mini-abelha"><ellipse cx="0" cy="0" rx="7" ry="5" class="ma-corpo"/><path d="M-2,-5 v10 M2,-5 v10" class="ma-listra"/><ellipse cx="-2" cy="-7" rx="4" ry="5" class="ma-asa"/><ellipse cx="3" cy="-7" rx="3.5" ry="4.5" class="ma-asa"/></g><animateMotion dur="3.20s" begin="0.0s" repeatCount="indefinite" rotate="auto" keyPoints="0;1;1" keyTimes="0;0.8;1" calcMode="linear" path="M260,200 C 410,200 400,80 512,80"/></g><g class="voo"><g class="mini-abelha"><ellipse cx="0" cy="0" rx="7" ry="5" class="ma-corpo"/><path d="M-2,-5 v10 M2,-5 v10" class="ma-listra"/><ellipse cx="-2" cy="-7" rx="4" ry="5" class="ma-asa"/><ellipse cx="3" cy="-7" rx="3.5" ry="4.5" class="ma-asa"/></g><animateMotion dur="3.55s" begin="0.8s" repeatCount="indefinite" rotate="auto" keyPoints="0;1;1" keyTimes="0;0.8;1" calcMode="linear" path="M260,200 C 410,200 490,160 602,160"/></g><g class="voo"><g class="mini-abelha"><ellipse cx="0" cy="0" rx="7" ry="5" class="ma-corpo"/><path d="M-2,-5 v10 M2,-5 v10" class="ma-listra"/><ellipse cx="-2" cy="-7" rx="4" ry="5" class="ma-asa"/><ellipse cx="3" cy="-7" rx="3.5" ry="4.5" class="ma-asa"/></g><animateMotion dur="3.90s" begin="1.6s" repeatCount="indefinite" rotate="auto" keyPoints="0;1;1" keyTimes="0;0.8;1" calcMode="linear" path="M260,200 C 410,200 400,240 512,240"/></g><g class="voo"><g class="mini-abelha"><ellipse cx="0" cy="0" rx="7" ry="5" class="ma-corpo"/><path d="M-2,-5 v10 M2,-5 v10" class="ma-listra"/><ellipse cx="-2" cy="-7" rx="4" ry="5" class="ma-asa"/><ellipse cx="3" cy="-7" rx="3.5" ry="4.5" class="ma-asa"/></g><animateMotion dur="4.25s" begin="2.4s" repeatCount="indefinite" rotate="auto" keyPoints="0;1;1" keyTimes="0;0.8;1" calcMode="linear" path="M260,200 C 410,200 490,320 602,320"/></g><g class="dg-papel"><rect x="760" y="40" width="124" height="74" rx="12" class="dg-caixa dg-caixa--humano"/><text x="822" y="72" class="dg-t dg-t--forte" text-anchor="middle">Humano</text><text x="822" y="92" class="dg-t dg-t--peq" text-anchor="middle">decide e commita</text></g><g class="dg-papel"><rect x="760" y="200" width="124" height="74" rx="12" class="dg-caixa dg-caixa--peixe"/><text x="822" y="232" class="dg-t dg-t--forte" text-anchor="middle">Peixinho</text><text x="822" y="252" class="dg-t dg-t--peq" text-anchor="middle">revisa isolado</text></g><path d="M700,200 C 725,205 735,235 760,237" class="dg-seta desenhar"/><path d="M822,200 L822,114" class="dg-seta desenhar"/><text x="832" y="162" class="dg-t dg-t--peq">veredito</text><text x="728" y="196" class="dg-t dg-t--peq" text-anchor="middle">diff</text><text x="190" y="376" class="dg-t dg-t--peq" text-anchor="middle">conhece o projeto, não executa</text><text x="605" y="392" class="dg-t dg-t--peq" text-anchor="middle">cada operária vê só a sua fatia e os ponteiros</text></svg></figure>

  <div class="grade grade--2 revelar-grupo" style="margin-top:22px">
    <div class="card" data-nivel="gestao"><h3>Para a gestão</h3>
      <p>O trabalho é dividido em <strong>fatias</strong>: pedaços que entregam um comportamento visível e cabem numa sessão. Cada fatia declara antes quais arquivos pode tocar.</p>
      <p>Isso permite paralelismo sem bagunça, usar o agente especialista de cada stack (Java, Angular, Swift…) e saber exatamente o que cada execução mudou.</p></div>
    <div class="card" data-nivel="tecnico"><h3>Para o time técnico</h3>
      <p><code>bchive-implement</code> lê o grafo (<code>fatias</code>), reivindica as fatias da sessão e delega cada uma a um <strong>subagente novo</strong>:
      <code>bia-credit-hive:bchive-implementador</code> ou o executor da fatia (<code>Executor: java-plugin:spring-dev</code>). A mensagem é só o caminho da fatia.</p>
      <p>Ao voltar: <code>conferir-toca</code> compara o que mudou com o <code>Toca:</code> declarado e abre cartão de decisão quando sai do escopo; o verificador roda só nas camadas da mudança.</p></div>
  </div>
</section>

<section class="secao conteudo" id="tokens" data-slide aria-labelledby="tok-t">
  <div class="secao__cab">
    <p class="eyebrow">3 · Economia de tokens</p>
    <h2 id="tok-t">Cada papel carrega só o que usa</h2>
    <p>Token é a unidade de custo e de atenção do modelo: contexto demais custa mais e piora a resposta. Abaixo, o tamanho real das instruções de cada agente do plugin (estimativa: caracteres ÷ 4).</p>
  </div>
  <div class="grafico revelar" role="figure" aria-label="Tokens estimados das instruções de cada agente">
  <div class="grafico__titulo">Instruções que cada papel carrega (≈ tokens)</div>
  <p class="nota">O contrato completo só é lido no plano; as outras fases leem as seções delas. O revisor, o menor de todos, recebe o resto num pacote sob medida.</p>
  <div class="grafico__linha"><span class="grafico__nome" title="bchive-gf · revisor">bchive-gf · revisor</span><div class="grafico__trilho"><div class="grafico__barra" style="--v:7.4%"></div></div><span class="grafico__v" data-to="485">485</span></div>
  <div class="grafico__linha"><span class="grafico__nome" title="bchive-discovery">bchive-discovery</span><div class="grafico__trilho"><div class="grafico__barra" style="--v:6.9%"></div></div><span class="grafico__v" data-to="448">448</span></div>
  <div class="grafico__linha"><span class="grafico__nome" title="bchive-implementador · operária">bchive-implementador · operária</span><div class="grafico__trilho"><div class="grafico__barra" style="--v:15.6%"></div></div><span class="grafico__v" data-to="1021">1.021</span></div>
  <div class="grafico__linha"><span class="grafico__nome" title="bchive-review">bchive-review</span><div class="grafico__trilho"><div class="grafico__barra" style="--v:20.1%"></div></div><span class="grafico__v" data-to="1316">1.316</span></div>
  <div class="grafico__linha"><span class="grafico__nome" title="bchive-archive">bchive-archive</span><div class="grafico__trilho"><div class="grafico__barra" style="--v:21.8%"></div></div><span class="grafico__v" data-to="1427">1.427</span></div>
  <div class="grafico__linha"><span class="grafico__nome" title="bchive-implement">bchive-implement</span><div class="grafico__trilho"><div class="grafico__barra" style="--v:21.1%"></div></div><span class="grafico__v" data-to="1381">1.381</span></div>
  <div class="grafico__linha"><span class="grafico__nome" title="bchive-plan">bchive-plan</span><div class="grafico__trilho"><div class="grafico__barra" style="--v:33.1%"></div></div><span class="grafico__v" data-to="2165">2.165</span></div>
  <div class="grafico__linha grafico__linha--sub"><span class="grafico__nome" title="contrato do fluxo (inteiro)">contrato do fluxo (inteiro)</span><div class="grafico__trilho"><div class="grafico__barra" style="--v:100.0%"></div></div><span class="grafico__v" data-to="6539">6.539</span></div>
</div>
  <div class="grade revelar-grupo" style="margin-top:22px">
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>1</span></span>Nada fixo em todo chat</h3>
      <div class="nivel"><div data-nivel="gestao"><p>Fora do fluxo, o Hive custa quase nada: cerca de 61 tokens por pedido, só a descrição do comando de entrada.</p></div>
      <div data-nivel="tecnico"><p>Sem bloco no <code>AGENTS.md</code>: as regras foram para os agentes, o hook e a skill <code>start</code> (a única que o modelo pode carregar sozinho).</p></div></div></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>2</span></span>Mapa antes de busca</h3>
      <div class="nivel"><div data-nivel="gestao"><p>Em vez de o agente abrir dezenas de arquivos para se localizar, ele pergunta a um mapa do projeto.</p></div>
      <div data-nivel="tecnico"><p><code>bchivemap.mjs query | explain | affected</code>, saída cortada em 2.000 caracteres; o hook nega a primeira busca textual numa sessão do fluxo.</p></div></div></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>3</span></span>Regra em código, não em texto</h3>
      <div class="nivel"><div data-nivel="gestao"><p>O que dá para conferir por programa não é pedido ao modelo: é conferido, sempre igual, sem custo.</p></div>
      <div data-nivel="tecnico"><p>5.466 linhas de script fazem os portões mecânicos (formato, grafo, escopo, veredito). Regra em markdown custa token a cada leitura; em código, zero.</p></div></div></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>4</span></span>Contexto por fatia</h3>
      <div class="nivel"><div data-nivel="gestao"><p>Quem executa recebe a tarefa e os ponteiros dela, não a conversa inteira.</p></div>
      <div data-nivel="tecnico"><p>O executor lê a fatia e só o que <code>## Ponteiros</code> cita; o revisor lê só o que o pacote lista; as referências do contrato carregam sob demanda.</p></div></div></div>
  </div>
</section>

<section class="secao conteudo" id="revisao" data-slide aria-labelledby="rev-t">
  <div class="secao__cab">
    <p class="eyebrow">4 · Revisão isolada</p>
    <h2 id="rev-t">Quem escreve não revisa</h2>
    <p>O autor não enxerga a suposição que nunca escreveu. Um revisor que não viu a conversa tropeça exatamente nela.</p>
  </div>
  <figure class="diagrama diagrama--revisao revelar"><svg viewBox="0 0 900 300" role="img" aria-labelledby="dr-t dr-d"><title id="dr-t">Revisão isolada</title><desc id="dr-d">O autor tem a conversa inteira; o script gera um pacote; o peixinho lê só o pacote e devolve um veredito que o script grava.</desc><rect x="20" y="40" width="230" height="220" rx="16" class="dg-caixa"/><text x="135" y="72" class="dg-t dg-t--forte" text-anchor="middle">Autor (elefante)</text><rect x="44" y="92" width="182" height="28" rx="8" class="dg-bolha" style="--i:0"/><text x="135" y="111" class="dg-t dg-t--peq" text-anchor="middle">conversa inteira</text><rect x="44" y="130" width="182" height="28" rx="8" class="dg-bolha" style="--i:1"/><text x="135" y="149" class="dg-t dg-t--peq" text-anchor="middle">suposições não escritas</text><rect x="44" y="168" width="182" height="28" rx="8" class="dg-bolha" style="--i:2"/><text x="135" y="187" class="dg-t dg-t--peq" text-anchor="middle">decisões do chat</text><rect x="44" y="206" width="182" height="28" rx="8" class="dg-bolha" style="--i:3"/><text x="135" y="225" class="dg-t dg-t--peq" text-anchor="middle">o código</text><path d="M250,150 L340,150" class="dg-seta desenhar"/><path d="M420.0,80.0 L480.6,115.0 L480.6,185.0 L420.0,220.0 L359.4,185.0 L359.4,115.0 Z" class="dg-hex dg-hex--rainha"/><text x="420" y="144" class="dg-t dg-t--forte" text-anchor="middle">Script</text><text x="420" y="162" class="dg-t dg-t--mono" text-anchor="middle">pacote-revisao</text><path d="M490,150 L580,150" class="dg-seta desenhar"/><text x="535" y="138" class="dg-t dg-t--peq" text-anchor="middle">só o pacote</text><rect x="580" y="70" width="170" height="160" rx="16" class="dg-caixa dg-caixa--peixe"/><text x="665" y="104" class="dg-t dg-t--forte" text-anchor="middle">Peixinho</text><text x="665" y="128" class="dg-t dg-t--peq" text-anchor="middle">lente do estágio</text><text x="665" y="148" class="dg-t dg-t--peq" text-anchor="middle">lista do que ler</text><text x="665" y="168" class="dg-t dg-t--peq" text-anchor="middle">régua de severidade</text><text x="665" y="198" class="dg-t dg-t--mono" text-anchor="middle">read · search</text><path d="M750,150 L800,150" class="dg-seta desenhar"/><rect x="800" y="112" width="84" height="76" rx="12" class="dg-caixa dg-caixa--veredito"/><text x="842" y="146" class="dg-t dg-t--forte" text-anchor="middle">Veredito</text><text x="842" y="166" class="dg-t dg-t--peq" text-anchor="middle">gravado</text><path d="M250,110 C 330,40 520,30 580,90" class="dg-bloqueio"/><text x="420" y="40" class="dg-t dg-t--nao" text-anchor="middle">a conversa não passa (o canário prova)</text></svg></figure>

  <div class="grade grade--2 revelar-grupo" style="margin-top:22px">
    <div class="card" data-nivel="gestao"><h3>Para a gestão</h3>
      <p>Toda spec e todo código passam por um revisor independente antes de chegar à PR. O critério de reprovação é escrito e versionado: só reprova o que é
      bug introduzido, risco de dado ou segurança, ou critério impossível de verificar. Depois de duas reprovações seguidas, a decisão vai para uma pessoa.</p></div>
    <div class="card" data-nivel="tecnico"><h3>Para o time técnico</h3>
      <p><code>pacote-revisao</code> gera um pacote com a lente do estágio e a lista exata do que ler; o orquestrador delega a <code>bia-credit-hive:bchive-gf</code>
      com o prompt literal, e o hook nega qualquer texto a mais. O <strong>canário</strong> prova na máquina que a conversa não chega ao revisor e que ele só tem leitura e busca.</p>
      <p>Spec: estágios <code>design</code> e <code>prontidao</code> (Lite) ou cinco (Full). Código: eixos <code>spec</code>, <code>padroes</code> e <code>plantao</code>, no mesmo turno.</p></div>
  </div>
</section>

<section class="secao conteudo" id="qualidade" data-slide aria-labelledby="qual-t">
  <div class="secao__cab">
    <p class="eyebrow">5 · Qualidade das entregas</p>
    <h2 id="qual-t">Portões em série: script, revisor e pessoa</h2>
    <p>Cada portão pega um tipo de falha diferente. Nenhum depende de alguém lembrar de fazer.</p>
  </div>
  <figure class="diagrama diagrama--portoes revelar"><svg viewBox="0 0 980 200" role="img" aria-labelledby="dp-t dp-d"><title id="dp-t">Portões em série</title><desc id="dp-d">Validar, revisão da spec, aprovação humana, verificação, três eixos, commit e PR, OK do QA: script, revisor e pessoa se alternam.</desc><path d="M60,100 L920,100" class="dg-rota desenhar"/><g class="dg-portao dg-portao--det" style="--i:0"><path d="M70.0,62.0 L102.9,81.0 L102.9,119.0 L70.0,138.0 L37.1,119.0 L37.1,81.0 Z" class="dg-hex"/><text x="70" y="105" class="dg-t dg-t--forte" text-anchor="middle">1</text><text x="70" y="160" class="dg-t dg-t--peq" text-anchor="middle">validar</text><text x="70" y="46" class="dg-t dg-t--mono" text-anchor="middle">script</text></g><g class="dg-portao dg-portao--peixe" style="--i:1"><path d="M210.0,62.0 L242.9,81.0 L242.9,119.0 L210.0,138.0 L177.1,119.0 L177.1,81.0 Z" class="dg-hex"/><text x="210" y="105" class="dg-t dg-t--forte" text-anchor="middle">2</text><text x="210" y="160" class="dg-t dg-t--peq" text-anchor="middle">revisão da spec</text><text x="210" y="46" class="dg-t dg-t--mono" text-anchor="middle">peixinho</text></g><g class="dg-portao dg-portao--humano" style="--i:2"><path d="M350.0,62.0 L382.9,81.0 L382.9,119.0 L350.0,138.0 L317.1,119.0 L317.1,81.0 Z" class="dg-hex"/><text x="350" y="105" class="dg-t dg-t--forte" text-anchor="middle">3</text><text x="350" y="160" class="dg-t dg-t--peq" text-anchor="middle">aprovar spec</text><text x="350" y="46" class="dg-t dg-t--mono" text-anchor="middle">humano</text></g><g class="dg-portao dg-portao--det" style="--i:3"><path d="M490.0,62.0 L522.9,81.0 L522.9,119.0 L490.0,138.0 L457.1,119.0 L457.1,81.0 Z" class="dg-hex"/><text x="490" y="105" class="dg-t dg-t--forte" text-anchor="middle">4</text><text x="490" y="160" class="dg-t dg-t--peq" text-anchor="middle">verificação com escopo</text><text x="490" y="46" class="dg-t dg-t--mono" text-anchor="middle">script</text></g><g class="dg-portao dg-portao--peixe" style="--i:4"><path d="M630.0,62.0 L662.9,81.0 L662.9,119.0 L630.0,138.0 L597.1,119.0 L597.1,81.0 Z" class="dg-hex"/><text x="630" y="105" class="dg-t dg-t--forte" text-anchor="middle">5</text><text x="630" y="160" class="dg-t dg-t--peq" text-anchor="middle">3 eixos</text><text x="630" y="46" class="dg-t dg-t--mono" text-anchor="middle">peixinho</text></g><g class="dg-portao dg-portao--humano" style="--i:5"><path d="M770.0,62.0 L802.9,81.0 L802.9,119.0 L770.0,138.0 L737.1,119.0 L737.1,81.0 Z" class="dg-hex"/><text x="770" y="105" class="dg-t dg-t--forte" text-anchor="middle">6</text><text x="770" y="160" class="dg-t dg-t--peq" text-anchor="middle">commit e PR</text><text x="770" y="46" class="dg-t dg-t--mono" text-anchor="middle">humano</text></g><g class="dg-portao dg-portao--humano" style="--i:6"><path d="M910.0,62.0 L942.9,81.0 L942.9,119.0 L910.0,138.0 L877.1,119.0 L877.1,81.0 Z" class="dg-hex"/><text x="910" y="105" class="dg-t dg-t--forte" text-anchor="middle">7</text><text x="910" y="160" class="dg-t dg-t--peq" text-anchor="middle">OK do QA</text><text x="910" y="46" class="dg-t dg-t--mono" text-anchor="middle">humano</text></g><g class="voo"><circle r="6" class="dg-ponto"/><animateMotion dur="9s" repeatCount="indefinite" path="M60,100 L920,100"/></g></svg></figure>

  <div class="grade grade--2 revelar-grupo" style="margin-top:22px">
    <div class="card"><h3><span class="selo selo--nao">Reprova</span></h3>
      <ul class="lista">
        <li>Critério de aceite que não dá para verificar ou que contradiz outro</li>
        <li>Comportamento que dois executores fariam diferente, sem resposta no briefing</li>
        <li>Risco de perda de dado, segurança ou regulatório</li>
        <li>Bug que o diff introduziu, critério sem cobertura, restrição violada</li>
      </ul></div>
    <div class="card"><h3><span class="selo selo--ok">Não reprova</span></h3>
      <ul class="lista">
        <li>O que a proposta declarou fora do escopo, ou é de outra camada</li>
        <li>Erro que já existia antes da mudança (vira outra mudança)</li>
        <li>Desenho interno de componente de terceiros (prova manual basta)</li>
        <li>Forma da evidência manual: a declaração do dev basta, sem print</li>
      </ul></div>
  </div>
</section>

<section class="secao conteudo" id="licoes" data-slide aria-labelledby="lic-t">
  <div class="secao__cab">
    <p class="eyebrow">6 · Lições de uso</p>
    <h2 id="lic-t">O que o time aprende fica, com dono e prazo</h2>
    <p>Uma memória curada: o agente propõe, uma pessoa aprova, o Git guarda. Nada entra sozinho, e nada fica para sempre sem ser revisto.</p>
  </div>
  <div class="pilha" role="list">
    <div class="pilha__item" role="listitem" style="--n:3"><span class="pilha__num">1</span><div><h3>Sinal</h3><p>Achado de revisão que virou trabalho, revisão aceita apesar de reprovada, defeito do QA, spec replanejada, ou o dev pedindo com <code>/bia-credit-hive:lembrar</code>.</p></div><span class="selo">script</span></div>
    <div class="pilha__item" role="listitem" style="--n:4"><span class="pilha__num">2</span><div><h3>Proposta</h3><p>No <code>fechar</code>, o agente propõe até três lições curtas: tipo (regra, processo, termo), escopo em pastas e o porquê.</p></div><span class="selo selo--sinal">agente</span></div>
    <div class="pilha__item" role="listitem" style="--n:5"><span class="pilha__num">3</span><div><h3>Aprovação</h3><p>Uma pessoa roda <code>licoes aprovar</code> no terminal. O hook nega o comando ao agente.</p></div><span class="selo selo--mel">portão humano</span></div>
    <div class="pilha__item" role="listitem" style="--n:6"><span class="pilha__num">4</span><div><h3>Uso com teto</h3><p>Plano e executor leem só as lições do escopo da tarefa, dentro de um orçamento de tokens. Na revisão de padrões, a lição do tipo regra é regra do time.</p></div><span class="selo selo--ok">versionada</span></div>
    <div class="pilha__item" role="listitem" style="--n:7"><span class="pilha__num">5</span><div><h3>Revisão</h3><p>Cada lição tem data para ser revista; o <code>squad-audit</code> aponta as vencidas e as de pastas que não existem mais.</p></div><span class="selo">script</span></div>
  </div>
</section>

<section class="secao conteudo" id="rastro" data-slide aria-labelledby="ras-t">
  <div class="secao__cab">
    <p class="eyebrow">E o que fica registrado</p>
    <h2 id="ras-t">Rastro sem burocracia</h2>
  </div>
  <div class="grade revelar-grupo">
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>A</span></span>Antes do código</h3><p>Briefing com insumos, proposta com critérios, fatias com escopo, aprovação humana com nome e hash da versão aprovada.</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>B</span></span>Durante</h3><p>Vereditos que nunca são sobrescritos, saída do verificador separando o que é novo do que já existia, cartões de decisão.</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>C</span></span>Depois</h3><p>Resumo pronto para a PR, OK do QA (quem, onde, quando, resultado) e um registro em <code>conhecimento/</code>: o que vai para o Git.</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>D</span></span>Uso</h3><p>Contagens por sessão e agente, seladas por dia numa cadeia de hash: dá para provar que ninguém editou o histórico.</p></div>
  </div>
</section>

<div class="conteudo">
  <nav class="passagem" aria-label="Navegação entre páginas">
    <a href="index.aspx" data-anterior><small>← Anterior</small><strong>Início</strong></a>
    <a class="prox" href="fluxo.aspx" data-proxima><small>Próxima →</small><strong>Fluxo</strong></a>
  </nav>
  <footer class="rodape"><span>b.IA Credit Hive · documentação da versão 1.1 do plugin <code>bia-credit-hive</code></span><span><kbd>P</kbd> apresentação · <kbd>←</kbd> <kbd>→</kbd> navegar · <kbd>Esc</kbd> sair</span></footer>
</div>
</main>
<div class="slide-contador" aria-live="polite"></div>
</body>
</html>
