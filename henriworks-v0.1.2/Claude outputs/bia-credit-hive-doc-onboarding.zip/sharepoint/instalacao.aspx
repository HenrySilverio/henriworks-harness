<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Instalação e configuração · b.IA Credit Hive</title>
  <meta name="description" content="Do marketplace ao primeiro pedido, e como preparar o agente da sua stack.">
  <link rel="icon" type="image/svg+xml" href="img/simbolo-bia.svg">
  <link rel="stylesheet" href="style.css">
  <script src="vendor/motion-lite.js" defer></script>
  <script src="app.js" defer></script>
</head>
<body>
<a class="pular" href="#conteudo">Pular para o conteúdo</a>
<div class="colmeia" aria-hidden="true">
<svg class="colmeia__favo" aria-hidden="true" focusable="false"><defs><pattern id="bchive-favo" width="48.497" height="84" patternUnits="userSpaceOnUse"><path d="M24.25,0.00 L48.50,14.00 L48.50,42.00 L24.25,56.00 L-0.00,42.00 L0.00,14.00 Z"/><path d="M0.00,42.00 L24.25,56.00 L24.25,84.00 L0.00,98.00 L-24.25,84.00 L-24.25,56.00 Z"/><path d="M48.50,42.00 L72.75,56.00 L72.75,84.00 L48.50,98.00 L24.25,84.00 L24.25,56.00 Z"/><path d="M0.00,-42.00 L24.25,-28.00 L24.25,-0.00 L0.00,14.00 L-24.25,-0.00 L-24.25,-28.00 Z"/><path d="M48.50,-42.00 L72.75,-28.00 L72.75,-0.00 L48.50,14.00 L24.25,-0.00 L24.25,-28.00 Z"/></pattern></defs><rect width="100%" height="100%" fill="url(#bchive-favo)"/></svg>
<svg class="colmeia__cacho colmeia__cacho--a" viewBox="0 0 227.9 207.0" aria-hidden="true" focusable="false"><path d="M61.98,7.80 L86.40,21.90 L86.40,50.10 L61.98,64.20 L37.56,50.10 L37.56,21.90 Z" class="vazio"/><path d="M113.94,7.80 L138.36,21.90 L138.36,50.10 L113.94,64.20 L89.52,50.10 L89.52,21.90 Z" class="vazio"/><path d="M165.90,7.80 L190.33,21.90 L190.33,50.10 L165.90,64.20 L141.48,50.10 L141.48,21.90 Z" class="vazio"/><path d="M36.00,52.80 L60.42,66.90 L60.42,95.10 L36.00,109.20 L11.58,95.10 L11.58,66.90 Z" class="vazio"/><path d="M87.96,52.80 L112.38,66.90 L112.38,95.10 L87.96,109.20 L63.54,95.10 L63.54,66.90 Z" class="mel"/><path d="M139.92,52.80 L164.34,66.90 L164.34,95.10 L139.92,109.20 L115.50,95.10 L115.50,66.90 Z" class="mel"/><path d="M191.88,52.80 L216.31,66.90 L216.31,95.10 L191.88,109.20 L167.46,95.10 L167.46,66.90 Z" class="vazio"/><path d="M61.98,97.80 L86.40,111.90 L86.40,140.10 L61.98,154.20 L37.56,140.10 L37.56,111.90 Z" class="mel"/><path d="M113.94,97.80 L138.36,111.90 L138.36,140.10 L113.94,154.20 L89.52,140.10 L89.52,111.90 Z" class="mel"/><path d="M165.90,97.80 L190.33,111.90 L190.33,140.10 L165.90,154.20 L141.48,140.10 L141.48,111.90 Z" class="vazio"/><path d="M139.92,142.80 L164.34,156.90 L164.34,185.10 L139.92,199.20 L115.50,185.10 L115.50,156.90 Z" class="vazio"/><path d="M36.00,142.80 L60.42,156.90 L60.42,185.10 L36.00,199.20 L11.58,185.10 L11.58,156.90 Z" class="vazio"/><path d="M87.96,142.80 L112.38,156.90 L112.38,185.10 L87.96,199.20 L63.54,185.10 L63.54,156.90 Z" class="vazio"/></svg>
<svg class="colmeia__cacho colmeia__cacho--b" viewBox="0 0 197.5 140.4" aria-hidden="true" focusable="false"><path d="M53.72,6.76 L74.88,18.98 L74.88,43.42 L53.72,55.64 L32.55,43.42 L32.55,18.98 Z" class="vazio"/><path d="M98.75,6.76 L119.92,18.98 L119.92,43.42 L98.75,55.64 L77.58,43.42 L77.58,18.98 Z" class="mel"/><path d="M143.78,6.76 L164.95,18.98 L164.95,43.42 L143.78,55.64 L122.62,43.42 L122.62,18.98 Z" class="vazio"/><path d="M31.20,45.76 L52.37,57.98 L52.37,82.42 L31.20,94.64 L10.03,82.42 L10.03,57.98 Z" class="vazio"/><path d="M76.23,45.76 L97.40,57.98 L97.40,82.42 L76.23,94.64 L55.07,82.42 L55.07,57.98 Z" class="vazio"/><path d="M121.27,45.76 L142.43,57.98 L142.43,82.42 L121.27,94.64 L100.10,82.42 L100.10,57.98 Z" class="vazio"/><path d="M166.30,45.76 L187.47,57.98 L187.47,82.42 L166.30,94.64 L145.13,82.42 L145.13,57.98 Z" class="mel"/><path d="M53.72,84.76 L74.88,96.98 L74.88,121.42 L53.72,133.64 L32.55,121.42 L32.55,96.98 Z" class="vazio"/><path d="M98.75,84.76 L119.92,96.98 L119.92,121.42 L98.75,133.64 L77.58,121.42 L77.58,96.98 Z" class="vazio"/><path d="M143.78,84.76 L164.95,96.98 L164.95,121.42 L143.78,133.64 L122.62,121.42 L122.62,96.98 Z" class="mel"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="left:1%;top:14%" aria-hidden="true" focusable="false"><path d="M10 100 C 40 20, 90 110, 130 50 S 180 20, 195 40"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="right:1%;top:70%;transform:scaleX(-1)" aria-hidden="true" focusable="false"><path d="M10 90 C 50 10, 80 100, 120 40 S 170 30, 195 60"/></svg>
<svg class="abelha ab1" style="left:2.5%;top:20%;--d:13s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab1"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab1)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab2" style="right:3%;top:34%;--d:16s;--x:-16px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab2"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab2)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab3" style="left:4%;top:62%;--d:15s;--x:14px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab3"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab3)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab4" style="right:5%;top:76%;--d:12s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab4"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab4)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab5" style="right:22%;top:12%;--d:18s;--x:-12px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab5"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab5)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
</div>

<div class="progresso" aria-hidden="true"><div class="progresso__barra"></div></div>
<header class="topo">
  <div class="conteudo topo__linha">
    <a class="marca" href="index.aspx" aria-label="b.IA Credit Hive, início">
      <img class="mlogo mlogo--c" src="img/logo-bia.svg" alt="b.IA Credit" height="28"><img class="mlogo mlogo--e" src="img/logo-bia-escuro.svg" alt="" height="28"><span class="marca__produto">Hive</span>
    </a>
    <nav aria-label="Páginas da documentação" class="nav"><ul class="menu"><li><a href="index.aspx">Início</a></li><li><a href="por-dentro.aspx">Por dentro</a></li><li><a href="fluxo.aspx">Fluxo</a></li><li><a href="camadas.aspx">Camadas</a></li><li><a href="instalacao.aspx" aria-current="page">Instalação</a></li><li><a href="cenarios.aspx">Cenários</a></li><li><a href="governanca.aspx">Governança</a></li><li><a href="referencia.aspx">Referência</a></li></ul></nav>
    <div class="controles" data-controles></div>
  </div>
</header>
<main id="conteudo">
<section class="hero hero--pagina conteudo" data-slide>
  <div>
    <p class="eyebrow">Instalação e configuração</p>
    <h1 class="titulo-abertura">Do marketplace ao primeiro pedido</h1>
    <p class="lede">Instala uma vez na máquina, prepara uma vez por repositório. Leva uns 10 minutos, a maior parte esperando o mapa do projeto ser montado.</p>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="req-t">
  <div class="secao__cab"><p class="eyebrow">Antes de começar</p><h2 id="req-t">Requisitos</h2></div>
  <div class="grade revelar-grupo">
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>1</span></span>VS Code + Copilot</h3><p>Chat no <strong>harness Copilot</strong>. O harness Local não é suportado: nele o revisor recebe ferramentas que não deveria, e o canário reprova.</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>2</span></span>Node 20 ou mais</h3><p>No PATH do VS Code. Os scripts não têm dependência: nada de <code>npm install</code>.</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>3</span></span>Repositório Git</h3><p>Aberto pela raiz. Qualquer stack: Angular, React, Java, Liberty, Swift, Node…</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>4</span></span>Ticket no Jira</h3><p>Toda mudança carrega a chave da task no nome. Sem ticket, o fluxo pede para abrir um.</p></div>
  </div>
</section>

<section class="secao conteudo passos-instalacao" data-slide aria-labelledby="inst-t">
  <div class="secao__cab"><p class="eyebrow">Passo a passo</p><h2 id="inst-t">Cinco passos, um chat</h2></div>
  <ol class="trilha revelar-grupo">
    <li class="trilha__passo"><span class="trilha__n">1</span><div>
      <h3>Instalar o plugin</h3>
      <p>Pelo botão <strong>Instalar o plugin no VS Code</strong> do README do repositório do plugin, ou pelos plugins do Copilot no VS Code, procurando
      <strong>bia-credit-hive</strong> no <code>bradesco-marketplace</code>. Antes da primeira release estável, ele fica no <code>bradesco-marketplace-unstable</code>.</p></div></li>
    <li class="trilha__passo"><span class="trilha__n">2</span><div>
      <h3>Preparar o repositório</h3>
      <p>Num chat novo, selecione o agente <strong>bchive</strong> e envie:</p>
<pre class="cmd"><code>/bia-credit-hive:init</code></pre>
      <p>Ele copia o núcleo para <code>.bchive/bin/</code>, cria os arquivos do time que faltam, põe <code>.bchive/</code> no <code>.git/info/exclude</code> (nunca no <code>.gitignore</code>), monta o mapa e confere tudo.</p></div></li>
    <li class="trilha__passo"><span class="trilha__n">3</span><div>
      <h3>Canário, no mesmo chat</h3>
      <p>O init prova na sua máquina que o revisor não recebe a conversa e só tem leitura e busca. Vale para a versão do VS Code em que passou; quando ela muda, o init pede de novo.</p></div></li>
    <li class="trilha__passo"><span class="trilha__n">4</span><div>
      <h3>Ajustar ao repositório</h3>
      <p>Em qualquer agente com terminal:</p>
<pre class="cmd"><code>/bia-credit-hive:configurar</code></pre>
      <p>Propõe o <code>verificacao.json</code> (lint, tipos e testes por camada, provando cada comando) e um rascunho de <code>padroes.md</code> a partir do código. Só grava com o seu "ok".</p></div></li>
    <li class="trilha__passo"><span class="trilha__n">5</span><div>
      <h3>Primeiro pedido</h3>
<pre class="cmd"><code>/bia-credit-hive:start quero mostrar o saldo projetado na confirmação (GPCNLS-10019)</code></pre>
      <p>Ele diz a rota e a mensagem exata para o próximo chat.</p></div></li>
  </ol>
</section>

<section class="secao conteudo" data-slide aria-labelledby="term-t">
  <div class="secao__cab"><p class="eyebrow">Como fica a saída do init</p><h2 id="term-t">Pronto, pendente, aviso ou grave</h2>
    <p>Grave para tudo. Pendente diz quem resolve. Aviso não impede o uso.</p></div>
  <div class="terminal revelar"><div class="terminal__barra"><i></i><i></i><i></i></div>
<pre class="digitar"><code><span class="dim">b.IA Credit Hive 1.1.0 preparado em recr-fed-agc-exemplo</span>
  núcleo       14 arquivo(s) em .bchive/bin/
  referências  10 arquivo(s) em .bchive/referencias/
  Git          .bchive/ acrescentado ao .git/info/exclude

b.IA Credit Hive init · 1.1.0 · recr-fed-agc-exemplo · com correções seguras
  <span class="ok">ok</span>         node               Node 22.11.0
  <span class="ok">ok</span>         plugin             bia-credit-hive 1.1.0, núcleo em .bchive/bin
  <span class="ok">ok</span>         hooks              6 eventos no plugin; o script responde e a guarda de veredito nega
  <span class="ok">ok</span>         personalizacao     4 arquivo(s) de personalização do Copilot no repositório: convivem com o fluxo
  <span class="ok">ok</span>         git-exclude        harness fora do Git (.git/info/exclude)
  <span class="ok">corrigido</span>  mapa               construído: 1.284 nós, 3.902 arestas
  <span class="sin">aviso</span>      tokens             sem telemetria do Agent Host nesta máquina: depende da TI
  <span class="sin">PENDENTE</span>   canário            não rodou: o /bia-credit-hive:init roda neste chat</code></pre></div>
  <p class="nota">Saída ilustrativa: os nomes e as linhas são os reais; os números variam por repositório.</p>
</section>

<section class="secao conteudo" id="seu-harness" data-slide aria-labelledby="harn-t">
  <div class="secao__cab"><p class="eyebrow">O que você já tem</p><h2 id="harn-t">Sua personalização continua valendo</h2>
    <p><code>AGENTS.md</code>, <code>.github/instructions/</code>, agentes, skills e hooks seus: nada é exigido, nada é editado, nada trava o fluxo.</p></div>
  <div class="grade grade--2 revelar-grupo">
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>A</span></span>Convivência</h3><ul class="lista">
      <li>Arquivo fora do Git em <code>.github/</code>, <code>.vscode/</code> ou <code>AGENTS.md</code> nunca conta como alteração pendente.</li>
      <li>No processo (fases, portões, Git), o fluxo vence. No jeito de escrever código, valem as suas instruções.</li>
      <li>Na revisão, só bloqueia regra declarada do time: <code>.bchive/padroes.md</code> ou os arquivos em <code>"instrucoes": { "doTime": [...] }</code>.</li></ul></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>B</span></span>Auditoria do seu harness</h3>
      <p>No agente <code>bchive</code>:</p>
<pre class="cmd"><code>/bia-credit-hive:auditar</code></pre>
      <p>Estima quantos tokens a sua personalização custa em todo pedido e aponta verbosidade, termos vagos, regras em conflito entre arquivos, o que falta e riscos em hooks e agentes, com o texto <em>Antes / Depois</em> de cada sugestão.</p></div>
  </div>
</section>

<section class="secao conteudo" id="executor" data-slide aria-labelledby="exe-t">
  <div class="secao__cab"><p class="eyebrow">Agentes de outras iniciativas</p><h2 id="exe-t">Preparar o agente da sua stack (ex.: codificador Java)</h2>
    <p>O plano propõe, por fatia, o agente instalado que cobre a stack, e só usa com o seu sim. Para um agente seu ou de outro plugin entrar nessa lista:</p></div>
  <div class="duas-col">
    <ol class="checklist revelar-grupo">
      <li>Estar num plugin, em <code>~/.copilot/agents/</code> ou em <code>.github/agents/</code>. A pasta de prompts do perfil do VS Code só serve ao harness Local.</li>
      <li><code>disable-model-invocation: false</code> (ou sem a chave): precisa poder ser chamado como subagente.</li>
      <li><code>description</code> dizendo a stack e a camada: é por ela que o plano escolhe.</li>
      <li><code>tools</code> com leitura, edição e terminal.</li>
      <li>Sem <code>agents</code>, <code>handoffs</code> ou <code>argument-hint</code> no frontmatter.</li>
      <li>No corpo, o bloco "When called with a slice file" ao lado.</li>
    </ol>
    <div>
<pre class="cmd"><code><span class="dim">---</span>
name: spring-dev
description: "Implementa BFF em Java 21 / Spring Boot com testes JUnit"
tools: ["read", "search", "edit", "execute"]
<span class="dim">---</span>
## When called with a slice file
If the message points to a slice file (`.bchive/changes/&lt;id&gt;/tarefas/NN-*.md`),
read it and only the files in its `## Ponteiros`. Change only the paths in `Toca:`.
Run the tests of what you changed. Do not commit, push or create branches,
and do not edit anything in `.bchive/`. End with: files changed; whether the
`Demonstra:` behavior happens; what you could not do or verify.</code></pre>
      <p>Para conferir:</p>
<pre class="cmd"><code>node .bchive/bin/bchive.mjs executores conferir</code></pre>
    </div>
  </div>
</section>

<section class="secao conteudo" id="problemas" data-slide aria-labelledby="prob-t">
  <div class="secao__cab"><p class="eyebrow">Deu erro, e agora?</p><h2 id="prob-t">Problemas comuns</h2></div>
  <div class="revelar-grupo">
    <details class="faq"><summary>O comando <code>/bia-credit-hive:init</code> não aparece no chat</summary><div class="faq__corpo"><p>O plugin não está instalado ou o VS Code não recarregou. Rode <em>Developer: Reload Window</em> e confira a lista de plugins instalados do Copilot.</p></div></details>
    <details class="faq"><summary>O comando responde "selecione o agente…"</summary><div class="faq__corpo"><p>Cada fase roda no seu agente, que define as ferramentas. Abra um chat novo, escolha o agente indicado no seletor e repita o comando.</p></div></details>
    <details class="faq"><summary>Canário: "NENHUM evento registrado"</summary><div class="faq__corpo"><p>Os hooks não rodaram nesta janela. Rode <em>Developer: Reload Window</em> e repita <code>/bia-credit-hive:canario</code>.</p></div></details>
    <details class="faq"><summary>Canário: ferramentas "FORA DO PERMITIDO"</summary><div class="faq__corpo"><p>O chat está no harness Local. Troque para o harness Copilot e rode o canário de novo.</p></div></details>
    <details class="faq"><summary>"núcleo em .bchive/bin é x e o plugin instalado é y"</summary><div class="faq__corpo"><p>O plugin foi atualizado. Rode <code>/bia-credit-hive:init</code> uma vez no repositório.</p></div></details>
    <details class="faq"><summary>"NÃO COMMITADO" no implement ou na revisão</summary><div class="faq__corpo"><p>Há código fora de commit. <code>node .bchive/bin/bchive.mjs arvore</code> mostra o quê. Personalização em <code>.github/</code> não conta.</p></div></details>
    <details class="faq"><summary>O relatório de uso sai sem tokens</summary><div class="faq__corpo"><p>Os tokens dependem da telemetria do Agent Host, ligada pela TI por configuração gerenciada. As contagens de sessão, turno e agente já funcionam.</p></div></details>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="atu-t">
  <div class="secao__cab"><p class="eyebrow">Ciclo de vida</p><h2 id="atu-t">Atualizar e remover</h2></div>
  <div class="grade grade--2 revelar-grupo">
    <div class="card"><h3>Atualizar</h3><p>O marketplace atualiza o plugin. No próximo chat, o Hive avisa que o núcleo do repositório está atrás: rode <code>/bia-credit-hive:init</code>. Arquivos do time não são tocados.</p></div>
    <div class="card"><h3>Remover de um repositório</h3><p>Apague <code>.bchive/</code> e o bloco <code># &gt;&gt;&gt; bchive</code> do <code>.git/info/exclude</code>. O que já foi para <code>conhecimento/</code> fica.</p></div>
  </div>
</section>

<div class="conteudo">
  <nav class="passagem" aria-label="Navegação entre páginas">
    <a href="camadas.aspx" data-anterior><small>← Anterior</small><strong>Camadas</strong></a>
    <a class="prox" href="cenarios.aspx" data-proxima><small>Próxima →</small><strong>Cenários</strong></a>
  </nav>
  <footer class="rodape"><span>b.IA Credit Hive · documentação da versão 1.1 do plugin <code>bia-credit-hive</code></span><span><kbd>P</kbd> apresentação · <kbd>←</kbd> <kbd>→</kbd> navegar · <kbd>Esc</kbd> sair</span></footer>
</div>
</main>
<div class="slide-contador" aria-live="polite"></div>
</body>
</html>
