<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Referência rápida · b.IA Credit Hive</title>
  <meta name="description" content="Comandos, agentes, glossário e perguntas frequentes.">
  <link rel="icon" type="image/svg+xml" href="img/simbolo-bia.svg">
  <link rel="stylesheet" href="style.css">
  <script src="vendor/motion-lite.js" defer></script>
  <script src="app.js" defer></script>
</head>
<body>
<a class="pular" href="#conteudo">Pular para o conteúdo</a>
<div class="colmeia" aria-hidden="true">
<svg class="colmeia__favo" aria-hidden="true" focusable="false"><defs><pattern id="bchive-favo" width="48.497" height="84" patternUnits="userSpaceOnUse"><path d="M24.25,0.00 L48.50,14.00 L48.50,42.00 L24.25,56.00 L-0.00,42.00 L0.00,14.00 Z"/><path d="M0.00,42.00 L24.25,56.00 L24.25,84.00 L0.00,98.00 L-24.25,84.00 L-24.25,56.00 Z"/><path d="M48.50,42.00 L72.75,56.00 L72.75,84.00 L48.50,98.00 L24.25,84.00 L24.25,56.00 Z"/><path d="M0.00,-42.00 L24.25,-28.00 L24.25,-0.00 L0.00,14.00 L-24.25,-0.00 L-24.25,-28.00 Z"/><path d="M48.50,-42.00 L72.75,-28.00 L72.75,-0.00 L48.50,14.00 L24.25,-0.00 L24.25,-28.00 Z"/></pattern></defs><rect width="100%" height="100%" fill="url(#bchive-favo)"/></svg>
<svg class="colmeia__cacho colmeia__cacho--a" viewBox="0 0 227.9 207.0" aria-hidden="true" focusable="false"><path d="M61.98,7.80 L86.40,21.90 L86.40,50.10 L61.98,64.20 L37.56,50.10 L37.56,21.90 Z" class="vazio"/><path d="M113.94,7.80 L138.36,21.90 L138.36,50.10 L113.94,64.20 L89.52,50.10 L89.52,21.90 Z" class="vazio"/><path d="M165.90,7.80 L190.33,21.90 L190.33,50.10 L165.90,64.20 L141.48,50.10 L141.48,21.90 Z" class="vazio"/><path d="M36.00,52.80 L60.42,66.90 L60.42,95.10 L36.00,109.20 L11.58,95.10 L11.58,66.90 Z" class="vazio"/><path d="M87.96,52.80 L112.38,66.90 L112.38,95.10 L87.96,109.20 L63.54,95.10 L63.54,66.90 Z" class="mel"/><path d="M139.92,52.80 L164.34,66.90 L164.34,95.10 L139.92,109.20 L115.50,95.10 L115.50,66.90 Z" class="mel"/><path d="M191.88,52.80 L216.31,66.90 L216.31,95.10 L191.88,109.20 L167.46,95.10 L167.46,66.90 Z" class="vazio"/><path d="M61.98,97.80 L86.40,111.90 L86.40,140.10 L61.98,154.20 L37.56,140.10 L37.56,111.90 Z" class="mel"/><path d="M113.94,97.80 L138.36,111.90 L138.36,140.10 L113.94,154.20 L89.52,140.10 L89.52,111.90 Z" class="mel"/><path d="M165.90,97.80 L190.33,111.90 L190.33,140.10 L165.90,154.20 L141.48,140.10 L141.48,111.90 Z" class="vazio"/><path d="M139.92,142.80 L164.34,156.90 L164.34,185.10 L139.92,199.20 L115.50,185.10 L115.50,156.90 Z" class="vazio"/><path d="M36.00,142.80 L60.42,156.90 L60.42,185.10 L36.00,199.20 L11.58,185.10 L11.58,156.90 Z" class="vazio"/><path d="M87.96,142.80 L112.38,156.90 L112.38,185.10 L87.96,199.20 L63.54,185.10 L63.54,156.90 Z" class="vazio"/></svg>
<svg class="colmeia__cacho colmeia__cacho--b" viewBox="0 0 197.5 140.4" aria-hidden="true" focusable="false"><path d="M53.72,6.76 L74.88,18.98 L74.88,43.42 L53.72,55.64 L32.55,43.42 L32.55,18.98 Z" class="vazio"/><path d="M98.75,6.76 L119.92,18.98 L119.92,43.42 L98.75,55.64 L77.58,43.42 L77.58,18.98 Z" class="mel"/><path d="M143.78,6.76 L164.95,18.98 L164.95,43.42 L143.78,55.64 L122.62,43.42 L122.62,18.98 Z" class="vazio"/><path d="M31.20,45.76 L52.37,57.98 L52.37,82.42 L31.20,94.64 L10.03,82.42 L10.03,57.98 Z" class="vazio"/><path d="M76.23,45.76 L97.40,57.98 L97.40,82.42 L76.23,94.64 L55.07,82.42 L55.07,57.98 Z" class="vazio"/><path d="M121.27,45.76 L142.43,57.98 L142.43,82.42 L121.27,94.64 L100.10,82.42 L100.10,57.98 Z" class="vazio"/><path d="M166.30,45.76 L187.47,57.98 L187.47,82.42 L166.30,94.64 L145.13,82.42 L145.13,57.98 Z" class="mel"/><path d="M53.72,84.76 L74.88,96.98 L74.88,121.42 L53.72,133.64 L32.55,121.42 L32.55,96.98 Z" class="vazio"/><path d="M98.75,84.76 L119.92,96.98 L119.92,121.42 L98.75,133.64 L77.58,121.42 L77.58,96.98 Z" class="vazio"/><path d="M143.78,84.76 L164.95,96.98 L164.95,121.42 L143.78,133.64 L122.62,121.42 L122.62,96.98 Z" class="mel"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="left:1%;top:14%" aria-hidden="true" focusable="false"><path d="M10 100 C 40 20, 90 110, 130 50 S 180 20, 195 40"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="right:1%;top:70%;transform:scaleX(-1)" aria-hidden="true" focusable="false"><path d="M10 90 C 50 10, 80 100, 120 40 S 170 30, 195 60"/></svg>
<svg class="abelha ab1" style="left:2.5%;top:20%;--d:13s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab1"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab1)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab2" style="right:3%;top:34%;--d:16s;--x:-16px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab2"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab2)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab3" style="left:4%;top:62%;--d:15s;--x:14px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab3"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab3)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab4" style="right:5%;top:76%;--d:12s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab4"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab4)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab5" style="right:22%;top:12%;--d:18s;--x:-12px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab5"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab5)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
</div>

<div class="progresso" aria-hidden="true"><div class="progresso__barra"></div></div>
<header class="topo">
  <div class="conteudo topo__linha">
    <a class="marca" href="index.aspx" aria-label="b.IA Credit Hive, início">
      <img class="mlogo mlogo--c" src="img/logo-bia.svg" alt="b.IA Credit" height="28"><img class="mlogo mlogo--e" src="img/logo-bia-escuro.svg" alt="" height="28"><span class="marca__produto">Hive</span>
    </a>
    <nav aria-label="Páginas da documentação" class="nav"><ul class="menu"><li><a href="index.aspx">Início</a></li><li><a href="por-dentro.aspx">Por dentro</a></li><li><a href="fluxo.aspx">Fluxo</a></li><li><a href="camadas.aspx">Camadas</a></li><li><a href="instalacao.aspx">Instalação</a></li><li><a href="cenarios.aspx">Cenários</a></li><li><a href="governanca.aspx">Governança</a></li><li><a href="referencia.aspx" aria-current="page">Referência</a></li></ul></nav>
    <div class="controles" data-controles></div>
  </div>
</header>
<main id="conteudo">
<section class="hero hero--pagina conteudo" data-slide>
  <div>
    <p class="eyebrow">Referência rápida</p>
    <h1 class="titulo-abertura">Comandos, agentes e termos</h1>
    <p class="lede">Tudo numa página, com busca. Os comandos de chat começam com <code>/bia-credit-hive:</code>; os de terminal, com <code>node .bchive/bin/</code>.</p>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="cmd-t">
  <div class="secao__cab"><p class="eyebrow">Comandos do chat</p><h2 id="cmd-t">Os 17 comandos</h2></div>
  <label class="busca" data-busca-rotulo data-sem-js aria-hidden="true">Filtrar <input type="search" data-busca="#tab-cmd" placeholder="ex.: revisão, QA, mapa"></label>
  <div class="tabela-wrap revelar"><table id="tab-cmd">
    <thead><tr><th>Comando</th><th>Agente</th><th>Para quê</th></tr></thead>
    <tbody>
      <tr><td><code>/bia-credit-hive:init</code></td><td><code>bchive</code></td><td>Prepara ou atualiza o repositório, roda o canário</td></tr>
      <tr><td><code>/bia-credit-hive:start</code></td><td>qualquer com terminal</td><td>Diz o próximo passo e para</td></tr>
      <tr><td><code>/bia-credit-hive:auditar</code></td><td><code>bchive</code></td><td>Qualidade e custo da sua personalização do Copilot</td></tr>
      <tr><td><code>/bia-credit-hive:grill</code></td><td><code>bchive-discovery</code></td><td>Entrevista uma dor até virar briefing</td></tr>
      <tr><td><code>/bia-credit-hive:triagem</code></td><td><code>bchive-discovery</code></td><td>Transforma um ticket escrito em briefing</td></tr>
      <tr><td><code>/bia-credit-hive:prototipo</code></td><td><code>bchive-prototipo</code></td><td>Responde uma pergunta de design com código descartável</td></tr>
      <tr><td><code>/bia-credit-hive:plan</code></td><td><code>bchive-plan</code></td><td>Proposta, fatias e deltas; também replaneja</td></tr>
      <tr><td><code>/bia-credit-hive:review</code></td><td><code>bchive-review</code></td><td>Revisão isolada da spec (<code>spec &lt;id&gt;</code>) ou do código (<code>&lt;id&gt;</code>)</td></tr>
      <tr><td><code>/bia-credit-hive:implement</code></td><td><code>bchive-implement</code></td><td>Executa a próxima fatia (ou várias, ou em paralelo)</td></tr>
      <tr><td><code>/bia-credit-hive:archive</code></td><td><code>bchive-archive</code></td><td>Aplica specs e decisões, escreve o resumo da PR, arquiva</td></tr>
      <tr><td><code>/bia-credit-hive:fechar</code></td><td><code>bchive-archive</code></td><td>Registro de conhecimento, depois do OK do QA</td></tr>
      <tr><td><code>/bia-credit-hive:canario</code></td><td><code>bchive</code></td><td>Repete a prova de isolamento do revisor</td></tr>
      <tr><td><code>/bia-credit-hive:configurar</code></td><td>qualquer com terminal</td><td>Verificação por camada e padrões do time</td></tr>
      <tr><td><code>/bia-credit-hive:uso</code></td><td>qualquer com terminal</td><td>Relatório de uso e adoção, exportação</td></tr>
      <tr><td><code>/bia-credit-hive:mapa</code></td><td>qualquer com terminal</td><td>Onde fica, quem chama, o que quebra</td></tr>
      <tr><td><code>/bia-credit-hive:ticket</code></td><td>qualquer com terminal</td><td>Mostra ou fixa o ticket da sessão</td></tr>
      <tr><td><code>/bia-credit-hive:adotar</code></td><td>qualquer com terminal</td><td>Copia specs e decisões do HenriSpec, uma vez</td></tr>
    </tbody></table></div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="ter-t">
  <div class="secao__cab"><p class="eyebrow">Terminal (Git Bash)</p><h2 id="ter-t">Os que você roda</h2><p>Portões humanos e utilitários. O agente mostra o comando pronto quando é a sua vez.</p></div>
  <div class="tabela-wrap revelar"><table>
    <thead><tr><th>Comando</th><th>Para quê</th></tr></thead>
    <tbody>
      <tr><td><code>node .bchive/bin/bchive.mjs estado</code></td><td>Fase de cada mudança aberta</td></tr>
      <tr><td><code>node .bchive/bin/bchive.mjs aprovar-spec &lt;id&gt; --por "Nome"</code></td><td><span class="selo selo--mel">portão</span> aprova a spec</td></tr>
      <tr><td><code>node .bchive/bin/bchive.mjs aceitar-revisao &lt;id&gt; --por "Nome" --apesar "motivo"</code></td><td><span class="selo selo--mel">portão</span> aceita eixo reprovado</td></tr>
      <tr><td><code>node .bchive/bin/bchive.mjs rodada-extra &lt;id&gt; &lt;alvo&gt; --por "Nome"</code></td><td><span class="selo selo--mel">portão</span> uma rodada além do teto</td></tr>
      <tr><td><code>node .bchive/bin/bchive.mjs qa-ok &lt;pasta&gt; --por --ambiente --resultado</code></td><td><span class="selo selo--mel">portão</span> OK de quem testou</td></tr>
      <tr><td><code>node .bchive/bin/bchive.mjs descartar &lt;id&gt; --aplicar</code></td><td><span class="selo selo--mel">portão</span> apaga a mudança (sem <code>--aplicar</code>, só mostra)</td></tr>
      <tr><td><code>node .bchive/bin/bchive.mjs arvore</code></td><td>O que conta como não commitado</td></tr>
      <tr><td><code>node .bchive/bin/bchive.mjs executores conferir</code></td><td>Agentes externos prontos para executar fatia?</td></tr>
      <tr><td><code>node .bchive/bin/bchivemap.mjs query "termos"</code></td><td>Consulta o mapa do projeto</td></tr>
      <tr><td><code>node .bchive/bin/uso.mjs relatorio</code></td><td>Relatório de uso do período</td></tr>
    </tbody></table></div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="ag-t">
  <div class="secao__cab"><p class="eyebrow">Agentes</p><h2 id="ag-t">Nove papéis</h2></div>
  <div class="grade revelar-grupo">
    <div class="card"><h3><code>bchive</code></h3><p>Entrada: prepara, audita e diz o próximo passo.</p></div>
    <div class="card"><h3><code>bchive-discovery</code></h3><p>Entrevista. Sem busca e sem terminal, de propósito.</p></div>
    <div class="card"><h3><code>bchive-prototipo</code></h3><p>Código descartável para decidir.</p></div>
    <div class="card"><h3><code>bchive-plan</code></h3><p>Escreve o acordo e escolhe executores com você.</p></div>
    <div class="card"><h3><code>bchive-review</code></h3><p>Orquestra a revisão; não revisa.</p></div>
    <div class="card"><h3><code>bchive-implement</code></h3><p>Coordena as fatias; não escreve código.</p></div>
    <div class="card"><h3><code>bchive-archive</code></h3><p>Arquiva, escreve o resumo da PR e o registro.</p></div>
    <div class="card"><h3><code>bchive-implementador</code> <span class="selo">subagente</span></h3><p>Executa uma fatia em contexto limpo.</p></div>
    <div class="card"><h3><code>bchive-gf</code> <span class="selo">subagente</span></h3><p>O peixinho: revisor só com leitura e busca.</p></div>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="glo-t">
  <div class="secao__cab"><p class="eyebrow">Glossário</p><h2 id="glo-t">Termos do Hive</h2></div>
  <dl class="glossario revelar-grupo">
    <div><dt>Mudança (change)</dt><dd>Uma entrega com ticket: pasta <code>.bchive/changes/&lt;TICKET&gt;-&lt;slug&gt;/</code>.</dd></div>
    <div><dt>Briefing</dt><dd>Uma página com problema, esperado, restrições, fora do escopo e insumos. Sem solução.</dd></div>
    <div><dt>Fatia</dt><dd>Pedaço vertical que demonstra um comportamento e cabe numa sessão. Um arquivo cada.</dd></div>
    <div><dt>Toca</dt><dd>Os arquivos que uma fatia pode alterar, declarados antes.</dd></div>
    <div><dt>Ponteiros</dt><dd>O que o executor lê além da fatia: seção e número, não cópia.</dd></div>
    <div><dt>Rigor Lite / Full</dt><dd>Lite é o padrão. Full, com design e cinco revisões, só com um gatilho (contrato entre camadas, irreversível, regulatório…).</dd></div>
    <div><dt>Peixinho</dt><dd>O revisor sem contexto. Elefante é quem tem o contexto todo.</dd></div>
    <div><dt>Pacote de revisão</dt><dd>Arquivo gerado por script com a lente e a lista exata do que o revisor lê.</dd></div>
    <div><dt>Canário</dt><dd>Teste que prova, na sua máquina, o isolamento do revisor e que os hooks rodam.</dd></div>
    <div><dt>Portão humano</dt><dd>Decisão que só uma pessoa toma, no próprio terminal.</dd></div>
    <div><dt>Eixos</dt><dd>As três revisões de código: <code>spec</code> (fez o combinado), <code>padroes</code> (regras do time), <code>plantao</code> (bug, risco, carga).</dd></div>
    <div><dt>Executor</dt><dd>Quem implementa a fatia: o do Hive ou um agente da stack.</dd></div>
  </dl>
</section>

<section class="secao conteudo" data-slide aria-labelledby="faq-t">
  <div class="secao__cab"><p class="eyebrow">Perguntas frequentes</p><h2 id="faq-t">FAQ</h2></div>
  <div class="revelar-grupo">
    <details class="faq"><summary>Preciso usar o fluxo em todo pedido?</summary><div class="faq__corpo"><p>Não. Ajuste pequeno vai direto no chat. O <code>/bia-credit-hive:start</code> diz quando o fluxo vale a pena.</p></div></details>
    <details class="faq"><summary>O Hive commita ou abre PR por mim?</summary><div class="faq__corpo"><p>Nunca. Ele lê o Git e sugere a mensagem de commit; quem commita e abre a PR é você.</p></div></details>
    <details class="faq"><summary>Funciona fora de Angular?</summary><div class="faq__corpo"><p>Sim. O processo é o mesmo em qualquer linguagem; o que muda é o <code>verificacao.json</code>, o <code>padroes.md</code> e os executores.</p></div></details>
    <details class="faq"><summary>Minhas instruções e meu AGENTS.md vão atrapalhar?</summary><div class="faq__corpo"><p>Não travam nada. No processo o fluxo vence; no código valem as suas regras. O <code>/bia-credit-hive:auditar</code> mostra o custo e os conflitos.</p></div></details>
    <details class="faq"><summary>A gestão vê o que eu escrevi no chat?</summary><div class="faq__corpo"><p>Não. Só contagens: sessões, turnos, comandos, tempo, tokens. Nunca conteúdo.</p></div></details>
    <details class="faq"><summary>Onde peço ajuda ou dou feedback?</summary><div class="faq__corpo"><p>Pelo canal indicado no README do plugin (seção Feedback). Problema de instalação: rode <code>/bia-credit-hive:init</code> e mande a saída, que não tem conteúdo de conversa.</p></div></details>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="nov-t">
  <div class="secao__cab"><p class="eyebrow">Versão</p><h2 id="nov-t">Novidades e próximos passos</h2></div>
  <div class="grade grade--2 revelar-grupo">
    <div class="card"><h3><span class="selo selo--ok">Nesta versão</span></h3><ul class="lista">
      <li>Plugin com comandos <code>/bia-credit-hive:*</code></li>
      <li>OK do QA obrigatório antes do registro</li>
      <li>Agentes de outros plugins como executores, com conferência</li>
      <li>Auditoria do harness do dev</li>
      <li>Coleta de uso só com contagens, selada</li></ul></div>
    <div class="card"><h3><span class="selo selo--aviso">A seguir</span></h3><ul class="lista">
      <li>Envio do uso para o Jira, com visão por squad</li>
      <li>Registro de conhecimento no padrão OKF</li>
      <li>Tokens por sessão com a telemetria do Agent Host</li></ul></div>
  </div>
</section>

<div class="conteudo">
  <nav class="passagem" aria-label="Navegação entre páginas">
    <a href="governanca.aspx" data-anterior><small>← Anterior</small><strong>Governança</strong></a>
    
  </nav>
  <footer class="rodape"><span>b.IA Credit Hive · documentação da versão 1.1 do plugin <code>bia-credit-hive</code></span><span><kbd>P</kbd> apresentação · <kbd>←</kbd> <kbd>→</kbd> navegar · <kbd>Esc</kbd> sair</span></footer>
</div>
</main>
<div class="slide-contador" aria-live="polite"></div>
</body>
</html>
