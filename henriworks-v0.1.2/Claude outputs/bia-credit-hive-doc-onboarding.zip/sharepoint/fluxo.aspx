<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>O fluxo · b.IA Credit Hive</title>
  <meta name="description" content="As fases, quem faz cada uma e um exemplo de ponta a ponta.">
  <link rel="icon" type="image/svg+xml" href="img/simbolo-bia.svg">
  <link rel="stylesheet" href="style.css">
  <script src="vendor/motion-lite.js" defer></script>
  <script src="app.js" defer></script>
</head>
<body>
<a class="pular" href="#conteudo">Pular para o conteúdo</a>
<div class="colmeia" aria-hidden="true">
<svg class="colmeia__favo" aria-hidden="true" focusable="false"><defs><pattern id="bchive-favo" width="48.497" height="84" patternUnits="userSpaceOnUse"><path d="M24.25,0.00 L48.50,14.00 L48.50,42.00 L24.25,56.00 L-0.00,42.00 L0.00,14.00 Z"/><path d="M0.00,42.00 L24.25,56.00 L24.25,84.00 L0.00,98.00 L-24.25,84.00 L-24.25,56.00 Z"/><path d="M48.50,42.00 L72.75,56.00 L72.75,84.00 L48.50,98.00 L24.25,84.00 L24.25,56.00 Z"/><path d="M0.00,-42.00 L24.25,-28.00 L24.25,-0.00 L0.00,14.00 L-24.25,-0.00 L-24.25,-28.00 Z"/><path d="M48.50,-42.00 L72.75,-28.00 L72.75,-0.00 L48.50,14.00 L24.25,-0.00 L24.25,-28.00 Z"/></pattern></defs><rect width="100%" height="100%" fill="url(#bchive-favo)"/></svg>
<svg class="colmeia__cacho colmeia__cacho--a" viewBox="0 0 227.9 207.0" aria-hidden="true" focusable="false"><path d="M61.98,7.80 L86.40,21.90 L86.40,50.10 L61.98,64.20 L37.56,50.10 L37.56,21.90 Z" class="vazio"/><path d="M113.94,7.80 L138.36,21.90 L138.36,50.10 L113.94,64.20 L89.52,50.10 L89.52,21.90 Z" class="vazio"/><path d="M165.90,7.80 L190.33,21.90 L190.33,50.10 L165.90,64.20 L141.48,50.10 L141.48,21.90 Z" class="vazio"/><path d="M36.00,52.80 L60.42,66.90 L60.42,95.10 L36.00,109.20 L11.58,95.10 L11.58,66.90 Z" class="vazio"/><path d="M87.96,52.80 L112.38,66.90 L112.38,95.10 L87.96,109.20 L63.54,95.10 L63.54,66.90 Z" class="mel"/><path d="M139.92,52.80 L164.34,66.90 L164.34,95.10 L139.92,109.20 L115.50,95.10 L115.50,66.90 Z" class="mel"/><path d="M191.88,52.80 L216.31,66.90 L216.31,95.10 L191.88,109.20 L167.46,95.10 L167.46,66.90 Z" class="vazio"/><path d="M61.98,97.80 L86.40,111.90 L86.40,140.10 L61.98,154.20 L37.56,140.10 L37.56,111.90 Z" class="mel"/><path d="M113.94,97.80 L138.36,111.90 L138.36,140.10 L113.94,154.20 L89.52,140.10 L89.52,111.90 Z" class="mel"/><path d="M165.90,97.80 L190.33,111.90 L190.33,140.10 L165.90,154.20 L141.48,140.10 L141.48,111.90 Z" class="vazio"/><path d="M139.92,142.80 L164.34,156.90 L164.34,185.10 L139.92,199.20 L115.50,185.10 L115.50,156.90 Z" class="vazio"/><path d="M36.00,142.80 L60.42,156.90 L60.42,185.10 L36.00,199.20 L11.58,185.10 L11.58,156.90 Z" class="vazio"/><path d="M87.96,142.80 L112.38,156.90 L112.38,185.10 L87.96,199.20 L63.54,185.10 L63.54,156.90 Z" class="vazio"/></svg>
<svg class="colmeia__cacho colmeia__cacho--b" viewBox="0 0 197.5 140.4" aria-hidden="true" focusable="false"><path d="M53.72,6.76 L74.88,18.98 L74.88,43.42 L53.72,55.64 L32.55,43.42 L32.55,18.98 Z" class="vazio"/><path d="M98.75,6.76 L119.92,18.98 L119.92,43.42 L98.75,55.64 L77.58,43.42 L77.58,18.98 Z" class="mel"/><path d="M143.78,6.76 L164.95,18.98 L164.95,43.42 L143.78,55.64 L122.62,43.42 L122.62,18.98 Z" class="vazio"/><path d="M31.20,45.76 L52.37,57.98 L52.37,82.42 L31.20,94.64 L10.03,82.42 L10.03,57.98 Z" class="vazio"/><path d="M76.23,45.76 L97.40,57.98 L97.40,82.42 L76.23,94.64 L55.07,82.42 L55.07,57.98 Z" class="vazio"/><path d="M121.27,45.76 L142.43,57.98 L142.43,82.42 L121.27,94.64 L100.10,82.42 L100.10,57.98 Z" class="vazio"/><path d="M166.30,45.76 L187.47,57.98 L187.47,82.42 L166.30,94.64 L145.13,82.42 L145.13,57.98 Z" class="mel"/><path d="M53.72,84.76 L74.88,96.98 L74.88,121.42 L53.72,133.64 L32.55,121.42 L32.55,96.98 Z" class="vazio"/><path d="M98.75,84.76 L119.92,96.98 L119.92,121.42 L98.75,133.64 L77.58,121.42 L77.58,96.98 Z" class="vazio"/><path d="M143.78,84.76 L164.95,96.98 L164.95,121.42 L143.78,133.64 L122.62,121.42 L122.62,96.98 Z" class="mel"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="left:1%;top:14%" aria-hidden="true" focusable="false"><path d="M10 100 C 40 20, 90 110, 130 50 S 180 20, 195 40"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="right:1%;top:70%;transform:scaleX(-1)" aria-hidden="true" focusable="false"><path d="M10 90 C 50 10, 80 100, 120 40 S 170 30, 195 60"/></svg>
<svg class="abelha ab1" style="left:2.5%;top:20%;--d:13s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab1"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab1)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab2" style="right:3%;top:34%;--d:16s;--x:-16px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab2"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab2)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab3" style="left:4%;top:62%;--d:15s;--x:14px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab3"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab3)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab4" style="right:5%;top:76%;--d:12s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab4"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab4)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab5" style="right:22%;top:12%;--d:18s;--x:-12px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab5"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab5)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
</div>

<div class="progresso" aria-hidden="true"><div class="progresso__barra"></div></div>
<header class="topo">
  <div class="conteudo topo__linha">
    <a class="marca" href="index.aspx" aria-label="b.IA Credit Hive, início">
      <img class="mlogo mlogo--c" src="img/logo-bia.svg" alt="b.IA Credit" height="28"><img class="mlogo mlogo--e" src="img/logo-bia-escuro.svg" alt="" height="28"><span class="marca__produto">Hive</span>
    </a>
    <nav aria-label="Páginas da documentação" class="nav"><ul class="menu"><li><a href="index.aspx">Início</a></li><li><a href="por-dentro.aspx">Por dentro</a></li><li><a href="fluxo.aspx" aria-current="page">Fluxo</a></li><li><a href="camadas.aspx">Camadas</a></li><li><a href="instalacao.aspx">Instalação</a></li><li><a href="cenarios.aspx">Cenários</a></li><li><a href="governanca.aspx">Governança</a></li><li><a href="referencia.aspx">Referência</a></li></ul></nav>
    <div class="controles" data-controles></div>
  </div>
</header>
<main id="conteudo">
<section class="hero hero--pagina conteudo" data-slide>
  <div>
    <p class="eyebrow">O fluxo</p>
    <h1 class="titulo-abertura">Uma fase por chat, um portão por fase</h1>
    <p class="lede">Role a página: cada fase acende no favo à esquerda, com quem faz, o que entra, o que sai e o que fecha a fase.
      Ajuste pequeno (teste quebrado, texto, configuração) <strong>não passa por aqui</strong>: faça no chat normal.</p>
  </div>
</section>

<section class="secao conteudo historia" id="fases" aria-label="Fases do fluxo">
  <div class="historia__palco" aria-hidden="true"><svg class="fases-svg" viewBox="0 0 300 600" role="img" aria-label="As nove fases do fluxo"><path d="M80.0,50.0 L133.5,112.0 L80.0,174.0 L133.5,236.0 L80.0,298.0 L133.5,360.0 L80.0,422.0 L133.5,484.0 L80.0,546.0" class="dg-rota"/><path d="M80.0,50.0 L133.5,112.0 L80.0,174.0 L133.5,236.0 L80.0,298.0 L133.5,360.0 L80.0,422.0 L133.5,484.0 L80.0,546.0" class="dg-rota dg-rota--viva" data-traco-historia/><g class="dg-fase" data-fase-no="0"><path d="M80.0,20.0 L106.0,35.0 L106.0,65.0 L80.0,80.0 L54.0,65.0 L54.0,35.0 Z" class="dg-hex"/><text x="80.0" y="55.0" class="dg-t dg-t--forte" text-anchor="middle">0</text><text x="124.0" y="55.0" class="dg-t dg-t--rotulo">Preparação</text></g><g class="dg-fase" data-fase-no="1"><path d="M133.5,82.0 L159.5,97.0 L159.5,127.0 L133.5,142.0 L107.6,127.0 L107.6,97.0 Z" class="dg-hex"/><text x="133.5" y="117.0" class="dg-t dg-t--forte" text-anchor="middle">1</text><text x="177.5" y="117.0" class="dg-t dg-t--rotulo">Intenção</text></g><g class="dg-fase" data-fase-no="2"><path d="M80.0,144.0 L106.0,159.0 L106.0,189.0 L80.0,204.0 L54.0,189.0 L54.0,159.0 Z" class="dg-hex"/><text x="80.0" y="179.0" class="dg-t dg-t--forte" text-anchor="middle">2</text><text x="124.0" y="179.0" class="dg-t dg-t--rotulo">Discovery</text></g><g class="dg-fase" data-fase-no="3"><path d="M133.5,206.0 L159.5,221.0 L159.5,251.0 L133.5,266.0 L107.6,251.0 L107.6,221.0 Z" class="dg-hex"/><text x="133.5" y="241.0" class="dg-t dg-t--forte" text-anchor="middle">3</text><text x="177.5" y="241.0" class="dg-t dg-t--rotulo">Plano</text></g><g class="dg-fase" data-fase-no="4"><path d="M80.0,268.0 L106.0,283.0 L106.0,313.0 L80.0,328.0 L54.0,313.0 L54.0,283.0 Z" class="dg-hex"/><text x="80.0" y="303.0" class="dg-t dg-t--forte" text-anchor="middle">4</text><text x="124.0" y="303.0" class="dg-t dg-t--rotulo">Revisão da spec</text></g><g class="dg-fase" data-fase-no="5"><path d="M133.5,330.0 L159.5,345.0 L159.5,375.0 L133.5,390.0 L107.6,375.0 L107.6,345.0 Z" class="dg-hex"/><text x="133.5" y="365.0" class="dg-t dg-t--forte" text-anchor="middle">5</text><text x="177.5" y="365.0" class="dg-t dg-t--rotulo">Implementação</text></g><g class="dg-fase" data-fase-no="6"><path d="M80.0,392.0 L106.0,407.0 L106.0,437.0 L80.0,452.0 L54.0,437.0 L54.0,407.0 Z" class="dg-hex"/><text x="80.0" y="427.0" class="dg-t dg-t--forte" text-anchor="middle">6</text><text x="124.0" y="427.0" class="dg-t dg-t--rotulo">Revisão de código</text></g><g class="dg-fase" data-fase-no="7"><path d="M133.5,454.0 L159.5,469.0 L159.5,499.0 L133.5,514.0 L107.6,499.0 L107.6,469.0 Z" class="dg-hex"/><text x="133.5" y="489.0" class="dg-t dg-t--forte" text-anchor="middle">7</text><text x="177.5" y="489.0" class="dg-t dg-t--rotulo">Archive</text></g><g class="dg-fase" data-fase-no="8"><path d="M80.0,516.0 L106.0,531.0 L106.0,561.0 L80.0,576.0 L54.0,561.0 L54.0,531.0 Z" class="dg-hex"/><text x="80.0" y="551.0" class="dg-t dg-t--forte" text-anchor="middle">8</text><text x="124.0" y="551.0" class="dg-t dg-t--rotulo">QA e conhecimento</text></g></svg>
</div>
  <ol class="historia__passos">
    <li class="passo" data-fase="0" data-slide><p class="eyebrow">Preparação · uma vez por repositório</p><h3>Deixar o repositório pronto</h3>
      <dl><dt>Quem</dt><dd>agente <code>bchive</code> · <code>/bia-credit-hive:init</code></dd><dt>Entra</dt><dd>o repositório como está, com ou sem <code>.github/</code></dd>
      <dt>Sai</dt><dd><code>.bchive/</code> fora do Git, mapa do projeto, canário conferido</dd><dt>Fecha</dt><dd>init sem GRAVE</dd></dl></li>
    <li class="passo" data-fase="1" data-slide><p class="eyebrow">Intenção</p><h3>Qual é o próximo passo?</h3>
      <dl><dt>Quem</dt><dd>qualquer agente com terminal · <code>/bia-credit-hive:start</code></dd><dt>Entra</dt><dd>o pedido em uma frase</dd>
      <dt>Sai</dt><dd>a rota: chat normal, discovery, protótipo ou plano</dd><dt>Fecha</dt><dd>o dev confirma a rota</dd></dl></li>
    <li class="passo" data-fase="2" data-slide><p class="eyebrow">Discovery</p><h3>Entender antes de planejar</h3>
      <dl><dt>Quem</dt><dd><code>bchive-discovery</code> · <code>/bia-credit-hive:grill</code> (dor) ou <code>:triagem</code> (ticket)</dd><dt>Entra</dt><dd>a necessidade ou o ticket</dd>
      <dt>Sai</dt><dd>briefing de uma página com os insumos: telas, contrato de cada camada, exemplos</dd><dt>Fecha</dt><dd>sem lacuna que impeça descrever o esperado</dd></dl>
      <p class="nota">Não lê código de propósito: o estado atual é pergunta para o humano.</p></li>
    <li class="passo" data-fase="3" data-slide><p class="eyebrow">Plano</p><h3>Acordo escrito antes do código</h3>
      <dl><dt>Quem</dt><dd><code>bchive-plan</code> · <code>/bia-credit-hive:plan &lt;briefing&gt;</code></dd><dt>Entra</dt><dd>briefing, mapa, specs e decisões vigentes</dd>
      <dt>Sai</dt><dd>proposta com critérios, fatias verticais com <code>Toca:</code> e executor, deltas</dd><dt>Fecha</dt><dd><code>validar</code> sem erro</dd></dl></li>
    <li class="passo" data-fase="4" data-slide><p class="eyebrow">Revisão da spec</p><h3>O peixinho lê o acordo</h3>
      <dl><dt>Quem</dt><dd><code>bchive-review</code> · <code>/bia-credit-hive:review spec &lt;id&gt;</code></dd><dt>Entra</dt><dd>pacote gerado por script</dd>
      <dt>Sai</dt><dd>um veredito por estágio</dd><dt>Fecha</dt><dd><span class="selo selo--mel">humano</span> <code>aprovar-spec</code></dd></dl></li>
    <li class="passo" data-fase="5" data-slide><p class="eyebrow">Implementação</p><h3>Uma fatia por sessão</h3>
      <dl><dt>Quem</dt><dd><code>bchive-implement</code> → executor da fatia · <code>/bia-credit-hive:implement &lt;id&gt;</code></dd><dt>Entra</dt><dd>a fatia e os ponteiros dela</dd>
      <dt>Sai</dt><dd>código, testes, tarefas marcadas e a mensagem de commit sugerida</dd><dt>Fecha</dt><dd><span class="selo selo--mel">humano</span> revisa o diff e commita</dd></dl></li>
    <li class="passo" data-fase="6" data-slide><p class="eyebrow">Revisão de código</p><h3>Três eixos, três revisores</h3>
      <dl><dt>Quem</dt><dd><code>bchive-review</code> · <code>/bia-credit-hive:review &lt;id&gt;</code></dd><dt>Entra</dt><dd>diff, verificação, raio de impacto</dd>
      <dt>Sai</dt><dd>vereditos de <code>spec</code>, <code>padroes</code> e <code>plantao</code></dd><dt>Fecha</dt><dd>três APROVADO no HEAD</dd></dl></li>
    <li class="passo" data-fase="7" data-slide><p class="eyebrow">Archive</p><h3>Descrição da PR pronta</h3>
      <dl><dt>Quem</dt><dd><code>bchive-archive</code> · <code>/bia-credit-hive:archive &lt;id&gt;</code></dd><dt>Entra</dt><dd>artefatos e diff</dd>
      <dt>Sai</dt><dd><code>resumo.md</code> com Como testar e Risco do merge; specs e decisões atualizadas</dd><dt>Fecha</dt><dd><span class="selo selo--mel">humano</span> abre a PR</dd></dl></li>
    <li class="passo" data-fase="8" data-slide><p class="eyebrow">QA e conhecimento</p><h3>Só fecha depois do teste</h3>
      <dl><dt>Quem</dt><dd><span class="selo selo--mel">QA</span> <code>qa-ok</code>, depois <code>bchive-archive</code> · <code>/bia-credit-hive:fechar</code></dd><dt>Entra</dt><dd>o OK de quem testou: quem, ambiente, data, resultado</dd>
      <dt>Sai</dt><dd><code>conhecimento/&lt;data&gt;-&lt;ticket&gt;.md</code>, o único arquivo para o Git</dd><dt>Fecha</dt><dd>o dev commita na branch da PR</dd></dl></li>
  </ol>
</section>

<section class="secao conteudo" id="exemplo" data-slide aria-labelledby="ex-t">
  <div class="secao__cab">
    <p class="eyebrow">Exemplo de ponta a ponta</p>
    <h2 id="ex-t">GPCNLS-10019 · mostrar o saldo projetado</h2>
    <p>Uma mudança fictícia, com os artefatos no formato real. Clique em cada etapa.</p>
  </div>
  <div class="abas" data-abas>
    <div class="abas__lista" role="tablist" aria-label="Artefatos do exemplo">
      <button role="tab" aria-selected="true" aria-controls="ab-1" id="tb-1">1 · Briefing</button>
      <button role="tab" aria-selected="false" aria-controls="ab-2" id="tb-2">2 · Proposta</button>
      <button role="tab" aria-selected="false" aria-controls="ab-3" id="tb-3">3 · Fatia</button>
      <button role="tab" aria-selected="false" aria-controls="ab-4" id="tb-4">4 · Veredito</button>
      <button role="tab" aria-selected="false" aria-controls="ab-5" id="tb-5">5 · Resumo da PR</button>
      <button role="tab" aria-selected="false" aria-controls="ab-6" id="tb-6">6 · OK do QA</button>
    </div>
    <div class="abas__painel" role="tabpanel" id="ab-1" aria-labelledby="tb-1">
      <p class="nota"><code>.bchive/briefings/GPCNLS-10019-saldo-projetado/briefing.md</code></p>
<pre class="cmd"><code># Briefing - saldo projetado na tela de acordo

## Problema
O gerente fecha o acordo sem ver quanto o cliente vai dever depois da 1ª parcela.

## O que se espera
Na confirmação, aparece o saldo projetado após a primeira parcela, com duas casas decimais.

## Restrições
- Não alterar o contrato da API de efetivação.

## Insumos
| Insumo | Situação | Onde |
| Telas (Figma) e análise | ok | `figma.md` |
| Contrato de API por camada | ok | MFE: `oferta.types.ts`; BFF: `contrato-bff.md` |
| Exemplos concretos | ok | saldo 12.500,00 − parcela 1.250,00 = 11.250,00 |</code></pre>
    </div>
    <div class="abas__painel" role="tabpanel" id="ab-2" aria-labelledby="tb-2">
      <p class="nota"><code>.bchive/changes/GPCNLS-10019-mostrar-saldo-projetado/proposta.md</code></p>
<pre class="cmd"><code>Ticket: GPCNLS-10019
Branch: feature/GPCNLS-10019
Base:   main
Rigor:  Lite

## Critérios de aceite
1. MUST mostrar o saldo projetado na confirmação.
   Dado saldo 12.500,00 e 1ª parcela 1.250,00, quando abrir a confirmação,
   então vê "Saldo após a 1ª parcela: R$ 11.250,00".
   Dado que o BFF não envia o saldo, quando abrir, então a linha não aparece.</code></pre>
    </div>
    <div class="abas__painel" role="tabpanel" id="ab-3" aria-labelledby="tb-3">
      <p class="nota"><code>tarefas/01-saldo-na-confirmacao.md</code></p>
<pre class="cmd"><code># 01. Saldo projetado na confirmação
Demonstra: a confirmação mostra o saldo após a 1ª parcela.
Bloqueado por: nenhum
Toca: src/app/feature/confirmacao/, src/app/core/api/oferta.types.ts
Executor: bchive-implementador

## Ponteiros
- proposta.md, critério 1
- figma.md, estado "confirmação"

- [ ] 1.1 Exibir a linha do saldo quando o BFF enviar o valor
- [ ] 1.2 Teste do componente: com e sem o valor</code></pre>
    </div>
    <div class="abas__painel" role="tabpanel" id="ab-4" aria-labelledby="tb-4">
      <p class="nota"><code>revisao/plantao-a1b2c3d.md</code>: gravado por script, nunca editado</p>
<pre class="cmd"><code># plantao - <span class="sin">REPROVADO</span>
Commit revisado: a1b2c3d
Achados: 1
- [bloqueante] confirmacao.component.ts:42 — formata o saldo com toFixed(2)
  — com 11250.005 mostra "11250.01" sem separador de milhar
  — usar o pipe de moeda do projeto (pt-BR)</code></pre>
      <p class="nota">Reprovou por um bug que o diff introduziu. O caminho é replanejar só esse ponto, ou o dev aceitar com motivo, no terminal dele.</p>
    </div>
    <div class="abas__painel" role="tabpanel" id="ab-5" aria-labelledby="tb-5">
      <p class="nota"><code>resumo.md</code>: vai para a descrição da PR e para a task</p>
<pre class="cmd"><code>## feat(confirmacao): mostra o saldo projetado após a 1ª parcela

### Como testar
1. Abrir a confirmação de um acordo com saldo 12.500,00 e parcela 1.250,00.
2. Ver "Saldo após a 1ª parcela: R$ 11.250,00".
3. Com o BFF sem o campo, a linha não aparece.

### Risco do merge
- Porta: mão dupla (reverter o commit desfaz tudo)
- Raio de impacto: tela de confirmação; nenhum outro consumidor</code></pre>
    </div>
    <div class="abas__painel" role="tabpanel" id="ab-6" aria-labelledby="tb-6">
      <p class="nota">No terminal de quem testou. O agente não consegue rodar este comando.</p>
<pre class="cmd"><code>node .bchive/bin/bchive.mjs qa-ok 2026-11-20-GPCNLS-10019-mostrar-saldo-projetado \
  --por "Fulana QA" --ambiente "TU" --resultado "saldo exibido e oculto sem o campo, conforme o Como testar"
<span class="ok">OK do QA gravado.</span> Próximo, no chat: /bia-credit-hive:fechar 2026-11-20-GPCNLS-10019-... &lt;PR&gt;</code></pre>
    </div>
  </div>
</section>

<section class="secao conteudo" id="desvios" data-slide aria-labelledby="desv-t">
  <div class="secao__cab">
    <p class="eyebrow">Quando algo não sai como planejado</p>
    <h2 id="desv-t">Os desvios também têm caminho</h2>
  </div>
  <div class="grade revelar-grupo">
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>1</span></span>Revisão reprovou</h3><p>Só o <code>[bloqueante]</code> vira trabalho: <code>/bia-credit-hive:plan replanejar: &lt;id&gt;</code>. Na rodada seguinte, roda de novo só o estágio que reprovou.</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>2</span></span>Duas reprovações seguidas</h3><p>O script não gera a terceira. A decisão é humana: aprovar com motivo, liberar uma rodada extra ou partir a mudança.</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>3</span></span>A execução saiu do escopo</h3><p>Arquivo fora do <code>Toca:</code> vira cartão de decisão: commitar junto, separar com <code>git add -p</code> ou replanejar.</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>4</span></span>O QA achou erro</h3><p>Nada é reaberto. Uma mudança nova e pequena, na mesma branch e PR; um <code>qa-ok</code> cobre as duas no fim.</p></div>
  </div>
</section>

<div class="conteudo">
  <nav class="passagem" aria-label="Navegação entre páginas">
    <a href="por-dentro.aspx" data-anterior><small>← Anterior</small><strong>Por dentro</strong></a>
    <a class="prox" href="camadas.aspx" data-proxima><small>Próxima →</small><strong>Camadas</strong></a>
  </nav>
  <footer class="rodape"><span>b.IA Credit Hive · documentação da versão 1.1 do plugin <code>bia-credit-hive</code></span><span><kbd>P</kbd> apresentação · <kbd>←</kbd> <kbd>→</kbd> navegar · <kbd>Esc</kbd> sair</span></footer>
</div>
</main>
<div class="slide-contador" aria-live="polite"></div>
</body>
</html>
