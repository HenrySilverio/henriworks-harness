/* b.IA Credit Hive · documentação. Sem script inline, sem eval: tudo por addEventListener (CSP do SharePoint).
   A página é completa sem JavaScript; aqui só entram preferências, interações e movimento. */
(function () {
  'use strict';
  var doc = document.documentElement;
  var M = window.Motion || null;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var guardar = function (k, v) { try { localStorage.setItem('bchive-doc-' + k, v); } catch (e) { /* sem armazenamento */ } };
  var ler = function (k) { try { return localStorage.getItem('bchive-doc-' + k); } catch (e) { return null; } };
  var reduzir = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  doc.classList.add('js');

  /* ---------------------------------------------------------- controles (só existem com JavaScript) */
  var caixa = $('[data-controles]');
  var criar = function (html) { var t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstChild; };
  if (caixa) {
    if (document.querySelector('main [data-nivel]')) caixa.appendChild(criar('<div class="seg" role="group" aria-label="Profundidade das explicações" data-nivel-seletor><button type="button" data-valor="tudo" aria-pressed="true">Tudo</button><button type="button" data-valor="gestao" aria-pressed="false">Gestão</button><button type="button" data-valor="tecnico" aria-pressed="false">Técnico</button></div>'));
    caixa.appendChild(criar('<button type="button" class="btn-icone" data-tema aria-label="Alternar tema claro e escuro">◐ <span class="rotulo-largo">Tema</span></button>'));
    caixa.appendChild(criar('<button type="button" class="btn-icone btn-apresentar" aria-pressed="false" title="Modo apresentação (P)">▶ <span class="rotulo-largo">Apresentar</span></button>'));
  }

  /* ---------------------------------------------------------- tema */
  var tema = ler('tema');
  if (tema === 'light' || tema === 'dark') doc.setAttribute('data-theme', tema);
  var btTema = $('[data-tema]');
  if (btTema) {
    btTema.addEventListener('click', function () {
      var escuroAgora = doc.getAttribute('data-theme') === 'dark' || (!doc.getAttribute('data-theme') && window.matchMedia('(prefers-color-scheme: dark)').matches);
      var novo = escuroAgora ? 'light' : 'dark';
      doc.setAttribute('data-theme', novo);
      guardar('tema', novo);
    });
  }

  /* ---------------------------------------------------------- gestão × técnico */
  var seg = $('[data-nivel-seletor]');
  if (seg) {
    var aplicar = function (v) {
      if (v === 'gestao' || v === 'tecnico') doc.setAttribute('data-mostrar', v); else doc.removeAttribute('data-mostrar');
      $$('button', seg).forEach(function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-valor') === (v || 'tudo'))); });
    };
    aplicar(ler('nivel') || 'tudo');
    seg.addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      var v = b.getAttribute('data-valor'); aplicar(v); guardar('nivel', v);
      if (M) M.from($$('[data-nivel]').filter(function (x) { return x.offsetParent; }), { opacity: 0, y: 8, duration: 0.3, stagger: 0.02 });
    });
  }

  /* ---------------------------------------------------------- copiar comando */
  $$('pre.cmd').forEach(function (pre) {
    if (!navigator.clipboard) return;
    var b = document.createElement('button');
    b.type = 'button'; b.className = 'copiar'; b.textContent = 'Copiar';
    b.addEventListener('click', function () {
      navigator.clipboard.writeText(pre.querySelector('code').innerText.trim()).then(function () {
        b.textContent = 'Copiado'; b.setAttribute('data-ok', '');
        setTimeout(function () { b.textContent = 'Copiar'; b.removeAttribute('data-ok'); }, 1600);
      });
    });
    pre.appendChild(b);
  });

  /* ---------------------------------------------------------- abas */
  $$('[data-abas]').forEach(function (box) {
    var abas = $$('[role="tab"]', box), paineis = $$('[role="tabpanel"]', box);
    var mostrar = function (i, foco) {
      abas.forEach(function (a, k) { a.setAttribute('aria-selected', String(k === i)); a.tabIndex = k === i ? 0 : -1; });
      paineis.forEach(function (p, k) { p.hidden = k !== i; if (k !== i) p.setAttribute('aria-hidden', 'true'); else p.removeAttribute('aria-hidden'); });
      if (foco) abas[i].focus();
      if (M) M.from(paineis[i], { opacity: 0, y: 10, duration: 0.3 });
    };
    abas.forEach(function (a, i) {
      a.addEventListener('click', function () { mostrar(i); });
      a.addEventListener('keydown', function (e) {
        if (e.key === 'ArrowRight') mostrar((i + 1) % abas.length, true);
        if (e.key === 'ArrowLeft') mostrar((i - 1 + abas.length) % abas.length, true);
      });
    });
    mostrar(0);
  });

  /* ---------------------------------------------------------- filtros (cenários) */
  var filtros = $('[data-filtros]');
  if (filtros) {
    filtros.removeAttribute('data-sem-js'); filtros.removeAttribute('aria-hidden');
    filtros.addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      var f = b.getAttribute('data-filtro');
      $$('button', filtros).forEach(function (x) { x.setAttribute('aria-pressed', String(x === b)); });
      var visiveis = [];
      $$('.cenario').forEach(function (c) { var ok = f === 'todos' || c.getAttribute('data-tipo') === f; c.hidden = !ok; if (ok) { visiveis.push(c); c.removeAttribute('aria-hidden'); } else c.setAttribute('aria-hidden', 'true'); });
      if (M) M.from(visiveis, { opacity: 0, y: 14, scale: 0.98, duration: 0.35, stagger: 0.04 });
    });
  }
  $$('.rota').forEach(function (r) { $$('.selo', r).forEach(function (s, i) { s.style.setProperty('--k', i); }); });

  /* ---------------------------------------------------------- busca (referência) */
  $$('[data-busca]').forEach(function (input) {
    var rot = input.closest('[data-busca-rotulo]'); if (rot) { rot.removeAttribute('data-sem-js'); rot.removeAttribute('aria-hidden'); }
    var linhas = $$(input.getAttribute('data-busca') + ' tbody tr');
    input.addEventListener('input', function () {
      var q = input.value.trim().toLowerCase();
      linhas.forEach(function (tr) { var fora = Boolean(q) && tr.textContent.toLowerCase().indexOf(q) < 0; tr.hidden = fora; if (fora) tr.setAttribute('aria-hidden', 'true'); else tr.removeAttribute('aria-hidden'); });
    });
  });

  /* ---------------------------------------------------------- modo apresentação */
  var slides = $$('[data-slide]');
  var contador = $('.slide-contador');
  var atual = 0;
  var proxima = $('[data-proxima]'), anterior = $('[data-anterior]');
  var irPara = function (i) {
    if (i >= slides.length) { if (proxima) location.href = proxima.getAttribute('href') + '?apresentar=1'; return; }
    if (i < 0) { if (anterior) location.href = anterior.getAttribute('href') + '?apresentar=1&fim=1'; return; }
    atual = i;
    slides[i].scrollIntoView({ behavior: reduzir ? 'auto' : 'smooth', block: 'start' });
    if (contador) contador.textContent = (i + 1) + ' / ' + slides.length;
  };
  var apresentar = function (ligar) {
    document.body.classList.toggle('apresentando', ligar);
    var b = $('.btn-apresentar'); if (b) b.setAttribute('aria-pressed', String(ligar));
    if (ligar) irPara(atual);
  };
  var btAp = $('.btn-apresentar');
  if (btAp) { btAp.addEventListener('click', function () { apresentar(!document.body.classList.contains('apresentando')); }); }
  if ('IntersectionObserver' in window && slides.length) {
    var ioSlide = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { atual = slides.indexOf(e.target); if (contador) contador.textContent = (atual + 1) + ' / ' + slides.length; } });
    }, { rootMargin: '-45% 0px -50% 0px' });
    slides.forEach(function (s) { ioSlide.observe(s); });
  }
  document.addEventListener('keydown', function (e) {
    if (/input|textarea|select/i.test((e.target.tagName || '')) || e.ctrlKey || e.metaKey || e.altKey) return;
    if (e.key === 'p' || e.key === 'P') { apresentar(!document.body.classList.contains('apresentando')); return; }
    if (!document.body.classList.contains('apresentando')) return;
    if (['ArrowRight', 'ArrowDown', 'PageDown', ' '].indexOf(e.key) >= 0) { e.preventDefault(); irPara(atual + 1); }
    if (['ArrowLeft', 'ArrowUp', 'PageUp'].indexOf(e.key) >= 0) { e.preventDefault(); irPara(atual - 1); }
    if (e.key === 'Escape') apresentar(false);
  });
  var params = new URLSearchParams(location.search);
  if (params.get('apresentar') === '1') { atual = params.get('fim') === '1' ? slides.length - 1 : 0; apresentar(true); }

  /* ---------------------------------------------------------- história do fluxo (palco fixo) */
  var passos = $$('.passo[data-fase]');
  if (passos.length && 'IntersectionObserver' in window) {
    var nos = $$('[data-fase-no]');
    var ativar = function (n) {
      nos.forEach(function (no) { var k = +no.getAttribute('data-fase-no'); no.classList.toggle('ativa', k === n); no.classList.toggle('feita', k < n); });
      passos.forEach(function (p) { p.classList.toggle('ativa', +p.getAttribute('data-fase') === n); });
    };
    var ioPasso = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) ativar(+e.target.getAttribute('data-fase')); });
    }, { rootMargin: '-40% 0px -45% 0px' });
    passos.forEach(function (p) { ioPasso.observe(p); });
    ativar(0);
  }

  /* ---------------------------------------------------------- sem engine: termina aqui (página completa) */
  if (!M) return;
  M.config({ respectReducedMotion: true });

  // barra de leitura
  M.scrub('.progresso__barra', { scaleX: 0 }, { scaleX: 1 }, { source: 'page' });

  // abertura: o único momento orquestrado
  var titulo = $('.titulo-abertura');
  var tl = M.timeline({ defaults: { ease: 'power3.out', duration: 0.7 } });
  if (titulo) {
    var partes = M.splitText(titulo, { type: titulo.textContent.length > 40 ? 'words' : 'words,chars' });
    tl.from(partes.chars && partes.chars.length ? partes.chars : partes.words, { y: 42, opacity: 0, stagger: titulo.textContent.length > 40 ? 0.04 : 0.018 });
  }
  tl.from('.hero .eyebrow', { opacity: 0, x: -14, duration: 0.5 }, '<')
    .from('.hero .lede', { opacity: 0, y: 16 }, '-=0.4')
    .from('.hero .acoes > *', { opacity: 0, y: 12, stagger: 0.08, duration: 0.45 }, '-=0.35');
  if ($('.hero__simbolo')) tl.from('.hero__simbolo', { scale: 0.6, opacity: 0, rotation: -18, duration: 0.9, ease: 'back.out' }, 0.15)
    .from('.hero__marca .favo-hero', { opacity: 0, scale: 0.85, duration: 1.1 }, 0.1);
  if ($('.hero__simbolo')) M.scrub('.hero__simbolo', { y: -18 }, { y: 26 }, { trigger: '.hero', rangeStart: 'exit 0%', rangeEnd: 'exit 100%' });

  // números que contam
  var contados = $$('[data-count]');
  if (contados.length && 'IntersectionObserver' in window) {
    var ioNum = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { M.counter(e.target, { duration: 1.3, ease: 'power2.out' }); ioNum.unobserve(e.target); } });
    }, { threshold: 0.6 });
    contados.forEach(function (el) { ioNum.observe(el); });
  }

  // revelar ao rolar: blocos e grupos em sequência
  M.reveal('.revelar', { y: 26, opacity: 0, duration: 0.7, ease: 'power2.out' }, { threshold: 0.12 });
  $$('.revelar-grupo').forEach(function (g) {
    M.reveal(g.children, { y: 22, opacity: 0, duration: 0.55, ease: 'power2.out' }, { stagger: 0.07, threshold: 0.1 });
  });
  M.reveal('.secao__cab', { y: 18, opacity: 0, duration: 0.6 }, { threshold: 0.2 });
  M.reveal('.pilha__item', { x: -40, opacity: 0, duration: 0.6, ease: 'power3.out' }, { stagger: 0.07, threshold: 0.1 });

  // traços SVG que se desenham quando aparecem
  if ('IntersectionObserver' in window) {
    var ioTraco = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        if (!e.isIntersecting) return;
        $$('.desenhar', e.target).forEach(function (p, i) { setTimeout(function () { M.drawSVG(p, { duration: 1.1, ease: 'power1.inOut' }); }, i * 120); });
        $$('.dg-fatia', e.target).forEach(function (f, i) { setTimeout(function () { f.classList.add('cheia'); }, 900 + i * 450); });
        $$('.dg-portao, .dg-no, .dg-col', e.target).forEach(function (g, i) { M.from(g, { opacity: 0, scale: 0.6, duration: 0.5, delay: 0.25 + i * 0.09, ease: 'back.out' }); });
        ioTraco.unobserve(e.target);
      });
    }, { threshold: 0.25 });
    $$('.diagrama').forEach(function (d) { ioTraco.observe(d); });
  }

  // traço da história do fluxo, ligado ao scroll
  var traco = $('[data-traco-historia]');
  if (traco && traco.getTotalLength) {
    var len = traco.getTotalLength();
    traco.style.strokeDasharray = len + ' ' + len;
    M.scrub(traco, { strokeDashoffset: len }, { strokeDashoffset: 0 }, { trigger: '.historia', rangeStart: 'contain 0%', rangeEnd: 'contain 100%' });
  }

  // trilha de passos: a linha cresce com o scroll
  $$('.trilha').forEach(function (t) {
    var linha = document.createElement('span');
    linha.className = 'trilha__linha'; linha.setAttribute('aria-hidden', 'true');
    t.appendChild(linha);
    M.scrub(linha, { scaleY: 0 }, { scaleY: 1 }, { trigger: t, rangeStart: 'entry 40%', rangeEnd: 'exit 70%' });
  });

  // gráfico: barras crescem e valores contam
  $$('.grafico').forEach(function (g) {
    var ioG = new IntersectionObserver(function (es) {
      if (!es[0].isIntersecting) return;
      M.from($$('.grafico__barra', g), { scaleX: 0, duration: 0.9, ease: 'power3.out', stagger: 0.06 });
      $$('.grafico__v[data-to]', g).forEach(function (v) { M.counter(v, { duration: 1 }); });
      ioG.disconnect();
    }, { threshold: 0.3 });
    ioG.observe(g);
  });

  // terminal: linhas aparecem como se fossem digitadas
  $$('.digitar code').forEach(function (code) {
    var linhas = code.innerHTML.split('\n');
    code.innerHTML = linhas.map(function (l) { return '<span class="lt">' + (l || ' ') + '</span>'; }).join('\n');
    var ioT = new IntersectionObserver(function (es) {
      if (!es[0].isIntersecting) return;
      M.from($$('.lt', code), { opacity: 0, x: -8, duration: 0.25, stagger: 0.09, ease: 'power1.out' });
      ioT.disconnect();
    }, { threshold: 0.4 });
    ioT.observe(code);
  });

  // FAQ: corpo entra ao abrir
  $$('details.faq').forEach(function (d) {
    d.addEventListener('toggle', function () { if (d.open) M.from($('.faq__corpo', d), { opacity: 0, y: -8, duration: 0.25 }); });
  });
})();
