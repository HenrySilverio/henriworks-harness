#!/usr/bin/env node
// b.IA Credit Hive · gera a documentação de várias páginas a partir de uma fonte só. Node 20+, sem dependência.
//
//   node gerar.mjs <saida> [--ext aspx|html] [--plugin <pasta do plugin gerado>] [--motion <motion-lite.js>]
//
// Fonte: paginas/*.html (só o conteúdo), diagramas/*.html (SVG), base.css + componentes.css + colmeia.css,
// app.js, img/. Saída: uma página por arquivo, estilo e script externos (zero script inline: CSP do
// SharePoint), vendor/motion-lite.js. Os números do gráfico de tokens saem do plugin, não de estimativa à mão.

import { readFileSync, writeFileSync, mkdirSync, existsSync, readdirSync, statSync, copyFileSync, rmSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const AQUI = dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const op = (k, p) => { const i = args.indexOf(`--${k}`); return i >= 0 ? args[i + 1] : p; };
const SAIDA = resolve(args[0] || join(AQUI, 'out'));
const EXT = op('ext', 'aspx');
const PLUGIN = resolve(op('plugin', join(AQUI, '..', '..', '..', 'dist', 'bia-credit-hive-plugin')));
const MOTION = resolve(op('motion', join(AQUI, 'vendor', 'motion-lite.js')));
const VERSAO = '1.1'; // versão do plugin que esta documentação descreve

const PAGINAS = [
  { id: 'index', menu: 'Início', titulo: 'b.IA Credit Hive', descricao: 'Do ticket do Jira até a PR, com método: plano revisado, fatias, revisão isolada e OK do QA.' },
  { id: 'por-dentro', menu: 'Por dentro', titulo: 'Como funciona por dentro', descricao: 'Ciclo do agente, subagentes, economia de tokens, revisão isolada e qualidade.' },
  { id: 'fluxo', menu: 'Fluxo', titulo: 'O fluxo', descricao: 'As fases, quem faz cada uma e um exemplo de ponta a ponta.' },
  { id: 'camadas', menu: 'Camadas', titulo: 'Camadas', descricao: 'As sete camadas e onde cada coisa mora.' },
  { id: 'instalacao', menu: 'Instalação', titulo: 'Instalação e configuração', descricao: 'Do marketplace ao primeiro pedido, e como preparar o agente da sua stack.' },
  { id: 'cenarios', menu: 'Cenários', titulo: 'Cenários de uso', descricao: 'Que rota cada pedido toma, em qualquer stack e em vários repositórios.' },
  { id: 'governanca', menu: 'Governança', titulo: 'Governança', descricao: 'Papéis, portões, privacidade, indicadores e limitações.' },
  { id: 'referencia', menu: 'Referência', titulo: 'Referência rápida', descricao: 'Comandos, agentes, glossário e perguntas frequentes.' },
];

const ler = (p) => readFileSync(p, 'utf8');
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
const fmt = (n) => Number(n).toLocaleString('pt-BR');

// ------------------------------------------------------------------ números reais do plugin
function numerosDoPlugin() {
  const tok = (p) => (existsSync(p) ? Math.round(statSync(p).size / 4) : null);
  const ag = (n) => tok(join(PLUGIN, 'com.github.copilot', 'agents', `${n}.agent.md`));
  const papeis = [
    ['bchive-gf · revisor', ag('bchive-gf')], ['bchive-discovery', ag('bchive-discovery')], ['bchive-implementador · operária', ag('bchive-implementador')],
    ['bchive-review', ag('bchive-review')], ['bchive-archive', ag('bchive-archive')], ['bchive-implement', ag('bchive-implement')], ['bchive-plan', ag('bchive-plan')],
  ];
  const contrato = tok(join(PLUGIN, 'skills', 'init', 'assets', 'referencias', 'contrato.md'));
  let linhas = 0;
  const contar = (d) => { if (!existsSync(d)) return; for (const n of readdirSync(d)) { const p = join(d, n); if (statSync(p).isDirectory()) contar(p); else if (n.endsWith('.mjs')) linhas += ler(p).split('\n').length; } };
  contar(join(PLUGIN, 'scripts', 'core'));
  const start = existsSync(join(PLUGIN, 'skills', 'start', 'SKILL.md')) ? (ler(join(PLUGIN, 'skills', 'start', 'SKILL.md')).match(/^description: "(.+)"$/m) || [])[1] : null;
  if (papeis.some(([, v]) => v === null) || !contrato || !start) throw new Error(`plugin não encontrado ou incompleto em ${PLUGIN} (use --plugin)`);
  return { papeis, contrato, linhas, fixos: Math.round(start.length / 4) };
}

function graficoTokens(n) {
  const max = n.contrato;
  const linha = (nome, v, sub = false) => `<div class="grafico__linha${sub ? ' grafico__linha--sub' : ''}"><span class="grafico__nome" title="${esc(nome)}">${esc(nome)}</span><div class="grafico__trilho"><div class="grafico__barra" style="--v:${Math.max(2, (v / max) * 100).toFixed(1)}%"></div></div><span class="grafico__v" data-to="${v}">${fmt(v)}</span></div>`;
  return `<div class="grafico revelar" role="figure" aria-label="Tokens estimados das instruções de cada agente">
  <div class="grafico__titulo">Instruções que cada papel carrega (≈ tokens)</div>
  <p class="nota">O contrato completo só é lido no plano; as outras fases leem as seções delas. O revisor, o menor de todos, recebe o resto num pacote sob medida.</p>
  ${n.papeis.map(([k, v]) => linha(k, v)).join('\n  ')}
  ${linha('contrato do fluxo (inteiro)', n.contrato, true)}
</div>`;
}

const alveolo = (t) => `<span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>${esc(t)}</span></span>`;

// ------------------------------------------------------------------ layout
function pagina(p, i, n) {
  const ant = PAGINAS[i - 1];
  const prox = PAGINAS[i + 1];
  const menu = PAGINAS.map((x) => `<li><a href="${x.id}.${EXT}"${x.id === p.id ? ' aria-current="page"' : ''}>${esc(x.menu)}</a></li>`).join('');
  const diag = (k) => ler(join(AQUI, 'diagramas', `${k}.html`));
  let corpo = ler(join(AQUI, 'paginas', `${p.id}.html`))
    .replace(/\{\{ext\}\}/g, EXT)
    .replace(/\{\{favo-hero\}\}/g, ler(join(AQUI, 'img', 'favo-hero.svg')))
    .replace(/\{\{diagrama-(colmeia|loop|revisao|portoes|fases|onde|multi)\}\}/g, (_, k) => diag(k))
    .replace(/\{\{grafico-tokens\}\}/g, graficoTokens(n))
    .replace(/\{\{tokens-fixos\}\}/g, fmt(n.fixos))
    .replace(/\{\{linhas-script\}\}/g, fmt(n.linhas))
    .replace(/\{\{alveolo:([^}]+)\}\}/g, (_, t) => alveolo(t));
  const sobra = corpo.match(/\{\{[^}]+\}\}/);
  if (sobra) throw new Error(`${p.id}: marcador sem valor ${sobra[0]}`);
  return `<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${esc(p.id === 'index' ? 'b.IA Credit Hive · documentação' : `${p.titulo} · b.IA Credit Hive`)}</title>
  <meta name="description" content="${esc(p.descricao)}">
  <link rel="icon" type="image/svg+xml" href="img/simbolo-bia.svg">
  <link rel="stylesheet" href="style.css">
  <script src="vendor/motion-lite.js" defer></script>
  <script src="app.js" defer></script>
</head>
<body>
<a class="pular" href="#conteudo">Pular para o conteúdo</a>
${ler(join(AQUI, 'colmeia.html'))}
<div class="progresso" aria-hidden="true"><div class="progresso__barra"></div></div>
<header class="topo">
  <div class="conteudo topo__linha">
    <a class="marca" href="index.${EXT}" aria-label="b.IA Credit Hive, início">
      <img class="mlogo mlogo--c" src="img/logo-bia.svg" alt="b.IA Credit" height="28"><img class="mlogo mlogo--e" src="img/logo-bia-escuro.svg" alt="" height="28"><span class="marca__produto">Hive</span>
    </a>
    <nav aria-label="Páginas da documentação" class="nav"><ul class="menu">${menu}</ul></nav>
    <div class="controles" data-controles></div>
  </div>
</header>
<main id="conteudo">
${corpo}
<div class="conteudo">
  <nav class="passagem" aria-label="Navegação entre páginas">
    ${ant ? `<a href="${ant.id}.${EXT}" data-anterior><small>← Anterior</small><strong>${esc(ant.menu)}</strong></a>` : '<span></span>'}
    ${prox ? `<a class="prox" href="${prox.id}.${EXT}" data-proxima><small>Próxima →</small><strong>${esc(prox.menu)}</strong></a>` : ''}
  </nav>
  <footer class="rodape"><span>b.IA Credit Hive · documentação da versão ${VERSAO} do plugin <code>bia-credit-hive</code></span><span><kbd>P</kbd> apresentação · <kbd>←</kbd> <kbd>→</kbd> navegar · <kbd>Esc</kbd> sair</span></footer>
</div>
</main>
<div class="slide-contador" aria-live="polite"></div>
</body>
</html>
`;
}

// ------------------------------------------------------------------ build
const n = numerosDoPlugin();
if (existsSync(SAIDA)) rmSync(SAIDA, { recursive: true, force: true });
mkdirSync(join(SAIDA, 'vendor'), { recursive: true });
mkdirSync(join(SAIDA, 'img'), { recursive: true });
const css = ['base.css', 'componentes.css', 'colmeia.css'].map((f) => `/* ${f} */\n${ler(join(AQUI, f))}`).join('\n');
writeFileSync(join(SAIDA, 'style.css'), `${css}\n.digitar .lt { display: inline-block; }\n`);
copyFileSync(join(AQUI, 'app.js'), join(SAIDA, 'app.js'));
copyFileSync(MOTION, join(SAIDA, 'vendor', 'motion-lite.js'));
for (const f of readdirSync(join(AQUI, 'img'))) copyFileSync(join(AQUI, 'img', f), join(SAIDA, 'img', f));
PAGINAS.forEach((p, i) => writeFileSync(join(SAIDA, `${p.id}.${EXT}`), pagina(p, i, n)));
console.log(`${PAGINAS.length} páginas .${EXT} em ${SAIDA} · tokens: ${n.papeis.map(([k, v]) => `${k.split(' ')[0]}=${v}`).join(' ')} contrato=${n.contrato} · ${n.linhas} linhas de script · ${n.fixos} tokens fixos`);
