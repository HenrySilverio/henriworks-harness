#!/usr/bin/env node
// Bia Credit Hive - format probe hook.
// Records which hook events run, through which command variant, where, and whether PLUGIN_ROOT is set.
// Never blocks a tool and never prints a decision: it always exits 0 with no output.
// Privacy: logs payload key names, tool names and subagent names only, never prompt or argument content.
//
//   node <plugin>/scripts/probe-hook.mjs <event> --via <command|bash|powershell|agent-scoped>

import { appendFileSync, mkdirSync, writeFileSync, existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { homedir } from 'node:os';

const argv = process.argv.slice(2);
const event = argv[0] || '?';
const iVia = argv.indexOf('--via');
const via = iVia >= 0 ? argv[iVia + 1] : '?';

let payload = {};
try {
  if (!process.stdin.isTTY) payload = JSON.parse(readFileSync(0, 'utf8') || '{}');
} catch { /* no payload or not JSON */ }

const root = process.env.PLUGIN_ROOT || process.env.CLAUDE_PLUGIN_ROOT || '';
const shortName = (v) => (typeof v === 'string' && /^[\w:.\-]{1,80}$/.test(v) ? v : null);

try {
  // Outside any repository: lets /bchive-init find the plugin when the agent cannot locate the skill folder.
  if (root) {
    const home = join(homedir(), '.bchive-probe');
    mkdirSync(home, { recursive: true });
    writeFileSync(join(home, 'plugin-root.txt'), `${root}\n`);
  }

  // Inside a repository: only where /bchive-init created .bchive-probe/. Everywhere else the hook is inert.
  const cwd = typeof payload.cwd === 'string' ? payload.cwd : process.cwd();
  const dir = join(cwd, '.bchive-probe');
  if (existsSync(dir)) {
    const args = payload.toolArgs || payload.tool_input || {};
    const agentArgs = typeof args === 'object' && args ? args : {};
    appendFileSync(join(dir, 'hooks.jsonl'), `${JSON.stringify({
      t: new Date().toISOString(),
      event,
      via,
      pluginRootEnv: Boolean(root),
      processCwdIsRepo: process.cwd() === cwd,
      platform: process.platform,
      shell: process.env.SHELL ? 'sh' : process.env.PSModulePath ? 'powershell?' : process.env.ComSpec ? 'cmd?' : null,
      payloadKeys: Object.keys(payload).sort(),
      tool: shortName(payload.toolName || payload.tool_name),
      agentType: shortName(agentArgs.agent_type || agentArgs.agentType || agentArgs.subagent_type || payload.agentName || payload.agent_name || payload.agent_type),
    })}\n`);
  }
} catch { /* a probe must never break the chat */ }

process.exit(0);
