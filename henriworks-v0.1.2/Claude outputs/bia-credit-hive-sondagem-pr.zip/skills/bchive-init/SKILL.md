---
name: bchive-init
description: "Prepares the current repository for Bia Credit Hive: copies the core CLI into .bchive/bin/, records the plugin version and keeps its folders out of Git. Use when the developer runs /bchive-init or says the plugin was just installed."
---

# bchive-init

Run this in the `bchive` agent, from the repository root. Reply to the developer in Brazilian Portuguese.
Do not edit any other file.

## Step 1 - Find the init script

The script is `scripts/init.mjs` inside the folder that contains this SKILL.md.

1. If you know the absolute path of this SKILL.md, the script is
   `<that folder>/scripts/init.mjs`. Use method `skill-dir`.
2. Otherwise, run this in the terminal and use `<printed path>/skills/bchive-init/scripts/init.mjs`.
   Use method `home-file`:
   ```
   node -e "console.log(require('fs').readFileSync(require('os').homedir()+'/.bchive-probe/plugin-root.txt','utf8').trim())"
   ```
   If that file does not exist, tell the developer that the plugin hooks did not run yet: open a new chat
   with the `bchive` agent, send any message, and run `/bchive-init` again. Stop.

## Step 2 - Run it

```
node "<script path>" --metodo <skill-dir|home-file>
```

Show the output to the developer exactly as printed. If it fails, show the error and stop: do not fix
anything by hand.

## Step 3 - Next step

Tell the developer, in Portuguese: open a new chat, select the `bchive` agent, and run `/bchive-probe`.
A new chat is required so the `sessionStart` hook is recorded.
