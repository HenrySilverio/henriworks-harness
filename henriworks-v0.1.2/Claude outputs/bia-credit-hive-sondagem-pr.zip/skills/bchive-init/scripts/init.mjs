#!/usr/bin/env node
// Bia Credit Hive - repository bootstrap (probe version).
// Copies the core CLI from the plugin into <repo>/.bchive/bin/, records the plugin version, creates
// .bchive-probe/ and keeps both folders out of Git through .git/info/exclude (never .gitignore).
//
//   node <plugin>/skills/bchive-init/scripts/init.mjs --metodo <skill-dir|home-file>

import { spawnSync } from 'node:child_process';
import { copyFileSync, existsSync, mkdirSync, readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const sair = (codigo, msg) => { (codigo ? console.error : console.log)(msg); process.exit(codigo); };

const [maior] = process.versions.node.split('.').map(Number);
if (maior < 20) sair(2, `Node ${process.versions.node} encontrado; o Bia Credit Hive precisa de 20 ou mais.`);

const argv = process.argv.slice(2);
const iMet = argv.indexOf('--metodo');
const metodo = iMet >= 0 ? argv[iMet + 1] : 'desconhecido';

const AQUI = dirname(fileURLToPath(import.meta.url));
const PLUGIN = resolve(AQUI, '..', '..', '..');
const manifesto = JSON.parse(readFileSync(join(PLUGIN, 'plugin.json'), 'utf8'));

const git = (args) => spawnSync('git', args, { encoding: 'utf8' });
const top = git(['rev-parse', '--show-toplevel']);
if (top.status !== 0) sair(2, 'esta pasta não é um repositório Git: abra a raiz do repositório no VS Code e rode /bchive-init de novo.');
const RAIZ = resolve(top.stdout.trim());

// 1. Núcleo no repositório: os agentes chamam node .bchive/bin/bchive.mjs, um caminho que não depende do plugin.
const origemBin = join(AQUI, '..', 'assets', 'bin');
const destinoBin = join(RAIZ, '.bchive', 'bin');
mkdirSync(destinoBin, { recursive: true });
for (const n of readdirSync(origemBin)) copyFileSync(join(origemBin, n), join(destinoBin, n));

// 2. Versão: o hook e o init comparam com o plugin instalado para saber se o núcleo está atrasado.
writeFileSync(join(RAIZ, '.bchive', 'versao.json'), `${JSON.stringify({ plugin: manifesto.name, versao: manifesto.version, instaladoEm: new Date().toISOString() }, null, 2)}\n`);

// 3. Pasta da sondagem: liga o registro do hook neste repositório.
const sonda = join(RAIZ, '.bchive-probe');
mkdirSync(sonda, { recursive: true });
writeFileSync(join(sonda, 'init.json'), `${JSON.stringify({
  metodo,
  pluginEncontrado: existsSync(join(PLUGIN, 'plugin.json')),
  pluginRootNoTerminal: Boolean(process.env.PLUGIN_ROOT || process.env.CLAUDE_PLUGIN_ROOT),
  plataforma: process.platform,
  node: process.versions.node,
  em: new Date().toISOString(),
}, null, 2)}\n`);

// 4. Fora do Git sem tocar no .gitignore, que é versionado.
const rel = git(['rev-parse', '--git-path', 'info/exclude']);
let exclude = 'não atualizado (sem caminho do Git)';
if (rel.status === 0) {
  const abs = resolve(RAIZ, rel.stdout.trim());
  const atual = existsSync(abs) ? readFileSync(abs, 'utf8').replace(/\r\n/g, '\n') : '';
  const bloco = '# >>> bchive\n/.bchive/\n/.bchive-probe/\n# <<< bchive\n';
  if (atual.includes('# >>> bchive')) exclude = 'já tinha o bloco';
  else {
    mkdirSync(dirname(abs), { recursive: true });
    writeFileSync(abs, `${atual.replace(/\s*$/, '')}${atual.trim() ? '\n\n' : ''}${bloco}`);
    exclude = 'bloco incluído';
  }
}

console.log([
  `Bia Credit Hive ${manifesto.version} preparado em ${RAIZ}`,
  `  núcleo: .bchive/bin/ (${readdirSync(destinoBin).join(', ')})`,
  `  sondagem: .bchive-probe/ (método para achar o plugin: ${metodo})`,
  `  .git/info/exclude: ${exclude}`,
  'Próximo: chat novo, agente bchive, /bchive-probe.',
].join('\n'));
