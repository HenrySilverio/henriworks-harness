---
name: bchive-probe
description: "Checks how the Bia Credit Hive plugin format behaves in this VS Code: command names, plugin hooks, subagent invocation and reviewer isolation. Use when the developer runs /bchive-probe after /bchive-init."
---

# bchive-probe

Run this in the `bchive` agent, in a new chat, after `/bchive-init`. Reply to the developer in Brazilian
Portuguese. Follow the steps in order and do not add checks of your own: the script decides each result.

If `.bchive/bin/bchive.mjs` does not exist, tell the developer to run `/bchive-init` first and stop. If you
do not have a tool to call a subagent, say so and stop: that is a probe result in itself.

## Step 1 - How this command reached you

Write down the exact text the developer used to invoke this skill, as it appears in their message (for
example `/bchive-probe` or `/bia-credit-hive:bchive-probe`). Call it COMMAND.

## Step 2 - A token only this conversation knows

Run:

```
node -e "console.log(require('crypto').randomBytes(3).toString('hex').toUpperCase())"
```

Tell the developer: `Token desta conversa: <TOKEN>`. Never put the token in any prompt or file.

## Step 3 - Call the reviewer as a subagent

Call the subagent `bchive-gf` with exactly this prompt and nothing else:

```
BCHIVE-PROBE. Answer in the format your instructions define.
```

If the call fails with an unknown agent error, try again with `bia-credit-hive:bchive-gf`. Call the name
that worked AGENT. If neither works, set AGENT to `none` and continue.

Save the reviewer's reply, unedited, to `.bchive-probe/gf-resposta.md` (empty file if there was no reply).

## Step 4 - Report

Run:

```
node .bchive/bin/bchive.mjs relatorio --token <TOKEN> --agente <AGENT> --comando "<COMMAND>"
```

Show the table exactly as printed, then tell the developer, in Portuguese, to send the file
`.bchive-probe/relatorio.md` to whoever maintains the plugin. It contains no prompt or conversation content.
