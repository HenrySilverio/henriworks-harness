# bia-credit-hive

Bia Credit Hive: orquestrador completo de agentes para Spec-Driven Development no Copilot do VS Code, organizado como uma colmeia — a rainha conduz a mudança e cada operária tem um papel (discovery, plano em fatias, implementação em paralelo, revisão por um subagente que não viu a conversa e arquivamento) — do ticket do Jira até a PR, com portões humanos e o conhecimento de cada entrega guardado como base viva de specs e decisões no repositório. Comandos /bchive-*. Use em front-end, BFF ou backend da Bia Credit para planejar, implementar, revisar ou fechar uma mudança.

## Como usar

> **Versão de sondagem.** Esta versão não traz o fluxo do Bia Credit Hive ainda. Ela confere, no seu VS Code,
> como o formato de plugin se comporta: nome dos comandos no chat, hooks do plugin, chamada do revisor como
> subagente e isolamento dele. O resultado decide como o harness completo será empacotado.

Precisa de Node 20 ou mais no PATH e do repositório aberto pela raiz no VS Code.

1. Instale o plugin pelo `bradesco-marketplace-unstable` (veja [Teste antes da release](CONTRIBUTING.md#teste-antes-da-release)).
2. Num chat novo, selecione o agente **bchive** e peça:
   ```
   /bchive-init
   ```
   Ele copia o núcleo para `.bchive/bin/`, cria `.bchive-probe/` e coloca as duas pastas no
   `.git/info/exclude`. Nada vai para o Git e nenhum arquivo do produto muda.
3. Abra **outro** chat novo, agente **bchive**, e peça:
   ```
   /bchive-probe
   ```
   Ele chama o revisor `bchive-gf` como subagente e imprime uma tabela com OK, FALHOU ou INFO por item.
4. Mande o arquivo `.bchive-probe/relatorio.md` para quem mantém o plugin. Ele não tem conteúdo de
   prompt nem de conversa.

Depois da sondagem, apague `.bchive/` e `.bchive-probe/` do repositório e `~/.bchive-probe/` da sua pasta de
usuário. Os hooks desta versão só registram algo nos repositórios que têm `.bchive-probe/`.

## Instalação

[![Instalar o plugin no GitHub Copilot app][badge-install-app]][install-app] [![Instalar o plugin no VS Code][badge-install-vscode]][install-vscode]

Antes da primeira release, o plugin só está no `bradesco-marketplace-unstable`: veja como testá-lo em [Teste antes da release](CONTRIBUTING.md#teste-antes-da-release).

<details>
<summary>Copilot CLI e Claude Code</summary>

No Copilot CLI:

```sh
copilot plugin install bia-credit-hive@bradesco-marketplace
```

O Claude Code não recebe o `bradesco-marketplace` da empresa, então adicione-o antes:

```text
/plugin marketplace add Bradesco-Automation/bradesco-marketplace
/plugin install bia-credit-hive@bradesco-marketplace
```

</details>

## Feedback

Se o plugin não funcionar ou faltar algo nele, conte ao [Reusable AI Creator](https://github.com/Bradesco-Automation/reusable-ai/tree/main/tech/reusable-ai) em uma conversa: ele leva o seu feedback aos responsáveis pelo plugin.

## Como contribuir

Está criando ou alterando este plugin? Veja o [CONTRIBUTING.md](CONTRIBUTING.md).

[badge-install-app]: https://img.shields.io/badge/GitHub_Copilot_app-Instalar_o_plugin-8250DF?style=flat-square&logo=githubcopilot&logoColor=white&labelColor=24292F
[badge-install-vscode]: https://img.shields.io/badge/VS_Code-Instalar_o_plugin-0098FF?style=flat-square&logo=githubcopilot&logoColor=white&labelColor=24292F
[install-app]: https://github.com/copilot/app/launch?open=ghapp%3A%2F%2Fplugins%2Finstall%3Fsource%3Dbia-credit-hive%2540bradesco-marketplace
[install-vscode]: https://vscode.dev/redirect?url=vscode%3A%2F%2Fchat-plugin%2Finstall%3Fsource%3DBradesco-Automation%252Fbradesco-marketplace%2526plugin%253Dbia-credit-hive
