---
name: bcatlas-implement
description: "Atalho de /bcatlas-implement. A fase roda no agente bcatlas-implement."
argument-hint: "<change-id> [N fatias | paralelo]"
disable-model-invocation: true
---
# /bcatlas-implement

Esta fase roda no agente `bcatlas-implement`, que define as ferramentas e os passos dela.

Se as instruções deste chat começam com `# Agente bcatlas-implement`, siga-as com o texto que veio depois do comando e ignore o resto deste arquivo.

Caso contrário, não leia nem execute nada. Responda em uma linha: selecione o agente `bcatlas-implement` no seletor
de agentes, num chat novo, e reenvie o mesmo pedido. Rodar a fase fora do agente pula o contrato e libera ferramentas
que ela não deveria ter.
