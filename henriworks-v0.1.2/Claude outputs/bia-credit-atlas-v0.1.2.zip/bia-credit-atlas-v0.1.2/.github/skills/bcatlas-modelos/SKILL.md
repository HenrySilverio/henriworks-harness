---
name: bcatlas-modelos
description: "Modelos que a política do Copilot libera, cruzados com o uso registrado e a tabela de preço."
argument-hint: "[atualizar [--de <fonte>] | conferir]"
disable-model-invocation: true
---
# /bcatlas-modelos

Utilitário: roda em qualquer agente com terminal.

- Sem argumento: rode `node .bcatlas/bin/modelos.mjs` e mostre a saída inteira.
- `atualizar`: rode `node .bcatlas/bin/modelos.mjs atualizar` com o resto do argumento, sem alterar. Sem
  fonte configurada, ele carrega a lista de referência que vem no pacote.
- `conferir`: rode `node .bcatlas/bin/modelos.mjs conferir`. Código 1 é alerta grave: mostre e pare.

Não interprete além da saída. Política, uso e preço vêm de script; não sugira trocar de modelo por conta própria.
