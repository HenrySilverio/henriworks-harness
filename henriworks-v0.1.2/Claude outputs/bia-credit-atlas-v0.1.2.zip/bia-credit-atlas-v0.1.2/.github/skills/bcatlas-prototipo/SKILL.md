---
name: bcatlas-prototipo
description: "Atalho de /bcatlas-prototipo. A fase roda no agente bcatlas-prototipo."
argument-hint: "<a pergunta de design>"
disable-model-invocation: true
---
# /bcatlas-prototipo

Esta fase roda no agente `bcatlas-prototipo`, que define as ferramentas e os passos dela.

Se as instruções deste chat começam com `# Agente bcatlas-prototipo`, siga-as com o texto que veio depois do comando e ignore o resto deste arquivo.

Caso contrário, não leia nem execute nada. Responda em uma linha: selecione o agente `bcatlas-prototipo` no seletor
de agentes, num chat novo, e reenvie o mesmo pedido. Rodar a fase fora do agente pula o contrato e libera ferramentas
que ela não deveria ter.
