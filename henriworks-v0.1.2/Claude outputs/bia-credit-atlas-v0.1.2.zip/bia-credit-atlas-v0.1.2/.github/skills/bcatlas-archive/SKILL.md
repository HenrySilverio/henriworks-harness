---
name: bcatlas-archive
description: "Atalho de /bcatlas-archive. A fase roda no agente bcatlas-archive."
argument-hint: "<change-id>"
disable-model-invocation: true
---
# /bcatlas-archive

Esta fase roda no agente `bcatlas-archive`, que define as ferramentas e os passos dela.

Se as instruções deste chat começam com `# Agente bcatlas-archive`, siga-as com o texto que veio depois do comando e ignore o resto deste arquivo.

Caso contrário, não leia nem execute nada. Responda em uma linha: selecione o agente `bcatlas-archive` no seletor
de agentes, num chat novo, e reenvie o mesmo pedido. Rodar a fase fora do agente pula o contrato e libera ferramentas
que ela não deveria ter.
