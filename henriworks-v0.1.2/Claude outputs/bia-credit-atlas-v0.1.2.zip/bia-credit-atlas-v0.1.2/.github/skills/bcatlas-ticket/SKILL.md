---
name: bcatlas-ticket
description: "Mostra ou fixa o ticket do Jira usado para ligar uso e custo à task."
argument-hint: "[CHAVE-123 | --limpar]"
disable-model-invocation: true
---
# /bcatlas-ticket

Utilitário: roda em qualquer agente com terminal.

Rode `node .bcatlas/bin/bcatlas.mjs ticket` com o argumento recebido, sem alterar, e mostre a saída. Sem argumento, ele só mostra o
ticket atual e de onde ele veio: fixado, proposta ou nome da branch.
