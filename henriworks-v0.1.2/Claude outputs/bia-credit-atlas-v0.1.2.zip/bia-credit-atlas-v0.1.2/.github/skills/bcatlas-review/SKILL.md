---
name: bcatlas-review
description: "Atalho de /bcatlas-review. A fase roda no agente bcatlas-review."
argument-hint: "<spec | (nada) | estrito> <change-id>"
disable-model-invocation: true
---
# /bcatlas-review

Esta fase roda no agente `bcatlas-review`, que define as ferramentas e os passos dela.

Se as instruções deste chat começam com `# Agente bcatlas-review`, siga-as com o texto que veio depois do comando e ignore o resto deste arquivo.

Caso contrário, não leia nem execute nada. Responda em uma linha: selecione o agente `bcatlas-review` no seletor
de agentes, num chat novo, e reenvie o mesmo pedido. Rodar a fase fora do agente pula o contrato e libera ferramentas
que ela não deveria ter.
