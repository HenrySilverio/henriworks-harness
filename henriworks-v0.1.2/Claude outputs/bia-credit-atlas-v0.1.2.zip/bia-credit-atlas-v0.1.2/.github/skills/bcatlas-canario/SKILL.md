---
name: bcatlas-canario
description: "Prova que o revisor sem contexto é isolado nesta máquina e que os hooks rodam. Roda no agente bcatlas."
argument-hint: "[conferir | aplicar]"
disable-model-invocation: true
---
# /bcatlas-canario

Prova, nesta máquina, que o peixinho (`bcatlas-gf`) não recebe a conversa do pai, e que os hooks rodam. O
`/bcatlas-init` já faz isto; use este comando para repetir só o canário. O resultado vale para a versão do
VS Code em que passou: quando ela muda, o `/bcatlas-init` marca o canário como PENDENTE.

Roda no agente `bcatlas`. Se as instruções deste chat não começam com a linha `# Agente bcatlas`, não leia nem execute nada: responda em uma linha que é para selecionar o agente `bcatlas` num chat novo e enviar `/bcatlas-canario` de novo. O agente define as ferramentas que estes passos precisam.

- `conferir`: rode `node .bcatlas/bin/bcatlas.mjs canario conferir` e mostre a saída.
- `aplicar`: rode `node .bcatlas/bin/bcatlas.mjs canario aplicar` e mostre a saída. Só faz efeito se o canário passou.
- Sem argumento: o teste inteiro, neste chat:

1. `node .bcatlas/bin/bcatlas.mjs canario preparar`. A palavra-código passa a estar na conversa deste chat: é a isca. Não a
   repita em nenhuma mensagem sua.
2. `node .bcatlas/bin/bcatlas.mjs pacote-revisao canario`.
3. Delegue ao subagente `bcatlas-gf` com o prompt literal impresso, sem nada antes nem depois.
4. Grave a resposta dele, sem edição, em `.bcatlas/estado/canario-resposta.md`.
5. `node .bcatlas/bin/bcatlas.mjs canario conferir` e mostre a saída inteira.
   - "isolamento confirmado" e chamada de subagente registrada: rode `node .bcatlas/bin/bcatlas.mjs canario aplicar`.
   - "NENHUM evento registrado": os hooks não rodaram nesta janela. Diga ao dev para rodar
     "Developer: Reload Window" e repetir o comando.
   - "INCONCLUSIVO": o peixinho recusou ou explicou em vez de responder as linhas pedidas. Não diga que o
     isolamento foi confirmado. Mostre a saída e sugira repetir num chat novo; se a recusa se repetir,
     trocar o modelo do chat.
   - "isolamento FALHOU": mostre e encerre o canário. A revisão padrão não é confiável nesta máquina até investigar;
     o caminho é o modo estrito (`estrito` no `bcatlas-review`).

Sem ferramenta de subagente nesta sessão: diga isso e encerre o canário. Não simule a resposta do peixinho.
