#!/usr/bin/env node
// b.IA Credit Hive - núcleo determinístico. Arquivo único de entrada, sem dependência, Node 20+.
// Lê Git, nunca escreve Git. Rode da raiz do repositório:
//
//   node .bchive/bin/bchive.mjs <comando> [args]
//
// Comandos:
//   estado [--json]                       fase de cada mudança aberta, derivada dos artefatos
//   validar [change-id]                   portões mecânicos (formato, grafo, Toca, deltas, decisões)
//   fatias <id> [--gravar] [--json]       grafo, frontier e quais fatias podem rodar juntas
//   reivindicar <id> <NN...>              marca as fatias da sessão (base da trava e do conferir-toca)
//   conferir-toca <id> [--liberar]        arquivos alterados contra o Toca; abre cartão de decisão
//   ponto-de-partida <base>               Início sugerido e trabalho que já existe na branch
//   arvore                                alteração não commitada (ignora personalização local não rastreada)
//   hash <caminho...>                     git hash-object, sem gravar nada
//   pacote-revisao <id> <alvo>            prompt literal do peixinho; teto de 2 reprovações seguidas
//   rodada-extra <id> <alvo> --por <nome> portão humano: libera uma rodada além do teto
//   gravar-veredito <id> <alvo> --de <rascunho>   grava veredito sem nunca sobrescrever
//   aprovar-spec <id> --por <nome> [--apesar "<motivo>"]   portão humano da spec
//   arquivar <id> [--conferir]            precondições, Fim: e mudança movida para archive/
//   aceitar-revisao <id> --por <nome> --apesar "<motivo>"   portão humano: aceita eixo REPROVADO neste HEAD
//   qa-ok <pasta|id> --por <QA> --ambiente <amb> --resultado "<texto>"   portão humano: OK do QA
//   conhecimento <id> --pr <número>       registro em conhecimento/, só depois do qa-ok
//   ticket [CHAVE-123 | --limpar]         ticket da sessão: fixado, proposta ou branch
//   adotar [--aplicar]                    copia specs e decisões do .sdd/ do HenriSpec, uma vez
//   canario preparar|conferir|aplicar     prova do isolamento do peixinho e dos hooks
//   estrito <id> <alvo>                   revisor em processo separado do Copilot CLI (experimental)
//   uso ...                               uso e adoção, só tokens e contagens (ver uso.mjs)
//   auditar [--usuario]                   qualidade da personalização do Copilot do dev (ver auditar.mjs)
//   executores [registrar --de <arquivo> | conferir [nome]]   executores de fatia: registrados, descobertos, prontos?
//   init [--corrigir] [--json]            confere a preparação do repositório e corrige o que é seguro
//   briefing <caminho do briefing.md>     confere seções e insumos antes do plano
//   descartar <id> [--com-briefing] [--aplicar]   apaga a mudança e o estado dela; Git fica com o dev
//   configurar verificacao|padroes ...    propõe verificacao.json e padroes.md (ver configurar.mjs)
//   pos-instalacao                        roda no fim do /<plugin>:init (mapa e hooks do Git)

import { spawnSync } from 'node:child_process';
import { createHash, randomBytes } from 'node:crypto';
import { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync, renameSync, copyFileSync, rmSync, statSync, mkdtempSync } from 'node:fs';
import { join, dirname, basename, relative, resolve } from 'node:path';
import { homedir, tmpdir } from 'node:os';
import { fileURLToPath } from 'node:url';
import {
  HW, CHANGES, ARCHIVE, ESTADO, sair, barra, ler, lerJson, gravarJson, anexarJsonl, git, branchAtual, headCurto, mergeBase,
  hashArquivo, naoCommitados, config, mudancasAbertas, dirMudanca, metadados, lerFatias, frontier, paralelizaveis,
  tocaParaTeste, vereditoVigente, ultimoVeredito, aprovado, EIXOS_CODIGO, ESTAGIOS_SPEC, ticketDaSessao, linhasDe, globParaRegex,
  promptDoPacote, tocasSobrepoem, versaoVsCode, historicoVereditos, reprovacoesSeguidas, REGUA_REVISAO, textoDoDev, lerFatia,
  nomePlugin, versaoInstalada, USO_DIR, OTEL_AGENT_HOST, INSTRUCOES, rastreado,
} from './lib/comum.mjs';

// Lê a resposta do canário. A prova é a linha 1: a palavra-código só existe na conversa do pai (saída do
// terminal dele), então "none" mostra que essa conversa não chegou ao revisor. A linha 2 lista as
// ferramentas do revisor: no harness Local o frontmatter "tools" não é respeitado e o revisor ganha
// terminal, sessão e skills (visto em 19/11/2026); isso também reprova. Só conta resposta no formato.
const FERRAMENTA_PROIBIDA = /edit|write|create|apply|patch|delete|terminal|shell|bash|powershell|execute|run_|session|sql|task|skill|todo|fetch|browser/i;
function avaliarCanario(resp, token) {
  const r = (n) => ((resp || '').match(new RegExp(`^\\s*${n}[.)]\\s*(.+)$`, 'm')) || [])[1]?.trim() || '';
  const [a1, a2] = [r(1), r(2)];
  const ferramentas = a2.split(/[,;]/).map((x) => x.trim()).filter(Boolean);
  const proibidas = ferramentas.filter((f) => FERRAMENTA_PROIBIDA.test(f));
  if (resp && token && resp.includes(token)) return { resultado: 'falhou', isolado: false, ferramentas, proibidas, motivo: 'conversa' };
  if (!/^(none|nenhuma)\b/i.test(a1) || !ferramentas.length) return { resultado: 'inconclusivo', isolado: null, ferramentas, proibidas };
  if (proibidas.length) return { resultado: 'falhou', isolado: false, ferramentas, proibidas, motivo: 'ferramentas' };
  return { resultado: 'isolado', isolado: true, ferramentas, proibidas };
}

// Confere o corpo de um veredito no formato que o pacote pede. O script não corrige a resposta do
// revisor: recusa, e o agente delega o mesmo pacote de novo. Motivo real: um revisor escreveu a etiqueta
// em outro idioma ("[重要?] ... should [bloqueante]") e o veredito foi gravado assim.
const SEVERIDADES = ['bloqueante', 'importante', 'sugestão', 'sugestao'];
function errosDoVeredito(conteudo) {
  const erros = [];
  const linhas = conteudo.split(/\r?\n/);
  const decisao = (linhas[0].match(/ - (APROVADO|REPROVADO)\s*$/) || [])[1];
  const iA = linhas.findIndex((l) => /^Achados:/.test(l.trim()));
  if (iA < 0) return ['falta a linha "Achados: <número>".'];
  const n = (linhas[iA].trim().match(/^Achados:\s*(\d+)\s*$/) || [])[1];
  if (n === undefined) erros.push(`"${linhas[iA].trim()}" não é "Achados: <número>".`);
  const itens = [];
  let antes = false;
  for (const [k, bruta] of linhas.slice(iA + 1).entries()) {
    const l = bruta.trim();
    if (!l) continue;
    // Item = linha que começa por [etiqueta], com ou sem marcador de lista ("- ", "1. ").
    const m = l.match(/^(?:[-*•]|\d+[.)])?\s*\[([^\]]*)\]/);
    if (m) {
      const tag = m[1].trim().toLowerCase();
      if (!SEVERIDADES.includes(tag)) erros.push(`linha ${iA + 2 + k}: etiqueta "[${m[1]}]" não é [bloqueante], [importante] nem [sugestão].`);
      itens.push(tag);
    } else if (!itens.length) antes = true;
  }
  if (antes) erros.push('há texto entre "Achados:" e o primeiro achado: cada achado começa por [bloqueante], [importante] ou [sugestão].');
  if (n !== undefined && Number(n) !== itens.length) erros.push(`"Achados: ${n}", mas há ${itens.length} achado(s).`);
  const bloq = itens.filter((t) => t === 'bloqueante').length;
  if (decisao === 'REPROVADO' && !bloq) erros.push('REPROVADO sem nenhum [bloqueante].');
  if (decisao === 'APROVADO' && bloq) erros.push(`APROVADO com ${bloq} [bloqueante].`);
  return erros;
}

// Limpeza de pasta temporária nunca derruba o comando: no Windows a pasta pode estar presa por um
// watcher (EBUSY/EPERM). Tenta algumas vezes e, se não der, deixa para a próxima execução.
function apagarSemFalhar(p) {
  try { rmSync(p, { recursive: true, force: true, maxRetries: 5, retryDelay: 200 }); } catch { /* fica para depois */ }
}
import { validarMudanca, validarBriefing, imprimir } from './lib/validar.mjs';
import { PERSONAS } from './lib/personas.mjs';
import { inventario, conferirExecutor, nomeChamavel } from './lib/personalizacao.mjs';

const BIN = dirname(fileURLToPath(import.meta.url));
const RAIZ = process.cwd();
const sha = (t) => createHash('sha256').update(t).digest('hex');

function exigirRaiz() {
  if (!existsSync(join(RAIZ, HW))) sair(2, `${HW}/ não existe aqui. Rode da raiz do repositório onde o b.IA Credit Hive foi instalado.`);
}

function opcoes(argv) {
  const pos = [];
  const op = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const [k, v] = a.slice(2).split('=');
      if (v !== undefined) op[k] = v;
      else if (argv[i + 1] && !argv[i + 1].startsWith('--')) op[k] = argv[++i];
      else op[k] = true;
    } else pos.push(a);
  }
  return { pos, op };
}

// Hash da spec: proposta, design, deltas e fatias, com checkbox e evidência normalizados.
// Marcar tarefa não muda o acordo; mudar texto, sim.
// Registro de execução numa fatia: o checkbox e o bloco de evidência inteiro (a linha "Evidência:" e as
// linhas de continuação recuadas abaixo dela) saem do hash, como se nunca tivessem sido escritos.
// Caso real: a evidência de uma tarefa manual mudou o hash, o estado pediu revisão da spec no meio da
// implementação e o revisor julgou a evidência como se fosse spec.
// modo 'compat': aprovação gravada antes desta versão. A normalização antiga deixava uma linha vazia no
// lugar de cada evidência; na aprovação só existia a do "Trabalho já existente" (Evidência: commit), então
// essa vira linha vazia e as outras saem.
function semExecucao(texto, modo = 'novo') {
  const out = [];
  let recuo = -1;
  for (const l of texto.replace(/\r\n/g, '\n').split('\n')) {
    // Recuada ou não: agente costuma escrever "Evidência:" na coluna 0, logo abaixo da tarefa.
    const ev = l.match(/^(\s*)Evid[êe]ncia\s*:\s*(.*)$/i);
    if (ev) {
      recuo = Math.max(ev[1].length, 1);
      if (modo === 'compat' && /^commit\b/i.test(ev[2])) out.push('');
      continue;
    }
    if (recuo >= 0 && l.trim() && l.match(/^\s*/)[0].length >= recuo && !/^\s*-\s*\[[ xX]\]/.test(l)) continue;
    recuo = -1;
    out.push(l.replace(/\[[xX]\]/g, '[ ]'));
  }
  return out.join('\n');
}

function hashSpec(dir, { modo = 'novo' } = {}) {
  const partes = [];
  for (const n of ['proposta.md', 'design.md', 'deltas.md']) {
    const t = ler(join(dir, n));
    if (t !== null) partes.push(`${n}\n${t.replace(/^(\s*)(Fim|In[ií]cio)\s*:.*$/gim, '')}`);
  }
  for (const f of lerFatias(dir)) {
    // legado: a normalização até 11/2026, exata, para aprovação gravada antes desta versão.
    partes.push(`${f.nome}\n${modo === 'legado' ? f.texto.replace(/\[x\]/g, '[ ]').replace(/^\s+Evid[êe]ncia\s*:.*$/gim, '') : semExecucao(f.texto, modo)}`);
  }
  return sha(partes.join('\n\0\n').replace(/\r\n/g, '\n')).slice(0, 7);
}

// Comando do chat para a próxima fase: /<plugin>:<fase>.
const C = (fase) => `/${nomePlugin(RAIZ)}:${fase}`;

const estagiosDoRigor = (rigor) => (/full/i.test(rigor || '') ? ESTAGIOS_SPEC : ['design', 'prontidao']);

// ------------------------------------------------------------------ estado

function faseDe(id) {
  const dir = join(RAIZ, CHANGES, id);
  const m = metadados(dir);
  const fatias = lerFatias(dir);
  if (!existsSync(join(dir, 'proposta.md')) || !fatias.length) return { id, fase: 'plan', proximo: C('plan'), detalhe: 'proposta ou fatias ausentes' };
  const aprov = ler(join(dir, 'revisao-spec', 'APROVACAO.md'));
  const hAtual = hashSpec(dir);
  const hAprov = aprov && (aprov.match(/^Spec:\s*([0-9a-f]{7})/m) || [])[1];
  if (!aprov || (hAprov !== hAtual && hAprov !== hashSpec(dir, { modo: 'compat' }) && hAprov !== hashSpec(dir, { modo: 'legado' }))) {
    const pasta = join(dir, 'revisao-spec');
    // Convergência: estágio que aprovou numa versão anterior não roda de novo; só o que reprovou ou nunca
    // rodou. O aprovar-spec mostra quais aprovações são de versão anterior.
    const faltam = estagiosDoRigor(m.rigor).filter((e) => !vereditoVigente(pasta, e, hAtual) && !historicoVereditos(pasta, e)[0]?.aprovado);
    const teto = Number(config(RAIZ).revisaoIsolada.tetoRodadas) || 2;
    const travados = faltam.filter((e) => reprovacoesSeguidas(historicoVereditos(pasta, e)) >= teto);
    return {
      id, fase: 'revisao-spec', proximo: travados.length ? 'humano: bchive aprovar-spec --apesar, ou partir a mudança' : faltam.length ? `${C('review')} spec ${id}` : 'humano: bchive aprovar-spec',
      detalhe: `${aprov ? 'spec alterada depois da aprovação; ' : ''}estágios a revisar nesta versão (${hAtual}): ${faltam.join(', ') || 'nenhum'}${travados.length ? `; teto de rodadas atingido em ${travados.join(', ')}` : ''}`,
    };
  }
  const pendentes = fatias.filter((f) => !f.feita);
  if (pendentes.length) {
    const prontas = frontier(fatias);
    return { id, fase: 'implement', proximo: `${C('implement')} ${id}`, detalhe: `frontier: ${prontas.map((f) => f.num).join(', ') || 'nenhuma (bloqueio)'}; pendentes ${pendentes.length}/${fatias.length}` };
  }
  const head = headCurto(RAIZ);
  const pasta = join(dir, 'revisao');
  const vs = EIXOS_CODIGO.map((e) => ({ e, v: vereditoVigente(pasta, e, head) }));
  const reprov = vs.filter((x) => x.v && !aprovado(x.v.arquivo)).map((x) => x.e);
  if (reprov.length) return { id, fase: 'replan', proximo: `${C('plan')} replanejar: ${id}`, detalhe: `REPROVADO em ${reprov.join(', ')} no HEAD ${head}` };
  const faltam = vs.filter((x) => !x.v).map((x) => x.e);
  if (faltam.length) return { id, fase: 'revisao', proximo: `${C('review')} ${id}`, detalhe: `eixos sem veredito no HEAD ${head}: ${faltam.join(', ')}` };
  return { id, fase: 'archive', proximo: `${C('archive')} ${id}`, detalhe: `três eixos APROVADO no HEAD ${head}` };
}

function cmdEstado({ op }) {
  exigirRaiz();
  const branch = branchAtual(RAIZ);
  const linhas = mudancasAbertas(RAIZ).map((id) => ({ ...faseDe(id), branch: metadados(join(RAIZ, CHANGES, id)).branch }));
  // Mudança arquivada sem registro de conhecimento.
  const reg = lerJson(join(RAIZ, ESTADO, 'conhecimento.json'), {});
  const semConhecimento = existsSync(join(RAIZ, ARCHIVE))
    ? readdirSync(join(RAIZ, ARCHIVE)).filter((d) => !reg[d]).filter((d) => metadados(join(RAIZ, ARCHIVE, d)).branch === branch)
    : [];
  // HenriSpec na mesma branch: uma branch, um harness.
  const sdd = join(RAIZ, '.sdd', 'changes');
  const henrispec = existsSync(sdd)
    ? readdirSync(sdd).filter((n) => n !== 'archive' && existsSync(join(sdd, n, 'proposta.md'))).filter((n) => metadados(join(sdd, n)).branch === branch)
    : [];
  const t = ticketDaSessao(RAIZ);
  if (op.json) return console.log(JSON.stringify({ branch, ticket: t, mudancas: linhas, fechar: semConhecimento, henrispec }, null, 2));
  console.log(`branch: ${branch} | ticket: ${t.ticket || 'nenhum'} (${t.origem})`);
  if (henrispec.length) console.log(`HENRISPEC esta branch tem mudança aberta no HenriSpec (${henrispec.join(', ')}): continue com os agentes henrispec-*. Uma branch, um harness.`);
  if (!linhas.length) console.log('nenhuma mudança aberta em .bchive/changes/');
  for (const l of linhas) console.log(`- ${l.id} [${l.branch === branch ? 'esta branch' : `branch ${l.branch}`}] fase ${l.fase} → ${l.proximo}\n    ${l.detalhe}`);
  for (const d of semConhecimento) console.log(`- ${d} arquivada sem registro de conhecimento → ${C('fechar')} ${d} <PR>, depois do OK do QA (bchive qa-ok)`);
}

// ---------------------------------------------------------------- validar

function cmdValidar({ pos }) {
  exigirRaiz();
  const alvo = pos[0] ? [pos[0]] : mudancasAbertas(RAIZ);
  if (!alvo.length) sair(0, 'Nenhuma mudança aberta. Nada a validar.');
  let erros = 0;
  for (const id of alvo) erros += imprimir(id, validarMudanca(dirMudanca(id, RAIZ), RAIZ));
  console.log(`\n${alvo.length} mudança(s), ${erros} erro(s).`);
  process.exit(erros ? 1 : 0);
}

// --------------------------------------------------------------- briefing

function cmdBriefing({ pos }) {
  exigirRaiz();
  if (!pos[0]) sair(2, 'uso: bchive briefing <caminho do briefing.md>');
  const arq = resolve(RAIZ, pos[0]);
  const erros = imprimir(barra(relative(RAIZ, arq)), validarBriefing(arq, RAIZ));
  if (erros) console.log('\nO plano não começa com erro no briefing. Insumo pendente: o dev fornece; o /bia-credit-hive:triagem com este briefing completa as seções.');
  process.exit(erros ? 1 : 0);
}

// -------------------------------------------------------------- descartar

// Apaga uma mudança aberta e tudo que o estado guarda dela. Mudança arquivada é imutável e não entra.
// Não toca no Git: lista os commits e o dev decide (revert, reset ou manter). Sem --aplicar, só mostra.
function cmdDescartar({ pos, op }) {
  exigirRaiz();
  const id = pos[0];
  if (id && existsSync(join(RAIZ, ARCHIVE)) && readdirSync(join(RAIZ, ARCHIVE)).some((d) => d.endsWith(`-${id}`))) sair(2, `${id} já foi arquivada: archive é imutável e não se descarta.`);
  const dir = dirMudanca(id, RAIZ);
  const m = metadados(dir);
  const relDir = barra(relative(RAIZ, dir));
  const copia = (ler(join(dir, 'briefing.md')) || '').trim();
  const pBrief = join(RAIZ, HW, 'briefings');
  const briefings = copia && existsSync(pBrief)
    ? readdirSync(pBrief).filter((d) => (ler(join(pBrief, d, 'briefing.md')) || '').trim() === copia).map((d) => `${HW}/briefings/${d}`)
    : [];
  const pPac = join(RAIZ, ESTADO, 'pacotes.jsonl');
  const pEd = join(RAIZ, ESTADO, 'edicoes.jsonl');
  const pAg = join(RAIZ, ESTADO, 'agentes.json');
  const pCon = join(RAIZ, ESTADO, 'conhecimento.json');
  const jsonl = (p) => linhasDe(ler(p) || '').filter(Boolean);
  const daMudanca = (l) => { try { return JSON.parse(l).change === id; } catch { return false; } };
  const nPac = jsonl(pPac).filter(daMudanca).length;
  const nEd = jsonl(pEd).filter(daMudanca).length;
  const reiv = lerJson(REIV, { ativas: [] });
  const nReiv = reiv.ativas.filter((r) => r.change === id).length;
  const ag = lerJson(pAg, {});
  const nAg = Object.values(ag).filter((v) => v?.change === id).length;
  // Commits: do Início da proposta até HEAD, sem merges, mais os que citam o change-id na mensagem.
  const log = (args) => (git(['log', '--oneline', ...args], { cwd: RAIZ, permitirFalha: true }) || '').split('\n').filter(Boolean);
  const commits = [...new Set([...(m.inicio ? log(['--no-merges', `${m.inicio}..HEAD`]) : []), ...log(['--no-merges', `--grep=${id}`])])];

  console.log(`Descartar ${id}${op.aplicar ? '' : ' (prévia: nada é apagado sem --aplicar)'}\n`);
  console.log(`- pasta da mudança: ${relDir}`);
  console.log(`- estado: ${nPac} pacote(s) de revisão, ${nEd} edição(ões) registradas, ${nReiv} reivindicação(ões), ${nAg} subagente(s) com fatia`);
  console.log(`- briefing de origem: ${briefings.length ? briefings.join(', ') : 'não identificado (a cópia não bate com nenhum)'}${op['com-briefing'] ? ' (será apagado)' : ' (fica; --com-briefing apaga)'}`);
  console.log('- uso em ~/.bchive/uso: fica (é histórico, não estado da mudança)');
  console.log(`\nGit (o b.IA Credit Hive não mexe; decida você):${commits.length ? '' : ' nenhum commit encontrado desde o Início nem com o change-id na mensagem.'}`);
  for (const c of commits) console.log(`  ${c}`);
  if (commits.length) {
    console.log('  Manter o código: não faça nada; o plano novo parte dele ("Trabalho já existente na branch").');
    console.log(`  Desfazer com histórico (seguro, branch já publicada): git revert --no-edit ${commits.map((c) => c.split(' ')[0]).join(' ')}`);
    console.log(`  Apagar da branch (só se nunca deu push): git reset --hard ${m.inicio || '<commit anterior ao primeiro>'}`);
  }
  if (!op.aplicar) return console.log(`\nPara apagar: node .bchive/bin/bchive.mjs descartar ${id}${op['com-briefing'] ? ' --com-briefing' : ''} --aplicar`);

  rmSync(dir, { recursive: true, force: true });
  const filtrar = (p) => { if (existsSync(p)) writeFileSync(p, jsonl(p).filter((l) => !daMudanca(l)).map((l) => `${l}\n`).join('')); };
  filtrar(pPac);
  filtrar(pEd);
  if (nReiv) gravarJson(REIV, { ...reiv, ativas: reiv.ativas.filter((r) => r.change !== id) });
  if (nAg) gravarJson(pAg, Object.fromEntries(Object.entries(ag).filter(([, v]) => v?.change !== id)));
  if (existsSync(pCon)) { const c = lerJson(pCon, {}); if (Object.keys(c).some((k) => k.includes(id))) gravarJson(pCon, Object.fromEntries(Object.entries(c).filter(([k]) => !k.includes(id)))); }
  if (op['com-briefing']) for (const b of briefings) rmSync(join(RAIZ, b), { recursive: true, force: true });
  console.log(`\nApagado: ${relDir}${op['com-briefing'] && briefings.length ? ` e ${briefings.join(', ')}` : ''}, mais o estado da mudança.`);
}

// ----------------------------------------------------------------- fatias

function indiceMd(id, fatias) {
  const linhas = [
    `# Fatias: ${id}`,
    '',
    'Gerado por `node .bchive/bin/bchive.mjs fatias <id> --gravar`. Não edite: a fonte é cada arquivo de fatia.',
    '',
    '| # | Fatia | Bloqueado por | Toca | Executor | Estado |',
    '| --- | --- | --- | --- | --- | --- |',
  ];
  for (const f of fatias) {
    const estado = f.feita ? 'feita' : f.iniciada ? 'em andamento' : 'pendente';
    linhas.push(`| ${f.num} | [${f.titulo}](${f.nome}) | ${f.bloqueadoTxt || '?'} | ${f.verificacao ? `Escopo: ${f.escopo || '?'}` : f.toca.join(', ')} | ${f.executor} | ${estado} |`);
  }
  return `${linhas.join('\n')}\n`;
}

function cmdFatias({ pos, op }) {
  exigirRaiz();
  const id = pos[0];
  const dir = dirMudanca(id, RAIZ);
  const fatias = lerFatias(dir);
  if (!fatias.length) sair(2, `${id} não tem fatias em tarefas/.`);
  const prontas = frontier(fatias);
  const juntas = paralelizaveis(prontas);
  const ex = executoresConhecidos();
  const conhecido = (e) => ex.registrados[e] || ex.descobertos[e] || ex.registrados[e.replace(/^[\w.-]+:/, '')];
  const desconhecidos = [...new Set(fatias.map((f) => f.executor))].filter((e) => !conhecido(e));
  if (op.gravar) writeFileSync(join(dir, 'tarefas', 'index.md'), indiceMd(id, fatias));
  if (op.json) return console.log(JSON.stringify({ fatias: fatias.map(({ texto, ...f }) => f), frontier: prontas.map((f) => f.num), juntas: juntas.map((f) => f.num), desconhecidos }, null, 2));
  console.log(indiceMd(id, fatias).split('\n').slice(4).join('\n').trim());
  console.log(`\nfrontier: ${prontas.map((f) => `${f.num} (${f.executor})`).join(', ') || 'nenhuma'}`);
  console.log(`padrão: a próxima sessão executa ${prontas[0] ? prontas[0].num : '-'} e para para o commit.`);
  if (juntas.length > 1) console.log(`podem rodar juntas, se o dev pedir: ${juntas.map((f) => f.num).join(', ')} (sem aresta e Toca disjunto)`);
  else if (prontas.length > 1) console.log('as fatias prontas têm Toca sobreposto: rodam em sequência.');
  if (desconhecidos.length) console.log(`AVISO executor que não está em ${HW}/executores.json nem entre os descobertos nesta máquina: ${desconhecidos.join(', ')} (bchive executores)`);
  const sobre = ler(join(dir, 'tarefas', 'sobreposicoes.md'));
  const abertos = sobre ? (sobre.match(/^Decisão:\s*pendente/gim) || []).length : 0;
  if (abertos) console.log(`cartões de sobreposição em aberto: ${abertos} (tarefas/sobreposicoes.md)`);
  if (op.gravar) console.log(`\ngravado: ${barra(relative(RAIZ, join(dir, 'tarefas', 'index.md')))}`);
}

// ---------------------------------------------------- reivindicar e conferir

const REIV = join(RAIZ, ESTADO, 'reivindicacoes.json');

function cmdReivindicar({ pos }) {
  exigirRaiz();
  const [id, ...nums] = pos;
  const dir = dirMudanca(id, RAIZ);
  const fatias = lerFatias(dir);
  if (!nums.length) sair(2, 'informe ao menos uma fatia: bchive reivindicar <id> 02 [03]');
  const prontas = new Set(frontier(fatias).map((f) => f.num));
  const reg = lerJson(REIV, { ativas: [] });
  for (const n of nums.map((x) => x.padStart(2, '0'))) {
    const f = fatias.find((x) => x.num === n);
    if (!f) sair(2, `fatia ${n} não existe em ${id}.`);
    if (!prontas.has(n)) sair(2, `fatia ${n} não está na frontier: ${f.feita ? 'já feita' : `bloqueada por ${f.bloqueadoTxt}`}.`);
    const outra = reg.ativas.find((r) => r.change === id && r.fatia !== n && !f.verificacao && tocasSobrepoem(r.toca, f.toca));
    if (outra) sair(2, `fatia ${n} tem Toca sobreposto à fatia ${outra.fatia}, em andamento. Rode em sequência.`);
    reg.ativas = reg.ativas.filter((r) => !(r.change === id && r.fatia === n));
    reg.ativas.push({ change: id, fatia: n, toca: f.toca, desde: new Date().toISOString(), head: headCurto(RAIZ) });
  }
  gravarJson(REIV, reg);
  console.log(`reivindicadas em ${id}: ${nums.join(', ')}. Ao fechar a sessão: bchive conferir-toca ${id} --liberar`);
}

function cmdConferirToca({ pos, op }) {
  exigirRaiz();
  const id = pos[0];
  const dir = dirMudanca(id, RAIZ);
  const fatias = lerFatias(dir);
  const reg = lerJson(REIV, { ativas: [] });
  const ativas = reg.ativas.filter((r) => r.change === id);
  const alterados = naoCommitados(RAIZ);
  // Registro de edição por subagente, quando o hook de trava está ligado: diz quem editou o quê.
  const edicoes = linhasDe(ler(join(RAIZ, ESTADO, 'edicoes.jsonl')) || '').filter(Boolean).map((l) => JSON.parse(l)).filter((e) => e.change === id);
  const porArquivo = new Map();
  for (const e of edicoes) {
    if (!porArquivo.has(e.arquivo)) porArquivo.set(e.arquivo, new Set());
    porArquivo.get(e.arquivo).add(e.fatia);
  }
  const alvo = ativas.length ? ativas.map((r) => fatias.find((f) => f.num === r.fatia)).filter(Boolean) : fatias.filter((f) => f.iniciada && !f.feita);
  const cartoes = [];
  for (const arq of alterados) {
    const donos = alvo.filter((f) => f.toca.some((t) => tocaParaTeste(t)(arq)));
    const editores = porArquivo.get(arq);
    if (editores && editores.size > 1) cartoes.push({ arq, tipo: 'editado por mais de uma fatia', fatias: [...editores] });
    else if (donos.length > 1) cartoes.push({ arq, tipo: 'cabe no Toca de mais de uma fatia da sessão', fatias: donos.map((f) => f.num) });
    else if (donos.length === 0 && alvo.length) cartoes.push({ arq, tipo: 'fora do Toca das fatias da sessão', fatias: alvo.map((f) => f.num) });
  }
  if (cartoes.length) {
    const p = join(dir, 'tarefas', 'sobreposicoes.md');
    const atual = ler(p) || `# Sobreposições: ${id}\n\nCartões de decisão. Nenhum bloqueia a entrega: os abertos vão para o resumo.md, em "Pontos para o revisor humano".\n`;
    const carimbo = new Date().toISOString().slice(0, 16).replace('T', ' ');
    const novos = cartoes.map((c, i) => [
      `\n## ${carimbo} · ${c.arq}`,
      `Situação: ${c.tipo}`,
      `Fatias: ${c.fatias.join(', ')}`,
      `Diff: git diff -- ${c.arq}`,
      'Saídas: (a) commitar junto, citando as fatias na mensagem; (b) separar com git add -p; (c) replanejar com ' + C('plan'),
      'Decisão: pendente',
    ].join('\n'));
    writeFileSync(p, `${atual.replace(/\s*$/, '')}\n${novos.join('\n')}\n`);
  }
  console.log(`arquivos alterados e não commitados: ${alterados.length} | fatias da sessão: ${alvo.map((f) => f.num).join(', ') || 'nenhuma'}`);
  if (!cartoes.length) console.log('Toca conferido: nenhum arquivo fora do declarado, nenhum arquivo dividido entre fatias.');
  for (const c of cartoes) console.log(`CARTÃO ${c.arq}: ${c.tipo} (fatias ${c.fatias.join(', ')})`);
  if (cartoes.length) console.log(`→ ${barra(relative(RAIZ, join(dir, 'tarefas', 'sobreposicoes.md')))}. Decida antes do commit; troque "Decisão: pendente" pela escolha.`);
  if (op.liberar) {
    reg.ativas = reg.ativas.filter((r) => r.change !== id);
    gravarJson(REIV, reg);
    console.log('reivindicações liberadas.');
  }
}

// ---------------------------------------------------------- ponto de partida

function cmdPontoDePartida({ pos }) {
  exigirRaiz();
  const base = pos[0] || sair(2, 'informe a branch base: bchive ponto-de-partida main');
  const branch = branchAtual(RAIZ);
  const head = git(['rev-parse', 'HEAD']).trim();
  let inicio = mergeBase(base, RAIZ);
  let origem = `ponto em que ${branch} saiu de ${base}`;
  let melhor = null;
  for (const raizArq of [join(RAIZ, ARCHIVE), join(RAIZ, '.sdd', 'changes', 'archive')]) {
    if (!existsSync(raizArq)) continue;
    for (const d of readdirSync(raizArq)) {
      const m = metadados(join(raizArq, d));
      if (m.branch !== branch || !m.fim) continue;
      if (spawnSync('git', ['merge-base', '--is-ancestor', m.fim, 'HEAD'], { cwd: RAIZ }).status !== 0) continue;
      const dist = Number(git(['rev-list', '--count', `${m.fim}..HEAD`]).trim());
      if (!melhor || dist < melhor.dist) melhor = { fim: m.fim, dist, d };
    }
  }
  if (melhor) {
    inicio = git(['rev-parse', melhor.fim]).trim();
    origem = `Fim da mudança arquivada ${melhor.d}`;
  }
  const fora = ['--', '.', `:(exclude)${HW}`, ':(exclude).sdd'];
  const log = git(['log', '--oneline', '-n', '30', `${inicio}..HEAD`, ...fora]).trim();
  const stat = log ? git(['diff', '--stat', `${inicio}..HEAD`, ...fora]).trim().split('\n').slice(-12).join('\n') : '';
  const sujo = naoCommitados(RAIZ, ['.sdd/']);
  console.log(`branch: ${branch}, HEAD ${head.slice(0, 7)}`);
  console.log(`Início sugerido: ${inicio.slice(0, 7)} (${origem})`);
  console.log(log ? `commits desde o Início:\n${log}\narquivos:\n${stat}` : 'nenhum commit desde o Início: declare Início igual ao HEAD.');
  console.log(sujo.length ? `NÃO COMMITADO: ${sujo.slice(0, 10).join(', ')}. Pare e peça para commitar ou guardar com git stash.` : 'árvore: limpa');
}

// Árvore de trabalho da mudança: o que não foi commitado, sem contar .bchive/ nem a personalização
// local do Copilot não rastreada (AGENTS.md, .github/instructions/ etc., que podem ser só do dev).
function cmdArvore() {
  const sujo = naoCommitados(RAIZ);
  if (!sujo.length) return console.log('árvore: limpa');
  sair(1, `NÃO COMMITADO: ${sujo.slice(0, 15).join(', ')}${sujo.length > 15 ? ` e mais ${sujo.length - 15}` : ''}`);
}

function cmdHash({ pos }) {
  for (const c of pos) console.log(`- ${c} ${existsSync(join(RAIZ, c)) ? hashArquivo(c, RAIZ) || 'ERRO' : 'AUSENTE'}`);
}

// --------------------------------------------------------------- revisão

const PACOTES_REG = join(RAIZ, ESTADO, 'pacotes.jsonl');
// Um só revisor sem contexto. A lente (persona) de cada estágio ou eixo vai dentro do pacote.
// O revisor é chamado pelo nome completo "<plugin>:bchive-gf" (o VS Code põe o nome do plugin na frente).
const REVISOR = `${nomePlugin(RAIZ)}:bchive-gf`;
const demover = (t) => t.replace(/^(#+) /gm, '##$1 ');


function instructionsQueCasam(arquivos) {
  const dir = join(RAIZ, '.github', 'instructions');
  if (!existsSync(dir)) return [];
  const out = [];
  for (const n of readdirSync(dir, { recursive: true }).map(String).filter((x) => x.endsWith('.instructions.md'))) {
    const t = ler(join(dir, n)) || '';
    const apply = (t.match(/^applyTo\s*:\s*["']?(.+?)["']?\s*$/m) || [])[1];
    if (!apply) continue;
    const globs = apply.split(',').map((g) => g.trim()).filter(Boolean);
    if (globs.includes('**') || globs.some((g) => arquivos.some((a) => globParaRegex(g).test(a)))) out.push(barra(join('.github', 'instructions', n)));
  }
  return out;
}

function arquivosLocaisDasTarefas(dir) {
  const citados = new Set();
  for (const f of lerFatias(dir)) {
    for (const it of f.itens.filter((i) => i.feito)) for (const m of it.texto.matchAll(/`([^`\s]+\.[a-z0-9]+)`/gi)) citados.add(barra(m[1]));
  }
  return [...citados].filter((p) => existsSync(join(RAIZ, p)) && git(['ls-files', '--error-unmatch', p], { cwd: RAIZ, permitirFalha: true }) === null);
}

// Referência dos eixos: o /<plugin>:init copia para dentro do workspace, porque a pasta do plugin fica
// fora dele e o revisor isolado não lê fora do workspace sem pedir permissão.
function refEixos() {
  const rel = `${HW}/referencias/eixos-de-revisao.md`;
  return existsSync(join(RAIZ, rel)) ? rel : null;
}

// Caminhos citados entre crases nos "## Ponteiros" das fatias e na tabela de insumos do briefing copiado.
// Resolve pela raiz do repositório, pela pasta da mudança e pela pasta do briefing de origem. Vereditos e
// pacotes ficam de fora: cada revisor julga sem ver o veredito dos outros.
function consultasDaSpec(dir) {
  const achados = new Set();
  const textos = [];
  for (const f of lerFatias(dir)) {
    const t = readFileSync(f.arquivo, 'utf8');
    const i = t.search(/^##\s+Ponteiros/m);
    if (i >= 0) textos.push(t.slice(i).split(/^##\s+(?!Ponteiros)/m)[0]);
  }
  const brief = ler(join(dir, 'briefing.md')) || '';
  const ins = brief.split(/^##\s+Insumos\s*$/m)[1];
  if (ins) textos.push(ins.split(/^##\s+/m)[0]);
  const origem = (() => {
    const pB = join(RAIZ, HW, 'briefings');
    if (!brief.trim() || !existsSync(pB)) return null;
    const d = readdirSync(pB).find((n) => (ler(join(pB, n, 'briefing.md')) || '').trim() === brief.trim());
    return d ? join(pB, d) : null;
  })();
  for (const t of textos) {
    for (const m of t.matchAll(/`([^`\s]+\.[a-z0-9]{1,6})`/gi)) {
      const c = m[1].replace(/^\.\//, '');
      if (/^(revisao|revisao-spec|pacotes|rascunhos)\//.test(c) || /^https?:/.test(c)) continue;
      const alvo = [join(RAIZ, c), join(dir, c), origem && join(origem, c)].filter(Boolean).find((p) => existsSync(p) && statSync(p).isFile());
      if (alvo) achados.add(barra(relative(RAIZ, alvo)));
      if (achados.size >= 20) break;
    }
  }
  return [...achados];
}

function cmdPacoteRevisao({ pos, op }) {
  const cfgPac = config(RAIZ);
  exigirRaiz();
  let [id, alvo] = pos;
  if (id === 'canario' && !alvo) alvo = 'canario';
  const dir = alvo === 'canario' ? join(RAIZ, ESTADO) : dirMudanca(id, RAIZ);
  if (!PERSONAS[alvo]) sair(2, `alvo "${alvo}" inválido. Spec: ${ESTAGIOS_SPEC.join(', ')}. Código: ${EIXOS_CODIGO.join(', ')}.`);
  const m = alvo === 'canario' ? {} : metadados(dir);
  const rel = (p) => barra(relative(RAIZ, p));
  const pasta = join(dir, 'pacotes');
  mkdirSync(pasta, { recursive: true });
  const leitura = [];
  const add = (p, porque) => existsSync(join(RAIZ, p)) && leitura.push(`- \`${p}\`: ${porque}`);
  let pedido;
  let chave;
  let locais = [];
  if (alvo === 'canario') {
    const can = lerJson(join(RAIZ, ESTADO, 'canario.json'));
    if (!can) sair(2, 'rode antes: bchive canario preparar');
    chave = 'canario';
    pedido = [
      'This is an isolation test requested by the developer. Do not review anything.',
      'It proves that the conversation of whoever called you does not reach you. No question asks you to reveal or copy instructions: only "none", a code word that is not secret, or tool names.',
      '1. Does any text you received contain a code word that starts with "bchive-canario-"? If so, write it in full. If not, write "none".',
      '2. List the names of every tool you can call, comma-separated.',
      'Format: exactly two lines, "1. " and "2. " followed by the answer, and nothing else.',
    ].join('\n');
  } else if (ESTAGIOS_SPEC.includes(alvo)) {
    chave = hashSpec(dir);
    for (const n of ['proposta.md', 'design.md', 'deltas.md']) add(rel(join(dir, n)), 'document under review');
    for (const f of lerFatias(dir)) add(rel(f.arquivo), 'slice');
    add(`${HW}/glossario.md`, 'domain vocabulary');
    add(`${HW}/padroes.md`, 'auditable repository standards');
    add(`${HW}/decisoes/index.md`, 'decisions in force (open only the ones the document cites)');
    add(`${HW}/specs/index.md`, 'documented capabilities (absent means not documented)');
    // Ponteiros das fatias e insumos do briefing: o executor lê, então o revisor lê antes de reprovar por
    // falta de informação. Arquivo, não conversa: o isolamento continua.
    for (const c of consultasDaSpec(dir)) leitura.push(`- \`${c}\`: reference (pointer or input): read it only to settle a doubt before raising a finding`);
    if (alvo === 'zoom-out-2') {
      const v = vereditoVigente(join(dir, 'revisao-spec'), 'zoom-out', chave) || null;
      if (v) leitura.push(`- \`${rel(v.arquivo)}\`: report of the first zoom-out, to check what changed`);
    }
    pedido = `Stage "${alvo}" of the spec review of change ${id} (rigor ${m.rigor || '?'}), under your lens.`;
  } else {
    const head = headCurto(RAIZ);
    chave = head;
    const sujo = naoCommitados(RAIZ);
    if (sujo.length) sair(2, `há alteração não commitada (${sujo.slice(0, 4).join(', ')}): revisão julga commit. Commite ou guarde antes.`);
    const de = m.inicio || mergeBase(m.base || 'main', RAIZ);
    // AGENTS.md e instructions rastreados entram no diff: são arquivo do projeto, e mudar regra do time é mudança.
    const fora = ['--', '.', `:(exclude)${HW}`, ':(exclude).sdd'];
    const diff = git(['diff', '--no-color', `${de}..HEAD`, ...fora], { cwd: RAIZ });
    const arquivos = linhasDe(git(['diff', '--name-only', `${de}..HEAD`, ...fora], { cwd: RAIZ })).filter(Boolean);
    locais = arquivosLocaisDasTarefas(dir).map((p) => ({ p, h: hashArquivo(p, RAIZ) }));
    if (!diff.trim() && !locais.length) sair(2, `diff vazio entre ${de.slice(0, 7)} e HEAD, e nenhum arquivo local citado nas tarefas. Revisão sem diff é opinião.`);
    const pDiff = join(pasta, `diff-${head}.patch`);
    writeFileSync(pDiff, diff);
    leitura.push(`- \`${rel(pDiff)}\`: diff from ${de.slice(0, 7)} to ${head} (${arquivos.length} file(s))`);
    for (const l of locais) leitura.push(`- \`${l.p}\`: local file, outside Git, changed by this change (judge it whole)`);
    const verif = join(dir, 'revisao', `verificacao-${head}.txt`);
    if (existsSync(verif)) leitura.push(`- \`${rel(verif)}\`: scoped verifier output (BLOQUEANTE vs PRÉ-EXISTENTE)`);
    else if (alvo !== 'plantao') sair(2, `rode antes: node ${HW}/bin/verificar.mjs ${id} --salvar`);
    if (alvo === 'spec') {
      add(rel(join(dir, 'proposta.md')), 'the agreement');
      for (const f of lerFatias(dir)) add(rel(f.arquivo), 'slice');
      add(rel(join(dir, 'deltas.md')), 'spec deltas');
      add(rel(join(dir, 'design.md')), 'design and decisions');
      add(rel(join(dir, 'tarefas', 'sobreposicoes.md')), 'overlap decision cards');
    }
    if (alvo === 'padroes') {
      add(`${HW}/padroes.md`, 'declared source of this axis');
      // Fontes que podem não existir. Regra do time: declarada em instrucoes.doTime, ou AGENTS.md versionado
      // (.github/ nunca é versionado no banco). O resto pode ser preferência do dev e nunca bloqueia sozinho.
      const doTime = cfgPac.instrucoes.doTime.map((g) => globParaRegex(g));
      const origem = (p) => (doTime.some((re) => re.test(p)) || (!p.startsWith('.github/') && rastreado(p, RAIZ)) ? 'team rule' : 'not declared as a team rule: may be the developer\'s own preference, never blocking alone');
      for (const p of ['AGENTS.md', '.github/copilot-instructions.md']) add(p, `project instructions (${origem(p)})`);
      for (const p of instructionsQueCasam(arquivos)) leitura.push(`- \`${p}\`: instruction whose applyTo matches the diff (${origem(p)})`);
    }
    if (alvo === 'plantao') {
      const r = spawnSync(process.execPath, [join(BIN, 'bchivemap.mjs'), 'affected', ...arquivos.slice(0, 60), '--budget', '6000'], { cwd: RAIZ, encoding: 'utf8' });
      const pAff = join(pasta, `affected-${head}.txt`);
      writeFileSync(pAff, r.stdout || '(mapa indisponível)\n');
      leitura.push(`- \`${rel(pAff)}\`: impact radius from the map: callers and dependents of the changed files`);
      add('README.md', 'expected load and runtime context, if declared');
    }
    pedido = `Axis "${alvo}" of the code review of change ${id}, at commit ${head}, under your lens.`;
  }
  // Rodada: o veredito anterior do mesmo estágio ou eixo entra no pacote, e o teto corta a terceira
  // reprovação seguida. Depois disso a decisão é humana (aprovar-spec / aceitar-revisao com --apesar).
  if (alvo !== 'canario') {
    const pastaV = join(dir, ESTAGIOS_SPEC.includes(alvo) ? 'revisao-spec' : 'revisao');
    const hist = historicoVereditos(pastaV, alvo);
    const teto = Number(config(RAIZ).revisaoIsolada.tetoRodadas) || 2;
    const seguidas = reprovacoesSeguidas(hist);
    const liberacao = join(pastaV, `RODADA-EXTRA-${alvo}`);
    if (seguidas >= teto) {
      if (!existsSync(liberacao)) sair(2, `teto de rodadas: ${alvo} reprovou ${seguidas} vez(es) seguidas (${hist.slice(0, seguidas).map((v) => v.nome).join(', ')}). Não gero outra rodada. Decisão do dev, no terminal dele: ${ESTAGIOS_SPEC.includes(alvo) ? `bchive aprovar-spec ${id} --por "<nome>" --apesar "<motivo>"` : `bchive aceitar-revisao ${id} --por "<nome>" --apesar "<motivo>"`}; partir a mudança; ou liberar uma rodada a mais: bchive rodada-extra ${id} ${alvo} --por "<nome>".`);
      rmSync(liberacao); // a liberação vale uma rodada
    }
    const anterior = hist.find((v) => v.chave !== chave);
    if (anterior) leitura.push(`- \`${rel(anterior.arquivo)}\`: verdict of the previous round (${anterior.aprovado ? 'APROVADO' : 'REPROVADO'}). First check whether its blocking findings were resolved; a new finding is blocking only if it meets the rubric and appeared in this round`);
  }
  if (alvo !== 'canario') {
    const ref = refEixos();
    if (ref) leitura.unshift(`- \`${ref}\`: severity rules, the rules of your ${ESTAGIOS_SPEC.includes(alvo) ? 'stage' : 'axis'} and of the verdict (only the matching section)`);
  }
  const nome = `${alvo}-${chave}.md`;
  const caminho = join(pasta, nome);
  const corpo = [
    `# Review package · ${alvo}`,
    '',
    `Generated by script at ${new Date().toISOString()}. Reviewer: ${REVISOR}. Lens: ${alvo}.`,
    '',
    ...(PERSONAS[alvo].texto ? ['## Your lens in this review', '', demover(PERSONAS[alvo].texto), ''] : []),
    '## Request',
    '',
    pedido,
    '',
    alvo === 'canario' ? '' : '## Read this, and only this',
    alvo === 'canario' ? '' : '',
    ...(alvo === 'canario' ? [] : leitura),
    '',
    alvo === 'canario' ? '' : '## Rules',
    ...(alvo === 'canario' ? [] : [
      '',
      '- You do not have the conversation that produced these files, on purpose. Do not ask for it and do not assume it.',
      '- Edit nothing. Do not read files outside the list, except code cited by line in the diff or in the impact radius.',
      '- Every finding cites evidence: file and line, or section.',
      '- Blocking only under the rubric in the "Severity and verdict" section of the axes reference. Never blocking: what the proposal lists under "Fora do escopo", what belongs to another layer, the internal rendering of a third-party component (a manual task proves it), a problem that existed before the diff, and the form of a manual task\'s evidence.',
      '- The evidence of a (manual) task is the developer\'s statement: the "Evidência:" line with what, where, who and when is enough. Never require a screenshot, video, per-scenario result or PR link, even if the task text asks for one: this rule wins over the slice text.',
      ...(ESTAGIOS_SPEC.includes(alvo) ? ['- Checked boxes and "Evidência:" lines in the slices are an execution record, not spec: out of this review.'] : []),
      '- Write the findings in Brazilian Portuguese; keep the format tokens below exactly as written.',
      '',
      '## Answer format',
      '',
      `# ${ESTAGIOS_SPEC.includes(alvo) ? `spec-${alvo}` : alvo} - APROVADO | REPROVADO`,
      `${ESTAGIOS_SPEC.includes(alvo) ? 'Spec revisada' : 'Commit revisado'}: ${chave}`,
      'Achados: <número>',
      '',
      'One finding per item: `[bloqueante|importante|sugestão] <file>:<line or section> — what is wrong — the concrete case — the smallest fix`.',
      'REPROVADO if there is at least one bloqueante. With no findings, write "Achados: 0" and nothing else.',
    ]),
  ].join('\n').replace(/\n{3,}/g, '\n\n');
  writeFileSync(caminho, `${corpo}\n`);
  const p = rel(caminho);
  anexarJsonl(PACOTES_REG, { t: new Date().toISOString(), change: id, alvo, chave, arquivo: p, hash: sha(readFileSync(caminho, 'utf8')), prompt: sha(promptDoPacote(p)), locais });
  console.log(`pacote: ${p}`);
  console.log(`subagente: ${REVISOR}`);
  console.log(`prompt literal (copie exatamente, sem acrescentar nada):\n${promptDoPacote(p)}`);
}

function cmdGravarVeredito({ pos, op }) {
  exigirRaiz();
  const [id, alvo] = pos;
  const dir = dirMudanca(id, RAIZ);
  const ehSpec = ESTAGIOS_SPEC.includes(alvo);
  if (!ehSpec && !EIXOS_CODIGO.includes(alvo)) sair(2, `alvo "${alvo}" inválido.`);
  if (!op.de) sair(2, `informe o rascunho: --de ${HW}/changes/${id}/rascunhos/${alvo}.md`);
  const rasc = resolve(RAIZ, op.de);
  if (!existsSync(rasc)) sair(2, `${op.de} não existe.`);
  const conteudo = readFileSync(rasc, 'utf8').trim();
  const rotulo = ehSpec ? `spec-${alvo}` : alvo;
  const cab = conteudo.split('\n')[0].trim();
  if (!new RegExp(`^# ${rotulo} - (APROVADO|REPROVADO)$`).test(cab)) sair(2, `a primeira linha precisa ser "# ${rotulo} - APROVADO" ou "# ${rotulo} - REPROVADO".`);
  const chave = ehSpec ? hashSpec(dir) : headCurto(RAIZ);
  const campo = ehSpec ? 'Spec revisada' : 'Commit revisado';
  const declarado = (conteudo.match(new RegExp(`^${campo}:\\s*(\\S+)`, 'm')) || [])[1];
  if (declarado !== chave) sair(2, `"${campo}:" precisa ser ${chave} (${ehSpec ? 'hash atual da spec' : 'HEAD atual'}). A spec ou o código mudou depois do pacote: gere o pacote de novo.`);
  const errosFormato = errosDoVeredito(conteudo);
  if (errosFormato.length) {
    sair(2, `resposta do revisor fora do formato, nada gravado:\n- ${errosFormato.join('\n- ')}\nNão edite a resposta: gere o pacote de novo e delegue a um subagente novo (o rascunho fica em ${op.de} para você ver).`);
  }
  if (!ehSpec) {
    const sujo = naoCommitados(RAIZ);
    if (sujo.length) sair(2, `árvore com alteração não commitada (${sujo.slice(0, 3).join(', ')}): o veredito não valeria para nenhum commit.`);
  }
  const pasta = join(dir, ehSpec ? 'revisao-spec' : 'revisao');
  mkdirSync(pasta, { recursive: true });
  const atual = vereditoVigente(pasta, alvo, chave);
  const nome = atual ? `${alvo}-${chave}-${atual.ordem + 1}.md` : `${alvo}-${chave}.md`;
  // Arquivos locais do pacote vão junto, com hash: o archive confere que não mudaram.
  const pac = linhasDe(ler(PACOTES_REG) || '').filter(Boolean).map((l) => JSON.parse(l)).filter((r) => r.change === id && r.alvo === alvo && r.chave === chave).pop();
  const locais = pac?.locais?.length ? `\nRevisão local: sim\nArquivos revisados:\n${pac.locais.map((l) => `- ${l.p} ${l.h}`).join('\n')}` : '';
  writeFileSync(join(pasta, nome), `${conteudo}${locais}\nRégua: ${REGUA_REVISAO}\n`, { flag: 'wx' });
  rmSync(rasc);
  console.log(`gravado: ${barra(relative(RAIZ, join(pasta, nome)))}${atual ? ` (vigente; substitui ${atual.nome})` : ''}`);
}

function cmdAprovarSpec({ pos, op }) {
  exigirRaiz();
  const id = pos[0];
  const dir = dirMudanca(id, RAIZ);
  { const e = textoDoDev(op.por, 'quem aprova (--por "Nome Sobrenome")'); if (e) sair(2, `${e} Este portão é humano.`); }
  if (op.apesar !== undefined) { const e = textoDoDev(op.apesar, 'o motivo (--apesar)', 15); if (e) sair(2, e); }
  const v = validarMudanca(dir, RAIZ).filter((a) => a.nivel === 'ERRO');
  if (v.length) sair(1, `o validador tem ${v.length} erro(s): bchive validar ${id}`);
  const m = metadados(dir);
  const h = hashSpec(dir);
  const pasta = join(dir, 'revisao-spec');
  const linhas = [];
  let reprovados = 0;
  let faltando = 0;
  for (const e of estagiosDoRigor(m.rigor)) {
    const atual = vereditoVigente(pasta, e, h);
    const qualquer = ultimoVeredito(pasta, e)?.nome || null;
    if (atual) {
      const ok = aprovado(atual.arquivo);
      if (!ok) reprovados++;
      linhas.push(`- ${e}: ${ok ? 'APROVADO' : 'REPROVADO'} nesta versão (${atual.nome})`);
    } else if (qualquer) {
      linhas.push(`- ${e}: revisado numa versão anterior da spec (${qualquer}); a spec mudou depois`);
      if (!aprovado(join(pasta, qualquer))) reprovados++;
    } else {
      faltando++;
      linhas.push(`- ${e}: sem revisão`);
    }
  }
  console.log(`spec ${id} (${m.rigor || '?'}, versão ${h}):\n${linhas.join('\n')}`);
  if (faltando && !op.apesar) sair(1, `\n${faltando} estágio(s) sem revisão. Rode ${C('review')} spec ${id}, ou aprove com --apesar "<motivo>".`);
  if (reprovados && !op.apesar) sair(1, `\n${reprovados} estágio(s) REPROVADO. Resolva com ${C('plan')} replanejar: ${id}, ou aprove com --apesar "<motivo>".`);
  mkdirSync(pasta, { recursive: true });
  writeFileSync(join(pasta, 'APROVACAO.md'), `# Spec aprovada\nSpec: ${h}\nPor: ${op.por}\nEm: ${new Date().toISOString()}\n${op.apesar ? `Apesar de: ${op.apesar}\n` : ''}\n${linhas.join('\n')}\n`);
  console.log(`\naprovada por ${op.por}. Próximo, num chat novo: ${C('implement')} ${id}`);
}

// ---------------------------------------------------------------- arquivar

function cmdArquivar({ pos, op }) {
  exigirRaiz();
  const id = pos[0];
  const dir = dirMudanca(id, RAIZ);
  const falha = (m) => sair(1, `NÃO ARQUIVADO: ${m}`);
  const head = headCurto(RAIZ);
  const aceitos = [];
  for (const eixo of EIXOS_CODIGO) {
    const v = vereditoVigente(join(dir, 'revisao'), eixo, head);
    if (!v && new RegExp(`^- ${eixo}: REPROVADO`, 'm').test(ler(join(dir, 'revisao', `ACEITE-${head}.md`)) || '')) { aceitos.push(eixo); continue; }
    if (!v) falha(`sem veredito de ${eixo} para o HEAD ${head}. Rode ${C('review')} ${id}.`);
    const texto = readFileSync(v.arquivo, 'utf8');
    if (!aprovado(v.arquivo)) {
      // Portão humano: o dev aceitou o REPROVADO deste eixo neste HEAD, com motivo (bchive aceitar-revisao).
      const aceite = ler(join(dir, 'revisao', `ACEITE-${head}.md`)) || '';
      if (!new RegExp(`^- ${eixo}: REPROVADO`, 'm').test(aceite)) falha(`o veredito vigente de ${eixo} (${v.nome}) não é APROVADO. Caminhos: ${C('plan')} replanejar: ${id}, ou o dev aceita com motivo: bchive aceitar-revisao ${id} --por "<nome>" --apesar "<motivo>".`);
      aceitos.push(eixo);
    }
    if (/^Revisão local:\s*sim/im.test(texto)) {
      for (const mm of texto.matchAll(/^-\s+(\S+)\s+([0-9a-f]{40})\s*$/gim)) {
        if ((existsSync(join(RAIZ, mm[1])) ? hashArquivo(mm[1], RAIZ) : null) !== mm[2]) falha(`${mm[1]} mudou depois da revisão de ${eixo}: revise de novo.`);
      }
    }
  }
  const pend = lerFatias(dir).flatMap((f) => f.itens.filter((i) => !i.feito).map((i) => `${f.num}:${i.numero}`));
  if (pend.length) falha(`tarefas pendentes: ${pend.slice(0, 6).join(', ')}.`);
  const fora = naoCommitados(RAIZ);
  if (fora.length) falha(`alteração não commitada: ${fora.slice(0, 5).join(', ')}.`);
  const sobre = ler(join(dir, 'tarefas', 'sobreposicoes.md')) || '';
  const abertos = (sobre.match(/^Decisão:\s*pendente/gim) || []).length;
  if (op.conferir) sair(0, `precondições ok para ${id}: ${aceitos.length ? `${3 - aceitos.length} eixo(s) APROVADO e ${aceitos.join(', ')} REPROVADO aceito(s) pelo dev (revisao/ACEITE-${head}.md, vai para "Pontos para o revisor humano")` : 'três eixos APROVADO'} em ${head}, tarefas concluídas, árvore limpa${abertos ? `, ${abertos} cartão(ões) de sobreposição em aberto (vão para o resumo.md)` : ''}.`);
  const resumo = ler(join(dir, 'resumo.md'));
  if (!resumo) falha('falta o resumo.md: ele é escrito antes de mover.');
  if (aceitos.length && !/Pontos para o revisor humano/i.test(resumo)) falha(`revisão aceita apesar de REPROVADO (${aceitos.join(', ')}) e o resumo.md não tem a seção "Pontos para o revisor humano" com o motivo e os achados.`);
  if (abertos && !/Pontos para o revisor humano/i.test(resumo)) falha(`${abertos} cartão(ões) de sobreposição em aberto e o resumo.md não tem a seção "Pontos para o revisor humano".`);
  if (/\.bchive\/|change-id|\bDEC-\d{3}\b|\bREQ-[\w-]+-\d{3}\b/.test(resumo)) falha('o resumo.md cita o fluxo (caminho, change-id, DEC- ou REQ-): quem lê a PR não tem como seguir essas referências.');
  const propPath = join(dir, 'proposta.md');
  const prop = readFileSync(propPath, 'utf8');
  const completo = git(['rev-parse', 'HEAD']).trim();
  writeFileSync(propPath, /^\s*Fim\s*:.*$/im.test(prop.split(/^##\s+/m)[0]) ? prop.replace(/^(\s*)Fim\s*:.*$/im, `$1Fim: ${completo}`) : prop.replace(/^(\s*Base\s*:.*)$/im, `$1\nFim: ${completo}`));
  const hoje = new Date().toISOString().slice(0, 10);
  const destino = join(RAIZ, ARCHIVE, `${hoje}-${id}`);
  if (existsSync(destino)) falha(`${barra(relative(RAIZ, destino))} já existe.`);
  mkdirSync(dirname(destino), { recursive: true });
  renameSync(dir, destino);
  console.log(`movido: ${barra(relative(RAIZ, destino))}/`);
  console.log(`descrição da PR: ${barra(relative(RAIZ, join(destino, 'resumo.md')))}`);
  console.log(`depois de abrir a PR e do OK de quem testou (o QA roda: node ${HW}/bin/bchive.mjs qa-ok ${hoje}-${id} --por ... --ambiente ... --resultado ...): ${C('fechar')} ${hoje}-${id} <número da PR>`);
}

// Portão humano: o dev libera uma rodada além do teto para um estágio ou eixo. Vale uma vez.
function cmdRodadaExtra({ pos, op }) {
  exigirRaiz();
  const [id, alvo] = pos;
  const dir = dirMudanca(id, RAIZ);
  if (![...ESTAGIOS_SPEC, ...EIXOS_CODIGO].includes(alvo)) sair(2, `alvo "${alvo}" inválido. Spec: ${ESTAGIOS_SPEC.join(', ')}. Código: ${EIXOS_CODIGO.join(', ')}.`);
  { const e = textoDoDev(op.por, 'quem libera (--por "Nome Sobrenome")'); if (e) sair(2, `${e} Este portão é humano.`); }
  const pasta = join(dir, ESTAGIOS_SPEC.includes(alvo) ? 'revisao-spec' : 'revisao');
  mkdirSync(pasta, { recursive: true });
  writeFileSync(join(pasta, `RODADA-EXTRA-${alvo}`), `Por: ${op.por}\nEm: ${new Date().toISOString()}\n`);
  console.log(`rodada extra liberada para ${alvo} em ${id}: vale para o próximo pacote-revisao. Peça a revisão no chat.`);
}

// Portão humano da revisão de código: o dev aceita um ou mais eixos REPROVADO neste HEAD, com motivo.
// O agente nunca roda (o hook nega). O arquivar passa e o resumo.md leva o motivo para a PR.
function cmdAceitarRevisao({ pos, op }) {
  exigirRaiz();
  const id = pos[0];
  const dir = dirMudanca(id, RAIZ);
  { const e = textoDoDev(op.por, 'quem aceita (--por "Nome Sobrenome")'); if (e) sair(2, `${e} Este portão é humano.`); }
  { const e = textoDoDev(op.apesar, 'o motivo (--apesar: por que os achados não impedem a entrega)', 15); if (e) sair(2, e); }
  const head = headCurto(RAIZ);
  const linhas = [];
  const reprovados = [];
  for (const eixo of EIXOS_CODIGO) {
    let v = vereditoVigente(join(dir, 'revisao'), eixo, head);
    if (!v) {
      // Eixo que bateu no teto não tem veredito neste HEAD: o aceite vale sobre o último REPROVADO.
      const hist = historicoVereditos(join(dir, 'revisao'), eixo);
      const teto = Number(config(RAIZ).revisaoIsolada.tetoRodadas) || 2;
      if (reprovacoesSeguidas(hist) < teto) sair(2, `sem veredito de ${eixo} no HEAD ${head}: rode a revisão de código antes.`);
      v = { ...hist[0], nome: `${hist[0].nome}, não revisado em ${head} (teto de rodadas)` };
    }
    if (aprovado(v.arquivo)) { linhas.push(`- ${eixo}: APROVADO (${v.nome})`); continue; }
    reprovados.push(eixo);
    const bloq = linhasDe(readFileSync(v.arquivo, 'utf8')).filter((l) => /^\s*(?:[-*]|\d+[.)])?\s*\[bloqueante\]/i.test(l)).map((l) => `  ${l.trim()}`);
    linhas.push(`- ${eixo}: REPROVADO (${v.nome})`, ...bloq);
  }
  if (!reprovados.length) sair(0, `nada a aceitar: os três eixos estão APROVADO em ${head}.`);
  const p = join(dir, 'revisao', `ACEITE-${head}.md`);
  writeFileSync(p, `# Revisão de código aceita apesar de REPROVADO\nCommit: ${head}\nPor: ${op.por}\nEm: ${new Date().toISOString()}\nApesar de: ${op.apesar}\n\n${linhas.join('\n')}\n`);
  console.log(`aceite gravado: ${barra(relative(RAIZ, p))} (${reprovados.join(', ')}). O resumo.md da PR leva o motivo em "Pontos para o revisor humano". Commit novo invalida o aceite.`);
}

// ----------------------------------------------------------- conhecimento

function cmdConhecimento({ pos, op }) {
  exigirRaiz();
  const pasta = pos[0];
  const dir = join(RAIZ, ARCHIVE, pasta || '');
  if (!pasta || !existsSync(dir)) sair(2, `informe a pasta arquivada: ${existsSync(join(RAIZ, ARCHIVE)) ? readdirSync(join(RAIZ, ARCHIVE)).join(', ') : 'nenhuma'}`);
  if (!op.pr || op.pr === true) sair(2, 'informe a PR: --pr 1234 (o registro nasce depois da PR aberta).');
  const cfg = config(RAIZ);
  // Fechar só depois do OK de quem testou: com PR aberta e QA pendente, o registro esperaria um código que
  // ainda pode mudar (caso real: QA achou erro depois do fechar e o conhecimento já estava no Git).
  const qa = ler(join(dir, 'QA.md'));
  const campoQa = (k) => ((qa || '').match(new RegExp(`^${k}:\\s*(.+)$`, 'm')) || [])[1]?.trim() || '?';
  if (!qa && cfg.qa.exigir !== false) sair(1, `NÃO FECHADO: ${pasta} sem o OK do QA. Quem testou declara, no terminal: node ${HW}/bin/bchive.mjs qa-ok ${pasta} --por "<QA>" --ambiente "<ambiente>" --resultado "<o que foi testado e passou>". Se o QA achou erro: mudança nova e pequena na mesma branch, e as duas fecham juntas depois do OK.`);
  const m = metadados(dir);
  const slug = pasta.replace(/^\d{4}-\d{2}-\d{2}-/, '');
  const hoje = new Date().toISOString().slice(0, 10);
  const destRel = barra(join(cfg.conhecimento, `${hoje}-${slug}.md`));
  const dest = join(RAIZ, destRel);
  if (existsSync(dest)) sair(2, `${destRel} já existe.`);
  const decis = [...(ler(join(dir, 'design.md')) || '').matchAll(/^###\s+(.+)\n(?:.*\n){0,3}?\s*Durabilidade\s*:\s*permanente/gim)].map((x) => x[1]);
  const caps = [...new Set([...(ler(join(dir, 'deltas.md')) || '').matchAll(/^\s*[-|]?\s*Capacidade\s*[:|]\s*(\S+)/gim)].map((x) => x[1]))];
  const uso = spawnSync(process.execPath, [join(BIN, 'uso.mjs'), 'resumo', pasta], { cwd: RAIZ, encoding: 'utf8' }).stdout?.trim() || 'Sem dados de uso coletados para esta mudança.';
  const inicioCommits = m.inicio
    || (m.base && (git(['merge-base', m.base, m.fim || 'HEAD'], { cwd: RAIZ, permitirFalha: true }) || '').trim())
    || m.base || 'base';
  const corpo = [
    `# ${slug}`,
    '',
    `Data: ${hoje}`,
    `Ticket: ${m.ticket || 'sem ticket'}`,
    `PR: ${op.pr}`,
    `Branch: ${m.branch || '?'}`,
    `Commits: ${inicioCommits.slice(0, 7)}..${m.fim ? m.fim.slice(0, 7) : '?'}`,
    `Rigor: ${m.rigor || '?'}`,
    `QA: ${qa ? `${campoQa('Por')}, ${campoQa('Ambiente')}, ${campoQa('Data')}: ${campoQa('Resultado')}` : 'não exigido neste repositório'}`,
    '',
    '## Problema',
    '',
    '<!-- preencher: de onde partiu, para quem, por que importa -->',
    '',
    '## O que mudou',
    '',
    '<!-- preencher: comportamento, pelo efeito -->',
    '',
    '## Regras de negócio',
    '',
    '<!-- preencher: regras que a mudança criou ou alterou, em linguagem de negócio -->',
    '',
    '## Decisões',
    '',
    decis.length ? decis.map((d) => `- ${d}`).join('\n') : '- nenhuma decisão durável',
    '',
    '## Capacidades afetadas',
    '',
    caps.length ? caps.map((c) => `- ${c}`).join('\n') : '- nenhuma',
    '',
    '## Fora do escopo',
    '',
    '<!-- preencher -->',
    '',
    '## Uso',
    '',
    uso,
    '',
  ].join('\n');
  mkdirSync(dirname(dest), { recursive: true });
  writeFileSync(dest, corpo);
  const reg = lerJson(join(RAIZ, ESTADO, 'conhecimento.json'), {});
  reg[pasta] = destRel;
  gravarJson(join(RAIZ, ESTADO, 'conhecimento.json'), reg);
  console.log(`esqueleto: ${destRel} (preencha as seções marcadas; números e metadados vieram do script)`);
}

// ------------------------------------------------------------------ ticket

function cmdTicket({ pos, op }) {
  exigirRaiz();
  const p = join(RAIZ, ESTADO, 'ticket.json');
  if (op.limpar) {
    if (existsSync(p)) rmSync(p);
    return console.log('ticket fixado removido.');
  }
  if (pos[0]) {
    if (!new RegExp(`^${config(RAIZ).ticket.padrao}$`).test(pos[0])) sair(2, `"${pos[0]}" não segue o padrão de ticket (${config(RAIZ).ticket.padrao}).`);
    gravarJson(p, { ticket: pos[0], em: new Date().toISOString() });
  }
  const t = ticketDaSessao(RAIZ);
  console.log(`ticket: ${t.ticket || 'nenhum'} (${t.origem})`);
}

// ------------------------------------------------------------------ adotar

function cmdAdotar({ op }) {
  exigirRaiz();
  const pares = [['.sdd/specs', `${HW}/specs`], ['.sdd/decisoes', `${HW}/decisoes`]];
  let n = 0;
  for (const [de, para] of pares) {
    const a = join(RAIZ, de);
    if (!existsSync(a)) continue;
    for (const f of readdirSync(a, { recursive: true }).map(String)) {
      const origem = join(a, f);
      if (!statSync(origem).isFile()) continue;
      const destino = join(RAIZ, para, f);
      const ehIndice = basename(f) === 'index.md';
      if (existsSync(destino) && !ehIndice) {
        console.log(`  manter   ${barra(join(para, f))} (já existe)`);
        continue;
      }
      if (ehIndice && existsSync(destino)) {
        const atual = readFileSync(destino, 'utf8');
        const novas = linhasDe(readFileSync(origem, 'utf8')).filter((l) => /^\s*[-|]/.test(l) && !atual.includes(l.trim()));
        console.log(`  índice   ${barra(join(para, f))} +${novas.length} linha(s)`);
        if (op.aplicar && novas.length) writeFileSync(destino, `${atual.replace(/\s*$/, '')}\n${novas.join('\n')}\n`);
        continue;
      }
      console.log(`  copiar   ${barra(join(de, f))} → ${barra(join(para, f))}`);
      if (op.aplicar) {
        mkdirSync(dirname(destino), { recursive: true });
        copyFileSync(origem, destino);
      }
      n++;
    }
  }
  console.log(op.aplicar ? `\n${n} arquivo(s) copiado(s). O .sdd/ não foi alterado.` : '\nplano: nada foi escrito. Rode com --aplicar.');
}

// ----------------------------------------------------------------- canário

function cmdCanario({ pos }) {
  exigirRaiz();
  const sub = pos[0];
  const pCan = join(RAIZ, ESTADO, 'canario.json');
  if (sub === 'preparar') {
    const token = `bchive-canario-${randomBytes(4).toString('hex')}`;
    gravarJson(pCan, { token, criadoEm: new Date().toISOString() });
    rmSync(join(RAIZ, ESTADO, 'canario-hooks.jsonl'), { force: true });
    rmSync(join(RAIZ, ESTADO, 'canario-resposta.md'), { force: true });
    console.log([
      `Canário preparado. Palavra-código: ${token}`,
      '',
      'A palavra-código agora está na conversa deste chat (a isca). Neste mesmo chat:',
      '1. node .bchive/bin/bchive.mjs pacote-revisao canario',
      `2. Delegue ao subagente ${REVISOR} com o prompt literal impresso, sem acrescentar nada.`,
      '3. Grave a resposta dele, sem edição, em .bchive/estado/canario-resposta.md',
      '4. node .bchive/bin/bchive.mjs canario conferir',
      `O /${nomePlugin(RAIZ)}:canario faz os quatro passos. Só vale no harness Copilot: no Local o revisor ganha ferramentas que não deveria.`,
    ].join('\n'));
    return;
  }
  if (sub === 'conferir') {
    const can = lerJson(pCan);
    if (!can) sair(2, 'rode antes: bchive canario preparar');
    const resp = ler(join(RAIZ, ESTADO, 'canario-resposta.md'));
    const hooks = linhasDe(ler(join(RAIZ, ESTADO, 'canario-hooks.jsonl')) || '').filter(Boolean).map((l) => JSON.parse(l));
    const eventos = [...new Set(hooks.map((h) => h.ev))];
    const sub = hooks.filter((h) => h.subagente);
    console.log(`hooks: ${eventos.length ? eventos.join(', ') : 'NENHUM evento registrado (hooks bloqueados, não recarregados ou fora do harness Copilot)'}`);
    if (sub.length) {
      const s = sub[sub.length - 1];
      console.log(`chamada de subagente vista pelo preToolUse: ferramenta "${s.ferramenta}", campos [${s.campos.join(', ')}], campo do prompt provável "${s.campoPrompt}"`);
    } else if (eventos.length) console.log('AVISO o preToolUse não registrou a chamada de subagente: a conferência do pacote (C) não tem como funcionar.');
    if (!resp) sair(1, 'sem resposta do peixinho em .bchive/estado/canario-resposta.md: o passo 3 não rodou até o fim.');
    const av = avaliarCanario(resp, can.token);
    const vscode = versaoVsCode();
    gravarJson(pCan, { ...can, conferidoEm: new Date().toISOString(), vscode, resultado: av.resultado, isolado: av.isolado, ferramentas: av.ferramentas, proibidas: av.proibidas, motivo: av.motivo || null, hooks: eventos, subagente: sub[sub.length - 1] || null });
    if (av.resultado === 'inconclusivo') {
      sair(1, `Resultado: INCONCLUSIVO. O revisor não respondeu no formato pedido (recusou ou explicou), então a resposta não prova isolamento. Rode o /${nomePlugin(RAIZ)}:canario de novo num chat novo; se a recusa se repetir, troque o modelo do chat e repita.`);
    }
    console.log(`conversa do pai chegou ao revisor: ${av.motivo === 'conversa' ? 'SIM — isolamento FALHOU' : 'não'}`);
    console.log(`ferramentas do revisor: ${av.ferramentas.join(', ') || '?'}${av.proibidas.length ? ` — FORA DO PERMITIDO: ${av.proibidas.join(', ')} (harness Local? use o harness Copilot)` : ' (só leitura e busca)'}`);
    console.log(`VS Code: ${vscode || 'versão não identificada'} (o canário vale para esta versão; o /${nomePlugin(RAIZ)}:init pede de novo quando ela mudar)`);
    if (!av.isolado) sair(1, av.motivo === 'ferramentas' ? 'Resultado: o revisor recebeu ferramentas além de leitura e busca. Isso acontece no harness Local, que o fluxo não suporta: troque para o harness Copilot e rode o canário de novo.' : 'Resultado: o revisor NÃO é isolado nesta máquina. Use o modo estrito (bchive estrito) até investigar.');
    console.log(`Resultado: isolamento confirmado.${sub.length ? ' Para ligar a conferência do pacote: bchive canario aplicar' : ''}`);
    return;
  }
  if (sub === 'aplicar') {
    const can = lerJson(pCan);
    if (can?.isolado !== true || !can.subagente) sair(1, 'o canário precisa ter passado (resposta no formato, sem a palavra-código) e registrado a chamada de subagente. Rode preparar e conferir.');
    const p = join(RAIZ, HW, 'bchive.json');
    const cfg = lerJson(p, {});
    cfg.revisaoIsolada = { ...(cfg.revisaoIsolada || {}), conferirPacote: 'negar', ferramenta: can.subagente.ferramenta, campoPrompt: can.subagente.campoPrompt };
    gravarJson(p, cfg);
    console.log(`conferência do pacote ligada: chamada de subagente "${can.subagente.ferramenta}" para ${REVISOR} só passa com o prompt literal do pacote.`);
    return;
  }
  sair(2, 'uso: bchive canario preparar | conferir | aplicar');
}

// ----------------------------------------------------------------- estrito

function cmdEstrito({ pos }) {
  exigirRaiz();
  const [id, alvo] = pos;
  dirMudanca(id, RAIZ);
  const reg = linhasDe(ler(PACOTES_REG) || '').filter(Boolean).map((l) => JSON.parse(l)).filter((r) => r.change === id && r.alvo === alvo).pop();
  if (!reg) sair(2, `gere antes: bchive pacote-revisao ${id} ${alvo}`);
  const tem = spawnSync(process.platform === 'win32' ? 'where' : 'which', ['copilot'], { encoding: 'utf8' });
  if (tem.status !== 0) sair(1, 'modo estrito exige o Copilot CLI (copilot) no PATH. A revisão para aqui: não cai para o modo padrão em silêncio.');
  const args = ['-p', promptDoPacote(reg.arquivo), '--agent', REVISOR, '--no-custom-instructions', '--deny-tool=write', '--deny-tool=shell', '-s'];
  console.log(`executando: copilot ${args.map((a) => (/\s/.test(a) ? `"${a}"` : a)).join(' ')}`);
  const r = spawnSync('copilot', args, { cwd: RAIZ, encoding: 'utf8', maxBuffer: 1 << 26, timeout: 15 * 60 * 1000 });
  if (r.status !== 0) sair(1, `copilot saiu com ${r.status}: ${(r.stderr || '').trim().slice(0, 600)}`);
  const out = join(RAIZ, CHANGES, id, 'rascunhos', `${alvo}.md`);
  mkdirSync(dirname(out), { recursive: true });
  writeFileSync(out, r.stdout.trim() + '\n');
  console.log(`resposta do revisor: ${barra(relative(RAIZ, out))}\nconfira e grave: bchive gravar-veredito ${id} ${alvo} --de ${barra(relative(RAIZ, out))}`);
}

// -------------------------------------------------------------------- init

// O que o /<plugin>:init confere. Agentes e skills vêm do plugin instalado (versao.json → pluginRoot).
const AGENTES = ['bchive', 'bchive-discovery', 'bchive-prototipo', 'bchive-plan', 'bchive-review', 'bchive-implement', 'bchive-implementador', 'bchive-archive', 'bchive-gf'];
const SKILLS = ['init', 'auditar', 'start', 'configurar', 'grill', 'triagem', 'canario', 'prototipo', 'plan', 'review', 'implement', 'archive', 'fechar', 'ticket', 'adotar', 'mapa', 'uso'];
const EVENTOS_HOOK = ['sessionStart', 'userPromptSubmitted', 'preToolUse', 'postToolUse', 'subagentStart', 'sessionEnd'];

async function cmdInit({ op }) {
  exigirRaiz();
  const itens = [];
  const add = (id, nivel, txt, extra = {}) => itens.push({ id, nivel, txt, ...extra });
  const corrigir = Boolean(op.corrigir);
  const rodar = (script, args, env = {}) => spawnSync(process.execPath, [join(BIN, script), ...args], { cwd: RAIZ, encoding: 'utf8', env: { ...process.env, ...env }, timeout: 4 * 60 * 1000 });
  const plugin = nomePlugin(RAIZ);
  const cmd = (n) => `/${plugin}:${n}`;
  const inst = versaoInstalada(RAIZ);

  // 1. Node e Git
  const nodeMaior = Number(process.versions.node.split('.')[0]);
  add('node', nodeMaior >= 20 ? 'ok' : 'grave', `Node ${process.versions.node}${nodeMaior >= 20 ? '' : ': o b.IA Credit Hive precisa de 20 ou mais'}`);
  const temGit = git(['rev-parse', '--show-toplevel'], { cwd: RAIZ, permitirFalha: true }) !== null;
  add('git', temGit ? 'ok' : 'aviso', temGit ? `branch ${branchAtual(RAIZ) || '?'}` : 'sem Git: revisão de código e mapa incremental não funcionam');

  // 2. Plugin: versão do núcleo copiado, agentes, skills e hooks onde o plugin está instalado
  const raizPlugin = inst?.pluginRoot && existsSync(join(inst.pluginRoot, 'plugin.json')) ? inst.pluginRoot : null;
  const manif = raizPlugin ? lerJson(join(raizPlugin, 'plugin.json'), {}) : null;
  if (!inst) add('plugin', 'grave', `sem ${HW}/versao.json: rode ${cmd('init')} (ele copia o núcleo e grava a versão)`);
  else if (!raizPlugin) add('plugin', 'pendente', `o plugin não está mais em ${inst.pluginRoot || '?'} (atualizou ou trocou de marketplace): rode ${cmd('init')} de novo`);
  else if (manif.version && manif.version !== inst.versao) add('plugin', 'pendente', `núcleo em ${HW}/bin é ${inst.versao} e o plugin instalado é ${manif.version}: rode ${cmd('init')} de novo`);
  else add('plugin', 'ok', `${manif.name || plugin} ${inst.versao}, núcleo em ${HW}/bin`);
  if (raizPlugin) {
    const pAg = (n) => join(raizPlugin, 'com.github.copilot', 'agents', `${n}.agent.md`);
    const faltaAg = AGENTES.filter((n) => !existsSync(pAg(n)));
    const faltaSk = SKILLS.filter((n) => !existsSync(join(raizPlugin, 'skills', n, 'SKILL.md')));
    if (faltaAg.length || faltaSk.length) add('plugin-conteudo', 'grave', `o plugin instalado não traz ${[...faltaAg.map((n) => `agente ${n}`), ...faltaSk.map((n) => `skill ${n}`)].slice(0, 6).join(', ')}. Reinstale o plugin.`);
    else add('plugin-conteudo', 'ok', `${AGENTES.length} agentes e ${SKILLS.length} skills no plugin`);
    // Subagente com disable-model-invocation: true some da lista que o agente pode chamar ("Unknown agent_type").
    const travados = ['bchive-gf', 'bchive-implementador'].filter((n) => /^disable-model-invocation:\s*true\s*$/m.test(ler(pAg(n)) || ''));
    if (travados.length) add('subagentes', 'grave', `${travados.join(', ')} com "disable-model-invocation: true": a delegação responde "Unknown agent_type". Reinstale o plugin.`);
    const hooks = lerJson(join(raizPlugin, 'com.github.copilot', 'hooks', 'hooks.json'));
    const faltaEv = EVENTOS_HOOK.filter((e) => !hooks?.hooks?.[e]);
    if (!hooks || faltaEv.length) add('hooks', 'grave', `hooks.json do plugin ${hooks ? `sem ${faltaEv.join(', ')}` : 'ausente ou inválido'}: sem guarda e sem coleta de uso. Reinstale o plugin.`);
    else {
      // Prova de que o script do hook responde, com a coleta numa pasta temporária fora do repositório
      // (no Windows, watcher e antivírus seguram pasta nova dentro do projeto: EBUSY).
      const tmpUso = mkdtempSync(join(tmpdir(), 'bchive-init-uso-'));
      const script = join(raizPlugin, 'scripts', 'core', 'hook.mjs');
      const prova = (ev, payload) => {
        const r = spawnSync(process.execPath, [existsSync(script) ? script : join(BIN, 'hook.mjs'), ev], { cwd: tmpdir(), input: JSON.stringify({ cwd: RAIZ, sessionId: 'bchive-init', ...payload }), encoding: 'utf8', env: { ...process.env, BCHIVE_USO: tmpUso, BCHIVE_HOOK_TESTE: '1' }, timeout: 10000 });
        try { return JSON.parse(r.stdout || '{}'); } catch { return null; }
      };
      const leitura = prova('preToolUse', { toolName: 'view', toolArgs: { path: 'README.md' } });
      const guarda = prova('preToolUse', { toolName: 'edit', toolArgs: { path: `${HW}/changes/init-teste/revisao/spec-x.md` } });
      apagarSemFalhar(tmpUso);
      const ok = leitura && !leitura.permissionDecision && guarda?.permissionDecision === 'deny';
      add('hooks', ok ? 'ok' : 'grave', ok ? `${EVENTOS_HOOK.length} eventos no plugin; o script responde fora da pasta do repositório e a guarda de veredito nega. Se o VS Code roda os hooks, quem prova é o canário` : 'o hook.mjs do plugin não respondeu como esperado: confira o Node no PATH do VS Code');
    }
  }
  // Instalação anterior pelo zip: agentes e hooks em dobro (dois hooks contam o uso duas vezes).
  const antigos = ['.github/agents/bchive.agent.md', '.github/hooks/bchive.json'].filter((c) => existsSync(join(RAIZ, c)));
  const blocoAntigo = INSTRUCOES.find((f) => (ler(join(RAIZ, f)) || '').includes('<!-- bchive:inicio -->'));
  if (antigos.length || blocoAntigo) add('instalacao-antiga', 'aviso', `restos da instalação pelo zip (${[...antigos, ...(blocoAntigo ? [`bloco em ${blocoAntigo}`] : [])].join(', ')}). Com o plugin eles duplicam agentes e hooks: apague .github/agents/bchive*.agent.md, .github/skills/bchive-*, .github/skills/bchive-fluxo, .github/hooks/bchive.json e o bloco <!-- bchive:inicio --> ... <!-- bchive:fim -->.`);

  // Personalização que o dev já tinha: convive com o fluxo, nunca bloqueia. Só informa e aponta a auditoria.
  const local = inventario(RAIZ).filter((it) => it.escopo === 'repositorio');
  if (local.length) {
    const tipos = [...new Set(local.map((it) => it.tipo))].join(', ');
    add('personalizacao', 'ok', `${local.length} arquivo(s) de personalização do Copilot no repositório (${tipos}): convivem com o fluxo e não bloqueiam nada; o fluxo nunca cria nem edita .github/ nem AGENTS.md. Qualidade e custo: ${cmd('auditar')}`);
  }

  // 3. Git: nada do harness versionado nem aparecendo como não rastreado
  if (temGit) {
    const caminhos = [`${HW}/bchive.json`, `${HW}/bin/bchive.mjs`, `${HW}/versao.json`].filter((c) => existsSync(join(RAIZ, c)));
    const versionados = caminhos.filter((c) => git(['ls-files', '--error-unmatch', c], { cwd: RAIZ, permitirFalha: true }) !== null);
    const visiveis = caminhos.filter((c) => !versionados.includes(c) && git(['check-ignore', '-q', c], { cwd: RAIZ, permitirFalha: true }) === null);
    if (versionados.length) add('git-exclude', 'grave', `arquivo do harness versionado: ${versionados.join(', ')}. Ele vai para a PR. Tire do índice (git rm -r --cached ${HW}) e rode ${cmd('init')} de novo.`);
    else if (visiveis.length) add('git-exclude', 'pendente', `${visiveis.join(', ')} aparece(m) no git status: falta a exclusão em .git/info/exclude. Rode ${cmd('init')} de novo.`);
    else add('git-exclude', 'ok', 'harness fora do Git (.git/info/exclude)');
  }

  // 4. Mapa e hooks do Git que o mantêm
  const temMapa = () => existsSync(join(RAIZ, HW, 'mapa', 'graph.json')) || existsSync(join(RAIZ, 'graphify-out', 'graph.json'));
  if (!temMapa() && corrigir) {
    const r = rodar('bchivemap.mjs', ['build']);
    add('mapa', temMapa() ? 'corrigido' : 'pendente', temMapa() ? `construído: ${(r.stdout || '').trim().split('\n').find((l) => /nós/.test(l)) || 'ok'}` : `build falhou: ${(r.stderr || r.stdout || '').trim().split('\n').pop()}`);
  } else if (temMapa()) {
    const st = rodar('bchivemap.mjs', ['status']);
    add('mapa', 'ok', (st.stdout || '').trim().split('\n').find((l) => /nós/.test(l)) || 'construído');
  } else add('mapa', 'pendente', `sem mapa: node ${HW}/bin/bchivemap.mjs build (o init --corrigir faz)`);
  if (temGit) {
    const hp = (git(['config', '--get', 'core.hooksPath'], { cwd: RAIZ, permitirFalha: true }) || '').trim();
    const dir = resolve(RAIZ, (git(['rev-parse', '--git-path', 'hooks'], { cwd: RAIZ, permitirFalha: true }) || '.git/hooks').trim());
    const instalado = () => ['post-checkout', 'post-merge', 'post-commit'].every((h) => (ler(join(hp ? resolve(RAIZ, hp) : dir, h)) || '').includes('>>> bchive'));
    if (instalado()) add('git-hooks', 'ok', 'mapa se atualiza em checkout, merge e commit');
    else if (hp) add('git-hooks', 'aviso', `core.hooksPath=${hp} (Husky ou similar): o mapa se atualiza antes de cada consulta; não mexa nos hooks do time`);
    else if (corrigir) { rodar('bchivemap.mjs', ['git-hooks']); add('git-hooks', instalado() ? 'corrigido' : 'aviso', instalado() ? 'hooks do Git instalados (post-checkout, post-merge, post-commit)' : `hook do Git existente em outra linguagem: veja node ${HW}/bin/bchivemap.mjs git-hooks`); }
    else add('git-hooks', 'pendente', 'hooks do Git do mapa ausentes (o init --corrigir instala)');
  }

  // 5. Uso: pasta gravável e tokens do Agent Host (configuração gerenciada pela TI)
  const cfg = config(RAIZ);
  if (cfg.uso.coletar === false) add('uso', 'aviso', '"uso.coletar": false no bchive.json: este repositório não entra no relatório de uso');
  else {
    try {
      mkdirSync(USO_DIR, { recursive: true });
      writeFileSync(join(USO_DIR, '.init'), new Date().toISOString());
      rmSync(join(USO_DIR, '.init'), { force: true });
      add('uso', 'ok', `contagens em ${barra(USO_DIR).replace(barra(homedir()), '~')} (nunca prompt, resposta ou código)`);
    } catch (e) { add('uso', 'aviso', `não consigo gravar em ${USO_DIR} (${e.code || e.message}): o uso fica de fora`); }
  }
  let otelRecente = false;
  try { otelRecente = existsSync(OTEL_AGENT_HOST) && statSync(OTEL_AGENT_HOST).size > 0 && Date.now() - statSync(OTEL_AGENT_HOST).mtimeMs < 7 * 864e5; } catch { /* sem arquivo */ }
  add('tokens', otelRecente ? 'ok' : 'aviso', otelRecente ? 'telemetria do Agent Host recebendo dados: o relatório traz tokens por sessão' : 'sem telemetria do Agent Host nesta máquina: o relatório sai sem tokens (depende da configuração gerenciada da TI; nada a fazer no repositório)');

  // 6. Canário. A resposta salva é a fonte da verdade: se a regra de leitura mudou numa versão nova, o
  // resultado acompanha sem repetir o teste (e o canario.json é atualizado).
  const pCan = join(RAIZ, ESTADO, 'canario.json');
  let can = lerJson(pCan);
  if (can?.conferidoEm) {
    const resp = ler(join(RAIZ, ESTADO, 'canario-resposta.md'));
    if (resp && can.token) {
      const av = avaliarCanario(resp, can.token);
      if (av.resultado !== can.resultado || av.isolado !== can.isolado) { can = { ...can, ...av }; gravarJson(pCan, can); }
    }
  }
  if (can?.isolado && can.subagente && cfg.revisaoIsolada.conferirPacote !== 'negar' && corrigir) {
    const r = spawnSync(process.execPath, [join(BIN, 'bchive.mjs'), 'canario', 'aplicar'], { cwd: RAIZ, encoding: 'utf8' });
    add('canário', r.status === 0 ? 'corrigido' : 'pendente', r.status === 0 ? 'isolado; conferência do pacote ligada agora' : (r.stderr || '').trim());
  } else if (!can) add('canário', 'pendente', `não rodou: o ${cmd('init')} roda neste chat (ou ${cmd('canario')})`);
  else if (!can.conferidoEm) add('canário', 'pendente', `preparado e não conferido: rode o ${cmd('canario')} de novo`);
  else if (can.resultado === 'inconclusivo') add('canário', 'pendente', `inconclusivo: o revisor não respondeu no formato pedido. Rode o ${cmd('canario')} num chat novo`);
  else if (can.resultado === 'falhou' && can.motivo === 'ferramentas') add('canário', 'pendente', `o revisor recebeu ferramentas além de leitura e busca (${(can.proibidas || []).join(', ') || '?'}): é o harness Local, que o fluxo não suporta. Troque o chat para o harness Copilot e rode o ${cmd('canario')}`);
  else if (can.resultado === 'falhou') add('canário', 'aviso', 'isolamento FALHOU nesta máquina: a conversa chegou ao revisor. Use a revisão em modo estrito até investigar');
  else if (!can.hooks?.length) add('canário', 'pendente', `isolado, mas nenhum hook registrou evento: Developer: Reload Window e rode o ${cmd('canario')} de novo`);
  else if (cfg.revisaoIsolada.conferirPacote === 'negar') {
    // Isolamento provado por teste: numa versão nova do VS Code, prova de novo. A conferência do pacote
    // continua ligada enquanto isso (ela só nega, nunca libera).
    const atual = versaoVsCode();
    const quando = new Date(can.conferidoEm).toLocaleDateString('pt-BR');
    if (atual && can.vscode && atual !== can.vscode) add('canário', 'pendente', `passou no VS Code ${can.vscode} (${quando}); agora é ${atual}: rode o ${cmd('canario')} de novo`);
    else add('canário', 'ok', `isolado no VS Code ${can.vscode || '?'}; conferência do pacote ligada (${quando})`);
  } else add('canário', 'pendente', 'isolado, mas o preToolUse não viu a chamada de subagente: a conferência do pacote fica desligada');

  // 7. Mudanças abertas cujo nome não começa pela chave do Jira
  if (cfg.ticket.noId !== 'off') {
    const semChave = mudancasAbertas(RAIZ).filter((id) => {
      const t = metadados(join(RAIZ, CHANGES, id)).ticket || '';
      return !(new RegExp(`^(${cfg.ticket.padrao})$`).test(t) && id.startsWith(`${t}-`));
    });
    if (semChave.length) add('ticket-no-nome', cfg.ticket.noId === 'obrigatorio' ? 'pendente' : 'aviso', `mudança(s) aberta(s) sem a chave do Jira no nome: ${semChave.join(', ')}. Renomeie a pasta para <TICKET>-<slug> e confira o Ticket: da proposta`);
    else add('ticket-no-nome', 'ok', `change-id = <TICKET>-<slug> (ticket ${cfg.ticket.noId})`);
  }

  // 8. Executores e arquivos do time que nasceram do molde
  const ex = executoresConhecidos();
  add('executores', 'ok', `${Object.keys(ex.registrados).length} registrado(s), ${Object.keys(ex.descobertos).length} descoberto(s) nesta máquina${ex.descobertosEm ? ` (${new Date(ex.descobertosEm).toLocaleDateString('pt-BR')})` : ''}`);
  const verif = ler(join(RAIZ, HW, 'verificacao.json')) || '';
  if (/tsconfig\.app\.json/.test(verif) && /npx eslint -f json \{arquivos\}/.test(verif)) add('verificacao', 'pendente', `${HW}/verificacao.json parece o molde de MFE Angular: ${cmd('configurar')} verificacao propõe a partir do repositório e prova cada comando`);
  if ((ler(join(RAIZ, HW, 'padroes.md')) || '').includes('Apague os exemplos abaixo')) add('padroes', 'pendente', `${HW}/padroes.md ainda tem os exemplos: ${cmd('configurar')} padroes rascunha a partir do mapa de padrões, para o time aprovar`);

  const conta = (n) => itens.filter((i) => i.nivel === n).length;
  const res = { em: new Date().toISOString(), versao: inst?.versao || null, corrigir, itens, resumo: Object.fromEntries(['ok', 'corrigido', 'pendente', 'aviso', 'grave'].map((n) => [n, conta(n)])) };
  gravarJson(join(RAIZ, ESTADO, 'init.json'), res);
  if (op.json) { console.log(JSON.stringify(res, null, 2)); process.exit(conta('grave') ? 1 : 0); }
  const rot = { ok: 'ok', corrigido: 'corrigido', pendente: 'PENDENTE', aviso: 'aviso', grave: 'GRAVE' };
  console.log(`b.IA Credit Hive init${inst ? ` · ${inst.versao}` : ''} · ${basename(RAIZ)}${corrigir ? ' · com correções seguras' : ''}`);
  for (const i of itens) console.log(`  ${rot[i.nivel].padEnd(10)} ${i.id.padEnd(18)} ${i.txt}`);
  console.log(`\n${conta('ok') + conta('corrigido')} pronto(s), ${conta('pendente')} pendente(s), ${conta('aviso')} aviso(s), ${conta('grave')} grave(s). Registro: ${HW}/estado/init.json`);
  if (conta('grave')) process.exit(1);
}

// ---------------------------------------------------------- pós-instalação

function cmdPosInstalacao() {
  exigirRaiz();
  const r = (script, args) => spawnSync(process.execPath, [join(BIN, script), ...args], { cwd: RAIZ, encoding: 'utf8' });
  if (mudancasAbertas(RAIZ).length) {
    const v = r('bchive.mjs', ['validar']);
    console.log((v.stdout || '').trim().split('\n').slice(-1)[0]);
  }
  const m = r('bchivemap.mjs', ['build']);
  console.log((m.stdout || m.stderr || '').trim().split('\n').slice(-2).join('\n'));
  const g = r('bchivemap.mjs', ['git-hooks']);
  const gs = (g.stdout || g.stderr || '').trim();
  // Com Husky (core.hooksPath) a mensagem tem duas linhas; mostrar só a última parecia um comando solto.
  console.log(/core\.hooksPath/.test(gs) ? 'AVISO hooks do Git do mapa não instalados: o repositório usa core.hooksPath (Husky). Não mexa nos hooks do time: o bchivemap se atualiza antes de cada consulta.' : gs.split('\n').slice(-1)[0]);
}

// ------------------------------------------------------------------- qa-ok

// Portão humano: quem testou declara o OK. O agente nunca roda (o hook nega). Sem captura de tela, vídeo
// ou link: a evidência é a declaração (quem, ambiente, data, resultado). Uma declaração pode cobrir mais de
// uma mudança arquivada (correção depois do QA = mudança nova na mesma branch e PR).
function cmdQaOk({ pos, op }) {
  exigirRaiz();
  if (!pos.length) sair(2, 'informe a(s) pasta(s) arquivada(s): bchive qa-ok <pasta...> --por "<QA>" --ambiente "<ambiente>" --resultado "<o que foi testado e passou>"');
  { const e = textoDoDev(op.por, 'quem testou (--por "Nome Sobrenome")'); if (e) sair(2, `${e} Este portão é humano.`); }
  { const e = textoDoDev(op.ambiente, 'o ambiente (--ambiente, ex.: "TU", "TI", "homologação")', 2); if (e) sair(2, e); }
  { const e = textoDoDev(op.resultado, 'o resultado (--resultado: o que foi testado e passou)', 15); if (e) sair(2, e); }
  const data = op.data && op.data !== true ? String(op.data) : new Date().toISOString().slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(data)) sair(2, `--data "${data}" não é AAAA-MM-DD.`);
  const pastas = pos.map((p) => resolverArquivada(p));
  for (const pasta of pastas) if (existsSync(join(RAIZ, ARCHIVE, pasta, 'QA.md'))) sair(2, `${pasta} já tem QA.md. O OK não é reescrito: correção depois do QA é mudança nova na mesma branch.`);
  for (const pasta of pastas) {
    const outras = pastas.filter((x) => x !== pasta);
    writeFileSync(join(RAIZ, ARCHIVE, pasta, 'QA.md'), `# OK do QA\nPor: ${op.por}\nAmbiente: ${op.ambiente}\nData: ${data}\nResultado: ${op.resultado}\n${outras.length ? `Junto com: ${outras.join(', ')}\n` : ''}Registrado em: ${new Date().toISOString()}\n`);
  }
  console.log(`OK do QA gravado em ${pastas.join(', ')}. Próximo, no chat: /${nomePlugin(RAIZ)}:fechar ${pastas[0]} <número da PR>`);
}

function resolverArquivada(nome) {
  const base = join(RAIZ, ARCHIVE);
  const todas = existsSync(base) ? readdirSync(base).filter((n) => statSync(join(base, n)).isDirectory()) : [];
  if (todas.includes(nome)) return nome;
  const casa = todas.filter((n) => n.replace(/^\d{4}-\d{2}-\d{2}-/, '') === nome);
  if (casa.length === 1) return casa[0];
  sair(2, `"${nome}" não é uma mudança arquivada${casa.length > 1 ? ` única (${casa.join(', ')})` : ''}. Arquivadas: ${todas.join(', ') || 'nenhuma'}`);
}

// --------------------------------------------------------------- executores

// Quem pode executar fatia: os registrados pelo time (executores.json, versionado com o harness) e os
// descobertos nesta máquina (agentes de outros plugins que o agente vê na lista de subagentes).
// Descoberto não é aprovado: o plano propõe, o dev confirma, a revisão de três eixos julga igual.
const STACKS = {
  java: /\bjava\b|spring|quarkus|maven|gradle|\bjdk\b/i,
  liberty: /liberty|websphere/i,
  angular: /angular/i,
  react: /\breact\b|next\.?js/i,
  swift: /\bswift\b|\bios\b/i,
  kotlin: /kotlin|android/i,
  observabilidade: /observab|telemetr|dynatrace|grafana|opentelemetry|\btracing\b|\blogs?\b/i,
  testes: /\btests?\b|\btesting\b|\bqa\b|playwright|cypress|jest|junit/i,
  dados: /\bsql\b|database|\bdb2\b|oracle|mongo/i,
  infra: /terraform|kubernetes|\bk8s\b|helm|docker|pipeline|openshift/i,
};
const P_DESCOBERTOS = () => join(RAIZ, ESTADO, 'executores-descobertos.json');

function executoresConhecidos() {
  const registrados = lerJson(join(RAIZ, HW, 'executores.json'), { executores: {} }).executores || {};
  const d = lerJson(P_DESCOBERTOS(), { executores: {} });
  return { registrados, descobertos: d.executores || {}, descobertosEm: d.em || null };
}

function cmdExecutores({ pos, op }) {
  exigirRaiz();
  if (pos[0] === 'registrar') {
    if (!op.de || op.de === true) sair(2, 'uso: bchive executores registrar --de <arquivo.json> (lista [{ "nome": "<plugin>:<agente>", "descricao": "..." }])');
    let lista;
    try { lista = JSON.parse(readFileSync(resolve(RAIZ, op.de), 'utf8')); } catch (e) { sair(2, `não li ${op.de}: ${e.message}`); }
    if (!Array.isArray(lista)) lista = lista?.executores || [];
    const proprio = new RegExp(`(^|:)bchive(-[a-z]+)*$`);
    const executores = {};
    const recusados = [];
    for (const x of lista) {
      const nome = String(x?.nome || x?.name || '').trim();
      const descricao = String(x?.descricao || x?.description || '').replace(/\s+/g, ' ').trim().slice(0, 300);
      if (!/^[\w.-]+(:[\w.-]+)?$/.test(nome) || proprio.test(nome)) { recusados.push(nome || '(sem nome)'); continue; }
      const stacks = Object.entries(STACKS).filter(([, re]) => re.test(`${nome} ${descricao}`)).map(([k]) => k);
      executores[nome] = { tipo: 'descoberto', descricao, stacks };
    }
    gravarJson(P_DESCOBERTOS(), { em: new Date().toISOString(), executores });
    console.log(`${Object.keys(executores).length} executor(es) descoberto(s) gravado(s) em ${barra(relative(RAIZ, P_DESCOBERTOS()))}${recusados.length ? `; ignorados: ${recusados.join(', ')} (nome inválido ou agente do próprio fluxo)` : ''}.`);
  }
  const { registrados, descobertos, descobertosEm } = executoresConhecidos();
  // Conferência: o agente existe nesta máquina e está pronto para ser chamado como executor de fatia?
  if (pos[0] === 'conferir' || pos[0] === 'registrar') {
    const agentes = inventario(RAIZ, { usuario: true }).filter((it) => it.tipo === 'agente');
    const alvo = pos[0] === 'conferir' && pos[1] ? [pos[1]] : Object.keys({ ...registrados, ...descobertos }).filter((n) => !/(^|:)bchive(-[a-z]+)*$/.test(n));
    let graves = 0;
    console.log('conferência dos executores (agente achado nesta máquina, chamável como subagente, pronto para fatia):');
    for (const nome of alvo) {
      const it = agentes.find((a) => nomeChamavel(a) === nome) || agentes.find((a) => nomeChamavel(a).endsWith(`:${nome}`) || nome.endsWith(`:${nomeChamavel(a)}`));
      if (!it) { console.log(`  ${nome}: NÃO ACHADO em .github/agents/, ~/.copilot/agents/ nem nos plugins instalados (o plano não pode usar)`); graves++; continue; }
      const probs = conferirExecutor(it);
      graves += probs.filter((x) => x.nivel === 'grave').length;
      console.log(`  ${nome} (${it.rel}): ${probs.length ? '' : 'pronto'}`);
      for (const x of probs) console.log(`    ${x.nivel === 'grave' ? 'GRAVE' : 'aviso'} ${x.txt}`);
    }
    if (!alvo.length) console.log('  nenhum executor externo registrado ou descoberto.');
    if (pos[0] === 'conferir') sair(graves ? 1 : 0, graves ? `\n${graves} problema(s) grave(s): corrija o agente (README do plugin, seção "Agentes de outros plugins") e rode de novo.` : '');
    console.log('');
  }
  if (op.json) return console.log(JSON.stringify({ registrados, descobertos, descobertosEm }, null, 2));
  console.log('registrados (executores.json):');
  for (const [n, e] of Object.entries(registrados)) console.log(`  ${n.padEnd(34)} ${e.tipo || '?'}: ${e.quando || ''}`);
  console.log(`descobertos nesta máquina${descobertosEm ? ` (${new Date(descobertosEm).toLocaleDateString('pt-BR')})` : ''}:`);
  const ds = Object.entries(descobertos);
  if (!ds.length) console.log('  nenhum. O bchive-plan lista os subagentes que vê e registra com: bchive executores registrar --de <arquivo>');
  for (const [n, e] of ds) console.log(`  ${n.padEnd(34)} [${e.stacks.join(', ') || 'stack?'}] ${e.descricao.slice(0, 90)}`);
}

// -------------------------------------------------------------------- main

const COMANDOS = {
  estado: cmdEstado, validar: cmdValidar, fatias: cmdFatias, reivindicar: cmdReivindicar, 'conferir-toca': cmdConferirToca,
  'ponto-de-partida': cmdPontoDePartida, arvore: cmdArvore, hash: cmdHash, 'pacote-revisao': cmdPacoteRevisao, 'gravar-veredito': cmdGravarVeredito,
  'aprovar-spec': cmdAprovarSpec, arquivar: cmdArquivar, conhecimento: cmdConhecimento, ticket: cmdTicket, adotar: cmdAdotar,
  canario: cmdCanario, estrito: cmdEstrito, init: cmdInit, 'pos-instalacao': cmdPosInstalacao, 'qa-ok': cmdQaOk, executores: cmdExecutores,
  briefing: cmdBriefing, descartar: cmdDescartar, 'aceitar-revisao': cmdAceitarRevisao, 'rodada-extra': cmdRodadaExtra,
};

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const [cmd, ...resto] = process.argv.slice(2);
  if (cmd === 'uso') {
    const r = spawnSync(process.execPath, [join(BIN, 'uso.mjs'), ...resto], { cwd: RAIZ, stdio: 'inherit' });
    process.exit(r.status ?? 1);
  }
  if (cmd === 'configurar') {
    const r = spawnSync(process.execPath, [join(BIN, 'configurar.mjs'), ...resto], { cwd: RAIZ, stdio: 'inherit' });
    process.exit(r.status ?? 1);
  }
  if (cmd === 'auditar') {
    const r = spawnSync(process.execPath, [join(BIN, 'auditar.mjs'), ...resto], { cwd: RAIZ, stdio: 'inherit' });
    process.exit(r.status ?? 1);
  }
  if (cmd === 'mapa') {
    const r = spawnSync(process.execPath, [join(BIN, 'bchivemap.mjs'), ...resto], { cwd: RAIZ, stdio: 'inherit' });
    process.exit(r.status ?? 1);
  }
  const f = COMANDOS[cmd];
  if (!f) sair(2, readFileSync(fileURLToPath(import.meta.url), 'utf8').split('\n').slice(1, 36).map((l) => l.replace(/^\/\/ ?/, '')).join('\n'));
  await f(opcoes(resto));
}
