---
name: prototipo
description: "Shortcut for /bia-credit-hive:prototipo. The phase runs in the bchive-prototipo agent."
argument-hint: "<the design question>"
disable-model-invocation: true
---
# /bia-credit-hive:prototipo

This phase runs in the `bchive-prototipo` agent, which sets its tools and steps.

If the instructions of this chat start with `# Agent bchive-prototipo`, follow them with the text that came after the
command and ignore the rest of this file.

Otherwise, do not read or run anything. Answer in one line, in Brazilian Portuguese: select the `bchive-prototipo` agent
in the agent picker, in a new chat, and send the same request. Running the phase
outside its agent skips the contract and grants tools it should not have.
