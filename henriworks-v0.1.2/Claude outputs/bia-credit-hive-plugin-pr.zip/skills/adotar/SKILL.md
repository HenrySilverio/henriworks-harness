---
name: adotar
description: "Copies specs and decisions from HenriSpec's .sdd/ into b.IA Credit Hive, once, without moving anything."
disable-model-invocation: true
---
# /bia-credit-hive:adotar

Utility: runs in any agent with a terminal. Reply in Brazilian Portuguese.

1. Run `node .bchive/bin/bchive.mjs adotar` and show the plan. Nothing is written in this step.
2. Ask whether to apply. Only with an explicit yes, run `node .bchive/bin/bchive.mjs adotar --aplicar`.

`.sdd/` is never changed. Open HenriSpec changes are not copied: they stay in HenriSpec.
