---
name: review
description: "Shortcut for /bia-credit-hive:review. The phase runs in the bchive-review agent."
argument-hint: "<spec | (nothing) | estrito> <change-id>"
disable-model-invocation: true
---
# /bia-credit-hive:review

This phase runs in the `bchive-review` agent, which sets its tools and steps.

If the instructions of this chat start with `# Agent bchive-review`, follow them with the text that came after the
command and ignore the rest of this file.

Otherwise, do not read or run anything. Answer in one line, in Brazilian Portuguese: select the `bchive-review` agent
in the agent picker, in a new chat, and send the same request. Running the phase
outside its agent skips the contract and grants tools it should not have.
