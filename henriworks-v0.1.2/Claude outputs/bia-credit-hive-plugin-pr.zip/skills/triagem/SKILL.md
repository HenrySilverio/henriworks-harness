---
name: triagem
description: "Turns an already written ticket, incident or bug into a briefing, interviewing only the gaps. Runs in the bchive-discovery agent."
argument-hint: "<path, #file or ticket text>"
disable-model-invocation: true
---
# /bia-credit-hive:triagem

Demand rarely arrives as a blank page: it arrives as a ticket written in a hurry. Use what is written and
ask only what is missing. Interview and write in Brazilian Portuguese.

Runs in the `bchive-discovery` agent. If the instructions of this chat do not start with the line
`# Agent bchive-discovery`, do not read or run anything: answer in one line that they should select the
`bchive-discovery` agent in a new chat and send `/bia-credit-hive:triagem` again.

## Inputs

The **material** comes in the first message: path, `#file` or pasted text. The following messages are the
round answers. Material that is already a `briefing.md` (for example without the Insumos section, from the
previous format): complete that same file, without creating another folder.

## Step 0 - Contract

Read `.bchive/referencias/contrato.md`, sections 1, 3 and 4. Empty material: ask for the ticket text
and stop. Missing path: say so and stop. Do not search and do not read code: the goal is to understand the
request, not the system.

## Step 1 - Map

Read the whole material and classify each mandatory briefing section, without writing a file: covered (the
material answers it and you cite the passage), partial, or absent.

Two traps, both count as absent:

- **Solution instead of problem.** "Criar endpoint de idempotência" says what someone decided. `Problema`
  is absent; the text goes to `Contexto útil` as a solution considered by the requester.
- **Reproduction instead of expected result.** Reproduction steps describe the defect. `O que se espera`
  stays absent until someone says what should happen.

Show the map in up to six lines before asking. The ticket key, when the material has it, goes to
`Prazo e ticket`. With no key in the material, it is the first question of the first round, and it is
mandatory: without it, nothing is saved.

## Step 2 - Interview the gaps

Read `.bchive/referencias/tecnica-grilling.md`. Ask only about what is partial or absent. At most three
rounds. `Restrições` is absent in almost every ticket and always enters the first round. An ambiguous
domain term becomes a question, as in `grill`.

## Step 3 - Inputs

Read the Insumos section of `.bchive/referencias/molde-briefing.md`. With the problem and the expected
result understood, spend one round on the inputs: for each of the eight, decide with the developer whether
it applies. For each one that applies and did not come, **ask** for it, saying what and in which form. Do
not assume content, do not invent field names:

- **Telas**: the Figma links and the analysis. If the developer has no analysis, give them this request for
  a chat with the team's Figma agent (or a design-to-code agent) and ask them to save the answer as
  `figma.md` in the briefing folder: "Só análise, sem gerar código. Para cada node: componentes do design
  system, estados (habilitado, desabilitado, erro, vazio, carregando), textos exatos, tokens e o
  comportamento de cada interação."
- **Contrato de API**: the path of the type or OpenAPI the MFE consumes and of the contract the BFF exposes,
  each layer its own. A file the developer points to is delivered material: read it to transcribe field
  names with exact spelling, with origin. Do not search for others.
- **Exemplos**: at least one case with real values.
- **Regras e limites, estados e erros, configuração, dependências**: ask what is missing; what does not
  apply gets the reason.

The developer does not have the input now: save it as `pendente`, with who provides it. The briefing is
saved, but the plan does not start until the input arrives; say so in the output.

## Step 4 - Save

Read `.bchive/referencias/molde-briefing.md` and save
`.bchive/briefings/<TICKET>-<subject>/briefing.md`. If the material contradicts the interview, the
interview wins and the contradiction goes to `Contexto útil` in one line. Resolved terms go to the end of
`.bchive/glossario.md`.

## Output

The template's format, plus one line with the origin of each section, one with the contradictions, one with
the inputs, and the next action: with a pending input, what is missing and who provides it; with none, in a
new chat, agent `bchive-plan`, `/bia-credit-hive:plan <briefing path>`.
