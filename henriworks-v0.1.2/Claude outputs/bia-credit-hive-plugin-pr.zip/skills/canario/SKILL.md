---
name: canario
description: "Proves on this machine that the no-context reviewer is isolated and that the plugin hooks run. Runs in the bchive agent."
argument-hint: "[conferir | aplicar]"
disable-model-invocation: true
---
# /bia-credit-hive:canario

Proves, on this machine, that the goldfish (`bia-credit-hive:bchive-gf`) does not receive the parent conversation,
has only read and search tools, and that the hooks run. `/bia-credit-hive:init` already does this; use this
command to repeat only the canary. The result holds for the VS Code version it passed on: when it changes,
the init marks the canary PENDENTE. Reply in Brazilian Portuguese.

Runs in the `bchive` agent. If the instructions of this chat do not start with the line `# Agent bchive`, do not
read or run anything: answer in one line that they should select the `bchive` agent in a new chat and send
`/bia-credit-hive:canario` again.

- `conferir`: run `node .bchive/bin/bchive.mjs canario conferir` and show the output.
- `aplicar`: run `node .bchive/bin/bchive.mjs canario aplicar` and show the output. It only takes effect if
  the canary passed.
- No argument: the whole test, in this chat:

1. `node .bchive/bin/bchive.mjs canario preparar`. The code word is now in this chat's conversation: it is
   the bait. Never repeat it in any message of yours.
2. `node .bchive/bin/bchive.mjs pacote-revisao canario`.
3. Delegate to the subagent `bia-credit-hive:bchive-gf` (this full name) with the printed literal prompt, nothing
   before or after.
4. Save its answer, unedited, to `.bchive/estado/canario-resposta.md`.
5. `node .bchive/bin/bchive.mjs canario conferir` and show the whole output.
   - "isolamento confirmado" and the subagent call recorded: run `node .bchive/bin/bchive.mjs canario aplicar`.
   - "NENHUM evento registrado": the hooks did not run in this window. Tell the developer to run
     "Developer: Reload Window" and repeat the command.
   - "INCONCLUSIVO": the goldfish refused or explained instead of answering the lines. Do not say isolation
     was confirmed. Show the output and suggest repeating in a new chat; if the refusal repeats, change the
     chat model.
   - "ferramentas ... FORA DO PERMITIDO": the chat is running in the Local harness, which the flow does not
     support. Tell the developer to switch the chat to the Copilot harness and run `/bia-credit-hive:canario`
     again.
   - "isolamento FALHOU": show it and end the canary. The default review is not reliable on this machine
     until investigated; the way is strict mode (`estrito` in the review).

With no subagent tool in this session: say so and end the canary. Never simulate the goldfish's answer.
