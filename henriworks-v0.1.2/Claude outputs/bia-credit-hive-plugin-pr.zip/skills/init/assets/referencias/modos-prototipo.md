# Prototype modes

<!-- Copied from the plugin by /bia-credit-hive:init. Do not edit: the next init overwrites it. -->

Construction reference. Read it before writing any prototype. Load only in `bchive-prototipo`.

## What a prototype is here

Code written to answer **one** question and then be deleted. The product is the answer; the code is the
evidence that lets someone disagree based on something other than opinion. If it is worth more than the
question, it became an unplanned change: stop and write a briefing.

## Before any line

Write the question in one sentence at the top of the file and confirm it with the human. A good question
is answerable by choosing between named alternatives. "Como fica a tela de acordos?" is not one. "A lista de
acordos deve ser tabela densa, cartão por acordo, ou linha do tempo?" is.

## Mode 1 - logic and state machine

When the doubt is about behavior: how many states, what triggers a transition, what happens in an
unexpected order, what is visible in each state. Deliver **one HTML file, no build, no server**, opened
directly in the browser.

- Logic in a pure module, separate from the DOM: state in, state out.
- Labeled panels show the whole state and redraw on every interaction.
- Free exploration buttons to fire each event out of order.
- A guided script, in tabs or numbered steps, with the scenarios that matter: happy path, error path, and
  the odd order nobody can describe by talking.
- Labels in business language. Whoever asked must be able to operate the file alone.

## Mode 2 - interface variations

When the doubt is about layout, hierarchy or density, and conversation does not settle it. Deliver
**structurally different variations of the same screen**, switchable live.

- Switch by a fixed bottom bar and by a URL parameter, so the chosen variation is shareable by link.
- Structural, not cosmetic, difference: variations must disagree about what comes first, what comes
  together and what only appears on demand.
- Realistic data, in real volume and size. Short names and three-item lists hide the problem.
- Two or three variations. From four on, nobody compares.

Design system and style rules come from the project instructions. The prototype may ignore them when that
speeds up the answer, as long as the chosen variation is later built within them.

## Construction restrictions

All in the same direction: nothing that raises the cost of throwing it away. No tests. No error handling
beyond what the script needs. No persistence, database or real network call: data is fixed in the file. No
abstraction for future reuse. No authentication, environment configuration or environment variable.

## Where things go

| Artifact | Destination |
| --- | --- |
| the code | `.bchive/prototipos/<question>.html`. Never in `src/` |
| the answer | **suggested** to the human as a line for the briefing's `Contexto útil`, not saved |

This phase does not write the briefing. It returns the ready line, and the human or a new `grill` round
saves it. The conclusion is the model's, not the human's: it needs explicit acceptance before it becomes an
agreement.

## How to conclude

The agent does not open a browser. Walk the script's scenarios against the pure logic module and state each
result in writing. Then ask the human to open the file and confirm. If the prototype did not answer the
question, say so: inconclusive is a legitimate, cheap result; conclusive declared without being so is the
worst state.

## Output

At most eight lines, in Portuguese: the sharpened question; the chosen alternative or "inconclusivo"; what
the prototype revealed that nobody foresaw; the file path; and the exact line suggested for the briefing's
`Contexto útil`. Do not describe the code.
