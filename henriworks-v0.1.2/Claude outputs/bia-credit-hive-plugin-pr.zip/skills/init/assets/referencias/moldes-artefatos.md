# Artifact templates

<!-- Copied from the plugin by /bia-credit-hive:init. Do not edit: the next init overwrites it. -->

Format reference. Read it before writing any artifact in `.bchive/changes/`. Artifacts are written in
Brazilian Portuguese; headings and field labels exactly as shown here.

## proposta.md

A metadata block right below the title, then four mandatory sections, in this order, plus an optional one
at the end.

### Metadata

Four mandatory lines before the first section, plus `Início` when there is one. Content rules are in the
contract, sections 5 and 6:

```markdown
Ticket: GPCNLS-10019   (mandatory; the change-id starts with it: GPCNLS-10019-<slug>)
Branch: <branch where the implementation happens>
Base:   <branch the review compares the diff against>
Rigor:  Lite, or Full
Gatilho: <Full only: one of the six cases of contract section 6>
Início: <hash of the commit where this change starts; optional, contract section 5>
```

### Sections

| Section | Content | Size |
| --- | --- | --- |
| `## Intenção` | the real problem and for whom | two to four sentences |
| `## Escopo` | two lists: in scope (Dentro) and out of scope (Fora) | observable items |
| `## Restrições` | what must not be done, transcribed from the briefing | one line each |
| `## Critérios de aceite` | see format below | one per behavior |
| `## Divergências` | optional; see format below | two lines per item |

The out-of-scope list is not optional: scope not denied in writing comes back as rework in review.

None of the four mandatory sections stays empty. With nothing to say, write `nenhuma`. An empty section
cannot be told apart from a forgotten one.

If the change does not alter observable behavior, say so in one line at the end of the intent. If it
conflicts with a decision in force, cite the identifier in the intent and say whether the proposal
respects or replaces it. An undeclared conflict is a review finding.

## Acceptance criteria

Each criterion is a numbered item with a normative sentence using MUST, SHOULD or MAY, followed by one to
three verification conditions in the form given (Dado), when (quando), then (então).

A criterion describes observable behavior. If you had to cite a class, file or library name, you moved an
implementation detail into the criterion: fix it, except in the subsection below.

Minimum coverage per criterion: one happy path and one error path. Add an edge condition whenever there is
a numeric, time or permission limit.

Bad criterion symptoms: it says something was "processed correctly" instead of the visible result; it
starts at the action with no initial state; it asserts a method was called instead of the perceived
consequence; it chains several behaviors in one sentence.

### Change without behavior change

A pure refactor has no new behavior to describe. Here, and only here, a structural criterion is
legitimate: which symbols an artifact exports, which imports it does not have, where a test lives, that the
build passes at each isolated step. It still has to be mechanically verifiable. "The screen renders the
same" is not a criterion; "for the input fixture recorded as baseline, the result equals, field by field,
the expected value committed alongside" is.

The baseline is recorded against the current code and committed **before** the change's first commit. That
makes it an operator prerequisite, not a flow task: the plan declares it as a `Precondição:` line in the
first slice, and implement checks it before dispatching. The baseline mechanism follows the project's test
instructions; if they forbid automatic snapshots as the only logic check, the baseline is an explicit
fixture with a hand-written expected output.

A structural criterion that a lint or CI grep can verify should become a lint or grep.

## Divergências

Optional. Records a contradiction found during planning between an input document and the reality of the
code. Only a divergence that **changed** scope, constraint or criterion goes in: which document was wrong,
what reading found, what was done. Two lines per entry. Without this lock the section becomes a notebook.

## design.md

Mandatory only in Full rigor. Three `##` sections, with these exact titles and in this order:
`## Abordagem` in prose, at most one page; `## Decisões`; and `## Arquivos afetados`, each path marked new,
changed or removed. The `## Decisões` title is literal: the validator and the archive find the block by it.

Each decision records four things: the constraint that forced it, the chosen option, the discarded
alternatives with each reason, and the accepted consequence. A decision without a discarded alternative is
narrative. If the change creates an artifact rigidly shared between layers, justify it explicitly or refuse
the approach.

Each decision is a `###` subtitle followed by three or four field lines and then the four parts:

```markdown
### Idempotência por chave de contrato
Durabilidade: permanente
Capacidades: confirmacao-efetivacao
Substitui: DEC-004
```

`Durabilidade` is `local` or `permanente` and has no default: missing is an error. `Capacidades` is
mandatory in a permanent decision (or `nenhuma`). `Substitui` appears only when the decision contradicts
one in force, and only in a permanent decision.

## Slices: tarefas/NN-<slug>.md

One slice per file, two digits and a kebab-case slug: `01-cliente-acordo-existente.md`. The vertical-slice
doctrine is in the contract, section 7.

```markdown
# 02. Confirmação idempotente na tela
Demonstra: uma segunda confirmação do mesmo contrato mostra o acordo existente.
Bloqueado por: 01
Toca: src/app/feature/renegociacao/confirmacao/, src/app/domain/acordo/acordo.service.ts
Executor: bchive-implementador

## Ponteiros
- proposta.md, critérios 2 e 3
- .bchive/specs/confirmacao-efetivacao/spec.md, REQ-confirmacao-efetivacao-004
- frame do Figma: <link>, quando o executor é de tela

- [ ] 2.1 Exibir o acordo existente quando a confirmação devolve 200 com acordo
- [ ] 2.2 Teste do componente cobrindo a segunda confirmação
```

Header rules, checked by `bchive validar`:

- `Demonstra:` is observable behavior when the slice closes, never a layer state.
- `Bloqueado por:` lists the slice numbers that must close first. The first slice writes `nenhum`. The
  Verification writes `todos`.
- `Toca:` lists, comma-separated, the folders (ending in `/`), files or globs the slice may change. Declare
  the honest minimum: under-declaring creates overlap cards; over-declaring removes parallel work.
- `Executor:` is a registered or discovered name, exact (`executores.md`). Omitted, `bchive-implementador`.
- `## Ponteiros` is everything the executor reads besides the slice. A pointer, not a copy: section and
  number, not the text.

Checklist item, no exceptions: hyphen, space, `[ ]` or `[x]`, space, number `N.M` where N is the slice
number, space, description.

### Manual task

A task that code and tests cannot prove (visual check, test in a shared environment, approval) ends with
`(manual)`. When done, the line below holds the evidence, **in one line**: what, where, who and when.
Without it, the validator refuses the `[x]`.

```markdown
- [x] 3.5 Conferir o calendário com o mock local (manual)
  Evidência: conferido por Fulano de Tal em 13/11/2026, localhost com mock, faixa 13/11 a 19/12: ok
```

The evidence is the **developer's declaration**, and it is enough. Never require a screenshot, print,
video, recording or PR link, not in the task text ("register in the PR", "attach the capture"), not in the
evidence, not in review. The checkbox and evidence lines are execution records: they do not change the
spec hash nor enter the spec review. Prefer a test; the manual task exists for what cannot be automated.

### Work already on the branch

Commits before the plan that belong to the change enter as slice 01, already done:

```markdown
# 01. Trabalho já existente na branch
Demonstra: <o que esse trabalho já entrega>
Bloqueado por: nenhum
Toca: <pastas que esse trabalho alterou>
- [x] 1.1 <o que foi feito>
  Evidência: commit a1b2c3d
```

### Verification

The last slice, and only it, has no `Demonstra:` and no `Toca:`, declares `Bloqueado por: todos` and
`Escopo:` with the layers of `.bchive/verificacao.json` the change touches:

```markdown
# 05. Verificação
Bloqueado por: todos
Escopo: domain, feature

- [ ] 5.1 `node .bchive/bin/verificar.mjs GPCNLS-10019-adicionar-idempotencia` sem achado BLOQUEANTE
- [ ] 5.2 Cada critério de aceite mapeado para ao menos um teste
```

Whole-project lint and tests do not go in: they fail on errors the change did not create.

### Index and rules

`tarefas/index.md` is generated by `node .bchive/bin/bchive.mjs fatias <id> --gravar`. Never by hand.

- A task fits in one session. So does a slice. If not, cut the slice thinner; do not add tasks.
- Every task has an observable criterion. "Ajustar o serviço" is not a task.
- Every acceptance criterion appears in at least one slice.
- A change that does not fit in a few slices is two changes: declare the cut line and plan the first.

## briefing.md (in the change)

A literal copy of the briefing given to the plan, with no edit. It keeps the original request next to the
agreement. It is not a source of truth for any later phase.

## deltas.md

Format in `specs-e-deltas.md`. Only exists when the change alters observable behavior.

## resumo.md

Written by the archive before moving the folder. It is the **pull request description**: it goes to the PR,
to the Jira task and, if any, to Confluence. Whoever reads it does not know the flow and cannot see
`.bchive/`. In Brazilian Portuguese, with these exact headings:

```markdown
## <tipo>(<escopo>): <o que muda, no imperativo>

**Ticket:** <Ticket>

### Contexto
<o problema em duas ou três frases: quem era afetado, o que acontecia, por que importa>

### O que mudou
- <cada mudança de comportamento ou de estrutura, pelo efeito, não pelo arquivo>

### Como testar
1. <passo a passo para ver a mudança funcionando, como um revisor ou QA faria>
2. <resultado esperado em cada cenário relevante, inclusive os de erro>

### Evidências manuais
- <cada tarefa (manual) concluída: o que foi conferido, onde, por quem, quando e o resultado, copiado da linha `Evidência:`>
- ou: nenhuma conferência manual

### Risco do merge
- Porta: <mão dupla, se reverter o commit desfaz tudo; mão única, se há migração, dado gravado,
  contrato publicado ou efeito fora do repositório, e o que muda para reverter>
- Raio de impacto: <quem chama o que mudou, pelo mapa: telas, serviços, consumidores do endpoint>

### Decisões técnicas
- <cada escolha que um revisor questionaria, com o porquê e a alternativa descartada>
- ou: nenhuma decisão fora do padrão do projeto

### Fora do escopo
- <o que ficou de fora de propósito>

### Pontos para o revisor humano
- <cada cartão de sobreposição em aberto: arquivo e o que ficou para decidir>
- <revisão de código aceita apesar de reprovada: quem aceitou, o motivo e cada achado aceito>
- ou: nenhum

### Testes
- <testes criados ou alterados, pelo que cobrem>
- Lint, tipos e testes das áreas alteradas sem erro novo; <N> erro(s) que já existiam e não foram tocados

### Arquivos
<o resumo do diff --stat, agrupado por pasta quando passar de oito arquivos>
```

Rules: every line comes from a change artifact, from Git or from the map, nothing from conversation
memory. The title follows the repository's commit subject pattern. No mention of change, change-id,
slice, task, acceptance criterion, delta, spec, `DEC-`, `REQ-`, verdict, agent or a `.bchive/` path:
the archive refuses. Sources: the briefing for Contexto; the proposal for O que mudou, Fora do escopo and
Como testar; the design for Decisões técnicas; `bchivemap affected` over the diff files for Raio de impacto;
the diff and the verifier for Testes and Arquivos; `tarefas/sobreposicoes.md` for the Pontos. A section with
no content keeps its "ou" sentence, never omitted.
