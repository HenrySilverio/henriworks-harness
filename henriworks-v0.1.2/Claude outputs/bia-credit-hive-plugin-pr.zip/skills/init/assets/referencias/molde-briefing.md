# Briefing template

<!-- Copied from the plugin by /bia-credit-hive:init. Do not edit: the next init overwrites it. -->

Format reference for the discovery output. Read it before saving the file. This template is the contract
between discovery and plan: sections and order are exactly what the plan expects. Do not create, rename or
reorder sections. The briefing is written in Brazilian Portuguese.

## Name and location

```code
.bchive/briefings/<TICKET>-<assunto>/
└── briefing.md
```

One folder per need; the file inside is always `briefing.md`. The folder holds what comes along (ticket
export, Figma analysis, contract copy) instead of scattering attachments at the root.

The folder starts with the exact Jira key (`GPCNLS-10019`), then the subject: `GPCNLS-10019-confirmacao-duplicada`.
The key is mandatory: it ties briefing, change, archive and knowledge record to the task. Subject in
kebab-case, a noun for the problem, at most four words. It names the **pain**, not the solution:
`confirmacao-duplicada`, not `adicionar-idempotencia`.

Create the folder and the file in the same operation. If the folder exists, do not overwrite: ask whether
to update that briefing or create another subject. An attachment goes into the folder with a descriptive
name and is cited in `Contexto útil` by relative path.

## Sections

| Section | Mandatory | Content |
| --- | --- | --- |
| `## Problema` | yes | today's symptom and for whom, with no solution |
| `## O que se espera` | yes | the visible result, from the user's point of view |
| `## Restrições` | yes | what must not be done, touched or broken. One line each |
| `## Fora do escopo` | yes | what someone would think is included and is not |
| `## Insumos` | yes | the inputs table below: what the plan will read, and where it is |
| `## Contexto útil` | no | paths, links, owning team, solution already considered by the requester |
| `## Prazo e ticket` | yes | the Jira key (same as the folder) and the deadline, if any |

File title: `# Briefing - <assunto em uma linha>`.

## Insumos

The plan reads only what is here. A missing input becomes a requirement discovered in review, and each such
finding costs a whole replanning round. So the table always has the eight rows, in this order, and
`bchive briefing <path>` checks it before the plan:

```markdown
## Insumos

| Insumo | Situação | Onde | Observação |
| --- | --- | --- | --- |
| Ticket e critérios do PO | ok | Jira GPCNLS-10019, critérios copiados em `O que se espera` | |
| Telas (Figma) e análise | ok | `figma.md` (nodes 13323-100576, 13323-97372) | análise feita pelo agente de Figma |
| Contrato de API por camada | ok | MFE: `src/app/core/api/oferta.types.ts`; BFF: `contrato-bff.md` | campos: dataMinimaVencimentoPrimeiraParcela |
| Regras de negócio e limites | ok | seção `O que se espera` | faixa inclui as duas pontas |
| Estados de tela e erros | ok | `figma.md`, estados | dia, mês e ano fora da faixa desabilitados |
| Configuração e parametrização | não se aplica | | limites vêm do response, sem parâmetro novo |
| Exemplos concretos | ok | seção `O que se espera` | faixa 20/12/2026 a 15/01/2027 |
| Dependências de outros times | não se aplica | | BFF já devolve os dois campos |
```

| Situação | When | Mandatory column |
| --- | --- | --- |
| `ok` | the input exists and was delivered | `Onde`: path in backticks (relative to the briefing folder or the repository root), link, or the briefing section |
| `não se aplica` | the change does not need it | `Observação`: the reason, one line |
| `pendente` | needed and not delivered yet | `Observação`: who provides it. **The plan does not start** |

Per input:

- **Telas.** A Figma link alone does not count: the plan does not read Figma. The analysis (components,
  states, texts, tokens, disabled behavior) goes into `figma.md` in the briefing folder.
- **Contrato de API, por camada.** MFE and BFF each have their own: the type or OpenAPI the MFE consumes and
  the contract the BFF exposes, cited separately. Never one file shared by both layers. Field names keep
  the contract's exact spelling, even with typos.
- **Exemplos.** At least one case with real values (dates, numbers, profile). Verifiable acceptance
  criteria come from them.
- **Regras e limites.** Values, ranges and whether the ends are included, the source of each limit, what
  happens when the data does not come.

## Gap convention

An unanswered question becomes one line **in the section where the answer belongs**, at the end of it:

```markdown
**[NÃO RESPONDIDO]** <a pergunta exata, como foi feita, em uma linha>
```

Write the question, not an assumption about the answer. The right section is the answer's, not the topic's.
Only an **edge** gap becomes a marker. A blocking gap prevents saving the file (contract section 4).

## Origin convention

Text from delivered material, not from the conversation, appears as a contiguous quote block preceded by
the origin line:

```markdown
> Origem: INC-4472, campo Descrição.
>
> O cliente consegue clicar em confirmar mais de uma vez enquanto a resposta não volta.
```

Text outside the block came from the conversation. Reviewers need to know what a person stated and what was
copied from a system: an outdated ticket is the common case.

## Writing rules

- Plain Portuguese. No architecture jargon, no acronym unexpanded on first use.
- One page. A section with one good line beats five lines of filler.
- No acceptance criteria, no dado/quando/então, no MUST/SHOULD: that belongs to the plan.
- No class, file, library or design-pattern name in Problema and O que se espera. In `Contexto útil`, they
  are allowed and useful.
- No interview transcript. The briefing is the result, not the minutes.
- A constraint is one line, in the negative or maintenance imperative: "não alterar o contrato da API de
  efetivação".

## Command output

After saving, at most eight lines in the chat: file path; rounds used; how many gaps remain and in which
sections; whether something the requester asked for went out of scope; and the next command, in a new chat.
Do not reproduce the briefing in the chat.
