# Interview technique

<!-- Copied from the plugin by /bia-credit-hive:init. Do not edit: the next init overwrites it. -->

Reference for conducting the interview. Read it before any round of questions. The interview itself is in
Brazilian Portuguese: the example questions below are kept in Portuguese on purpose.

## Dependency order

The order is dependency, not preference: each block is only answerable after the previous one. Asking for
constraints before knowing what will change produces generic, useless answers.

| Order | Block | What you look for | Briefing section |
| --- | --- | --- | --- |
| 1 | symptom and owner | what goes wrong today, and with whom | Problema |
| 2 | expected result | what the person would see differently if it were solved | O que se espera |
| 3 | limits | what must not be touched, broken or changed | Restrições |
| 4 | boundary | what someone would reasonably think is included | Fora do escopo |
| 5 | trail | paths, ticket, owning team, deadline | Contexto útil |

Blocks 1 and 2 almost always fit in the same round. Blocks 3 and 4 almost never fit before the second.
Block 5 is the last round, often a single question.

## How to ask

**Ask in the language of whoever uses the system, never in the language of whoever builds it.** Jargon does
not produce an answer: it produces silence or polite agreement, which is worse.

| Do not ask | Ask |
| --- | --- |
| Quais são os requisitos não funcionais? | Se isso acontecer mil vezes numa sexta de pagamento, o que quebra primeiro? |
| Precisa ser idempotente? | Se a pessoa clicar duas vezes, o que deveria acontecer na segunda? |
| Qual o SLA? | Quanto tempo a pessoa espera olhando a tela antes de achar que travou? |
| Há dependência de outros times? | Quem mais precisa aprovar ou mexer em alguma coisa para isso funcionar? |
| Qual o comportamento em caso de exceção? | Quando dá errado hoje, quem descobre, e como? |

**Force a choice instead of accepting agreement.** An open question that accepts "yes" confirms the
ambiguity. Offer two concrete alternatives and ask them to pick one, or to say neither fits.

Bad: "o segundo clique deve ser bloqueado?"
Good: "no segundo clique, o certo é (a) mostrar o acordo que já foi criado, ou (b) mostrar erro dizendo que
já existe acordo? Se nenhuma das duas, qual?"

**One question is one question.** Two question marks on one line get one answer, and you lose half.

## The three questions that are almost always missing

Ask all three in every interview, unless already answered:

1. **O que acontece hoje quando dá errado?** Reveals current behavior nobody documented that the change must
   not break.
2. **Quem descobre o problema, e por qual caminho?** Reveals integrations, alerts, reports and neighboring
   teams nobody mentioned.
3. **O que absolutamente não pode mudar nesta entrega?** Fills Restrições, the only briefing section the
   plan cannot infer.

## Signs the question cannot be interviewed

When progress depends on one of these, stop and recommend `bchive-prototipo`:

- the answer depends on seeing the screen;
- two people disagree about layout, hierarchy or order of steps;
- the state machine has more than three states and nobody can describe the transitions in one sentence;
- the answer depends on what the real data looks like, and nobody has seen it.

When leaving, state the exact question the prototype must answer.

## Signs these are two changes

Stop and offer two briefings when: the Problem needs "and" to join two symptoms with different owners; the
constraints of one part do not apply to the other; one part could go to production alone and still be
worth something. The last one is decisive.

## Conducting mistakes

- **Building on a vague answer.** "Acho que sim" is a gap, not an answer. Rephrase in the next round, with
  alternatives.
- **Accepting a solution as the problem.** When block 1 comes as "precisamos de um cache", step back: "o que
  está lento hoje, e para quem?". The proposed solution goes into `Contexto útil`, never into `Problema`.
- **Asking what can be read.** If the ticket already says it, confirm in one line and move on.
- **Grilling after it is settled.** A round that changes nothing is a stop signal. The product is a
  one-page briefing.
