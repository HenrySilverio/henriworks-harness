# Review axes

<!-- Copied from the plugin by /bia-credit-hive:init. Do not edit: the next init overwrites it. -->

Reference for the review phase and for the goldfish `bchive-gf`. Read it only there.

## Why isolated

The author of a document cannot see the assumption they never wrote: to them it is obvious. A reviewer
without the conversation trips exactly on it. So each stage and each axis runs in a new subagent, with a
script-generated package, and none sees another's verdict.

Isolation is verified, not assumed: `bchive canario` proves, on the machine, that the parent conversation does
not reach the subagent. Until the canary passes, treat the review as weaker and say so in the report.

## Severity and verdict

Every finding has a severity and evidence:

```
[bloqueante|importante|sugestão] <file>:<line or section> — what is wrong — the concrete case — the smallest fix
```

The severity tags stay in Portuguese exactly as written. Findings are written in Brazilian Portuguese.

- **bloqueante**: only in these cases, and the finding says which:
  1. an acceptance criterion that cannot be verified, or that contradicts another;
  2. observable behavior that two executors would build differently, and neither the briefing, the
     inputs nor the slice pointers answer it (read them before raising it);
  3. risk of data loss, a security flaw or a regulatory breach;
  4. in code review: a bug **the diff introduced**, an uncovered criterion, a violated constraint.
- **importante**: should change, but does not block the next step.
- **sugestão**: an improvement; ignore it without guilt.

Never blocking, however serious it looks:

- what the proposal declares as out of scope ("Fora do escopo"), or what belongs to another layer (an API
  returning an invalid limit is the problem of whoever maintains it);
- **internal rendering of a third-party component** (design system, library): it is proven with a manual
  task and evidence; do not demand an automated test of how the component draws;
- hardening behavior that existed before the diff: it is `[importante]`, "another change";
- asking for more tests or more evidence for a criterion that already has a test or a manual task
  covering it;
- **the form of manual task evidence**: the `Evidência:` line with what, where, who and when is the
  developer's declaration, and it is enough. Never demand a screenshot, print, video, per-scenario result
  or PR link, even if the task text asks for one: this rule beats the slice text.

**Rounds.** A round-2 package brings the previous verdict of the same stage or axis. First check whether
its blocking findings were resolved. A new finding is blocking only if it meets the rubric above **and**
appeared with this round's change. After two failed rounds the script does not generate a third: the
decision is human (`--apesar`, `rodada-extra` or splitting the change). The cap counts only verdicts of
the current rubric (the verdict's `Régua:` line): when the rubric changes, the count restarts.

A finding without a concrete case does not go in: "this input leads to this wrong result". No "consider",
no style taste, no vague concern. Do not praise, soften or apologize. Start with what is wrong.

One verdict per stage or axis, never consolidated: **REPROVADO** if there is at least one blocking
finding; **APROVADO** otherwise. "Approved with caveats" is a polite REPROVADO.

First line of the verdict: `# <label> - APROVADO` or `# <label> - REPROVADO`. Spec label:
`spec-<stage>`; code label: the axis name. Second line: `Spec revisada: <hash>` or
`Commit revisado: <HEAD>`, exactly as the package asked. Third: `Achados: <n>`. Then the findings in
order of severity.

## Spec review

Lite: `design` (with the zoom-out view), then `prontidao`. Full: `zoom-out`, `compreensao`, `design`,
`zoom-out-2`, `prontidao`, in this order. Structure and style are not a stage: format is a gate of
`bchive validar`, and the validator already ran.

| Stage | Lens in the package | Question |
| --- | --- | --- |
| `zoom-out` | `zoom-out` | does it need to exist? is there something simpler, or existing, that solves it? |
| `compreensao` | `compreensao` | can someone without context understand what and why, without asking? |
| `design` | `design` | where does it break: risk, load, cost, coupling, contract between layers |
| `zoom-out-2` | `zoom-out` | after the adjustments, did the solution grow beyond the problem? |
| `prontidao` | `prontidao` | does each slice run with no pending decision, in a fresh context, only with its pointers? |

The spec verdict is bound to the **spec hash** (proposal, design, deltas and slice text, without checklist
marks and evidence). A spec changed after the review invalidates that version's verdict.

**Approval.** The gate is human: `node .bchive/bin/bchive.mjs aprovar-spec <id> --por "<name>"`. With a
stage REPROVADO or missing, the command refuses unless `--apesar "<reason>"` is given, which is recorded.
The agent never runs this command: it shows the result and asks for the decision.

**Resolution.** An accepted finding becomes a spec edit through the plan with `replanejar:`, which records
in `## Divergências` what changed and why. A rejected finding stays in the verdict.

## Code review

Three axes, three goldfish, three verdicts. Code may meet the proposal and break every repository
standard, or follow every standard and implement something else, or do both and break a caller outside
the diff. The three failures are independent.

Before the packages, the orchestrator runs `node .bchive/bin/verificar.mjs <id> --salvar`: the output
goes to `revisao/verificacao-<HEAD>.txt` and is the only source of lint, types and tests. No goldfish runs
tools or reclassifies that output.

### Spec axis (lens `spec`)

Reads the proposal, the slices, the deltas, the design, the diff and the verification.

- Acceptance criterion: covered, partially covered or not covered. Covered by code without a test is
  partial.
- A `[x]` task needs evidence in the diff (a changed file) or a command. A `(manual)` task has the
  `Evidência:` line as evidence: accept the declaration, point out only a missing what, where, who or
  when. Never ask for a screenshot, print, video or PR link.
  A `Trabalho já existente na branch` task has a commit between `Início` and HEAD as evidence.
- Every closed slice, except the Verification, demonstrates its own `Demonstra:` line in the code.
- Deltas in both directions: every new behavior criterion has a delta; every delta has a criterion. A delta
  that describes intent instead of final text fails.
- A permanent decision has the four parts and `Capacidades`; none contradicts one in force without
  `Substitui:`; the local or permanent classification survives the three tests.
- An open overlap card: raise it as important, with the file.

Fails with: uncovered or untested criterion; task without evidence; slice that does not demonstrate; scope
beyond the proposal; violated constraint; a finding in a delta or decision; BLOQUEANTE in the
verification. Third-party component behavior covered by a manual task with evidence is covered.

### Standards axis (lens `padroes`)

Does not read the proposal, on purpose: without it, a violation cannot be rationalized as "needed for
criterion 3". Reads the diff, `.bchive/padroes.md`, the instructions whose `applyTo` matches the diff
(the package already lists only those) and the verification.

- Judge the diff, not the file. A violation on a line the change did not touch is pre-existing: it does
  not fail and is not a finding.
- `.bchive/padroes.md` marks with `[grave]` a rule whose single violation already fails. An unmarked
  rule fails with more than one finding on the same subject. A rule from a versioned instruction follows the
  general condition. A rule from a file the package marks "not declared as a team rule" may be the
  developer's own preference: at most `[importante]`, never blocking.
- Instruction files may not exist. Judge only by what the package lists; an instruction you see in your
  context but not in the package does not count.
- With no written standard, use the baseline below and declare that the repository has no standard: that
  is an important finding, and the baseline alone never fails.
- A finding that a lint, type check or CI grep would catch also goes in as a recommendation to promote it
  to lint.

Baseline: a function that can only be understood by reading all of it; logic duplicated in the diff or
with an obvious neighbor; a boolean parameter that switches two behaviors; a nested conditional that is an
unnamed business rule; data exposed between layers in the producer's internal format; an artifact rigidly
shared between layers created without justification; a swallowed error; a repeated magic value; a name
for the mechanism instead of the purpose; a test that asserts a call instead of a consequence.

### On-call axis (lens `plantao`)

The senior engineer who gets woken up when it breaks. Reads the diff, the map's impact radius, the
verification, and the code the diff touches: callers of each changed function, what it calls, the tests.

In order: correct, secure, handles the real load, tested, fast, lean.

1. **Bug**: wrong result, edge case (empty, zero, last item, rounding, time zone), a caller broken by a
   signature or return change, a fix made in one caller while the shared function is still broken.
2. **Risk**: injection, secret, user input without validation at the boundary, swallowed error,
   out-of-order write, data loss.
3. **Load**: right for one user, wrong for many: check-then-write race, per-item query, a list that only
   grows, per-process state that needed to be shared. State the load you assumed.
4. **Missing test**: new risky logic (branch, parser, money, security, write, bug fix) without a test that
   fails when it breaks. One good test, not coverage.
5. **Slowness** that matters. A small gain is a suggestion.
6. **Lean**: code that did not need to exist; a helper the repository already has (give the path); a
   standard library or native feature that already solves it; an abstraction with one implementation; a
   copy that must change together.

A `shortcut: <limit>, <when to upgrade>` comment is a recorded decision, not a finding, unless the expected
load already exceeds the limit. Propose the smallest fix; prefer the one that deletes code. Never propose a
layer, framework or setting the problem does not ask for.

Fails with: bug, security flaw, data loss, breaking under the expected load, risky logic without a test,
**as long as the diff introduced it**. A problem that existed before the diff (the parser already accepted
that, the limit already came like that from the API) is `[importante]`, "another change": fixing it here
changes behavior outside the agreement and the spec axis fails next. Never ask for hardening that changes
behavior the proposal says to preserve.

## Recording the verdict

The goldfish returns the text. The orchestrator writes the answer, unedited, to
`.bchive/changes/<id>/rascunhos/<target>.md` and runs:

```
node .bchive/bin/bchive.mjs gravar-veredito <id> <target> --de .bchive/changes/<id>/rascunhos/<target>.md
```

The script checks the first line and the hash or HEAD, refuses a dirty tree in code review, adds the
reviewed local files with each one's hash, and writes `revisao/<axis>-<HEAD>.md` or
`revisao-spec/<stage>-<hash>.md`. It never overwrites: a repeated review on the same version becomes `-2`,
`-3`, and the highest number wins.

The archive requires the three code axes APROVADO at the current HEAD. Approve, keep coding and archive
does not pass: HEAD changed.
