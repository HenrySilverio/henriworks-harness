# Marcas sobre o núcleo HenriWorks

O núcleo (HenriWorks) é público e não sabe que uma marca existe. Cada harness do Bia Credit é um perfil aqui, com prefixo próprio (o Atlas usa `bcatlas`; `biacred` fica reservado ao guarda-chuva), num
repositório privado, que gera a sua distribuição a partir de uma versão do núcleo. Correção feita no
núcleo chega à marca na próxima geração; nada é corrigido duas vezes.

```
marcas/
  gerar.mjs               gerador (Node 20+, sem dependência)
  bia-credit-atlas/
    perfil.json           nome, autor, renomes, termos proibidos
    logo-bia.svg          lockup BIA CREDIT, letras cinza (fundo claro)
    logo-bia-escuro.svg   lockup BIA CREDIT, letras claras (fundo escuro)
    simbolo-bia.svg       só o símbolo (favicon e destaque da documentação)
    fonte/                SVG oficial da BIA (Liquid) e o script que compõe o lockup
    sobrepor/             arquivos da marca copiados por cima (SVGs do README)
```

## Gerar o Bia Credit Atlas (Git Bash)

```bash
node marcas/gerar.mjs pacote <pasta-do-henriworks> marcas/bia-credit-atlas/perfil.json bia-credit-atlas-v0.1.2
node bia-credit-atlas-v0.1.2/testes/smoke.mjs        # esperado: 38/38 passos ok
node marcas/gerar.mjs doc <henriworks-doc.html> marcas/bia-credit-atlas/perfil.json bia-credit-atlas-doc.html
```

O `doc` usa uma documentação do núcleo com os marcadores `marca:favicon`, `marca:logo` e `marca:hero`.
Com `logo-bia.svg` na pasta do perfil, o logo entra como data URI (funciona offline e no SharePoint).
Sem ele, a documentação sai sem logo nenhum: nunca com o logo de outra marca.

## O que o perfil troca

| Núcleo | Bia Credit Atlas |
| --- | --- |
| HenriWorks Engineering Harness | Bia Credit Atlas |
| `/hwk-*`, agentes `hwk-*`, `hwk.mjs` | `/bcatlas-*`, agentes `bcatlas-*`, `bcatlas.mjs` |
| `.henriworks/` | `.bcatlas/` |
| `henrimap` | `bcatlasmap` |
| `HENRIWORKS_*` (variáveis) | `BCATLAS_*` |
| exemplos `ACME-10019` | `GPCNLS-10019` |

`preservar` protege termos que não são da marca (HenriSpec, o nome do autor). Depois de gerar, o script
procura `proibidos` no resultado, em conteúdo e em nome de arquivo, e falha se achar algum.

## Limites conhecidos

- Os SVGs do README em `sobrepor/` foram gerados à parte (skin arcade, acento #cc092f). Se o README do
  núcleo ganhar um componente novo, gere o SVG da marca de novo.
- Renomear é troca de texto: termo novo do núcleo que contenha `hwk` ou `henriworks` vira
  `bcatlas` automaticamente; termo que não deva virar entra em `preservar`.
