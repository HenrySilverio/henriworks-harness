#!/usr/bin/env node
// Gera uma distribuição com outra marca a partir do núcleo HenriWorks. Node 20+, sem dependência.
//
//   node gerar.mjs pacote <pasta-do-nucleo> <perfil.json> <saida>
//   node gerar.mjs doc    <doc-do-nucleo.html> <perfil.json> <saida.html>
//
// O núcleo não sabe que a marca existe: o perfil diz o que renomear (conteúdo e caminhos), o que
// remover e o que sobrepor. Assim o núcleo segue público e a marca fica num repositório à parte.
// Depois de gerar, o script procura no resultado os termos de "proibidos" e falha se achar algum.

import { readFileSync, writeFileSync, mkdirSync, readdirSync, statSync, existsSync, rmSync, copyFileSync } from 'node:fs';
import { join, dirname, relative, resolve, extname } from 'node:path';

const BINARIOS = new Set(['.png', '.jpg', '.jpeg', '.gif', '.ico', '.zip', '.woff', '.woff2']);
const sair = (c, m) => { (c ? console.error : console.log)(m); process.exit(c); };
const barra = (p) => p.split('\\').join('/');

function listar(dir, base = dir) {
  const out = [];
  for (const n of readdirSync(dir)) {
    const p = join(dir, n);
    if (statSync(p).isDirectory()) out.push(...listar(p, base));
    else out.push(barra(relative(base, p)));
  }
  return out;
}

function globRe(g) {
  const s = g.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*\*\/?/g, '\u0000').replace(/\*/g, '[^/]*').replace(/\u0000/g, '.*');
  return new RegExp(`^${s}$`);
}

function carregarPerfil(p) {
  const perfil = JSON.parse(readFileSync(p, 'utf8'));
  for (const k of ['nome', 'renomear', 'proibidos']) if (!perfil[k]) sair(2, `perfil sem "${k}"`);
  perfil.dir = dirname(resolve(p));
  perfil.preservar ||= [];
  perfil.remover ||= [];
  return perfil;
}

// Renomeia preservando os termos protegidos (ex.: HenriSpec, que é outro produto).
function marcar(texto, perfil) {
  const guarda = [];
  let t = texto;
  perfil.preservar.forEach((p, i) => {
    t = t.split(p).join(`\u0001${i}\u0001`);
    guarda[i] = p;
  });
  for (const [de, para] of perfil.renomear) t = t.split(de).join(para);
  return t.replace(/\u0001(\d+)\u0001/g, (_, i) => guarda[Number(i)]);
}

function proibidosEm(texto, perfil) {
  const limpo = perfil.preservar.reduce((t, p) => t.split(p).join(''), texto);
  return perfil.proibidos.filter((p) => new RegExp(p, 'i').test(limpo));
}

function cmdPacote([origem, pPerfil, saida]) {
  if (!origem || !pPerfil || !saida) sair(2, 'uso: node gerar.mjs pacote <pasta-do-nucleo> <perfil.json> <saida>');
  const perfil = carregarPerfil(pPerfil);
  const remover = perfil.remover.map(globRe);
  if (existsSync(saida)) rmSync(saida, { recursive: true, force: true });
  let n = 0;
  for (const rel of listar(origem)) {
    if (remover.some((r) => r.test(rel))) continue;
    const destino = join(saida, marcar(rel, perfil));
    mkdirSync(dirname(destino), { recursive: true });
    if (BINARIOS.has(extname(rel).toLowerCase())) copyFileSync(join(origem, rel), destino);
    else writeFileSync(destino, marcar(readFileSync(join(origem, rel), 'utf8'), perfil));
    n++;
  }
  // Sobreposição: arquivos da marca, copiados como estão (logo, SVGs do README).
  const sob = perfil.sobrepor ? join(perfil.dir, perfil.sobrepor) : null;
  if (sob && existsSync(sob)) {
    for (const rel of listar(sob)) {
      mkdirSync(dirname(join(saida, rel)), { recursive: true });
      copyFileSync(join(sob, rel), join(saida, rel));
      n++;
    }
  }
  // README: bloco da marca no topo (logo), se o perfil trouxer.
  const pr = join(saida, 'README.md');
  if (perfil.readmeTopo && existsSync(pr)) writeFileSync(pr, `${perfil.readmeTopo.join('\n')}\n\n${readFileSync(pr, 'utf8')}`);
  // Manifesto: autor da marca.
  const pm = join(saida, 'manifesto.json');
  if (perfil.autor && existsSync(pm)) {
    const m = JSON.parse(readFileSync(pm, 'utf8'));
    m.autor = perfil.autor;
    writeFileSync(pm, `${JSON.stringify(m, null, 2)}\n`);
  }
  const achados = [];
  for (const rel of listar(saida)) {
    if (BINARIOS.has(extname(rel).toLowerCase())) continue;
    for (const p of proibidosEm(`${rel}\n${readFileSync(join(saida, rel), 'utf8')}`, perfil)) achados.push(`${rel}: ${p}`);
  }
  if (achados.length) sair(1, `termo de outra marca no resultado:\n  ${achados.slice(0, 30).join('\n  ')}`);
  console.log(`${perfil.nome}: ${n} arquivo(s) em ${saida}, sem termo proibido.`);
}

// Documentação: renomeia o texto e troca favicon e logo pelos da marca (data URI, funciona offline).
function cmdDoc([origem, pPerfil, saida]) {
  if (!origem || !pPerfil || !saida) sair(2, 'uso: node gerar.mjs doc <doc.html> <perfil.json> <saida.html>');
  const perfil = carregarPerfil(pPerfil);
  let html = marcar(readFileSync(origem, 'utf8'), perfil);
  const trocar = (nome, novo) => {
    const re = new RegExp(`<!-- marca:${nome}:inicio -->[\\s\\S]*?<!-- marca:${nome}:fim -->`);
    if (!re.test(html)) sair(2, `doc sem os marcadores marca:${nome}`);
    html = html.replace(re, novo);
  };
  // logo: lockup para fundo claro; logoEscuro: para fundo escuro; simbolo: favicon e destaque.
  const arq = (k) => (perfil[k] && existsSync(join(perfil.dir, perfil[k])) ? join(perfil.dir, perfil[k]) : null);
  const uri = (p) => `data:image/svg+xml;base64,${readFileSync(p).toString('base64')}`;
  const [pLogo, pEscuro, pSimbolo] = [arq('logo'), arq('logoEscuro'), arq('simbolo')];
  if (pLogo) {
    const claro = uri(pLogo);
    const escuro = pEscuro ? uri(pEscuro) : claro;
    const simbolo = pSimbolo ? uri(pSimbolo) : claro;
    // O tema segue a mesma regra da página: preferência do sistema, ou data-theme escolhido.
    const css = '<style>.mlogo--e{display:none}@media (prefers-color-scheme: dark){:root:not([data-theme="light"]) .mlogo--c{display:none}:root:not([data-theme="light"]) .mlogo--e{display:block}}:root[data-theme="dark"] .mlogo--c{display:none}:root[data-theme="dark"] .mlogo--e{display:block}</style>';
    trocar('favicon', `<link rel="icon" type="image/svg+xml" href="${simbolo}">\n  ${css}`);
    const img = (src, cls) => `<img class="mlogo ${cls}" src="${src}" alt="${perfil.nome}" height="30" style="height:30px;width:auto">`;
    // produtoNoLogo: nome do produto ao lado da marca guarda-chuva (ex.: BIA CREDIT · Atlas).
    const produto = perfil.produtoNoLogo ? `<span style="border-left:1px solid currentColor;padding-left:.6em;margin-left:.1em;opacity:.85">${perfil.produtoNoLogo}</span>` : '';
    trocar('logo', `${img(claro, 'mlogo--c')}${img(escuro, 'mlogo--e')}${produto}`);
    trocar('hero', `<figure class="hero__marca" aria-hidden="true"><img src="${simbolo}" alt="" style="width:min(220px,40vw);height:auto;display:block;margin:auto"></figure>`);
    console.log(`logo: ${perfil.logo}${pEscuro ? `, ${perfil.logoEscuro}` : ''}${pSimbolo ? `, ${perfil.simbolo}` : ''}`);
  } else {
    // Sem o arquivo da marca: nenhum logo de outra marca fica no lugar; o nome fica em texto.
    trocar('favicon', '');
    trocar('logo', `<span>${perfil.nome}</span>`);
    trocar('hero', '');
    console.log(`AVISO sem ${perfil.logo || 'logo no perfil'}: a documentação sai sem logo e sem favicon. Coloque o SVG e gere de novo.`);
  }
  const achados = proibidosEm(html, perfil);
  if (achados.length) sair(1, `termo de outra marca na documentação: ${achados.join(', ')}`);
  mkdirSync(dirname(resolve(saida)), { recursive: true });
  writeFileSync(saida, html);
  console.log(`${perfil.nome}: documentação em ${saida}`);
}

const [cmd, ...resto] = process.argv.slice(2);
if (cmd === 'pacote') cmdPacote(resto);
else if (cmd === 'doc') cmdDoc(resto);
else sair(2, 'uso: node gerar.mjs pacote <nucleo> <perfil.json> <saida> | doc <doc.html> <perfil.json> <saida.html>');
