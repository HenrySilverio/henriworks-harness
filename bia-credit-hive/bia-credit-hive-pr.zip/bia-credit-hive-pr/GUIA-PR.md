# Levar o plugin completo do b.IA Credit Hive para o repositório

Arquivos usados (deixe em `~/Downloads`):

- `bia-credit-hive-plugin-pr.zip`: o plugin completo, sem `plugin.json`.
- `atualizar-plugin-json.mjs`: troca só `description` e `author` do `plugin.json`. A versão fica com o release-please.

## Branch

```
feat/plugin-completo
```

## Comandos (Git Bash, na raiz do clone do repositório do plugin)

```bash
cd <pasta do clone do bia-credit-hive>
git switch main && git pull

git switch -c feat/plugin-completo

# 1. Tira a versão de sondagem (o zip traz tudo de novo; plugin.json, CONTRIBUTING.md e .github/ ficam)
git rm -r -q com.github.copilot skills scripts README.md

# 2. Põe o plugin completo
unzip -q -o ~/Downloads/bia-credit-hive-plugin-pr.zip -d .
# sem unzip no seu Git Bash:
# powershell -NoProfile -Command "Expand-Archive -Force '$(cygpath -w ~/Downloads/bia-credit-hive-plugin-pr.zip)' ."

# 3. Description e author do plugin.json
node ~/Downloads/atualizar-plugin-json.mjs

# 4. Teste de fumaça (sem rede, numa pasta temporária): esperado "46/46 passos ok"
node testes/smoke.mjs

# 5. Confere e commita
git add -A
git status --short          # esperado: ~69 A, 5 M (README, 2 agentes, hooks.json, plugin.json), 5 D (sondagem)
git commit -m "feat: plugin completo do b.IA Credit Hive" -m "Substitui a versão de sondagem pelo fluxo completo: 9 agentes, 18 comandos /bia-credit-hive:*, hooks em 6 eventos e núcleo Node sem dependência."
git push -u origin feat/plugin-completo
```

Abra a PR para a `main` com o título e o texto abaixo. Se o `smoke` falhar no Windows, não suba: mande a
saída inteira (não tem conteúdo de projeto).

## Título da PR

```
feat: plugin completo do b.IA Credit Hive
```

## Texto da PR

```markdown
## Resumo

Substitui a versão de sondagem pelo plugin completo do b.IA Credit Hive: leva uma demanda do ticket do Jira até a PR com plano em fatias, implementação por fatia (inclusive com agentes de outros plugins da stack), revisão por um subagente que não viu a conversa, OK do QA antes de fechar e relatório de uso só com contagens e tokens.

Melhor uso hoje: VS Code com o chat no harness Copilot, ou GitHub Copilot app. O harness Local não é suportado.

## O que muda

| Parte | Antes (sondagem) | Agora |
| --- | --- | --- |
| Agentes | `bchive`, `bchive-gf` | 9: `bchive`, `bchive-discovery`, `bchive-prototipo`, `bchive-plan`, `bchive-review`, `bchive-implement`, `bchive-archive` e os subagentes `bchive-gf` (revisor) e `bchive-implementador` |
| Comandos | `:bchive-init`, `:bchive-probe` | 18: `init`, `start`, `grill`, `triagem`, `prototipo`, `plan`, `review`, `implement`, `archive`, `fechar`, `canario`, `configurar`, `uso`, `mapa`, `ticket`, `adotar`, `squad-audit`, `lembrar` |
| Hooks | registro da sondagem | 6 eventos para `scripts/core/hook.mjs`: guardas do fluxo e coleta de uso |
| Núcleo | `bchive.mjs` mínimo | `scripts/core/`, copiado para `.bchive/bin/` pelo `init` |
| Testes | nenhum | `testes/smoke.mjs`, 46 passos, sem rede |
| README | sondagem | instalação, uso e privacidade, com a identidade da colmeia: banner, fluxo em alvéolos e papéis em SVG animado (claro e escuro) em `docs/assets/`, sem serviço externo |
| `plugin.json` | — | só `description` e `author`; versão com o release-please |

Removidos: `skills/bchive-init/`, `skills/bchive-probe/`, `scripts/probe-hook.mjs`. Os comandos da sondagem deixam de existir.

## Destaques

- **Portões humanos:** aprovar a spec, aceitar revisão reprovada, liberar rodada extra, OK do QA, aprovar lição e descartar mudança. O hook nega esses comandos ao agente; a pessoa roda no terminal.
- **Revisão isolada:** o revisor recebe um pacote gerado por script e só tem leitura; o canário prova o isolamento na máquina do dev.
- **Executores da stack:** o plano propõe, por fatia, o agente instalado que cobre a stack (Java, Angular, COBOL…) e só usa com o sim do dev; `executores conferir` diz se o agente está pronto.
- **Personalização do dev não trava:** `.github/`, `.vscode/` e `AGENTS.md` não versionados nunca contam como alteração pendente; só regra declarada do time bloqueia na revisão. `squad-audit` audita custo e conflitos dessa personalização.
- **Lições de uso:** o agente propõe, uma pessoa aprova, o arquivo vai para `conhecimento/licoes/` com escopo e data de revisão.
- **Legado:** o fluxo vale para COBOL, mainframe e outros com o agente que o time já usa; o init avisa o que o mapa não lê.

## Privacidade e segurança

- Nunca grava prompt, resposta, código, argumento de ferramenta nem comando de terminal.
- Sem valor em dinheiro, crédito ou preço de modelo; tokens só quando a telemetria do Agent Host estiver ligada pela TI.
- Uso local em `~/.bchive/uso/`, fora de qualquer repositório, com dias selados em cadeia de hash. O envio para uma visão central está em definição e não faz parte desta PR.
- Sem rede, sem `npm install`, sem permissão de administrador. Não cria nem edita `.github/` nem `AGENTS.md` do produto; no repositório do produto, só `conhecimento/` é versionado.

## Como testar

1. `node testes/smoke.mjs` na raiz: `46/46 passos ok`.
2. Depois do merge, no `bradesco-marketplace-unstable` ([Teste antes da release](CONTRIBUTING.md#teste-antes-da-release)):
   - instalar o plugin e abrir a raiz de um repositório de produto;
   - chat novo, agente `bchive`: `/bia-credit-hive:init` termina sem item GRAVE e com o canário aprovado;
   - `/bia-credit-hive:squad-audit` gera o relatório da personalização;
   - `/bia-credit-hive:start <um pedido real>` indica a rota.

## Checklist

- [x] Teste de fumaça 46/46
- [x] Nenhuma dependência npm; núcleo em Node 20+
- [x] Frontmatter dos agentes no schema do harness Copilot (sem `agents`, `handoffs`, `argument-hint`)
- [x] Hooks com variantes `bash` e `powershell` que nunca derrubam a sessão (`|| true` / `exit 0`)
- [ ] Canário aprovado no Windows com a versão publicada no unstable
- [ ] Preview pedido antes da primeira release

## Fora do escopo

- Envio do relatório de uso para um destino central (em definição).
- Registro de conhecimento no padrão OKF.
- Copilot CLI e Claude Code: instalam, mas o fluxo não foi validado neles.
```

## Depois do merge

1. Espere a publicação no `bradesco-marketplace-unstable` e atualize o plugin no VS Code (a versão de sondagem tem
   o mesmo nome: é atualização, não instalação nova). Se não atualizar, desinstale e instale de novo.
2. Rode a limpeza abaixo **antes** do primeiro `/bia-credit-hive:init`.
3. Em cada repositório: `/bia-credit-hive:init`. O item `instalacao-antiga` confirma que não sobrou nada.

## Limpar a máquina dos testes anteriores

O `limpar-henriworks.sh` remove o que as versões de teste deixaram (zip do HenriWorks, Bia Credit Atlas e
sondagem). Por padrão só mostra; apaga com `--aplicar`.

```bash
# 1. Prévia: sua pasta de usuário + os repositórios com restos dentro da pasta dos seus projetos
bash ~/Downloads/limpar-henriworks.sh --procurar ~/projetos
#    (troque ~/projetos pela pasta onde ficam seus clones; pode repetir --procurar ou passar repositórios soltos)

# 2. Conferiu a lista? Apague:
bash ~/Downloads/limpar-henriworks.sh --procurar ~/projetos --aplicar
```

O que ele remove:

| Onde | O quê |
| --- | --- |
| Pasta de usuário | `~/.henriworks/` (uso dos testes), `~/.bcatlas/`, `~/.bchive-probe/`; em `~/.copilot/`: `agents/hwk*.agent.md`, `skills/hwk-*`, `skills/henriworks-fluxo`, `henriworks.lock.json`, `.henriworks-backup` (e os equivalentes `bcatlas`); `hwk*` na pasta de prompts do perfil do VS Code |
| Cada repositório | `.henriworks/`, `.bcatlas/`, `.bchive-probe/`; `.github/agents/hwk*.agent.md`, `.github/skills/hwk-*`, `.github/skills/henriworks-fluxo`, `.github/hooks/henriworks.json`; o bloco `<!-- henriworks:inicio -->…<!-- henriworks:fim -->` do `AGENTS.md` ou do `copilot-instructions.md` (o resto do arquivo fica); o bloco `# >>> henriworks` do `.git/info/exclude` e dos hooks `post-checkout`, `post-merge` e `post-commit` do Git (hook que só tinha isso é apagado) |

O que ele **não** faz:

- Não apaga arquivo que o Git rastreia: lista como `NO GIT` para você tirar numa PR.
- Não mexe no plugin `bia-credit-hive` instalado, em `.bchive/` (o `init` substitui) nem em `conhecimento/`.
- Não edita o `settings.json` do VS Code nem variáveis de ambiente: se achar `github.copilot.chat.otel.*` ou
  `COPILOT_OTEL_*`/`HENRIWORKS_*`, avisa para você tirar à mão, se foram só do teste. A configuração gerenciada
  de telemetria da TI (`managed-settings.json`) não é do HenriWorks: deixe como está.

Por fim, feche e abra o VS Code e apague dos Downloads os zips antigos (`henriworks-v0.1.*.zip`,
`bia-credit-atlas-*.zip`, `bchive-sondagem.zip`) e as pastas extraídas deles.
