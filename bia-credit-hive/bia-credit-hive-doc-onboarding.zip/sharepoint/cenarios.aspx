<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Cenários de uso · b.IA Credit Hive</title>
  <meta name="description" content="Que rota cada pedido toma, em qualquer stack e em vários repositórios.">
  <link rel="icon" type="image/svg+xml" href="img/simbolo-bia.svg">
  <link rel="stylesheet" href="style.css">
  <script src="vendor/motion-lite.js" defer></script>
  <script src="app.js" defer></script>
</head>
<body>
<a class="pular" href="#conteudo">Pular para o conteúdo</a>
<div class="colmeia" aria-hidden="true">
<svg class="colmeia__favo" aria-hidden="true" focusable="false"><defs><pattern id="bchive-favo" width="48.497" height="84" patternUnits="userSpaceOnUse"><path d="M24.25,0.00 L48.50,14.00 L48.50,42.00 L24.25,56.00 L-0.00,42.00 L0.00,14.00 Z"/><path d="M0.00,42.00 L24.25,56.00 L24.25,84.00 L0.00,98.00 L-24.25,84.00 L-24.25,56.00 Z"/><path d="M48.50,42.00 L72.75,56.00 L72.75,84.00 L48.50,98.00 L24.25,84.00 L24.25,56.00 Z"/><path d="M0.00,-42.00 L24.25,-28.00 L24.25,-0.00 L0.00,14.00 L-24.25,-0.00 L-24.25,-28.00 Z"/><path d="M48.50,-42.00 L72.75,-28.00 L72.75,-0.00 L48.50,14.00 L24.25,-0.00 L24.25,-28.00 Z"/></pattern></defs><rect width="100%" height="100%" fill="url(#bchive-favo)"/></svg>
<svg class="colmeia__cacho colmeia__cacho--a" viewBox="0 0 227.9 207.0" aria-hidden="true" focusable="false"><path d="M61.98,7.80 L86.40,21.90 L86.40,50.10 L61.98,64.20 L37.56,50.10 L37.56,21.90 Z" class="vazio"/><path d="M113.94,7.80 L138.36,21.90 L138.36,50.10 L113.94,64.20 L89.52,50.10 L89.52,21.90 Z" class="vazio"/><path d="M165.90,7.80 L190.33,21.90 L190.33,50.10 L165.90,64.20 L141.48,50.10 L141.48,21.90 Z" class="vazio"/><path d="M36.00,52.80 L60.42,66.90 L60.42,95.10 L36.00,109.20 L11.58,95.10 L11.58,66.90 Z" class="vazio"/><path d="M87.96,52.80 L112.38,66.90 L112.38,95.10 L87.96,109.20 L63.54,95.10 L63.54,66.90 Z" class="mel"/><path d="M139.92,52.80 L164.34,66.90 L164.34,95.10 L139.92,109.20 L115.50,95.10 L115.50,66.90 Z" class="mel"/><path d="M191.88,52.80 L216.31,66.90 L216.31,95.10 L191.88,109.20 L167.46,95.10 L167.46,66.90 Z" class="vazio"/><path d="M61.98,97.80 L86.40,111.90 L86.40,140.10 L61.98,154.20 L37.56,140.10 L37.56,111.90 Z" class="mel"/><path d="M113.94,97.80 L138.36,111.90 L138.36,140.10 L113.94,154.20 L89.52,140.10 L89.52,111.90 Z" class="mel"/><path d="M165.90,97.80 L190.33,111.90 L190.33,140.10 L165.90,154.20 L141.48,140.10 L141.48,111.90 Z" class="vazio"/><path d="M139.92,142.80 L164.34,156.90 L164.34,185.10 L139.92,199.20 L115.50,185.10 L115.50,156.90 Z" class="vazio"/><path d="M36.00,142.80 L60.42,156.90 L60.42,185.10 L36.00,199.20 L11.58,185.10 L11.58,156.90 Z" class="vazio"/><path d="M87.96,142.80 L112.38,156.90 L112.38,185.10 L87.96,199.20 L63.54,185.10 L63.54,156.90 Z" class="vazio"/></svg>
<svg class="colmeia__cacho colmeia__cacho--b" viewBox="0 0 197.5 140.4" aria-hidden="true" focusable="false"><path d="M53.72,6.76 L74.88,18.98 L74.88,43.42 L53.72,55.64 L32.55,43.42 L32.55,18.98 Z" class="vazio"/><path d="M98.75,6.76 L119.92,18.98 L119.92,43.42 L98.75,55.64 L77.58,43.42 L77.58,18.98 Z" class="mel"/><path d="M143.78,6.76 L164.95,18.98 L164.95,43.42 L143.78,55.64 L122.62,43.42 L122.62,18.98 Z" class="vazio"/><path d="M31.20,45.76 L52.37,57.98 L52.37,82.42 L31.20,94.64 L10.03,82.42 L10.03,57.98 Z" class="vazio"/><path d="M76.23,45.76 L97.40,57.98 L97.40,82.42 L76.23,94.64 L55.07,82.42 L55.07,57.98 Z" class="vazio"/><path d="M121.27,45.76 L142.43,57.98 L142.43,82.42 L121.27,94.64 L100.10,82.42 L100.10,57.98 Z" class="vazio"/><path d="M166.30,45.76 L187.47,57.98 L187.47,82.42 L166.30,94.64 L145.13,82.42 L145.13,57.98 Z" class="mel"/><path d="M53.72,84.76 L74.88,96.98 L74.88,121.42 L53.72,133.64 L32.55,121.42 L32.55,96.98 Z" class="vazio"/><path d="M98.75,84.76 L119.92,96.98 L119.92,121.42 L98.75,133.64 L77.58,121.42 L77.58,96.98 Z" class="vazio"/><path d="M143.78,84.76 L164.95,96.98 L164.95,121.42 L143.78,133.64 L122.62,121.42 L122.62,96.98 Z" class="mel"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="left:1%;top:14%" aria-hidden="true" focusable="false"><path d="M10 100 C 40 20, 90 110, 130 50 S 180 20, 195 40"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="right:1%;top:70%;transform:scaleX(-1)" aria-hidden="true" focusable="false"><path d="M10 90 C 50 10, 80 100, 120 40 S 170 30, 195 60"/></svg>
<svg class="abelha ab1" style="left:2.5%;top:20%;--d:13s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab1"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab1)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab2" style="right:3%;top:34%;--d:16s;--x:-16px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab2"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab2)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab3" style="left:4%;top:62%;--d:15s;--x:14px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab3"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab3)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab4" style="right:5%;top:76%;--d:12s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab4"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab4)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab5" style="right:22%;top:12%;--d:18s;--x:-12px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab5"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab5)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
</div>

<div class="progresso" aria-hidden="true"><div class="progresso__barra"></div></div>
<header class="topo">
  <div class="conteudo topo__linha">
    <a class="marca" href="index.aspx" aria-label="b.IA Credit Hive, início">
      <img class="mlogo mlogo--c" src="img/logo-bia.svg" alt="b.IA Credit" height="28"><img class="mlogo mlogo--e" src="img/logo-bia-escuro.svg" alt="" height="28"><span class="marca__produto">Hive</span>
    </a>
    <nav aria-label="Páginas da documentação" class="nav"><ul class="menu"><li><a href="index.aspx">Início</a></li><li><a href="por-dentro.aspx">Por dentro</a></li><li><a href="fluxo.aspx">Fluxo</a></li><li><a href="camadas.aspx">Camadas</a></li><li><a href="instalacao.aspx">Instalação</a></li><li><a href="cenarios.aspx" aria-current="page">Cenários</a></li><li><a href="governanca.aspx">Governança</a></li><li><a href="painel.aspx">Painel</a></li><li><a href="referencia.aspx">Referência</a></li></ul></nav>
    <div class="controles" data-controles></div>
  </div>
</header>
<main id="conteudo">
<section class="hero hero--pagina conteudo" data-slide>
  <div>
    <p class="eyebrow">Cenários de uso</p>
    <h1 class="titulo-abertura">Que rota cada pedido toma</h1>
    <p class="lede">O fluxo é o mesmo para qualquer stack. O que muda de um repositório para outro são os <strong>arquivos do time</strong>
      (verificação, padrões, executores), não o processo. Filtre pelo tipo de pedido.</p>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="cen-t">
  <h2 id="cen-t" class="visualmente-oculto">Cenários</h2>
  <div class="filtros" role="group" aria-label="Filtrar cenários" data-filtros data-sem-js aria-hidden="true">
    <button aria-pressed="true" data-filtro="todos">Todos</button>
    <button aria-pressed="false" data-filtro="pequeno">Pequeno</button>
    <button aria-pressed="false" data-filtro="feature">Feature</button>
    <button aria-pressed="false" data-filtro="bug">Bug</button>
    <button aria-pressed="false" data-filtro="estrutura">Refactor e legado</button>
    <button aria-pressed="false" data-filtro="multi">Vários repositórios</button>
    <button aria-pressed="false" data-filtro="excecao">Desvios</button>
  </div>
  <div class="grade cenarios">
    <article class="card cenario" data-tipo="pequeno"><h3>Teste quebrado, texto, configuração</h3><p>Ajuste em poucos arquivos, sem decisão de produto.</p>
      <div class="rota"><span class="selo">chat normal</span></div><p class="nota">Sem fluxo. O <code>/bia-credit-hive:start</code> diz isso quando é o caso.</p></article>
    <article class="card cenario" data-tipo="feature"><h3>Feature em MFE (Angular, React)</h3><p>Tela nova ou alterada, com Figma e contrato do BFF.</p>
      <div class="rota"><span class="selo">triagem</span><span class="selo">plan</span><span class="selo">review spec</span><span class="selo selo--mel">aprovar</span><span class="selo">implement</span><span class="selo">review</span><span class="selo">archive</span><span class="selo selo--mel">QA</span><span class="selo">fechar</span></div>
      <p class="nota">Insumos: análise do Figma em <code>figma.md</code> e o tipo que o MFE consome.</p></article>
    <article class="card cenario" data-tipo="feature"><h3>Feature em BFF ou serviço Java</h3><p>Endpoint novo, regra de negócio, integração.</p>
      <div class="rota"><span class="selo">triagem</span><span class="selo">plan</span><span class="selo">review spec</span><span class="selo selo--mel">aprovar</span><span class="selo selo--sinal">implement com o agente Java</span><span class="selo">review</span><span class="selo">archive</span></div>
      <p class="nota">Se houver um codificador Java instalado e pronto, o plano propõe ele para as fatias do BFF.</p></article>
    <article class="card cenario" data-tipo="bug"><h3>Bug com ticket escrito</h3><p>Passos de reprodução no Jira, sem o comportamento esperado claro.</p>
      <div class="rota"><span class="selo">triagem</span><span class="selo">plan</span><span class="selo">…</span></div>
      <p class="nota">A triagem separa reprodução de esperado e pergunta só o que falta.</p></article>
    <article class="card cenario" data-tipo="bug"><h3>Dor sem nada escrito</h3><p>"O gerente reclama que o acordo duplica."</p>
      <div class="rota"><span class="selo">grill</span><span class="selo">plan</span><span class="selo">…</span></div>
      <p class="nota">Até quatro rodadas de perguntas, na língua de quem usa o sistema.</p></article>
    <article class="card cenario" data-tipo="feature"><h3>Decisão que só se toma vendo</h3><p>Duas pessoas discordam de como a tela deve ficar.</p>
      <div class="rota"><span class="selo">protótipo</span><span class="selo">grill</span><span class="selo">plan</span></div>
      <p class="nota">Código descartável, fora de <code>src/</code>, que responde uma pergunta.</p></article>
    <article class="card cenario" data-tipo="estrutura"><h3>Refactor amplo</h3><p>Mudar uma estrutura usada em muitos lugares.</p>
      <div class="rota"><span class="selo">plan</span><span class="selo">fatias: expandir · migrar em lotes · contrair</span></div>
      <p class="nota">Linha de base gravada e commitada antes; critério estrutural verificável.</p></article>
    <article class="card cenario" data-tipo="estrutura"><h3>Legado sem testes e sem documentação</h3><p>Ninguém lembra por que o código é assim.</p>
      <div class="rota"><span class="selo">mapa</span><span class="selo">triagem</span><span class="selo">plan</span></div>
      <p class="nota">O mapa responde quem chama o quê; specs e decisões começam a existir a partir desta mudança.</p></article>
    <article class="card cenario" data-tipo="estrutura"><h3>COBOL, JCL, mainframe e outros legados</h3><p>A squad já usa um agente próprio para a stack.</p>
      <div class="rota"><span class="selo">triagem</span><span class="selo">plan</span><span class="selo selo--mel">fatia para o agente da squad</span><span class="selo">review</span></div>
      <p class="nota">O Hive planeja, revisa e fecha; o agente que o time já usa executa a fatia. A verificação roda os comandos do time. O mapa não lê esses arquivos.</p></article>
    <article class="card cenario" data-tipo="multi"><h3>Mudança que cruza MFE e BFF</h3><p>Um ticket, dois ou mais repositórios.</p>
      <div class="rota"><span class="selo">uma mudança por repositório</span><span class="selo">mesmo ticket</span></div>
      <p class="nota">Veja "Vários projetos juntos" abaixo.</p></article>
    <article class="card cenario" data-tipo="excecao"><h3>O QA achou erro depois do archive</h3><p>A PR já está aberta.</p>
      <div class="rota"><span class="selo">mudança nova e pequena</span><span class="selo">mesma branch e PR</span><span class="selo selo--mel">qa-ok cobre as duas</span></div></article>
    <article class="card cenario" data-tipo="excecao"><h3>A spec mudou no meio</h3><p>Descobriu-se uma decisão durável durante a implementação.</p>
      <div class="rota"><span class="selo">implement para</span><span class="selo">plan replanejar</span><span class="selo">review spec</span></div></article>
    <article class="card cenario" data-tipo="excecao"><h3>Desistiu da mudança</h3><p>Prioridade mudou.</p>
      <div class="rota"><span class="selo">bchive.mjs descartar (prévia)</span><span class="selo selo--mel">dev aplica</span></div>
      <p class="nota">Mostra o que será apagado; só você confirma, no seu terminal.</p></article>
  </div>
</section>

<section class="secao conteudo" id="multi" data-slide aria-labelledby="multi-t">
  <div class="secao__cab"><p class="eyebrow">Vários projetos juntos</p><h2 id="multi-t">Um ticket, vários repositórios, contratos isolados por camada</h2>
    <p>Cada repositório tem o seu Hive, os seus artefatos e a sua PR. O que os une é o ticket e o contrato combinado, nunca um arquivo compartilhado.</p></div>
  <figure class="diagrama diagrama--multi revelar"><svg viewBox="0 0 960 380" role="img" aria-labelledby="dm-t dm-d"><title id="dm-t">Vários repositórios, um ticket</title><desc id="dm-d">MFE, BFF e serviço, cada um com seu Hive, sua cópia do contrato e sua PR; o ticket liga as mudanças.</desc><path d="M480.0,4.0 L528.5,32.0 L528.5,88.0 L480.0,116.0 L431.5,88.0 L431.5,32.0 Z" class="dg-hex dg-hex--rainha"/><text x="480" y="56" class="dg-t dg-t--forte" text-anchor="middle">Ticket</text><text x="480" y="74" class="dg-t dg-t--mono" text-anchor="middle">GPCNLS-10019</text><path d="M480,116 C 480,140 160,130 160,158" class="dg-rota desenhar"/><g class="dg-col" style="--i:0"><rect x="20" y="158" width="280" height="170" rx="16" class="dg-caixa"/><text x="160" y="188" class="dg-t dg-t--titulo" text-anchor="middle">MFE (Angular)</text><text x="160" y="210" class="dg-t dg-t--mono" text-anchor="middle">.bchive/ próprio</text><rect x="40" y="226" width="240" height="34" rx="9" class="dg-bolha"/><text x="160" y="248" class="dg-t dg-t--peq" text-anchor="middle">contrato próprio: o que consome</text><rect x="40" y="270" width="240" height="34" rx="9" class="dg-bolha dg-bolha--pr"/><text x="160" y="292" class="dg-t dg-t--peq" text-anchor="middle">PR · GPCNLS-10019-mostrar-saldo-pr…</text></g><path d="M480,116 C 480,140 480,130 480,158" class="dg-rota desenhar"/><g class="dg-col" style="--i:1"><rect x="340" y="158" width="280" height="170" rx="16" class="dg-caixa"/><text x="480" y="188" class="dg-t dg-t--titulo" text-anchor="middle">BFF (Java)</text><text x="480" y="210" class="dg-t dg-t--mono" text-anchor="middle">.bchive/ próprio</text><rect x="360" y="226" width="240" height="34" rx="9" class="dg-bolha"/><text x="480" y="248" class="dg-t dg-t--peq" text-anchor="middle">contrato próprio: o que expõe</text><rect x="360" y="270" width="240" height="34" rx="9" class="dg-bolha dg-bolha--pr"/><text x="480" y="292" class="dg-t dg-t--peq" text-anchor="middle">PR · GPCNLS-10019-expor-saldo-proj…</text></g><path d="M480,116 C 480,140 800,130 800,158" class="dg-rota desenhar"/><g class="dg-col" style="--i:2"><rect x="660" y="158" width="280" height="170" rx="16" class="dg-caixa"/><text x="800" y="188" class="dg-t dg-t--titulo" text-anchor="middle">Serviço</text><text x="800" y="210" class="dg-t dg-t--mono" text-anchor="middle">.bchive/ próprio</text><rect x="680" y="226" width="240" height="34" rx="9" class="dg-bolha"/><text x="800" y="248" class="dg-t dg-t--peq" text-anchor="middle">contrato próprio: o que expõe</text><rect x="680" y="270" width="240" height="34" rx="9" class="dg-bolha dg-bolha--pr"/><text x="800" y="292" class="dg-t dg-t--peq" text-anchor="middle">PR · GPCNLS-10019-calcular-saldo…</text></g><path d="M658,243 L622,243" class="dg-fluxo"/><path d="M338,243 L302,243" class="dg-fluxo"/><path d="M300,362 L340,362" class="dg-fluxo"/><text x="350" y="366" class="dg-t dg-t--peq">contrato combinado na discovery; cada repositório gera a partir da sua cópia</text></svg></figure>

  <ol class="trilha revelar-grupo" style="margin-top:26px">
    <li class="trilha__passo"><span class="trilha__n">1</span><div><h3>Combine o contrato antes</h3><p>Na discovery, o briefing de cada repositório traz o contrato da sua camada: o BFF o que expõe, o MFE o que consome. Cada um guarda e gera a partir da <strong>sua cópia</strong> do OpenAPI.</p></div></li>
    <li class="trilha__passo"><span class="trilha__n">2</span><div><h3>Uma mudança por repositório, mesmo ticket</h3><p><code>GPCNLS-10019-expor-saldo-projetado</code> no BFF e <code>GPCNLS-10019-mostrar-saldo-projetado</code> no MFE. A proposta declara a dependência em <code>## Restrições</code>.</p></div></li>
    <li class="trilha__passo"><span class="trilha__n">3</span><div><h3>Produtor primeiro</h3><p>O BFF entrega e publica o contrato; o MFE implementa contra o contrato acordado (com mock até o BFF subir). Rigor Full se o contrato muda.</p></div></li>
    <li class="trilha__passo"><span class="trilha__n">4</span><div><h3>Uma PR por repositório, QA junto</h3><p>Os <code>resumo.md</code> citam o ticket. O QA testa o conjunto e dá o <code>qa-ok</code> em cada repositório.</p></div></li>
  </ol>
</section>

<section class="secao conteudo" data-slide aria-labelledby="stack-t">
  <div class="secao__cab"><p class="eyebrow">Qualquer stack</p><h2 id="stack-t">O que você adapta por tipo de projeto</h2></div>
  <div class="tabela-wrap revelar">
    <table>
      <thead><tr><th>Projeto</th><th>verificacao.json (por camada)</th><th>Executor sugerido</th><th>Insumos típicos</th></tr></thead>
      <tbody>
        <tr><td>MFE Angular</td><td>tsc, ESLint, Jest/Karma por pasta</td><td>implementador do Hive ou agente Angular</td><td>Figma, tipo consumido do BFF</td></tr>
        <tr><td>MFE React</td><td>tsc, ESLint, Vitest/Jest</td><td>implementador do Hive ou agente React</td><td>Figma, tipo consumido do BFF</td></tr>
        <tr><td>BFF / serviço Java</td><td>build Maven ou Gradle, testes por módulo</td><td>agente Java / Spring</td><td>OpenAPI exposto, regras de negócio</td></tr>
        <tr><td>Liberty / legado Java</td><td>build e testes do módulo tocado</td><td>agente Liberty</td><td>configuração do servidor, dependências</td></tr>
        <tr><td>App Swift / Kotlin</td><td>build e testes do alvo</td><td>agente mobile</td><td>Figma, contrato da API</td></tr>
        <tr><td>Observabilidade</td><td>validação do pipeline</td><td>agente de observabilidade</td><td>eventos e métricas esperados</td></tr>
      </tbody>
    </table>
  </div>
  <p class="nota">Sem agente da stack instalado, a fatia fica com o executor do Hive. Os portões (escopo, verificação, revisão isolada) são os mesmos para qualquer executor.</p>
</section>

<div class="conteudo">
  <nav class="passagem" aria-label="Navegação entre páginas">
    <a href="instalacao.aspx" data-anterior><small>← Anterior</small><strong>Instalação</strong></a>
    <a class="prox" href="governanca.aspx" data-proxima><small>Próxima →</small><strong>Governança</strong></a>
  </nav>
  <footer class="rodape"><span>b.IA Credit Hive · documentação da versão 1.1 do plugin <code>bia-credit-hive</code></span><span><kbd>P</kbd> apresentação · <kbd>←</kbd> <kbd>→</kbd> navegar · <kbd>Esc</kbd> sair</span></footer>
</div>
</main>
<div class="slide-contador" aria-live="polite"></div>
</body>
</html>
