<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>O que estudar · Fundamentos de IA</title>
  <meta name="description" content="Os temas que fazem diferença para o dev que trabalha com IA, por momento da carreira.">
  <link rel="icon" type="image/svg+xml" href="img/simbolo-bia.svg">
  <link rel="stylesheet" href="style.css">
  <script src="vendor/motion-lite.js" defer></script>
  <script src="app.js" defer></script>
</head>
<body>
<a class="pular" href="#conteudo">Pular para o conteúdo</a>
<div class="colmeia" aria-hidden="true">
<svg class="colmeia__favo" aria-hidden="true" focusable="false"><defs><pattern id="bchive-favo" width="48.497" height="84" patternUnits="userSpaceOnUse"><path d="M24.25,0.00 L48.50,14.00 L48.50,42.00 L24.25,56.00 L-0.00,42.00 L0.00,14.00 Z"/><path d="M0.00,42.00 L24.25,56.00 L24.25,84.00 L0.00,98.00 L-24.25,84.00 L-24.25,56.00 Z"/><path d="M48.50,42.00 L72.75,56.00 L72.75,84.00 L48.50,98.00 L24.25,84.00 L24.25,56.00 Z"/><path d="M0.00,-42.00 L24.25,-28.00 L24.25,-0.00 L0.00,14.00 L-24.25,-0.00 L-24.25,-28.00 Z"/><path d="M48.50,-42.00 L72.75,-28.00 L72.75,-0.00 L48.50,14.00 L24.25,-0.00 L24.25,-28.00 Z"/></pattern></defs><rect width="100%" height="100%" fill="url(#bchive-favo)"/></svg>
<svg class="colmeia__cacho colmeia__cacho--a" viewBox="0 0 227.9 207.0" aria-hidden="true" focusable="false"><path d="M61.98,7.80 L86.40,21.90 L86.40,50.10 L61.98,64.20 L37.56,50.10 L37.56,21.90 Z" class="vazio"/><path d="M113.94,7.80 L138.36,21.90 L138.36,50.10 L113.94,64.20 L89.52,50.10 L89.52,21.90 Z" class="vazio"/><path d="M165.90,7.80 L190.33,21.90 L190.33,50.10 L165.90,64.20 L141.48,50.10 L141.48,21.90 Z" class="vazio"/><path d="M36.00,52.80 L60.42,66.90 L60.42,95.10 L36.00,109.20 L11.58,95.10 L11.58,66.90 Z" class="vazio"/><path d="M87.96,52.80 L112.38,66.90 L112.38,95.10 L87.96,109.20 L63.54,95.10 L63.54,66.90 Z" class="mel"/><path d="M139.92,52.80 L164.34,66.90 L164.34,95.10 L139.92,109.20 L115.50,95.10 L115.50,66.90 Z" class="mel"/><path d="M191.88,52.80 L216.31,66.90 L216.31,95.10 L191.88,109.20 L167.46,95.10 L167.46,66.90 Z" class="vazio"/><path d="M61.98,97.80 L86.40,111.90 L86.40,140.10 L61.98,154.20 L37.56,140.10 L37.56,111.90 Z" class="mel"/><path d="M113.94,97.80 L138.36,111.90 L138.36,140.10 L113.94,154.20 L89.52,140.10 L89.52,111.90 Z" class="mel"/><path d="M165.90,97.80 L190.33,111.90 L190.33,140.10 L165.90,154.20 L141.48,140.10 L141.48,111.90 Z" class="vazio"/><path d="M139.92,142.80 L164.34,156.90 L164.34,185.10 L139.92,199.20 L115.50,185.10 L115.50,156.90 Z" class="vazio"/><path d="M36.00,142.80 L60.42,156.90 L60.42,185.10 L36.00,199.20 L11.58,185.10 L11.58,156.90 Z" class="vazio"/><path d="M87.96,142.80 L112.38,156.90 L112.38,185.10 L87.96,199.20 L63.54,185.10 L63.54,156.90 Z" class="vazio"/></svg>
<svg class="colmeia__cacho colmeia__cacho--b" viewBox="0 0 197.5 140.4" aria-hidden="true" focusable="false"><path d="M53.72,6.76 L74.88,18.98 L74.88,43.42 L53.72,55.64 L32.55,43.42 L32.55,18.98 Z" class="vazio"/><path d="M98.75,6.76 L119.92,18.98 L119.92,43.42 L98.75,55.64 L77.58,43.42 L77.58,18.98 Z" class="mel"/><path d="M143.78,6.76 L164.95,18.98 L164.95,43.42 L143.78,55.64 L122.62,43.42 L122.62,18.98 Z" class="vazio"/><path d="M31.20,45.76 L52.37,57.98 L52.37,82.42 L31.20,94.64 L10.03,82.42 L10.03,57.98 Z" class="vazio"/><path d="M76.23,45.76 L97.40,57.98 L97.40,82.42 L76.23,94.64 L55.07,82.42 L55.07,57.98 Z" class="vazio"/><path d="M121.27,45.76 L142.43,57.98 L142.43,82.42 L121.27,94.64 L100.10,82.42 L100.10,57.98 Z" class="vazio"/><path d="M166.30,45.76 L187.47,57.98 L187.47,82.42 L166.30,94.64 L145.13,82.42 L145.13,57.98 Z" class="mel"/><path d="M53.72,84.76 L74.88,96.98 L74.88,121.42 L53.72,133.64 L32.55,121.42 L32.55,96.98 Z" class="vazio"/><path d="M98.75,84.76 L119.92,96.98 L119.92,121.42 L98.75,133.64 L77.58,121.42 L77.58,96.98 Z" class="vazio"/><path d="M143.78,84.76 L164.95,96.98 L164.95,121.42 L143.78,133.64 L122.62,121.42 L122.62,96.98 Z" class="mel"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="left:1%;top:14%" aria-hidden="true" focusable="false"><path d="M10 100 C 40 20, 90 110, 130 50 S 180 20, 195 40"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="right:1%;top:70%;transform:scaleX(-1)" aria-hidden="true" focusable="false"><path d="M10 90 C 50 10, 80 100, 120 40 S 170 30, 195 60"/></svg>
<svg class="abelha ab1" style="left:2.5%;top:20%;--d:13s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab1"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab1)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab2" style="right:3%;top:34%;--d:16s;--x:-16px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab2"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab2)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab3" style="left:4%;top:62%;--d:15s;--x:14px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab3"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab3)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab4" style="right:5%;top:76%;--d:12s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab4"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab4)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab5" style="right:22%;top:12%;--d:18s;--x:-12px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab5"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab5)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
</div>

<div class="progresso" aria-hidden="true"><div class="progresso__barra"></div></div>
<header class="topo">
  <div class="conteudo topo__linha">
    <a class="marca" href="index.aspx" aria-label="Fundamentos de IA, início">
      <img class="mlogo mlogo--c" src="img/logo-bia.svg" alt="b.IA Credit" height="28"><img class="mlogo mlogo--e" src="img/logo-bia-escuro.svg" alt="" height="28">
    </a>
    <nav class="sites" aria-label="Documentações"><a href="index.aspx" aria-current="true">Fundamentos de IA</a><a href="../hive/index.aspx">b.IA Credit Hive</a></nav>
    <nav aria-label="Páginas" class="nav"><ul class="menu"><li><a href="index.aspx">Início</a></li><li><a href="tokens.aspx">Tokens e custo</a></li><li><a href="contexto.aspx">Janela de contexto</a></li><li><a href="modelo-agente.aspx">Modelo × agente</a></li><li><a href="pecas.aspx">Agents, skills, MCP</a></li><li><a href="harness.aspx">Harness</a></li><li><a href="estudar.aspx" aria-current="page">O que estudar</a></li></ul></nav>
    <div class="controles" data-controles></div>
  </div>
</header>
<main id="conteudo">
<section class="hero hero--pagina conteudo" data-slide>
  <div>
    <p class="eyebrow">6 · O que estudar</p>
    <h1 class="titulo-abertura">A IA escreve mais rápido. Quem decide se está certo é você.</h1>
    <p class="lede">Com agentes fazendo boa parte da digitação, o valor do dev muda de lugar: <strong>entender o problema,
      descrever bem, julgar o resultado e garantir que é seguro</strong>. É isso que vale estudar.</p>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="conc-t">
  <div class="secao__cab"><p class="eyebrow">Primeiro, aprofunde o que viu hoje</p><h2 id="conc-t">Os conceitos desta trilha, mais fundo</h2>
    <p>Cada conceito da apresentação tem um próximo nível. Clique no nome para voltar à página dele.</p></div>
  <div class="tabela-wrap revelar"><table>
    <thead><tr><th>Conceito</th><th>O que aprofundar</th><th>Para quê</th></tr></thead>
    <tbody>
      <tr><td><a href="tokens.aspx">Tokens e custo</a></td><td>Como o tokenizador corta o texto; preço de entrada, saída e cache; cobrança por créditos no Copilot</td><td>Estimar o custo de uma tarefa e escrever pedidos mais econômicos</td></tr>
      <tr><td><a href="contexto.aspx">Janela de contexto</a></td><td>O que entra em cada pedido; por que o começo de uma conversa longa perde peso; resumo e compactação</td><td>Saber quando abrir um chat novo e o que levar para ele</td></tr>
      <tr><td><a href="contexto.aspx#rag-t">RAG e Vault</a></td><td>Pedaços (chunks), busca semântica, citação de fonte, curadoria da base</td><td>Usar a base de conhecimento da BU e confiar na resposta certa</td></tr>
      <tr><td><a href="modelo-agente.aspx">LLM (o modelo)</a></td><td>Como um modelo gera texto; alucinação; por que ele tende a concordar com você; diferenças entre modelos</td><td>Escolher o modelo pela tarefa e desconfiar na hora certa</td></tr>
      <tr><td><a href="modelo-agente.aspx">Agente</a></td><td>O ciclo entender, planejar, agir e verificar; ferramentas e permissões; modo agente do Copilot</td><td>Pedir trabalho, não só resposta, e acompanhar o que o agente fez</td></tr>
      <tr><td><a href="pecas.aspx">Agents e subagents</a></td><td>Escrever um <code>.agent.md</code>; limitar ferramentas; quando delegar para um subagente com contexto limpo</td><td>Criar papéis para o time e revisões sem viés</td></tr>
      <tr><td><a href="pecas.aspx">Instructions</a></td><td><code>.instructions.md</code> com <code>applyTo</code>; instrução curta e verificável; custo de instrução em todo pedido</td><td>Ensinar as regras do projeto sem engordar o contexto</td></tr>
      <tr><td><a href="pecas.aspx">Skills</a></td><td>Escrever um <code>SKILL.md</code> com descrição que acerta quando carregar; procedimento passo a passo</td><td>Transformar o que o time repete num comando</td></tr>
      <tr><td><a href="pecas.aspx">Hooks</a></td><td>Os eventos do agente; negar uma ação; registrar uso sem gravar conteúdo</td><td>Garantir o que não pode falhar, sem depender do modelo</td></tr>
      <tr><td><a href="pecas.aspx">MCP</a></td><td>Como um servidor MCP expõe ferramentas; configuração no VS Code; política do banco; custo de cada servidor ligado</td><td>Ligar Jira, Figma e outros sistemas ao agente com segurança</td></tr>
      <tr><td><a href="harness.aspx">Harness engineering</a></td><td>Juntar contexto, ferramentas, regras, verificação, portões e medição num processo; medir qualidade e custo</td><td>Sair do uso individual para um jeito de trabalhar do time</td></tr>
    </tbody></table></div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="temas-t">
  <div class="secao__cab"><p class="eyebrow">Depois, o que está em volta</p><h2 id="temas-t">Oito habilidades que fazem diferença</h2></div>
  <div class="pecas revelar-grupo">
    <article class="peca-card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>1</span></span>Ler e revisar código</h3>
      <p class="frase">A habilidade mais importante agora.</p>
      <dl><dt>Estude</dt><dd>Ler um diff com olhar crítico, achar a suposição escondida, revisar PR de outra pessoa com regra clara do que bloqueia.</dd>
        <dt>Por quê</dt><dd>O agente erra com confiança. Quem não sabe revisar aprova o erro.</dd></dl></article>
    <article class="peca-card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>2</span></span>Descrever o problema</h3>
      <p class="frase">Pedido bom gera código bom.</p>
      <dl><dt>Estude</dt><dd>Escrever critério de aceite verificável ("dado, quando, então"), separar problema de solução, listar restrições e o que está fora do escopo.</dd>
        <dt>Por quê</dt><dd>É o que o briefing e o plano do Hive pedem, e o que separa o pedido que funciona do que gera retrabalho.</dd></dl></article>
    <article class="peca-card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>3</span></span>Testes automatizados</h3>
      <p class="frase">O teste é a prova de que o código faz o combinado.</p>
      <dl><dt>Estude</dt><dd>Testar comportamento, não implementação; testes como especificação; TDD em fatias pequenas.</dd>
        <dt>Por quê</dt><dd>Sem teste, o agente não tem como conferir o próprio trabalho, e você também não.</dd></dl></article>
    <article class="peca-card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>4</span></span>Segurança no código</h3>
      <p class="frase">Código gerado também tem falha.</p>
      <dl><dt>Estude</dt><dd>OWASP Top 10, validação de entrada, autenticação e autorização, segredo fora do código, dependência vulnerável, dado sensível e LGPD.</dd>
        <dt>Por quê</dt><dd>O agente repete os padrões que viu, inclusive os inseguros. Num banco, isso é risco direto.</dd></dl></article>
    <article class="peca-card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>5</span></span>Contratos e arquitetura</h3>
      <p class="frase">Saber onde cada coisa mora.</p>
      <dl><dt>Estude</dt><dd>Contrato de API primeiro (OpenAPI), camadas com responsabilidades claras, fatias verticais, cada camada gerando o próprio cliente a partir da especificação.</dd>
        <dt>Por quê</dt><dd>Com fronteiras claras, o agente acerta mais e a mudança não vaza para onde não devia.</dd></dl></article>
    <article class="peca-card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>6</span></span>Git bem usado</h3>
      <p class="frase">Commit pequeno é revisão fácil.</p>
      <dl><dt>Estude</dt><dd>Commits pequenos e com mensagem clara, <code>git add -p</code>, branch por tarefa, desfazer com segurança, resolver conflito.</dd>
        <dt>Por quê</dt><dd>O agente edita rápido; o Git é o seu botão de voltar.</dd></dl></article>
    <article class="peca-card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>7</span></span>Como os modelos funcionam</h3>
      <p class="frase">O que você viu hoje, mais fundo.</p>
      <dl><dt>Estude</dt><dd>Tokens, janela de contexto, alucinação, por que o modelo concorda com você, quando trocar de modelo, custo por tarefa.</dd>
        <dt>Por quê</dt><dd>Quem entende a ferramenta sabe quando confiar e quando desconfiar.</dd></dl></article>
    <article class="peca-card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>8</span></span>A sua ferramenta a fundo</h3>
      <p class="frase">Copilot no VS Code, além do autocomplete.</p>
      <dl><dt>Estude</dt><dd>Modo agente, instructions com <code>applyTo</code>, agents, skills, hooks e MCP; o fluxo do b.IA Credit Hive.</dd>
        <dt>Por quê</dt><dd>É a diferença entre usar a IA e configurar a IA para o seu time.</dd></dl></article>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="nivel-t">
  <div class="secao__cab"><p class="eyebrow">Por onde começar</p><h2 id="nivel-t">Uma trilha para cada momento da carreira</h2></div>
  <div class="tabela-wrap revelar"><table>
    <thead><tr><th>Momento</th><th>Foque primeiro em</th><th>Pratique assim</th></tr></thead>
    <tbody>
      <tr><td>Começando (estágio, júnior)</td><td>Ler código, testes, Git e o básico de segurança</td><td>Peça ao agente para explicar o código antes de mudar; escreva o teste antes de aceitar a sugestão</td></tr>
      <tr><td>Ganhando autonomia (pleno)</td><td>Descrever o problema, revisar com critério, contratos entre camadas</td><td>Escreva o briefing de uma tarefa real; revise PRs de outros usando os três eixos do Hive</td></tr>
      <tr><td>Referência técnica (sênior, especialista)</td><td>Arquitetura, segurança a fundo e harness engineering</td><td>Escreva instructions, agents e skills para o time; meça custo e qualidade; ensine o time a revisar</td></tr>
      <tr><td>Negócio e gestão</td><td>Critérios de aceite, o que a IA faz e não faz, custo e governança</td><td>Escreva o "esperado" de uma demanda como critério verificável; acompanhe o painel de uso</td></tr>
    </tbody></table></div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="fonte-t">
  <div class="secao__cab"><p class="eyebrow">Onde aprender</p><h2 id="fonte-t">Fontes oficiais, sem atalho</h2></div>
  <div class="grade revelar-grupo">
    <div class="card"><h3>GitHub Copilot</h3><p>Documentação do Copilot no VS Code (code.visualstudio.com/docs/copilot) e no GitHub (docs.github.com/copilot): modo agente, instructions, agents, skills, hooks e MCP.</p></div>
    <div class="card"><h3>Segurança</h3><p>OWASP Top 10 (owasp.org/Top10) e as normas de segurança e LGPD do banco. Na dúvida, pergunte ao time de segurança antes de codar.</p></div>
    <div class="card"><h3>Escrever para modelos</h3><p>Os guias de prompt dos fabricantes, como a Anthropic e a OpenAI: clareza, exemplos, contexto e formato da resposta.</p></div>
    <div class="card"><h3>Na prática</h3><p>Esta trilha e a documentação do b.IA Credit Hive, e uma mudança real feita do briefing ao OK do QA.</p></div>
  </div>
  <p class="regra-ouro revelar" style="margin-top:22px">Use a IA para ir mais rápido. <span>Estude para saber quando ela está errada.</span></p>
</section>

<div class="conteudo">
  <nav class="passagem" aria-label="Navegação entre páginas">
    <a href="harness.aspx" data-anterior><small>← Anterior</small><strong>Harness</strong></a>
    <a class="prox" href="../hive/index.aspx" data-proxima><small>Agora, na prática →</small><strong>b.IA Credit Hive</strong></a>
  </nav>
  <footer class="rodape"><span>Engenharia com IA · fundamentos · BU Crédito</span><span><kbd>P</kbd> apresentação · <kbd>←</kbd> <kbd>→</kbd> navegar · <kbd>Esc</kbd> sair</span></footer>
</div>
</main>
<div class="slide-contador" aria-live="polite"></div>
</body>
</html>
