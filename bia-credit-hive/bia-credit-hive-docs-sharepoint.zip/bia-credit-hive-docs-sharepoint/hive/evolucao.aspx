<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Evolução · b.IA Credit Hive</title>
  <meta name="description" content="As frentes em andamento e planejadas para o Hive, com o que falta para cada uma.">
  <link rel="icon" type="image/svg+xml" href="img/simbolo-bia.svg">
  <link rel="stylesheet" href="style.css">
  <script src="vendor/motion-lite.js" defer></script>
  <script src="app.js" defer></script>
</head>
<body>
<a class="pular" href="#conteudo">Pular para o conteúdo</a>
<div class="colmeia" aria-hidden="true">
<svg class="colmeia__favo" aria-hidden="true" focusable="false"><defs><pattern id="bchive-favo" width="48.497" height="84" patternUnits="userSpaceOnUse"><path d="M24.25,0.00 L48.50,14.00 L48.50,42.00 L24.25,56.00 L-0.00,42.00 L0.00,14.00 Z"/><path d="M0.00,42.00 L24.25,56.00 L24.25,84.00 L0.00,98.00 L-24.25,84.00 L-24.25,56.00 Z"/><path d="M48.50,42.00 L72.75,56.00 L72.75,84.00 L48.50,98.00 L24.25,84.00 L24.25,56.00 Z"/><path d="M0.00,-42.00 L24.25,-28.00 L24.25,-0.00 L0.00,14.00 L-24.25,-0.00 L-24.25,-28.00 Z"/><path d="M48.50,-42.00 L72.75,-28.00 L72.75,-0.00 L48.50,14.00 L24.25,-0.00 L24.25,-28.00 Z"/></pattern></defs><rect width="100%" height="100%" fill="url(#bchive-favo)"/></svg>
<svg class="colmeia__cacho colmeia__cacho--a" viewBox="0 0 227.9 207.0" aria-hidden="true" focusable="false"><path d="M61.98,7.80 L86.40,21.90 L86.40,50.10 L61.98,64.20 L37.56,50.10 L37.56,21.90 Z" class="vazio"/><path d="M113.94,7.80 L138.36,21.90 L138.36,50.10 L113.94,64.20 L89.52,50.10 L89.52,21.90 Z" class="vazio"/><path d="M165.90,7.80 L190.33,21.90 L190.33,50.10 L165.90,64.20 L141.48,50.10 L141.48,21.90 Z" class="vazio"/><path d="M36.00,52.80 L60.42,66.90 L60.42,95.10 L36.00,109.20 L11.58,95.10 L11.58,66.90 Z" class="vazio"/><path d="M87.96,52.80 L112.38,66.90 L112.38,95.10 L87.96,109.20 L63.54,95.10 L63.54,66.90 Z" class="mel"/><path d="M139.92,52.80 L164.34,66.90 L164.34,95.10 L139.92,109.20 L115.50,95.10 L115.50,66.90 Z" class="mel"/><path d="M191.88,52.80 L216.31,66.90 L216.31,95.10 L191.88,109.20 L167.46,95.10 L167.46,66.90 Z" class="vazio"/><path d="M61.98,97.80 L86.40,111.90 L86.40,140.10 L61.98,154.20 L37.56,140.10 L37.56,111.90 Z" class="mel"/><path d="M113.94,97.80 L138.36,111.90 L138.36,140.10 L113.94,154.20 L89.52,140.10 L89.52,111.90 Z" class="mel"/><path d="M165.90,97.80 L190.33,111.90 L190.33,140.10 L165.90,154.20 L141.48,140.10 L141.48,111.90 Z" class="vazio"/><path d="M139.92,142.80 L164.34,156.90 L164.34,185.10 L139.92,199.20 L115.50,185.10 L115.50,156.90 Z" class="vazio"/><path d="M36.00,142.80 L60.42,156.90 L60.42,185.10 L36.00,199.20 L11.58,185.10 L11.58,156.90 Z" class="vazio"/><path d="M87.96,142.80 L112.38,156.90 L112.38,185.10 L87.96,199.20 L63.54,185.10 L63.54,156.90 Z" class="vazio"/></svg>
<svg class="colmeia__cacho colmeia__cacho--b" viewBox="0 0 197.5 140.4" aria-hidden="true" focusable="false"><path d="M53.72,6.76 L74.88,18.98 L74.88,43.42 L53.72,55.64 L32.55,43.42 L32.55,18.98 Z" class="vazio"/><path d="M98.75,6.76 L119.92,18.98 L119.92,43.42 L98.75,55.64 L77.58,43.42 L77.58,18.98 Z" class="mel"/><path d="M143.78,6.76 L164.95,18.98 L164.95,43.42 L143.78,55.64 L122.62,43.42 L122.62,18.98 Z" class="vazio"/><path d="M31.20,45.76 L52.37,57.98 L52.37,82.42 L31.20,94.64 L10.03,82.42 L10.03,57.98 Z" class="vazio"/><path d="M76.23,45.76 L97.40,57.98 L97.40,82.42 L76.23,94.64 L55.07,82.42 L55.07,57.98 Z" class="vazio"/><path d="M121.27,45.76 L142.43,57.98 L142.43,82.42 L121.27,94.64 L100.10,82.42 L100.10,57.98 Z" class="vazio"/><path d="M166.30,45.76 L187.47,57.98 L187.47,82.42 L166.30,94.64 L145.13,82.42 L145.13,57.98 Z" class="mel"/><path d="M53.72,84.76 L74.88,96.98 L74.88,121.42 L53.72,133.64 L32.55,121.42 L32.55,96.98 Z" class="vazio"/><path d="M98.75,84.76 L119.92,96.98 L119.92,121.42 L98.75,133.64 L77.58,121.42 L77.58,96.98 Z" class="vazio"/><path d="M143.78,84.76 L164.95,96.98 L164.95,121.42 L143.78,133.64 L122.62,121.42 L122.62,96.98 Z" class="mel"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="left:1%;top:14%" aria-hidden="true" focusable="false"><path d="M10 100 C 40 20, 90 110, 130 50 S 180 20, 195 40"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="right:1%;top:70%;transform:scaleX(-1)" aria-hidden="true" focusable="false"><path d="M10 90 C 50 10, 80 100, 120 40 S 170 30, 195 60"/></svg>
<svg class="abelha ab1" style="left:2.5%;top:20%;--d:13s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab1"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab1)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab2" style="right:3%;top:34%;--d:16s;--x:-16px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab2"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab2)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab3" style="left:4%;top:62%;--d:15s;--x:14px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab3"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab3)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab4" style="right:5%;top:76%;--d:12s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab4"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab4)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab5" style="right:22%;top:12%;--d:18s;--x:-12px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab5"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab5)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
</div>

<div class="progresso" aria-hidden="true"><div class="progresso__barra"></div></div>
<header class="topo">
  <div class="conteudo topo__linha">
    <a class="marca" href="index.aspx" aria-label="b.IA Credit Hive, início">
      <img class="mlogo mlogo--c" src="img/logo-bia.svg" alt="b.IA Credit" height="28"><img class="mlogo mlogo--e" src="img/logo-bia-escuro.svg" alt="" height="28">
    </a>
    <nav class="sites" aria-label="Documentações"><a href="../fundamentos/index.aspx">Fundamentos de IA</a><a href="index.aspx" aria-current="true">b.IA Credit Hive</a></nav>
    <nav aria-label="Páginas da documentação" class="nav"><ul class="menu"><li><a href="index.aspx">Início</a></li><li><a href="por-que.aspx">Por que usar</a></li><li><a href="por-dentro.aspx">Por dentro</a></li><li><a href="fluxo.aspx">Fluxo</a></li><li><a href="camadas.aspx">Camadas</a></li><li><a href="instalacao.aspx">Instalação</a></li><li><a href="cenarios.aspx">Cenários</a></li><li><a href="governanca.aspx">Governança</a></li><li><a href="painel.aspx">Painel</a></li><li><a href="evolucao.aspx" aria-current="page">Evolução</a></li><li><a href="referencia.aspx">Referência</a></li></ul></nav>
    <div class="controles" data-controles></div>
  </div>
</header>
<main id="conteudo">
<section class="hero hero--pagina conteudo" data-slide>
  <div>
    <p class="eyebrow">Evolução</p>
    <h1 class="titulo-abertura">O que vem por aí no Hive</h1>
    <p class="lede">Dez frentes levantadas com o uso e com a gestão. Cada uma entra numa etapa própria, testada e documentada,
      <strong>sem data prometida</strong>: o status diz o que falta para começar.</p>
    <p><span class="selo selo--ok">Em andamento</span> <span class="selo selo--sinal">Próxima</span> <span class="selo selo--aviso">Aguardando insumo</span> <span class="selo">Planejada</span></p>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="ev-vault-t">
  <div class="secao__cab"><p class="eyebrow">Conhecimento e Vault</p><h2 id="ev-vault-t">O que o time aprende vira base para todos</h2></div>
  <div class="grade revelar-grupo">
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>1</span></span>Documentação do código para o Vault</h3><p>Gerar, a partir do código, documentos de regra de negócio e da jornada no padrão OKF 0.2, no formato que o validador da esteira aceita. Teste, pipeline e configuração não sobem.</p><p><span class="selo selo--aviso">Aguardando o padrão e o validador</span></p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>2</span></span>Atualizar o Vault sob demanda</h3><p>Um comando para o dev registrar no Vault algo importante de uma mudança que não passou pelo Hive.</p><p><span class="selo">Planejada · depois da 1</span></p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>3</span></span>Projetos conectados ao Vault, com grafo</h3><p>Ligar os repositórios ao Vault, mantê-lo atualizado e juntar o mapa do código com o do conhecimento, para o discovery e o plano começarem com o contexto de negócio.</p><p><span class="selo selo--aviso">Aguardando como o Vault expõe o conteúdo</span></p></div>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="ev-proc-t">
  <div class="secao__cab"><p class="eyebrow">Processo e qualidade</p><h2 id="ev-proc-t">Mais garantia antes da produção</h2></div>
  <div class="grade revelar-grupo">
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>4</span></span>Fluxo de aprovação de cada mudança</h3><p>Cada aplicação aprova de um jeito (QA, PM, os dois…). O discovery ou o plano pergunta qual é o fluxo, e o fechamento passa a exigir exatamente essas aprovações.</p><p><span class="selo selo--sinal">Próxima</span></p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>5</span></span>Agente de segurança</h3><p>Revisão de segurança do código e das dependências: injeção, autenticação, dado sensível em log, segredo no código, biblioteca vulnerável. Teste contra ambiente só com autorização formal da Segurança.</p><p><span class="selo selo--aviso">Alinhando o checklist com a Segurança</span></p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>6</span></span>Acompanhar o caminho dos agentes</h3><p>Uma linha do tempo visual da mudança: fases, fatias, revisões e decisões, para o dev ver por onde os agentes passaram.</p><p><span class="selo">Planejada</span></p></div>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="ev-med-t">
  <div class="secao__cab"><p class="eyebrow">Medição</p><h2 id="ev-med-t">Uso visível para a gestão</h2></div>
  <div class="grade revelar-grupo">
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>7</span></span>Refino das métricas de uso</h3><p>Conferir com dados reais o que a coleta registra e ajustar o que falta para o painel.</p><p><span class="selo selo--ok">Em andamento</span></p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>8</span></span>Visão central por squad</h3><p>Enviar o relatório de uso para um lugar único, com a visão por dev, squad e período do <a href="painel.aspx">painel de exemplo</a>.</p><p><span class="selo selo--aviso">Destino em definição</span></p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>9</span></span>Tokens por sessão</h3><p>Trazer os tokens de cada sessão para o relatório, a partir da telemetria do Copilot.</p><p><span class="selo selo--aviso">Depende da TI ligar a telemetria</span></p></div>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="ev-dist-t">
  <div class="secao__cab"><p class="eyebrow">Distribuição</p><h2 id="ev-dist-t">Para todos os times</h2></div>
  <div class="grade grade--2 revelar-grupo">
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>10</span></span>Versão estável no marketplace</h3><p>Sair do <code>bradesco-marketplace-unstable</code> para o <code>bradesco-marketplace</code>, com o canário validado no Windows na versão publicada.</p><p><span class="selo selo--ok">Em andamento</span></p></div>
    <div class="card"><h3>Quer contribuir?</h3><p>Sugestão, problema ou uma lição que vale para todos: fale com o time de IA da BU ou use o canal de feedback do README do plugin.</p></div>
  </div>
</section>

<div class="conteudo">
  <nav class="passagem" aria-label="Navegação entre páginas">
    <a href="painel.aspx" data-anterior><small>← Anterior</small><strong>Painel</strong></a>
    <a class="prox" href="referencia.aspx" data-proxima><small>Próxima →</small><strong>Referência</strong></a>
  </nav>
  <footer class="rodape"><span>b.IA Credit Hive · documentação da versão 1.1 do plugin <code>bia-credit-hive</code></span><span><kbd>P</kbd> apresentação · <kbd>←</kbd> <kbd>→</kbd> navegar · <kbd>Esc</kbd> sair</span></footer>
</div>
</main>
<div class="slide-contador" aria-live="polite"></div>
</body>
</html>
