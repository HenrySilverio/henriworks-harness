<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Camadas · b.IA Credit Hive</title>
  <meta name="description" content="As sete camadas e onde cada coisa mora.">
  <link rel="icon" type="image/svg+xml" href="img/simbolo-bia.svg">
  <link rel="stylesheet" href="style.css">
  <script src="vendor/motion-lite.js" defer></script>
  <script src="app.js" defer></script>
</head>
<body>
<a class="pular" href="#conteudo">Pular para o conteúdo</a>
<div class="colmeia" aria-hidden="true">
<svg class="colmeia__favo" aria-hidden="true" focusable="false"><defs><pattern id="bchive-favo" width="48.497" height="84" patternUnits="userSpaceOnUse"><path d="M24.25,0.00 L48.50,14.00 L48.50,42.00 L24.25,56.00 L-0.00,42.00 L0.00,14.00 Z"/><path d="M0.00,42.00 L24.25,56.00 L24.25,84.00 L0.00,98.00 L-24.25,84.00 L-24.25,56.00 Z"/><path d="M48.50,42.00 L72.75,56.00 L72.75,84.00 L48.50,98.00 L24.25,84.00 L24.25,56.00 Z"/><path d="M0.00,-42.00 L24.25,-28.00 L24.25,-0.00 L0.00,14.00 L-24.25,-0.00 L-24.25,-28.00 Z"/><path d="M48.50,-42.00 L72.75,-28.00 L72.75,-0.00 L48.50,14.00 L24.25,-0.00 L24.25,-28.00 Z"/></pattern></defs><rect width="100%" height="100%" fill="url(#bchive-favo)"/></svg>
<svg class="colmeia__cacho colmeia__cacho--a" viewBox="0 0 227.9 207.0" aria-hidden="true" focusable="false"><path d="M61.98,7.80 L86.40,21.90 L86.40,50.10 L61.98,64.20 L37.56,50.10 L37.56,21.90 Z" class="vazio"/><path d="M113.94,7.80 L138.36,21.90 L138.36,50.10 L113.94,64.20 L89.52,50.10 L89.52,21.90 Z" class="vazio"/><path d="M165.90,7.80 L190.33,21.90 L190.33,50.10 L165.90,64.20 L141.48,50.10 L141.48,21.90 Z" class="vazio"/><path d="M36.00,52.80 L60.42,66.90 L60.42,95.10 L36.00,109.20 L11.58,95.10 L11.58,66.90 Z" class="vazio"/><path d="M87.96,52.80 L112.38,66.90 L112.38,95.10 L87.96,109.20 L63.54,95.10 L63.54,66.90 Z" class="mel"/><path d="M139.92,52.80 L164.34,66.90 L164.34,95.10 L139.92,109.20 L115.50,95.10 L115.50,66.90 Z" class="mel"/><path d="M191.88,52.80 L216.31,66.90 L216.31,95.10 L191.88,109.20 L167.46,95.10 L167.46,66.90 Z" class="vazio"/><path d="M61.98,97.80 L86.40,111.90 L86.40,140.10 L61.98,154.20 L37.56,140.10 L37.56,111.90 Z" class="mel"/><path d="M113.94,97.80 L138.36,111.90 L138.36,140.10 L113.94,154.20 L89.52,140.10 L89.52,111.90 Z" class="mel"/><path d="M165.90,97.80 L190.33,111.90 L190.33,140.10 L165.90,154.20 L141.48,140.10 L141.48,111.90 Z" class="vazio"/><path d="M139.92,142.80 L164.34,156.90 L164.34,185.10 L139.92,199.20 L115.50,185.10 L115.50,156.90 Z" class="vazio"/><path d="M36.00,142.80 L60.42,156.90 L60.42,185.10 L36.00,199.20 L11.58,185.10 L11.58,156.90 Z" class="vazio"/><path d="M87.96,142.80 L112.38,156.90 L112.38,185.10 L87.96,199.20 L63.54,185.10 L63.54,156.90 Z" class="vazio"/></svg>
<svg class="colmeia__cacho colmeia__cacho--b" viewBox="0 0 197.5 140.4" aria-hidden="true" focusable="false"><path d="M53.72,6.76 L74.88,18.98 L74.88,43.42 L53.72,55.64 L32.55,43.42 L32.55,18.98 Z" class="vazio"/><path d="M98.75,6.76 L119.92,18.98 L119.92,43.42 L98.75,55.64 L77.58,43.42 L77.58,18.98 Z" class="mel"/><path d="M143.78,6.76 L164.95,18.98 L164.95,43.42 L143.78,55.64 L122.62,43.42 L122.62,18.98 Z" class="vazio"/><path d="M31.20,45.76 L52.37,57.98 L52.37,82.42 L31.20,94.64 L10.03,82.42 L10.03,57.98 Z" class="vazio"/><path d="M76.23,45.76 L97.40,57.98 L97.40,82.42 L76.23,94.64 L55.07,82.42 L55.07,57.98 Z" class="vazio"/><path d="M121.27,45.76 L142.43,57.98 L142.43,82.42 L121.27,94.64 L100.10,82.42 L100.10,57.98 Z" class="vazio"/><path d="M166.30,45.76 L187.47,57.98 L187.47,82.42 L166.30,94.64 L145.13,82.42 L145.13,57.98 Z" class="mel"/><path d="M53.72,84.76 L74.88,96.98 L74.88,121.42 L53.72,133.64 L32.55,121.42 L32.55,96.98 Z" class="vazio"/><path d="M98.75,84.76 L119.92,96.98 L119.92,121.42 L98.75,133.64 L77.58,121.42 L77.58,96.98 Z" class="vazio"/><path d="M143.78,84.76 L164.95,96.98 L164.95,121.42 L143.78,133.64 L122.62,121.42 L122.62,96.98 Z" class="mel"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="left:1%;top:14%" aria-hidden="true" focusable="false"><path d="M10 100 C 40 20, 90 110, 130 50 S 180 20, 195 40"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="right:1%;top:70%;transform:scaleX(-1)" aria-hidden="true" focusable="false"><path d="M10 90 C 50 10, 80 100, 120 40 S 170 30, 195 60"/></svg>
<svg class="abelha ab1" style="left:2.5%;top:20%;--d:13s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab1"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab1)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab2" style="right:3%;top:34%;--d:16s;--x:-16px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab2"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab2)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab3" style="left:4%;top:62%;--d:15s;--x:14px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab3"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab3)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab4" style="right:5%;top:76%;--d:12s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab4"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab4)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab5" style="right:22%;top:12%;--d:18s;--x:-12px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab5"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab5)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
</div>

<div class="progresso" aria-hidden="true"><div class="progresso__barra"></div></div>
<header class="topo">
  <div class="conteudo topo__linha">
    <a class="marca" href="index.aspx" aria-label="b.IA Credit Hive, início">
      <img class="mlogo mlogo--c" src="img/logo-bia.svg" alt="b.IA Credit" height="28"><img class="mlogo mlogo--e" src="img/logo-bia-escuro.svg" alt="" height="28">
    </a>
    <nav class="sites" aria-label="Documentações"><a href="../fundamentos/index.aspx">Fundamentos de IA</a><a href="index.aspx" aria-current="true">b.IA Credit Hive</a></nav>
    <nav aria-label="Páginas da documentação" class="nav"><ul class="menu"><li><a href="index.aspx">Início</a></li><li><a href="por-que.aspx">Por que usar</a></li><li><a href="por-dentro.aspx">Por dentro</a></li><li><a href="fluxo.aspx">Fluxo</a></li><li><a href="camadas.aspx" aria-current="page">Camadas</a></li><li><a href="instalacao.aspx">Instalação</a></li><li><a href="cenarios.aspx">Cenários</a></li><li><a href="governanca.aspx">Governança</a></li><li><a href="painel.aspx">Painel</a></li><li><a href="evolucao.aspx">Evolução</a></li><li><a href="referencia.aspx">Referência</a></li></ul></nav>
    <div class="controles" data-controles></div>
  </div>
</header>
<main id="conteudo">
<section class="hero hero--pagina conteudo" data-slide>
  <div>
    <p class="eyebrow">Camadas</p>
    <h1 class="titulo-abertura">Sete camadas, um trabalho cada</h1>
    <p class="lede">Acima da linha, o que o modelo lê e interpreta. Abaixo dela, o que é <strong>determinístico</strong>: script, hook e arquivo.
      Quanto mais regra desce da linha, mais previsível e mais barato fica.</p>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="cam-t">
  <h2 id="cam-t" class="visualmente-oculto">As sete camadas</h2>
  <div class="pilha" role="list">
    <div class="pilha__item" role="listitem" style="--n:1"><span class="pilha__num">1</span><div><h3>Instruções do seu projeto</h3><p>As regras de código do time e do dev: <code>.github/instructions/</code>, <code>AGENTS.md</code>. Opcionais; o Hive convive com elas e nunca as edita.</p></div><span class="selo">do time</span></div>
    <div class="pilha__item" role="listitem" style="--n:2"><span class="pilha__num">2</span><div><h3>Agentes</h3><p>Nove papéis. Agente separado só quando muda o que pode ser feito ou visto (ex.: o revisor só lê).</p></div><span class="selo selo--sinal">plugin</span></div>
    <div class="pilha__item" role="listitem" style="--n:3"><span class="pilha__num">3</span><div><h3>Skills e contrato</h3><p>Os 18 comandos e o contrato do fluxo com referências, carregados sob demanda.</p></div><span class="selo selo--sinal">plugin</span></div>
    <div class="pilha__fronteira" role="separator"><span>fronteira do modelo · acima interpreta, abaixo executa</span></div>
    <div class="pilha__item pilha__item--det" role="listitem" style="--n:4"><span class="pilha__num">4</span><div><h3>Núcleo</h3><p>Scripts em Node sem dependência: estado, validação, pacotes de revisão, verificação com escopo, mapa, uso. Copiado para <code>.bchive/bin/</code>.</p></div><span class="selo selo--ok">determinístico</span></div>
    <div class="pilha__item pilha__item--det" role="listitem" style="--n:5"><span class="pilha__num">5</span><div><h3>Hooks</h3><p>Seis eventos do chat. Coletam contagens em todo chat e, onde há <code>.bchive/</code>, barram o que o agente não pode fazer.</p></div><span class="selo selo--ok">determinístico</span></div>
    <div class="pilha__item pilha__item--det" role="listitem" style="--n:6"><span class="pilha__num">6</span><div><h3>Estado</h3><p>Os artefatos de cada mudança em <code>.bchive/</code>: briefing, proposta, fatias, vereditos. A fase sai deles, não da memória.</p></div><span class="selo selo--ok">determinístico</span></div>
    <div class="pilha__item pilha__item--det" role="listitem" style="--n:7"><span class="pilha__num">7</span><div><h3>Uso</h3><p>Contagens por sessão, selo diário em cadeia de hash e exportação para o relatório. Fora de qualquer repositório.</p></div><span class="selo selo--ok">determinístico</span></div>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="onde-t">
  <div class="secao__cab">
    <p class="eyebrow">Onde cada coisa mora</p>
    <h2 id="onde-t">Na máquina, no repositório e no Git</h2>
    <p>A política do banco não deixa versionar artefato de IA no produto. Por isso o Hive põe quase tudo fora do Git e manda para a PR só o registro de conhecimento.</p>
  </div>
  <figure class="diagrama diagrama--onde revelar"><svg viewBox="0 0 960 330" role="img" aria-labelledby="do-t do-d"><title id="do-t">Onde cada coisa mora</title><desc id="do-d">Na máquina do dev ficam o plugin e o uso; no repositório, a pasta .bchive fora do Git; no Git e na PR, só o código e o registro de conhecimento.</desc><g class="dg-col" style="--i:0"><rect x="20" y="20" width="290" height="290" rx="18" class="dg-caixa"/><text x="40" y="56" class="dg-t dg-t--titulo">Máquina do dev</text><text x="40" y="78" class="dg-t dg-t--mono">fora de qualquer repositório</text><rect x="38" y="100" width="254" height="38" rx="10" class="dg-bolha"/><text x="52" y="124" class="dg-t dg-t--peq">plugin: agentes, skills, hooks</text><rect x="38" y="150" width="254" height="38" rx="10" class="dg-bolha"/><text x="52" y="174" class="dg-t dg-t--peq">~/.bchive/uso/ (contagens)</text><rect x="38" y="200" width="254" height="38" rx="10" class="dg-bolha"/><text x="52" y="224" class="dg-t dg-t--peq">telemetria (se a TI ligar)</text></g><g class="dg-col" style="--i:1"><rect x="340" y="20" width="290" height="290" rx="18" class="dg-caixa"/><text x="360" y="56" class="dg-t dg-t--titulo">Repositório, fora do Git</text><text x="360" y="78" class="dg-t dg-t--mono">.git/info/exclude</text><rect x="358" y="100" width="254" height="38" rx="10" class="dg-bolha"/><text x="372" y="124" class="dg-t dg-t--peq">.bchive/bin/ (núcleo)</text><rect x="358" y="150" width="254" height="38" rx="10" class="dg-bolha"/><text x="372" y="174" class="dg-t dg-t--peq">.bchive/changes/ (artefatos)</text><rect x="358" y="200" width="254" height="38" rx="10" class="dg-bolha"/><text x="372" y="224" class="dg-t dg-t--peq">specs, decisões, mapa</text><rect x="358" y="250" width="254" height="38" rx="10" class="dg-bolha"/><text x="372" y="274" class="dg-t dg-t--peq">.github/ e AGENTS.md seus</text></g><g class="dg-col" style="--i:2"><rect x="660" y="20" width="290" height="290" rx="18" class="dg-caixa dg-caixa--git"/><text x="680" y="56" class="dg-t dg-t--titulo">Git e PR</text><text x="680" y="78" class="dg-t dg-t--mono">o que o time revisa</text><rect x="678" y="100" width="254" height="38" rx="10" class="dg-bolha"/><text x="692" y="124" class="dg-t dg-t--peq">o código da mudança</text><rect x="678" y="150" width="254" height="38" rx="10" class="dg-bolha"/><text x="692" y="174" class="dg-t dg-t--peq">conhecimento/&lt;data>-&lt;ticket>.md</text><rect x="678" y="200" width="254" height="38" rx="10" class="dg-bolha"/><text x="692" y="224" class="dg-t dg-t--peq">resumo.md na descrição da PR</text></g><path d="M310,165 L340,165" class="dg-seta desenhar"/><path d="M630,165 L660,165" class="dg-seta desenhar"/></svg></figure>

</section>

<section class="secao conteudo" data-slide aria-labelledby="hook-t">
  <div class="secao__cab">
    <p class="eyebrow">Hooks em detalhe</p>
    <h2 id="hook-t">O que os hooks fazem, e o que nunca fazem</h2>
  </div>
  <div class="grade grade--2 revelar-grupo">
    <div class="card"><h3><span class="selo selo--ok">Fazem</span></h3><ul class="lista">
      <li>Registram nome de comando, skill, agente e ferramenta, repositório, branch e ticket</li>
      <li>Impedem editar veredito ou mudança arquivada</li>
      <li>Impedem o agente de rodar portão humano (aprovar spec, OK do QA…)</li>
      <li>Conferem que o revisor recebeu exatamente o pacote gerado</li>
      <li>Pedem para consultar o mapa antes da primeira busca no fluxo</li></ul></div>
    <div class="card"><h3><span class="selo selo--nao">Nunca</span></h3><ul class="lista">
      <li>Gravam prompt, resposta, código ou argumento de ferramenta</li>
      <li>Barram agentes, skills ou hooks que são seus</li>
      <li>Escrevem no Git ou em <code>.github/</code></li>
      <li>Derrubam o chat: em qualquer erro, terminam sem decisão</li></ul></div>
  </div>
</section>

<div class="conteudo">
  <nav class="passagem" aria-label="Navegação entre páginas">
    <a href="fluxo.aspx" data-anterior><small>← Anterior</small><strong>Fluxo</strong></a>
    <a class="prox" href="instalacao.aspx" data-proxima><small>Próxima →</small><strong>Instalação</strong></a>
  </nav>
  <footer class="rodape"><span>b.IA Credit Hive · documentação da versão 1.1 do plugin <code>bia-credit-hive</code></span><span><kbd>P</kbd> apresentação · <kbd>←</kbd> <kbd>→</kbd> navegar · <kbd>Esc</kbd> sair</span></footer>
</div>
</main>
<div class="slide-contador" aria-live="polite"></div>
</body>
</html>
