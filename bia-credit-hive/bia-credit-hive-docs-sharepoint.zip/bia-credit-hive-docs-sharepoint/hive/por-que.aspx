<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Por que usar o Hive · b.IA Credit Hive</title>
  <meta name="description" content="Vantagens, o que se perde sem ele mesmo com os seus agentes, e quando não vale.">
  <link rel="icon" type="image/svg+xml" href="img/simbolo-bia.svg">
  <link rel="stylesheet" href="style.css">
  <script src="vendor/motion-lite.js" defer></script>
  <script src="app.js" defer></script>
</head>
<body>
<a class="pular" href="#conteudo">Pular para o conteúdo</a>
<div class="colmeia" aria-hidden="true">
<svg class="colmeia__favo" aria-hidden="true" focusable="false"><defs><pattern id="bchive-favo" width="48.497" height="84" patternUnits="userSpaceOnUse"><path d="M24.25,0.00 L48.50,14.00 L48.50,42.00 L24.25,56.00 L-0.00,42.00 L0.00,14.00 Z"/><path d="M0.00,42.00 L24.25,56.00 L24.25,84.00 L0.00,98.00 L-24.25,84.00 L-24.25,56.00 Z"/><path d="M48.50,42.00 L72.75,56.00 L72.75,84.00 L48.50,98.00 L24.25,84.00 L24.25,56.00 Z"/><path d="M0.00,-42.00 L24.25,-28.00 L24.25,-0.00 L0.00,14.00 L-24.25,-0.00 L-24.25,-28.00 Z"/><path d="M48.50,-42.00 L72.75,-28.00 L72.75,-0.00 L48.50,14.00 L24.25,-0.00 L24.25,-28.00 Z"/></pattern></defs><rect width="100%" height="100%" fill="url(#bchive-favo)"/></svg>
<svg class="colmeia__cacho colmeia__cacho--a" viewBox="0 0 227.9 207.0" aria-hidden="true" focusable="false"><path d="M61.98,7.80 L86.40,21.90 L86.40,50.10 L61.98,64.20 L37.56,50.10 L37.56,21.90 Z" class="vazio"/><path d="M113.94,7.80 L138.36,21.90 L138.36,50.10 L113.94,64.20 L89.52,50.10 L89.52,21.90 Z" class="vazio"/><path d="M165.90,7.80 L190.33,21.90 L190.33,50.10 L165.90,64.20 L141.48,50.10 L141.48,21.90 Z" class="vazio"/><path d="M36.00,52.80 L60.42,66.90 L60.42,95.10 L36.00,109.20 L11.58,95.10 L11.58,66.90 Z" class="vazio"/><path d="M87.96,52.80 L112.38,66.90 L112.38,95.10 L87.96,109.20 L63.54,95.10 L63.54,66.90 Z" class="mel"/><path d="M139.92,52.80 L164.34,66.90 L164.34,95.10 L139.92,109.20 L115.50,95.10 L115.50,66.90 Z" class="mel"/><path d="M191.88,52.80 L216.31,66.90 L216.31,95.10 L191.88,109.20 L167.46,95.10 L167.46,66.90 Z" class="vazio"/><path d="M61.98,97.80 L86.40,111.90 L86.40,140.10 L61.98,154.20 L37.56,140.10 L37.56,111.90 Z" class="mel"/><path d="M113.94,97.80 L138.36,111.90 L138.36,140.10 L113.94,154.20 L89.52,140.10 L89.52,111.90 Z" class="mel"/><path d="M165.90,97.80 L190.33,111.90 L190.33,140.10 L165.90,154.20 L141.48,140.10 L141.48,111.90 Z" class="vazio"/><path d="M139.92,142.80 L164.34,156.90 L164.34,185.10 L139.92,199.20 L115.50,185.10 L115.50,156.90 Z" class="vazio"/><path d="M36.00,142.80 L60.42,156.90 L60.42,185.10 L36.00,199.20 L11.58,185.10 L11.58,156.90 Z" class="vazio"/><path d="M87.96,142.80 L112.38,156.90 L112.38,185.10 L87.96,199.20 L63.54,185.10 L63.54,156.90 Z" class="vazio"/></svg>
<svg class="colmeia__cacho colmeia__cacho--b" viewBox="0 0 197.5 140.4" aria-hidden="true" focusable="false"><path d="M53.72,6.76 L74.88,18.98 L74.88,43.42 L53.72,55.64 L32.55,43.42 L32.55,18.98 Z" class="vazio"/><path d="M98.75,6.76 L119.92,18.98 L119.92,43.42 L98.75,55.64 L77.58,43.42 L77.58,18.98 Z" class="mel"/><path d="M143.78,6.76 L164.95,18.98 L164.95,43.42 L143.78,55.64 L122.62,43.42 L122.62,18.98 Z" class="vazio"/><path d="M31.20,45.76 L52.37,57.98 L52.37,82.42 L31.20,94.64 L10.03,82.42 L10.03,57.98 Z" class="vazio"/><path d="M76.23,45.76 L97.40,57.98 L97.40,82.42 L76.23,94.64 L55.07,82.42 L55.07,57.98 Z" class="vazio"/><path d="M121.27,45.76 L142.43,57.98 L142.43,82.42 L121.27,94.64 L100.10,82.42 L100.10,57.98 Z" class="vazio"/><path d="M166.30,45.76 L187.47,57.98 L187.47,82.42 L166.30,94.64 L145.13,82.42 L145.13,57.98 Z" class="mel"/><path d="M53.72,84.76 L74.88,96.98 L74.88,121.42 L53.72,133.64 L32.55,121.42 L32.55,96.98 Z" class="vazio"/><path d="M98.75,84.76 L119.92,96.98 L119.92,121.42 L98.75,133.64 L77.58,121.42 L77.58,96.98 Z" class="vazio"/><path d="M143.78,84.76 L164.95,96.98 L164.95,121.42 L143.78,133.64 L122.62,121.42 L122.62,96.98 Z" class="mel"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="left:1%;top:14%" aria-hidden="true" focusable="false"><path d="M10 100 C 40 20, 90 110, 130 50 S 180 20, 195 40"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="right:1%;top:70%;transform:scaleX(-1)" aria-hidden="true" focusable="false"><path d="M10 90 C 50 10, 80 100, 120 40 S 170 30, 195 60"/></svg>
<svg class="abelha ab1" style="left:2.5%;top:20%;--d:13s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab1"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab1)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab2" style="right:3%;top:34%;--d:16s;--x:-16px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab2"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab2)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab3" style="left:4%;top:62%;--d:15s;--x:14px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab3"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab3)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab4" style="right:5%;top:76%;--d:12s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab4"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab4)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab5" style="right:22%;top:12%;--d:18s;--x:-12px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab5"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab5)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
</div>

<div class="progresso" aria-hidden="true"><div class="progresso__barra"></div></div>
<header class="topo">
  <div class="conteudo topo__linha">
    <a class="marca" href="index.aspx" aria-label="b.IA Credit Hive, início">
      <img class="mlogo mlogo--c" src="img/logo-bia.svg" alt="b.IA Credit" height="28"><img class="mlogo mlogo--e" src="img/logo-bia-escuro.svg" alt="" height="28">
    </a>
    <nav class="sites" aria-label="Documentações"><a href="../fundamentos/index.aspx">Fundamentos de IA</a><a href="index.aspx" aria-current="true">b.IA Credit Hive</a></nav>
    <nav aria-label="Páginas da documentação" class="nav"><ul class="menu"><li><a href="index.aspx">Início</a></li><li><a href="por-que.aspx" aria-current="page">Por que usar</a></li><li><a href="por-dentro.aspx">Por dentro</a></li><li><a href="fluxo.aspx">Fluxo</a></li><li><a href="camadas.aspx">Camadas</a></li><li><a href="instalacao.aspx">Instalação</a></li><li><a href="cenarios.aspx">Cenários</a></li><li><a href="governanca.aspx">Governança</a></li><li><a href="painel.aspx">Painel</a></li><li><a href="evolucao.aspx">Evolução</a></li><li><a href="referencia.aspx">Referência</a></li></ul></nav>
    <div class="controles" data-controles></div>
  </div>
</header>
<main id="conteudo">
<section class="hero hero--pagina conteudo" data-slide>
  <div>
    <p class="eyebrow">Por que usar</p>
    <h1 class="titulo-abertura">Seus agentes escrevem código. O Hive garante a entrega.</h1>
    <p class="lede">O Hive não substitui o agente Java, Angular ou COBOL que você já usa. Ele coloca esse agente dentro de um
      <strong>processo</strong>: entender antes de codar, revisar com quem não viu a conversa, decidir com nome e motivo e só fechar depois do OK do QA.</p>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="vant-t">
  <div class="secao__cab"><p class="eyebrow">Vantagens</p><h2 id="vant-t">O que você ganha</h2></div>
  <div class="grade revelar-grupo">
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>1</span></span>Previsibilidade</h3><p>Briefing com insumos e um plano revisado antes da primeira linha de código. O escopo de cada fatia diz que arquivos ela pode tocar, e um script confere.</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>2</span></span>Qualidade</h3><p>Revisão em três eixos (fez o combinado, segue os padrões do time, não tem bug nem risco) por um revisor que não viu a conversa, mais verificação por script que separa erro novo de erro antigo.</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>3</span></span>Menos tokens, menos retrabalho</h3><p>Uma fase por chat, subagente com contexto limpo, mapa do projeto antes de busca ampla. Fora do fluxo, o plugin acrescenta só uns 60 tokens por pedido.</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>4</span></span>Decisão com dono</h3><p>Aprovar a spec, aceitar risco, liberar rodada extra, dar o OK do QA e aprovar lição: só uma pessoa faz, no terminal, com nome e motivo. O agente não consegue.</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>5</span></span>Conhecimento que fica</h3><p>Registro de cada entrega e lições aprovadas pelo time, versionadas no repositório e lidas pelos agentes só onde valem.</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>6</span></span>Visibilidade para a gestão</h3><p>Uso por dev, squad e período, com contagens e tokens, nunca o conteúdo da conversa.</p></div>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="comp-t">
  <div class="secao__cab"><p class="eyebrow">A comparação honesta</p><h2 id="comp-t">Só os seus agentes × seus agentes dentro do Hive</h2>
    <p>Os dois lados usam o mesmo modelo e o mesmo agente da stack. A diferença é o que acontece em volta.</p></div>
  <div class="tabela-wrap revelar"><table>
    <thead><tr><th>Momento</th><th>Só os seus agentes</th><th>Com o Hive</th></tr></thead>
    <tbody>
      <tr><td>Entender o pedido</td><td>O agente começa do que foi digitado no chat e preenche o que falta por conta própria</td><td>Briefing com problema, esperado, restrições e insumos; o que falta é perguntado antes</td></tr>
      <tr><td>Planejar</td><td>Decide no caminho; o escopo cresce sem ninguém ver</td><td>Proposta com critérios de aceite e fatias verticais, revisada e aprovada por uma pessoa</td></tr>
      <tr><td>Implementar</td><td>Uma conversa longa, que vai esquecendo o começo</td><td>Uma fatia por sessão, com contexto limpo e os arquivos permitidos conferidos por script</td></tr>
      <tr><td>Revisar</td><td>O mesmo agente que escreveu, ou ninguém até a PR</td><td>Revisor isolado, provado pelo canário, em três eixos e com régua de severidade</td></tr>
      <tr><td>Regras do time</td><td>Instruções que o modelo pode esquecer ou interpretar</td><td>Padrões e lições do time entram na revisão; hooks garantem o que não pode falhar</td></tr>
      <tr><td>Decidir</td><td>Na conversa, sem registro</td><td>Portões humanos com nome e motivo, que vão para a PR</td></tr>
      <tr><td>Fechar</td><td>Ao abrir a PR, mesmo que o QA ache erro depois</td><td>Só depois do OK do QA; correção é uma mudança nova na mesma PR</td></tr>
      <tr><td>Retomar</td><td>Depende de quem estava na conversa</td><td>O estado mora em arquivos: outro dev, ou você amanhã, continua de onde parou</td></tr>
      <tr><td>Aprender</td><td>O que deu errado se perde no histórico do chat</td><td>Lições propostas pelo agente e aprovadas pelo time, lidas na próxima tarefa daquele escopo</td></tr>
      <tr><td>Medir</td><td>Uso invisível</td><td>Painel por dev, squad e período</td></tr>
    </tbody></table></div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="perde-t">
  <div class="secao__cab"><p class="eyebrow">O que se perde sem o Hive</p><h2 id="perde-t">Mesmo com bons agentes, cinco riscos voltam</h2></div>
  <div class="pilha" role="list">
    <div class="pilha__item" role="listitem" style="--n:3"><span class="pilha__num">1</span><div><h3>Código certo para o problema errado</h3><p>Sem briefing e sem critérios de aceite, o agente resolve o que entendeu, não o que o negócio pediu. O erro aparece no QA, ou em produção.</p></div><span class="selo selo--nao">retrabalho</span></div>
    <div class="pilha__item" role="listitem" style="--n:4"><span class="pilha__num">2</span><div><h3>Quem escreveu revisa o próprio trabalho</h3><p>O agente que fez a suposição não enxerga a suposição. O revisor humano da PR recebe um diff grande e pouco contexto.</p></div><span class="selo selo--nao">bug escapa</span></div>
    <div class="pilha__item" role="listitem" style="--n:5"><span class="pilha__num">3</span><div><h3>A conversa vira a documentação</h3><p>Por que algo foi feito assim, o que foi testado e quem aceitou o risco ficam num chat que ninguém vai reabrir.</p></div><span class="selo selo--aviso">sem rastro</span></div>
    <div class="pilha__item" role="listitem" style="--n:6"><span class="pilha__num">4</span><div><h3>Instrução não é garantia</h3><p>"Não commite", "não aprove", "não mexa nessa pasta" escritos em instruções podem ser esquecidos. No Hive, o hook bloqueia.</p></div><span class="selo selo--aviso">risco</span></div>
    <div class="pilha__item" role="listitem" style="--n:7"><span class="pilha__num">5</span><div><h3>Cada dev, um jeito</h3><p>Sem processo comum, a qualidade depende de quem pediu e de como pediu. Não dá para comparar, ensinar nem melhorar.</p></div><span class="selo">sem padrão</span></div>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="junto-t">
  <div class="secao__cab"><p class="eyebrow">Com os agentes que você já tem</p><h2 id="junto-t">O seu agente continua trabalhando, agora no lugar certo</h2></div>
  <div class="grade grade--2 revelar-grupo">
    <div class="card"><h3>O que muda para o seu agente</h3><ul class="lista">
      <li>Recebe uma fatia pequena, com critérios e os arquivos que pode tocar, em vez de um pedido aberto.</li>
      <li>Trabalha num contexto limpo, sem a conversa inteira atrás.</li>
      <li>Tem o trabalho revisado por quem não o viu escrever.</li></ul></div>
    <div class="card"><h3>O que você precisa fazer</h3><ul class="lista">
      <li>Deixar o agente chamável como subagente e com descrição da stack.</li>
      <li>Conferir com <code>node .bchive/bin/bchive.mjs executores conferir</code>.</li>
      <li>Confirmar no plano qual agente executa cada fatia. <a href="instalacao.aspx#executor">Passo a passo</a>.</li></ul></div>
  </div>
  <div class="nivel revelar" style="margin-top:18px">
    <div data-nivel="gestao"><span class="nivel__tag">Gestão</span><p>Os investimentos em agentes por stack continuam valendo. O Hive é a camada que torna o uso deles previsível, auditável e comparável entre squads.</p></div>
    <div data-nivel="tecnico"><span class="nivel__tag">Técnico</span><p>O agente externo entra como <code>Executor:</code> da fatia. O <code>Toca:</code>, a verificação por camada, a revisão isolada e os portões continuam do Hive, para qualquer executor.</p></div>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="custo-t">
  <div class="secao__cab"><p class="eyebrow">Sem letra miúda</p><h2 id="custo-t">O que o Hive custa e quando não vale</h2></div>
  <div class="grade grade--2 revelar-grupo">
    <div class="card"><h3>O custo</h3><p>Mais passos que um chat solto: uma fase por chat, aprovar a spec, esperar a revisão. Numa entrega de verdade, esse tempo volta como menos idas e vindas com o QA e menos PR reprovada.</p></div>
    <div class="card"><h3>Quando não usar</h3><p>Ajuste pequeno sem decisão (teste quebrado, texto, configuração), dúvida sobre o código ou spike para aprender uma tecnologia: chat normal. O <code>/bia-credit-hive:start</code> diz quando o fluxo vale.</p></div>
  </div>
  <p class="regra-ouro revelar" style="margin-top:22px">Agente bom escreve código. <span>Processo bom entrega o que foi pedido.</span></p>
</section>

<div class="conteudo">
  <nav class="passagem" aria-label="Navegação entre páginas">
    <a href="index.aspx" data-anterior><small>← Anterior</small><strong>Início</strong></a>
    <a class="prox" href="por-dentro.aspx" data-proxima><small>Próxima →</small><strong>Por dentro</strong></a>
  </nav>
  <footer class="rodape"><span>b.IA Credit Hive · documentação da versão 1.1 do plugin <code>bia-credit-hive</code></span><span><kbd>P</kbd> apresentação · <kbd>←</kbd> <kbd>→</kbd> navegar · <kbd>Esc</kbd> sair</span></footer>
</div>
</main>
<div class="slide-contador" aria-live="polite"></div>
</body>
</html>
