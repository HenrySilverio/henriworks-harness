<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Janela de contexto · Fundamentos de IA</title>
  <meta name="description" content="O que cabe na memória de trabalho do modelo, como ela enche e como organizar o uso no Copilot.">
  <link rel="icon" type="image/svg+xml" href="img/simbolo-bia.svg">
  <link rel="stylesheet" href="style.css">
  <script src="vendor/motion-lite.js" defer></script>
  <script src="fundamentos.js" defer></script>
  <script src="app.js" defer></script>
</head>
<body>
<a class="pular" href="#conteudo">Pular para o conteúdo</a>
<div class="colmeia" aria-hidden="true">
<svg class="colmeia__favo" aria-hidden="true" focusable="false"><defs><pattern id="bchive-favo" width="48.497" height="84" patternUnits="userSpaceOnUse"><path d="M24.25,0.00 L48.50,14.00 L48.50,42.00 L24.25,56.00 L-0.00,42.00 L0.00,14.00 Z"/><path d="M0.00,42.00 L24.25,56.00 L24.25,84.00 L0.00,98.00 L-24.25,84.00 L-24.25,56.00 Z"/><path d="M48.50,42.00 L72.75,56.00 L72.75,84.00 L48.50,98.00 L24.25,84.00 L24.25,56.00 Z"/><path d="M0.00,-42.00 L24.25,-28.00 L24.25,-0.00 L0.00,14.00 L-24.25,-0.00 L-24.25,-28.00 Z"/><path d="M48.50,-42.00 L72.75,-28.00 L72.75,-0.00 L48.50,14.00 L24.25,-0.00 L24.25,-28.00 Z"/></pattern></defs><rect width="100%" height="100%" fill="url(#bchive-favo)"/></svg>
<svg class="colmeia__cacho colmeia__cacho--a" viewBox="0 0 227.9 207.0" aria-hidden="true" focusable="false"><path d="M61.98,7.80 L86.40,21.90 L86.40,50.10 L61.98,64.20 L37.56,50.10 L37.56,21.90 Z" class="vazio"/><path d="M113.94,7.80 L138.36,21.90 L138.36,50.10 L113.94,64.20 L89.52,50.10 L89.52,21.90 Z" class="vazio"/><path d="M165.90,7.80 L190.33,21.90 L190.33,50.10 L165.90,64.20 L141.48,50.10 L141.48,21.90 Z" class="vazio"/><path d="M36.00,52.80 L60.42,66.90 L60.42,95.10 L36.00,109.20 L11.58,95.10 L11.58,66.90 Z" class="vazio"/><path d="M87.96,52.80 L112.38,66.90 L112.38,95.10 L87.96,109.20 L63.54,95.10 L63.54,66.90 Z" class="mel"/><path d="M139.92,52.80 L164.34,66.90 L164.34,95.10 L139.92,109.20 L115.50,95.10 L115.50,66.90 Z" class="mel"/><path d="M191.88,52.80 L216.31,66.90 L216.31,95.10 L191.88,109.20 L167.46,95.10 L167.46,66.90 Z" class="vazio"/><path d="M61.98,97.80 L86.40,111.90 L86.40,140.10 L61.98,154.20 L37.56,140.10 L37.56,111.90 Z" class="mel"/><path d="M113.94,97.80 L138.36,111.90 L138.36,140.10 L113.94,154.20 L89.52,140.10 L89.52,111.90 Z" class="mel"/><path d="M165.90,97.80 L190.33,111.90 L190.33,140.10 L165.90,154.20 L141.48,140.10 L141.48,111.90 Z" class="vazio"/><path d="M139.92,142.80 L164.34,156.90 L164.34,185.10 L139.92,199.20 L115.50,185.10 L115.50,156.90 Z" class="vazio"/><path d="M36.00,142.80 L60.42,156.90 L60.42,185.10 L36.00,199.20 L11.58,185.10 L11.58,156.90 Z" class="vazio"/><path d="M87.96,142.80 L112.38,156.90 L112.38,185.10 L87.96,199.20 L63.54,185.10 L63.54,156.90 Z" class="vazio"/></svg>
<svg class="colmeia__cacho colmeia__cacho--b" viewBox="0 0 197.5 140.4" aria-hidden="true" focusable="false"><path d="M53.72,6.76 L74.88,18.98 L74.88,43.42 L53.72,55.64 L32.55,43.42 L32.55,18.98 Z" class="vazio"/><path d="M98.75,6.76 L119.92,18.98 L119.92,43.42 L98.75,55.64 L77.58,43.42 L77.58,18.98 Z" class="mel"/><path d="M143.78,6.76 L164.95,18.98 L164.95,43.42 L143.78,55.64 L122.62,43.42 L122.62,18.98 Z" class="vazio"/><path d="M31.20,45.76 L52.37,57.98 L52.37,82.42 L31.20,94.64 L10.03,82.42 L10.03,57.98 Z" class="vazio"/><path d="M76.23,45.76 L97.40,57.98 L97.40,82.42 L76.23,94.64 L55.07,82.42 L55.07,57.98 Z" class="vazio"/><path d="M121.27,45.76 L142.43,57.98 L142.43,82.42 L121.27,94.64 L100.10,82.42 L100.10,57.98 Z" class="vazio"/><path d="M166.30,45.76 L187.47,57.98 L187.47,82.42 L166.30,94.64 L145.13,82.42 L145.13,57.98 Z" class="mel"/><path d="M53.72,84.76 L74.88,96.98 L74.88,121.42 L53.72,133.64 L32.55,121.42 L32.55,96.98 Z" class="vazio"/><path d="M98.75,84.76 L119.92,96.98 L119.92,121.42 L98.75,133.64 L77.58,121.42 L77.58,96.98 Z" class="vazio"/><path d="M143.78,84.76 L164.95,96.98 L164.95,121.42 L143.78,133.64 L122.62,121.42 L122.62,96.98 Z" class="mel"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="left:1%;top:14%" aria-hidden="true" focusable="false"><path d="M10 100 C 40 20, 90 110, 130 50 S 180 20, 195 40"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="right:1%;top:70%;transform:scaleX(-1)" aria-hidden="true" focusable="false"><path d="M10 90 C 50 10, 80 100, 120 40 S 170 30, 195 60"/></svg>
<svg class="abelha ab1" style="left:2.5%;top:20%;--d:13s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab1"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab1)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab2" style="right:3%;top:34%;--d:16s;--x:-16px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab2"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab2)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab3" style="left:4%;top:62%;--d:15s;--x:14px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab3"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab3)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab4" style="right:5%;top:76%;--d:12s" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab4"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab4)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
<svg class="abelha ab5" style="right:22%;top:12%;--d:18s;--x:-12px" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-ab5"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-ab5)" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>
</div>

<div class="progresso" aria-hidden="true"><div class="progresso__barra"></div></div>
<header class="topo">
  <div class="conteudo topo__linha">
    <a class="marca" href="index.aspx" aria-label="Fundamentos de IA, início">
      <img class="mlogo mlogo--c" src="img/logo-bia.svg" alt="b.IA Credit" height="28"><img class="mlogo mlogo--e" src="img/logo-bia-escuro.svg" alt="" height="28"><span class="marca__produto">Fundamentos de IA</span>
    </a>
    <nav aria-label="Páginas" class="nav"><ul class="menu"><li><a href="index.aspx">Início</a></li><li><a href="tokens.aspx">Tokens e custo</a></li><li><a href="contexto.aspx" aria-current="page">Janela de contexto</a></li><li><a href="modelo-agente.aspx">Modelo × agente</a></li><li><a href="pecas.aspx">Agents, skills, hooks</a></li><li><a href="harness.aspx">Harness</a></li></ul></nav>
    <div class="controles" data-controles></div>
  </div>
</header>
<main id="conteudo">
<section class="hero hero--pagina conteudo" data-slide>
  <div>
    <p class="eyebrow">2 · Janela de contexto</p>
    <h1 class="titulo-abertura">A mesa de trabalho do modelo</h1>
    <p class="lede">O modelo só enxerga o que está <strong>na mesa</strong> naquele pedido. O que não está na janela de contexto,
      para ele, não existe. E a mesa tem tamanho.</p>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="jan-t">
  <div class="secao__cab"><p class="eyebrow">O que é</p><h2 id="jan-t">Memória de trabalho, não memória de longo prazo</h2></div>
  <div class="grade revelar-grupo">
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>1</span></span>Cabe um limite</h3><p>Claude Opus 5.5 e GPT-6 Luna aceitam cerca de <strong>1 milhão de tokens</strong> por pedido: umas 2.500 páginas. Parece infinito; numa conversa longa com arquivos, não é.</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>2</span></span>Ele não lembra de nada</h3><p>O modelo não guarda a conversa entre um pedido e outro. Quem "lembra" é o chat, que <strong>reenvia tudo</strong> a cada turno, e por isso cada turno custa mais que o anterior.</p></div>
    <div class="card"><h3><span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>3</span></span>Mais não é melhor</h3><p>Quanto mais coisa na mesa, menos atenção cada parte recebe. O que está no meio de um contexto enorme tende a pesar menos na resposta.</p></div>
  </div>
  <div class="nivel revelar" style="margin-top:18px">
    <div data-nivel="gestao"><span class="nivel__tag">Gestão</span><p>Pense numa reunião de quatro horas: no fim, ninguém lembra com precisão o que se decidiu na primeira meia hora. Uma conversa longa com a IA sofre do mesmo jeito, e ainda fica mais cara a cada fala.</p></div>
    <div data-nivel="tecnico"><span class="nivel__tag">Técnico</span><p>O chat é stateless do lado do modelo: cada requisição leva instruções do sistema, definições de ferramentas, instruções do repositório, arquivos anexados ou lidos pelas ferramentas, todo o histórico e espaço para a resposta. Perto do limite, o Copilot resume ou descarta o começo da conversa, e os detalhes se perdem.</p></div>
  </div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="sim-t">
  <div class="secao__cab"><p class="eyebrow">Experimente</p><h2 id="sim-t">O que ocupa a mesa em três jeitos de trabalhar</h2>
    <p>As instruções do Hive são reais; o resto é ilustrativo. A linha de 272 mil marca onde o GPT-6 Luna passa a cobrar mais caro.</p></div>
  <div class="fx-caixa revelar" data-janela data-hive="{&quot;fixos&quot;:61,&quot;gf&quot;:485,&quot;implementador&quot;:1021,&quot;plan&quot;:2091,&quot;review&quot;:1258,&quot;contrato&quot;:6539}" data-sem-js aria-hidden="true">
    <div class="fx-botoes" data-janela-cenas>
      <button type="button" data-cena="solto" aria-pressed="true">Chat solto</button>
      <button type="button" data-cena="fase" aria-pressed="false">Uma fase por chat</button>
      <button type="button" data-cena="sub" aria-pressed="false">Subagente com contexto limpo</button>
    </div>
    <div class="calc-campo" data-janela-turnos-box><label for="j-t">Turnos de conversa <strong data-janela-turnos-v>12</strong></label><input id="j-t" type="range" min="1" max="40" value="12" data-janela-turnos></div>
    <div class="jn-barra" data-janela-barra></div>
    <ul class="jn-legenda" data-janela-legenda></ul>
    <p class="jn-info" data-janela-info aria-live="polite"></p>
    <p class="nota" data-janela-texto></p>
  </div>
  <div class="tabela-wrap revelar" style="margin-top:18px"><table>
    <thead><tr><th>Jeito de trabalhar</th><th>O que vai em cada pedido</th><th>Efeito</th></tr></thead>
    <tbody>
      <tr><td>Chat solto, a mesma conversa para tudo</td><td>Instruções + arquivos colados + todo o histórico, que cresce a cada turno</td><td>Custo sobe a cada turno; o começo perde peso; perto do limite, o histórico é resumido</td></tr>
      <tr><td>Uma fase por chat</td><td>Instruções do agente da fase + o arquivo que a fase anterior deixou</td><td>Contexto pequeno e previsível; nada depende de lembrar a conversa</td></tr>
      <tr><td>Subagente com contexto limpo</td><td>Só a tarefa e os arquivos dela</td><td>O mais barato e o mais imparcial: ideal para revisar e para executar uma fatia</td></tr>
    </tbody></table></div>
</section>

<section class="secao conteudo" data-slide aria-labelledby="bp-t">
  <div class="secao__cab"><p class="eyebrow">Boas práticas no GitHub Copilot</p><h2 id="bp-t">Organize a mesa antes de pedir</h2></div>
  <ol class="checklist revelar-grupo">
    <li><strong>Um chat por tarefa ou por fase.</strong> Mudou de assunto, abra um chat novo. O que precisa continuar vai num arquivo, não na memória da conversa.</li>
    <li><strong>Aponte, não cole.</strong> Use <code>#arquivo</code> ou deixe o agente buscar. Colar código no chat soma tokens e envelhece rápido.</li>
    <li><strong>Instruções curtas e com endereço.</strong> Prefira <code>.instructions.md</code> com <code>applyTo</code> por pasta a um arquivo gigante que entra em todo pedido.</li>
    <li><strong>Feche o que não importa.</strong> O arquivo aberto no editor pode entrar como contexto. Anexar uma pasta inteira raramente ajuda.</li>
    <li><strong>Tarefa isolada, subagente.</strong> Revisão, busca ampla e execução de uma fatia rendem mais num contexto limpo.</li>
    <li><strong>Conversa longa, resumo e recomeço.</strong> Peça um resumo do que foi decidido, abra um chat novo e cole só o resumo.</li>
    <li><strong>Escolha o modelo pela tarefa.</strong> Contexto grande em modelo caro é o jeito mais rápido de gastar créditos.</li>
  </ol>
</section>

<section class="secao conteudo" data-slide aria-labelledby="vault-t">
  <div class="secao__cab"><p class="eyebrow">E a memória de longo prazo?</p><h2 id="vault-t">Vault: o conhecimento que fica</h2>
    <p>A janela de contexto é a mesa, que se limpa a cada pedido. O <strong>Vault</strong> é o arquivo da empresa: memória e conhecimento de longo prazo, consultados só quando importam.</p></div>
  <div class="vault">
    <div class="vault__cofre revelar" aria-hidden="true"><svg viewBox="0 0 220 180">
      <rect x="20" y="14" width="180" height="152" rx="16" class="cf-porta"/>
      <polygon points="70,44 86,53 86,71 70,80 54,71 54,53" class="cf-hex"/><polygon points="102,44 118,53 118,71 102,80 86,71 86,53" class="cf-hex cf-hex--v"/>
      <polygon points="86,71 102,80 102,98 86,107 70,98 70,80" class="cf-hex cf-hex--v"/><polygon points="118,71 134,80 134,98 118,107 102,98 102,80" class="cf-hex"/>
      <polygon points="70,98 86,107 86,125 70,134 54,125 54,107" class="cf-hex"/><polygon points="102,98 118,107 118,125 102,134 86,125 86,107" class="cf-hex cf-hex--v"/>
      <circle cx="166" cy="90" r="18" class="cf-gira"/><path d="M166 72 V108 M148 90 H184" class="cf-gira"/>
    </svg></div>
    <div class="revelar-grupo">
      <p><span class="selo selo--aviso">Em desenvolvimento no banco</span></p>
      <p>Uma base de documentos (regras de negócio, glossário, decisões, aprendizados) organizada num padrão do banco, que os agentes do Copilot consultam. Em vez de colar contexto, o agente <strong>busca no Vault só o trecho que a tarefa pede</strong> e traz para a janela.</p>
      <ul class="lista">
        <li><strong>Menos contexto colado, menos tokens:</strong> entra na mesa só o que é relevante.</li>
        <li><strong>Regra vigente, não lembrança:</strong> o agente responde com o que está documentado, não com o que alguém disse numa conversa antiga.</li>
        <li><strong>O conhecimento não sai com as pessoas:</strong> decisões e aprendizados ficam para quem chega.</li>
        <li><strong>Uma fonte para negócio e técnico:</strong> o PM consulta o mesmo conhecimento que o agente usa para codificar.</li>
        <li><strong>Curado:</strong> o que entra passa por gente, como as lições aprovadas do Hive.</li>
      </ul>
      <p class="nota">Como ele vai se conectar aos harness da BU, inclusive ao b.IA Credit Hive, ainda está sendo definido.</p>
    </div>
  </div>
</section>

<div class="conteudo">
  <nav class="passagem" aria-label="Navegação entre páginas">
    <a href="tokens.aspx" data-anterior><small>← Anterior</small><strong>Tokens e custo</strong></a>
    <a class="prox" href="modelo-agente.aspx" data-proxima><small>Próxima →</small><strong>Modelo × agente</strong></a>
  </nav>
  <footer class="rodape"><span>Engenharia com IA · fundamentos · BU Crédito</span><span><kbd>P</kbd> apresentação · <kbd>←</kbd> <kbd>→</kbd> navegar · <kbd>Esc</kbd> sair</span></footer>
</div>
</main>
<div class="slide-contador" aria-live="polite"></div>
</body>
</html>
