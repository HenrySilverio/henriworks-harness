#!/usr/bin/env node
// Fundamentos de engenharia com IA · gera as páginas a partir de uma fonte só. Node 20+, sem dependência.
//
//   node gerar.mjs <saida> [--ext aspx|html] [--plugin <pasta do plugin gerado>] [--motion <motion-lite.js>]
//
// Mesmo motor e mesmo visual da documentação do b.IA Credit Hive (split, zero script inline, CSP do SharePoint).
// Os tokens dos exemplos do Hive saem do plugin gerado (caracteres ÷ 4), não de estimativa à mão.

import { readFileSync, writeFileSync, mkdirSync, existsSync, readdirSync, statSync, copyFileSync, rmSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const req = createRequire(import.meta.url);
globalThis.window = globalThis; // o tokenizador é um IIFE de navegador
req('./vendor/tokenizador.js');
const FX = req('./fundamentos.js');

const AQUI = dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const op = (k, p) => { const i = args.indexOf(`--${k}`); return i >= 0 ? args[i + 1] : p; };
const SAIDA = resolve(args[0] || join(AQUI, 'out'));
const EXT = op('ext', 'aspx');
const PLUGIN = resolve(op('plugin', join(AQUI, '..', '..', '..', 'dist', 'bia-credit-hive-plugin')));
const MOTION = resolve(op('motion', '/root/.claude/skills/synced/a6a1a0f4-fd4d-46f0-b764-63cd57a32ca7_86a6d495-ef9d-4fb7-b198-186dc576d59d/html-motion/assets/motion-lite.js'));
const DATA_PRECOS = '23/11/2026';

const PAGINAS = [
  { id: 'index', menu: 'Início', titulo: 'Engenharia com IA: os fundamentos', descricao: 'Tokens, janela de contexto, modelo e agente, as peças de um harness e por que ele existe.' },
  { id: 'tokens', menu: 'Tokens e custo', titulo: 'Tokens e custo', descricao: 'Como o texto vira tokens e como os tokens viram custo, por modelo.', scripts: ['vendor/tokenizador.js', 'fundamentos.js'] },
  { id: 'contexto', menu: 'Janela de contexto', titulo: 'Janela de contexto', descricao: 'O que cabe na memória de trabalho do modelo, como ela enche e como organizar o uso no Copilot.', scripts: ['fundamentos.js'] },
  { id: 'modelo-agente', menu: 'Modelo × agente', titulo: 'Modelo e agente', descricao: 'A diferença entre o modelo de linguagem e o agente do GitHub Copilot no VS Code.' },
  { id: 'pecas', menu: 'Agents, skills, hooks', titulo: 'Agents, subagents, skills e hooks', descricao: 'As peças que personalizam o agente, o que cada uma faz e quando usar.' },
  { id: 'harness', menu: 'Harness', titulo: 'Harness engineering', descricao: 'O carro em volta do motor: o que é harness e como ele se monta do GitHub Copilot ao b.IA Credit Hive.', scripts: ['fundamentos.js'] },
];

const ler = (p) => readFileSync(p, 'utf8');
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
const fmt = (n) => Number(n).toLocaleString('pt-BR');

// ------------------------------------------------------------------ números reais do plugin
function numerosDoHive() {
  const tok = (p) => (existsSync(p) ? Math.round(statSync(p).size / 4) : null);
  const ag = (n) => tok(join(PLUGIN, 'com.github.copilot', 'agents', `${n}.agent.md`));
  const start = existsSync(join(PLUGIN, 'skills', 'start', 'SKILL.md')) ? (ler(join(PLUGIN, 'skills', 'start', 'SKILL.md')).match(/^description: "(.+)"$/m) || [])[1] : null;
  const n = {
    fixos: start ? Math.round(start.length / 4) : null,
    gf: ag('bchive-gf'), implementador: ag('bchive-implementador'), plan: ag('bchive-plan'), review: ag('bchive-review'),
    contrato: tok(join(PLUGIN, 'skills', 'init', 'assets', 'referencias', 'contrato.md')),
  };
  if (Object.values(n).some((v) => !v)) throw new Error(`plugin não encontrado ou incompleto em ${PLUGIN} (use --plugin)`);
  return n;
}

const alveolo = (t) => `<span class="alveolo" aria-hidden="true"><svg viewBox="0 0 34 38"><path d="M17 1.5 L32.5 10.25 L32.5 27.75 L17 36.5 L1.5 27.75 L1.5 10.25 Z"/></svg><span>${esc(t)}</span></span>`;

function pagina(p, i, n) {
  const ant = PAGINAS[i - 1];
  const prox = PAGINAS[i + 1];
  const menu = PAGINAS.map((x) => `<li><a href="${x.id}.${EXT}"${x.id === p.id ? ' aria-current="page"' : ''}>${esc(x.menu)}</a></li>`).join('');
  let corpo = ler(join(AQUI, 'paginas', `${p.id}.html`))
    .replace(/\{\{ext\}\}/g, EXT)
    .replace(/\{\{favo-hero\}\}/g, ler(join(AQUI, 'img', 'favo-hero.svg')))
    .replace(/\{\{diagrama-(loop|carro)\}\}/g, (_, k) => ler(join(AQUI, 'diagramas', `${k}.html`)))
    .replace(/\{\{hive:(\w+)\}\}/g, (_, k) => fmt(n[k]))
    .replace(/\{\{hive-json\}\}/g, esc(JSON.stringify(n)))
    .replace(/\{\{data-precos\}\}/g, DATA_PRECOS)
    .replace(/\{\{tabela-precos\}\}/g, () => FX.tabelaPrecos())
    .replace(/\{\{tabela-cenas\}\}/g, () => FX.tabelaCenas(n))
    .replace(/\{\{tok:([^}]+)\}\}/g, (_, t) => FX.pedacosHtml(globalThis.TokenizadorFundamentos.pedacos(t.replace(/\\n/g, '\n'))))
    .replace(/\{\{tok-n:([^}]+)\}\}/g, (_, t) => fmt(globalThis.TokenizadorFundamentos.pedacos(t.replace(/\\n/g, '\n')).ids.length))
    .replace(/\{\{alveolo:([^}]+)\}\}/g, (_, t) => alveolo(t));
  const sobra = corpo.match(/\{\{[^}]+\}\}/);
  if (sobra) throw new Error(`${p.id}: marcador sem valor ${sobra[0]}`);
  return `<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${esc(p.id === 'index' ? 'Engenharia com IA · fundamentos' : `${p.titulo} · Fundamentos de IA`)}</title>
  <meta name="description" content="${esc(p.descricao)}">
  <link rel="icon" type="image/svg+xml" href="img/simbolo-bia.svg">
  <link rel="stylesheet" href="style.css">
  <script src="vendor/motion-lite.js" defer></script>
${(p.scripts || []).map((s) => `  <script src="${s}" defer></script>\n`).join('')}  <script src="app.js" defer></script>
</head>
<body>
<a class="pular" href="#conteudo">Pular para o conteúdo</a>
${ler(join(AQUI, 'colmeia.html'))}
<div class="progresso" aria-hidden="true"><div class="progresso__barra"></div></div>
<header class="topo">
  <div class="conteudo topo__linha">
    <a class="marca" href="index.${EXT}" aria-label="Fundamentos de IA, início">
      <img class="mlogo mlogo--c" src="img/logo-bia.svg" alt="b.IA Credit" height="28"><img class="mlogo mlogo--e" src="img/logo-bia-escuro.svg" alt="" height="28"><span class="marca__produto">Fundamentos de IA</span>
    </a>
    <nav aria-label="Páginas" class="nav"><ul class="menu">${menu}</ul></nav>
    <div class="controles" data-controles></div>
  </div>
</header>
<main id="conteudo">
${corpo}
<div class="conteudo">
  <nav class="passagem" aria-label="Navegação entre páginas">
    ${ant ? `<a href="${ant.id}.${EXT}" data-anterior><small>← Anterior</small><strong>${esc(ant.menu)}</strong></a>` : '<span></span>'}
    ${prox ? `<a class="prox" href="${prox.id}.${EXT}" data-proxima><small>Próxima →</small><strong>${esc(prox.menu)}</strong></a>` : ''}
  </nav>
  <footer class="rodape"><span>Engenharia com IA · fundamentos · BU Crédito</span><span><kbd>P</kbd> apresentação · <kbd>←</kbd> <kbd>→</kbd> navegar · <kbd>Esc</kbd> sair</span></footer>
</div>
</main>
<div class="slide-contador" aria-live="polite"></div>
</body>
</html>
`;
}

const n = numerosDoHive();
if (existsSync(SAIDA)) rmSync(SAIDA, { recursive: true, force: true });
mkdirSync(join(SAIDA, 'vendor'), { recursive: true });
mkdirSync(join(SAIDA, 'img'), { recursive: true });
const css = ['base.css', 'componentes.css', 'colmeia.css', 'fundamentos.css'].map((f) => `/* ${f} */\n${ler(join(AQUI, f))}`).join('\n');
writeFileSync(join(SAIDA, 'style.css'), `${css}\n.digitar .lt { display: inline-block; }\n`);
for (const f of ['app.js', 'fundamentos.js']) copyFileSync(join(AQUI, f), join(SAIDA, f));
copyFileSync(MOTION, join(SAIDA, 'vendor', 'motion-lite.js'));
copyFileSync(join(AQUI, 'vendor', 'tokenizador.js'), join(SAIDA, 'vendor', 'tokenizador.js'));
for (const f of readdirSync(join(AQUI, 'img'))) copyFileSync(join(AQUI, 'img', f), join(SAIDA, 'img', f));
PAGINAS.forEach((p, i) => writeFileSync(join(SAIDA, `${p.id}.${EXT}`), pagina(p, i, n)));
console.log(`${PAGINAS.length} páginas .${EXT} em ${SAIDA} · Hive: ${Object.entries(n).map(([k, v]) => `${k}=${v}`).join(' ')}`);
