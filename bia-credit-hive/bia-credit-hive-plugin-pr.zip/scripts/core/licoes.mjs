#!/usr/bin/env node
// b.IA Credit Hive - lições de uso: memória curada do time. Sem dependência, Node 20+.
//
// O que o uso ensina (achado de revisão que virou trabalho, defeito pego pelo QA, causa de replanejamento,
// correção que o dev fez no agente) vira PROPOSTA; uma pessoa aprova; a lição aprovada vira um arquivo
// versionado em conhecimento/licoes/ (o único caminho que a política deixa versionar), um por lição, sem
// índice gravado (o script monta na hora: nada de conflito de merge entre devs). Os agentes leem só as
// lições cujo escopo casa com os arquivos da tarefa, dentro de um orçamento de tokens.
//
//   node .bchive/bin/licoes.mjs propor --titulo "<regra curta>" --texto "<o que fazer>" --porque "<motivo>"
//                                         --tipo regra|processo|termo --escopo "<glob[, glob]>|*" [--origem <change>]
//   node .bchive/bin/licoes.mjs propostas                    propostas abertas
//   node .bchive/bin/licoes.mjs aprovar <P-n> --por "<nome>"  portão humano: grava em conhecimento/licoes/
//   node .bchive/bin/licoes.mjs rejeitar <P-n>               descarta a proposta
//   node .bchive/bin/licoes.mjs para <arquivo|pasta...>       lições que valem para esses caminhos (orçamento)
//   node .bchive/bin/licoes.mjs sinais [<id|pasta arquivada>] o que o uso mostrou e pode virar lição
//   node .bchive/bin/licoes.mjs listar | revisar              todas; vencidas ou com escopo morto

import { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync, rmSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';
import { HW, CHANGES, ARCHIVE, ESTADO, sair, barra, ler, linhasDe, config, globParaRegex, textoDoDev, git } from './lib/comum.mjs';

const RAIZ = process.cwd();
if (!existsSync(join(RAIZ, HW))) sair(2, `${HW}/ não existe aqui: rode da raiz do repositório preparado pelo init.`);
const cfg = config(RAIZ);
const PASTA = join(RAIZ, cfg.licoes.pasta);
const PROP = join(RAIZ, ESTADO, 'licoes');
const TIPOS = ['regra', 'processo', 'termo'];
const hoje = () => new Date().toISOString().slice(0, 10);
const tokens = (t) => Math.ceil(String(t).length / 4);

function opcoes(argv) {
  const pos = []; const op = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) { const k = a.slice(2); if (argv[i + 1] !== undefined && !argv[i + 1].startsWith('--')) op[k] = argv[++i]; else op[k] = true; } else pos.push(a);
  }
  return { pos, op };
}

// Arquivo de lição: frontmatter simples + título + corpo curto.
function lerLicao(p) {
  const t = ler(p) || '';
  const m = t.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n([\s\S]*)$/);
  if (!m) return null;
  const fm = Object.fromEntries(linhasDe(m[1]).map((l) => l.match(/^([\w-]+):\s*(.*)$/)).filter(Boolean).map((x) => [x[1], x[2].trim()]));
  const corpo = m[2].trim();
  const titulo = (corpo.match(/^#\s+(.+)$/m) || [])[1] || fm.id;
  return { ...fm, titulo, corpo: corpo.replace(/^#\s+.+\n?/, '').trim(), arquivo: barra(relative(RAIZ, p)), globs: String(fm.escopo || '*').split(',').map((g) => g.trim()).filter(Boolean) };
}
const licoes = () => (existsSync(PASTA) ? readdirSync(PASTA).filter((n) => /^L-.*\.md$/.test(n)).map((n) => lerLicao(join(PASTA, n))).filter(Boolean) : []);
const propostas = () => (existsSync(PROP) ? readdirSync(PROP).filter((n) => /^P-\d+\.md$/.test(n)).sort((a, b) => parseInt(a.slice(2)) - parseInt(b.slice(2))).map((n) => lerLicao(join(PROP, n))).filter(Boolean) : []);
const casa = (l, caminho) => l.globs.includes('*') || l.globs.some((g) => {
  const re = globParaRegex(g.endsWith('/') ? `${g}**` : g);
  return re.test(caminho) || re.test(`${caminho.replace(/\/$/, '')}/x`) || caminho.startsWith(g.replace(/\*.*$/, ''));
});
const formato = (l) => `- [${l.tipo}] ${l.titulo}: ${l.corpo.replace(/\s+/g, ' ')} (${l.id})`;
const slug = (t) => String(t).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').split('-').slice(0, 5).join('-');

function cmdPropor(op) {
  const faltam = ['titulo', 'texto', 'porque', 'tipo', 'escopo'].filter((k) => !op[k] || op[k] === true);
  if (faltam.length) sair(2, `faltam: ${faltam.map((k) => `--${k}`).join(', ')}`);
  if (!TIPOS.includes(op.tipo)) sair(2, `--tipo é ${TIPOS.join(', ')}.`);
  const tamanho = `${op.titulo} ${op.texto} ${op.porque}`.length;
  if (tamanho > 700) sair(2, `lição com ${tamanho} caracteres: corte para até 700. Lição longa custa token em toda tarefa daquele escopo.`);
  for (const g of String(op.escopo).split(',').map((x) => x.trim())) if (!g) sair(2, '--escopo vazio.');
  mkdirSync(PROP, { recursive: true });
  const n = Math.max(0, ...readdirSync(PROP).map((x) => parseInt((x.match(/^P-(\d+)/) || [])[1] || 0))) + 1;
  const p = join(PROP, `P-${n}.md`);
  writeFileSync(p, `---\nid: P-${n}\ntipo: ${op.tipo}\nescopo: ${op.escopo}\norigem: ${op.origem && op.origem !== true ? op.origem : 'conversa'}\nproposto-em: ${hoje()}\n---\n# ${op.titulo}\n${op.texto}\nPor quê: ${op.porque}\n`);
  console.log(`proposta P-${n} gravada (${barra(relative(RAIZ, p))}). Quem aprova roda, no terminal:\n  node ${HW}/bin/bchive.mjs licoes aprovar P-${n} --por "<seu nome>"`);
}

function cmdAprovar(pos, op) {
  const id = pos[0];
  const p = join(PROP, `${id}.md`);
  if (!id || !existsSync(p)) sair(2, `proposta "${id || ''}" não existe. Abertas: ${propostas().map((x) => x.id).join(', ') || 'nenhuma'}`);
  { const e = textoDoDev(op.por, 'quem aprova (--por "Nome Sobrenome")'); if (e) sair(2, `${e} Este portão é humano.`); }
  const l = lerLicao(p);
  const validade = new Date(); validade.setMonth(validade.getMonth() + (Number(cfg.licoes.validadeMeses) || 6));
  const nome = `L-${hoje().replace(/-/g, '')}-${slug(l.titulo)}`;
  mkdirSync(PASTA, { recursive: true });
  let destino = join(PASTA, `${nome}.md`);
  for (let k = 2; existsSync(destino); k++) destino = join(PASTA, `${nome}-${k}.md`);
  const idFinal = destino.split(/[\\/]/).pop().replace(/\.md$/, '');
  writeFileSync(destino, `---\nid: ${idFinal}\ntipo: ${l.tipo}\nescopo: ${l.escopo}\norigem: ${l.origem}\naprovado-por: ${op.por}\naprovado-em: ${hoje()}\nrevisar-em: ${validade.toISOString().slice(0, 10)}\n---\n# ${l.titulo}\n${l.corpo}\n`);
  rmSync(p);
  const rel = barra(relative(RAIZ, destino));
  console.log(`lição aprovada: ${rel}\nVersione junto com o próximo commit (ou sozinha):\n  git add ${rel}\n  git commit -m "docs(licoes): ${l.titulo.slice(0, 60)}"`);
}

function cmdPara(pos, op) {
  const caminhos = pos.map((c) => barra(c).replace(/^\.\//, ''));
  if (!caminhos.length) sair(2, 'informe os arquivos ou pastas da tarefa (o Toca: da fatia, os arquivos do diff).');
  const orc = Number(op.orcamento) || Number(cfg.licoes.orcamentoTokens) || 1200;
  const todas = licoes().filter((l) => caminhos.some((c) => casa(l, c)));
  const ordem = { regra: 0, processo: 1, termo: 2 };
  todas.sort((a, b) => ordem[a.tipo] - ordem[b.tipo] || String(b['aprovado-em']).localeCompare(String(a['aprovado-em'])));
  const saida = []; let gasto = 0;
  for (const l of todas) { const t = tokens(formato(l)); if (gasto + t > orc) break; saida.push(formato(l)); gasto += t; }
  if (!todas.length) return console.log('nenhuma lição aprovada para esses caminhos.');
  if (!saida.length) return console.log(`${todas.length} lição(ões) valem aqui, mas nenhuma cabe no orçamento de ${orc} tokens (licoes.orcamentoTokens em ${HW}/bchive.json).`);
  console.log(`lições aprovadas que valem aqui (≈${gasto} tokens${todas.length > saida.length ? `; ${todas.length - saida.length} fora do orçamento, as de menor prioridade` : ''}):`);
  console.log(saida.join('\n'));
}

// Sinais determinísticos, tirados dos artefatos: o modelo só redige a proposta a partir deles.
function cmdSinais(pos) {
  const pastas = [];
  const add = (d) => existsSync(d) && pastas.push(d);
  if (pos[0]) {
    add(join(RAIZ, CHANGES, pos[0]));
    add(join(RAIZ, ARCHIVE, pos[0]));
    if (!pastas.length && existsSync(join(RAIZ, ARCHIVE))) for (const n of readdirSync(join(RAIZ, ARCHIVE))) if (n.endsWith(pos[0])) add(join(RAIZ, ARCHIVE, n));
    if (!pastas.length) sair(2, `"${pos[0]}" não é mudança aberta nem arquivada.`);
  } else if (existsSync(join(RAIZ, ARCHIVE))) {
    const arq = readdirSync(join(RAIZ, ARCHIVE)).sort().slice(-10);
    for (const n of arq) add(join(RAIZ, ARCHIVE, n));
  }
  const sinais = [];
  for (const d of pastas) {
    const nome = barra(relative(RAIZ, d));
    const rev = join(d, 'revisao');
    if (existsSync(rev)) {
      for (const n of readdirSync(rev).filter((x) => /^(spec|padroes|plantao)-.*\.md$/.test(x))) {
        for (const l of linhasDe(ler(join(rev, n)))) {
          const m = l.match(/^\s*(?:[-*]|\d+[.)])?\s*\[bloqueante\]\s*(.+)$/i);
          if (m) sinais.push({ tipo: 'achado bloqueante que virou trabalho', onde: `${nome}/revisao/${n}`, texto: m[1].slice(0, 200) });
        }
      }
      for (const n of readdirSync(rev).filter((x) => /^ACEITE-/.test(x))) sinais.push({ tipo: 'revisão aceita apesar de reprovada', onde: `${nome}/revisao/${n}`, texto: ((ler(join(rev, n)) || '').match(/^Apesar de:\s*(.+)$/m) || [])[1] || '' });
    }
    const qa = ler(join(d, 'QA.md'));
    if (qa && /^Junto com:/m.test(qa)) sinais.push({ tipo: 'correção depois do QA', onde: `${nome}/QA.md`, texto: (qa.match(/^Junto com:\s*(.+)$/m) || [])[1] });
    const prop = ler(join(d, 'proposta.md')) || '';
    const div = (prop.split(/^##\s+Diverg[êe]ncias\s*$/m)[1] || '').split(/^##\s/m)[0];
    for (const l of linhasDe(div).filter((x) => /^\s*[-*]\s+\S/.test(x)).slice(0, 5)) sinais.push({ tipo: 'divergência registrada no plano', onde: `${nome}/proposta.md`, texto: l.replace(/^\s*[-*]\s+/, '').slice(0, 200) });
    const rs = join(d, 'revisao-spec');
    if (existsSync(rs)) {
      const versoes = new Set(readdirSync(rs).map((x) => (x.match(/-([0-9a-f]{7})(?:-\d+)?\.md$/) || [])[1]).filter(Boolean));
      if (versoes.size >= 3) sinais.push({ tipo: 'spec replanejada várias vezes', onde: `${nome}/revisao-spec/`, texto: `${versoes.size} versões revisadas` });
    }
  }
  if (!sinais.length) return console.log('nenhum sinal nos artefatos: nada a propor agora.');
  console.log(`${sinais.length} sinal(is). Lição só para o que vai se repetir; o resto é desta mudança.`);
  for (const s of sinais.slice(0, 20)) console.log(`- ${s.tipo} · ${s.onde}\n    ${s.texto}`);
}

function cmdListar(revisar) {
  const ls = licoes();
  const rastreados = revisar ? (git(['ls-files'], { cwd: RAIZ, permitirFalha: true }) || '').split('\n').filter(Boolean) : [];
  const out = ls.map((l) => {
    const vencida = l['revisar-em'] && l['revisar-em'] < hoje();
    const morta = revisar && !l.globs.includes('*') && !rastreados.some((a) => casa(l, a));
    return { l, vencida, morta };
  }).filter((x) => !revisar || x.vencida || x.morta);
  if (!out.length) return console.log(revisar ? 'nenhuma lição vencida ou com escopo morto.' : `nenhuma lição em ${cfg.licoes.pasta}.`);
  for (const { l, vencida, morta } of out) console.log(`${l.id} [${l.tipo}] ${l.titulo} · escopo ${l.escopo} · revisar em ${l['revisar-em'] || '?'}${vencida ? ' · VENCIDA' : ''}${morta ? ' · ESCOPO SEM ARQUIVO' : ''}`);
  if (revisar) console.log('\nVencida: o time confirma (ajusta revisar-em no arquivo) ou apaga com git rm. Escopo sem arquivo: o código mudou; atualize ou apague.');
}

const [cmd, ...resto] = process.argv.slice(2);
const { pos, op } = opcoes(resto);
if (cmd === 'propor') cmdPropor(op);
else if (cmd === 'propostas') { const ps = propostas(); console.log(ps.length ? ps.map((p) => `${p.id} [${p.tipo}] ${p.titulo} · escopo ${p.escopo} · origem ${p.origem}`).join('\n') : 'nenhuma proposta aberta.'); }
else if (cmd === 'aprovar') cmdAprovar(pos, op);
else if (cmd === 'rejeitar') { const p = join(PROP, `${pos[0]}.md`); if (!existsSync(p)) sair(2, `proposta "${pos[0]}" não existe.`); rmSync(p); console.log(`${pos[0]} descartada.`); }
else if (cmd === 'para') cmdPara(pos, op);
else if (cmd === 'sinais') cmdSinais(pos);
else if (cmd === 'listar') cmdListar(false);
else if (cmd === 'revisar') cmdListar(true);
else sair(2, readFileSync(new URL(import.meta.url), 'utf8').split('\n').slice(1, 20).map((l) => l.replace(/^\/\/ ?/, '')).join('\n'));
