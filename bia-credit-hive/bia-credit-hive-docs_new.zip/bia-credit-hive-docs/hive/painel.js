/* b.IA Credit Hive · painel de uso de EXEMPLO (dados fictícios, gerados por semente fixa).
   Um arquivo para o gerador (Node, pré-renderiza a visão padrão) e para o navegador (troca de visão).
   Os campos são os do `uso.mjs exportar` (por dev e por dia); squad vem de um cadastro dev → squad no destino
   central, que ainda está em definição. Nenhum valor em dinheiro. Sem eval, sem script inline. */
(function (raiz) {
  'use strict';

  var FIM = '2026-11-13'; // sexta-feira: último dia com dados no exemplo
  var INICIO = '2026-05-25';
  var SQUADS = [
    { nome: 'Acordos', stack: 'MFE Angular + BFF Java', desde: '2026-06-01', teto: [0.62, 0.82], outros: 0.18,
      devs: ['Ana C.', 'Bruno M.', 'Carla S.', 'Diego R.', 'Elisa T.'],
      executores: [['bchive-implementador', 0.55], ['java-plugin:spring-dev', 0.45]] },
    { nome: 'Renegociação', stack: 'MFE React + BFF Java', desde: '2026-07-06', teto: [0.5, 0.75], outros: 0.15,
      devs: ['Fábio L.', 'Gabriela P.', 'Heitor A.', 'Isabela N.'],
      executores: [['bchive-implementador', 0.7], ['java-plugin:spring-dev', 0.3]] },
    { nome: 'Cobrança Digital', stack: 'BFF Java + Kotlin', desde: '2026-08-03', teto: [0.45, 0.7], outros: 0.2,
      devs: ['João V.', 'Karina O.', 'Lucas F.', 'Marina D.', 'Nelson B.'],
      executores: [['java-plugin:spring-dev', 0.6], ['bchive-implementador', 0.4]] },
    { nome: 'Crédito Mainframe', stack: 'COBOL, JCL e DB2 no z/OS', desde: '2026-09-14', teto: [0.32, 0.55], outros: 0.35,
      devs: ['Otávio G.', 'Paula E.', 'Rafael K.', 'Sílvia H.'],
      executores: [['mf-plugin:cobol-dev', 0.85], ['bchive-implementador', 0.15]] },
  ];
  var COMANDOS = [['implement', 0.34], ['review', 0.22], ['plan', 0.12], ['archive', 0.07], ['fechar', 0.06],
    ['triagem', 0.06], ['mapa', 0.05], ['grill', 0.04], ['lembrar', 0.02], ['squad-audit', 0.01]];
  var MESES = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
  var MESES_LONGO = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];

  // ------------------------------------------------------------ datas (UTC, sem fuso)
  var dia = function (s) { return Date.UTC(+s.slice(0, 4), +s.slice(5, 7) - 1, +s.slice(8, 10)); };
  var iso = function (t) { return new Date(t).toISOString().slice(0, 10); };
  var DIA = 864e5;
  var br = function (s) { return s.slice(8, 10) + '/' + s.slice(5, 7); };

  // ------------------------------------------------------------ gerador com semente
  function prng(seed) { return function () { seed |= 0; seed = (seed + 0x6D2B79F5) | 0; var t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

  function gerar() {
    var dias = [];
    for (var t = dia(INICIO); t <= dia(FIM); t += DIA) { var w = new Date(t).getUTCDay(); if (w > 0 && w < 6) dias.push(iso(t)); }
    var devs = [], regs = [];
    SQUADS.forEach(function (sq, si) {
      sq.devs.forEach(function (nome, di) {
        var id = devs.length, r = prng(1000 + si * 97 + di * 13);
        var teto = sq.teto[0] + r() * (sq.teto[1] - sq.teto[0]), ritmo = 4 + r() * 4;
        devs.push({ id: id, nome: nome, squad: si });
        dias.forEach(function (d) {
          if (r() < 0.12 && d < '2026-11-11') return; // folga, reunião o dia todo (os últimos dias têm uso, para o exemplo abrir cheio)
          var sem = Math.max(0, (dia(d) - dia(sq.desde)) / (7 * DIA));
          var adesao = d < sq.desde ? 0 : teto * (1 - Math.exp(-sem / ritmo));
          var n = 2 + Math.floor(r() * 5);
          var fluxo = Math.min(n, Math.round(n * adesao + (r() - 0.5)));
          var outros = Math.round((n - fluxo) * (sq.outros + (r() - 0.5) * 0.1));
          var solto = n - fluxo - outros;
          var planos = r() < fluxo * 0.13 ? 1 : 0;
          regs.push({
            dev: id, squad: si, d: d, fluxo: fluxo, outros: outros, solto: solto,
            ativo: Math.round(fluxo * (32 + r() * 14) + outros * 20 + solto * 11),
            tp: fluxo * 13 + outros * 8 + solto * 5 + Math.floor(r() * 4),
            ts: fluxo * 5 + Math.floor(r() * 2),
            ti: Math.round(fluxo * (85 + r() * 30) + outros * 55 + solto * 28),
            planos: planos, replan: planos && r() < 0.22 ? 1 : 0,
            fechar: r() < fluxo * 0.075 ? 1 : 0,
          });
        });
      });
    });
    return { dias: dias, devs: devs, regs: regs };
  }

  // ------------------------------------------------------------ períodos
  function segundaDe(d) { var t = dia(d), w = new Date(t).getUTCDay(); return iso(t - ((w + 6) % 7) * DIA); }
  function baldes(dados, periodo) {
    var b = [];
    if (periodo === 'dia') {
      dados.dias.slice(-10).forEach(function (d) { b.push({ chave: d, rot: br(d), longo: 'Dia ' + br(d), tem: function (x) { return x === d; } }); });
    } else if (periodo === 'semana') {
      var seg = segundaDe(FIM);
      for (var k = 7; k >= 0; k--) {
        (function (ini) {
          var fim = iso(dia(ini) + 4 * DIA);
          b.push({ chave: ini, rot: br(ini), longo: 'Semana de ' + br(ini) + ' a ' + br(fim), tem: function (x) { return x >= ini && x <= fim; } });
        })(iso(dia(seg) - k * 7 * DIA));
      }
    } else {
      var m = +FIM.slice(5, 7);
      for (var j = 5; j >= 0; j--) {
        (function (mm) {
          var p = FIM.slice(0, 4) + '-' + (mm < 10 ? '0' : '') + mm, parcial = mm === m;
          b.push({ chave: p, rot: MESES[mm - 1] + (parcial ? '*' : ''), longo: MESES_LONGO[mm - 1] + (parcial ? ' (até ' + br(FIM) + ')' : ''), tem: function (x) { return x.slice(0, 7) === p; } });
        })(m - j);
      }
    }
    return b;
  }

  function somar(regs) {
    var a = { sessoes: 0, fluxo: 0, outros: 0, solto: 0, ativo: 0, tp: 0, ts: 0, ti: 0, planos: 0, replan: 0, fechar: 0, devs: 0 }, vistos = {};
    regs.forEach(function (r) {
      a.fluxo += r.fluxo; a.outros += r.outros; a.solto += r.solto; a.ativo += r.ativo; a.tp += r.tp; a.ts += r.ts;
      a.ti += r.ti; a.planos += r.planos; a.replan += r.replan; a.fechar += r.fechar;
      if (r.fluxo + r.outros + r.solto) vistos[r.dev] = 1;
    });
    a.sessoes = a.fluxo + a.outros + a.solto;
    a.devs = Object.keys(vistos).length;
    a.adesao = a.sessoes ? a.fluxo / a.sessoes : 0;
    a.to = Math.round(a.ti * 0.16);
    return a;
  }

  // ------------------------------------------------------------ formatação
  var fmt = function (n) { return Math.round(n).toLocaleString('pt-BR'); };
  var pct = function (x) { return Math.round(x * 100) + '%'; };
  var horas = function (min) { return (min / 60).toLocaleString('pt-BR', { maximumFractionDigits: min < 600 ? 1 : 0 }); };
  var milhoes = function (k) { return k >= 1000 ? (k / 1000).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + ' mi' : fmt(k) + ' mil'; };
  var esc = function (s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;'); };

  function delta(a, b, tipo) {
    if (tipo === 'pp') { var pp = Math.round((a - b) * 100); return { txt: (pp > 0 ? '+' : '') + pp + ' p.p.', dir: pp > 0 ? 'sobe' : pp < 0 ? 'desce' : 'igual' }; }
    if (!b) return { txt: 'sem base', dir: 'igual' };
    var v = Math.round(((a - b) / b) * 100);
    return { txt: (v > 0 ? '+' : '') + v + '%', dir: v > 0 ? 'sobe' : v < 0 ? 'desce' : 'igual' };
  }

  // ------------------------------------------------------------ visão
  function filtro(dados, estado) {
    if (estado.visao === 'squad') return function (r) { return r.squad === estado.squad; };
    if (estado.visao === 'dev') return function (r) { return r.dev === estado.dev; };
    return function () { return true; };
  }
  function titulo(dados, estado) {
    if (estado.visao === 'squad') return 'Squad ' + SQUADS[estado.squad].nome;
    if (estado.visao === 'dev') { var d = dados.devs[estado.dev]; return d.nome + ' · squad ' + SQUADS[d.squad].nome; }
    return 'Todas as squads';
  }

  // fator: dias úteis do período anterior ÷ do atual, para o mês parcial não parecer queda.
  function kpis(atual, ant, rot, fator) {
    var dz = function (a, b) { return delta(a * fator, b); };
    var cx = function (rotulo, valor, d, nota) {
      return '<div class="pn-kpi"><div class="pn-kpi__r">' + rotulo + '</div><div class="pn-kpi__v">' + valor + '</div>' +
        '<div class="pn-kpi__d pn-kpi__d--' + d.dir + '"><span aria-hidden="true">' + (d.dir === 'sobe' ? '▲' : d.dir === 'desce' ? '▼' : '■') + '</span> ' + d.txt + ' <span class="pn-kpi__vs">vs ' + esc(rot) + (fator !== 1 && d.txt.indexOf('p.p.') < 0 ? ', por dia útil' : '') + '</span></div>' +
        (nota ? '<div class="pn-kpi__n">' + nota + '</div>' : '') + '</div>';
    };
    var rp = function (a) { return a.planos ? a.replan / a.planos : 0; };
    return '<div class="pn-kpis">' +
      cx('Sessões com o Hive', pct(atual.adesao), delta(atual.adesao, ant.adesao, 'pp'), fmt(atual.fluxo) + ' de ' + fmt(atual.sessoes) + ' sessões') +
      cx('Sessões no Copilot', fmt(atual.sessoes), dz(atual.sessoes, ant.sessoes), fmt(atual.devs) + ' dev(s) com uso') +
      cx('Tempo ativo', horas(atual.ativo) + ' h', dz(atual.ativo, ant.ativo), 'pausas longas não contam') +
      cx('Entregas fechadas', fmt(atual.fechar), dz(atual.fechar, ant.fechar), 'com OK do QA e registro') +
      cx('Replanejamentos', pct(rp(atual)), delta(rp(atual), rp(ant), 'pp'), 'dos planos do período') +
      cx('Tokens', milhoes(atual.ti + atual.to), dz(atual.ti + atual.to, ant.ti + ant.to), 'entrada + saída, sem custo') +
      '</div>';
  }

  function grafico(series, estado) {
    var max = Math.max.apply(null, series.map(function (s) { return s.a.sessoes; })) || 1;
    var cols = series.map(function (s, i) {
      var h = function (v) { return (v / max * 100).toFixed(2) + '%'; };
      var ult = i === series.length - 1;
      var tip = s.b.longo + ': ' + fmt(s.a.sessoes) + ' sessões · Hive ' + fmt(s.a.fluxo) + ' (' + pct(s.a.adesao) + ') · outros plugins ' + fmt(s.a.outros) + ' · chat solto ' + fmt(s.a.solto);
      return '<div class="pn-col' + (ult ? ' pn-col--atual' : '') + '" tabindex="0" role="listitem" aria-label="' + esc(tip) + '" data-tip="' + esc(tip) + '">' +
        '<div class="pn-pilha" style="--h:' + h(s.a.sessoes) + '">' +
        (s.a.solto ? '<span class="pn-seg pn-seg--solto" style="flex-grow:' + s.a.solto + '"></span>' : '') +
        (s.a.outros ? '<span class="pn-seg pn-seg--outros" style="flex-grow:' + s.a.outros + '"></span>' : '') +
        (s.a.fluxo ? '<span class="pn-seg pn-seg--hive" style="flex-grow:' + s.a.fluxo + '"></span>' : '') +
        '</div>' + (ult ? '<span class="pn-col__pct">' + pct(s.a.adesao) + ' Hive</span>' : '') +
        '<span class="pn-col__x">' + esc(s.b.rot) + '</span></div>';
    }).join('');
    var nomes = { dia: 'por dia (10 dias úteis)', semana: 'por semana (8 semanas)', mes: 'por mês (6 meses)' };
    return '<figure class="pn-graf"><figcaption class="pn-graf__t">Sessões ' + nomes[estado.periodo] + ', por tipo de uso</figcaption>' +
      '<ul class="pn-leg" aria-label="Legenda"><li><i class="pn-seg--hive"></i>Com o Hive (fluxo)</li><li><i class="pn-seg--outros"></i>Outros plugins sozinhos</li><li><i class="pn-seg--solto"></i>Chat solto</li></ul>' +
      '<div class="pn-cols" role="list">' + cols + '</div>' +
      '<details class="pn-tab-graf"><summary>Ver os números do gráfico</summary><div class="tabela-wrap"><table><thead><tr><th>Período</th><th>Sessões</th><th>Com o Hive</th><th>Outros plugins</th><th>Chat solto</th><th>% Hive</th></tr></thead><tbody>' +
      series.map(function (s) { return '<tr><td>' + esc(s.b.longo) + '</td><td>' + fmt(s.a.sessoes) + '</td><td>' + fmt(s.a.fluxo) + '</td><td>' + fmt(s.a.outros) + '</td><td>' + fmt(s.a.solto) + '</td><td>' + pct(s.a.adesao) + '</td></tr>'; }).join('') +
      '</tbody></table></div></details></figure>';
  }

  function tabela(dados, estado, b, series) {
    var linha = function (nome, a, extra) {
      return '<tr><th scope="row">' + nome + '</th>' + (extra || '') + '<td>' + fmt(a.sessoes) + '</td><td><span class="pn-barrinha" style="--v:' + pct(a.adesao) + '"></span>' + pct(a.adesao) + '</td><td>' + horas(a.ativo) + '</td><td>' + fmt(a.fechar) + '</td><td>' + (a.planos ? pct(a.replan / a.planos) : '—') + '</td><td>' + milhoes(a.ti + a.to) + '</td></tr>';
    };
    var cab = function (primeira, extra) { return '<thead><tr><th scope="col">' + primeira + '</th>' + (extra || '') + '<th scope="col">Sessões</th><th scope="col">% com o Hive</th><th scope="col">Tempo ativo (h)</th><th scope="col">Entregas fechadas</th><th scope="col">Replanejamentos</th><th scope="col">Tokens</th></tr></thead>'; };
    var corpo, t;
    if (estado.visao === 'todas') {
      t = 'Squads · ' + b.longo;
      corpo = cab('Squad', '<th scope="col">Devs com uso</th>') + '<tbody>' + SQUADS.map(function (sq, i) {
        var a = somar(dados.regs.filter(function (r) { return r.squad === i && b.tem(r.d); }));
        return linha(esc(sq.nome) + '<small>' + esc(sq.stack) + '</small>', a, '<td>' + a.devs + ' de ' + sq.devs.length + '</td>');
      }).join('') + '</tbody>';
    } else if (estado.visao === 'squad') {
      t = 'Devs da squad ' + SQUADS[estado.squad].nome + ' · ' + b.longo;
      corpo = cab('Dev') + '<tbody>' + dados.devs.filter(function (d) { return d.squad === estado.squad; }).map(function (d) {
        return linha(esc(d.nome), somar(dados.regs.filter(function (r) { return r.dev === d.id && b.tem(r.d); })));
      }).join('') + '</tbody>';
    } else {
      t = 'Histórico de ' + dados.devs[estado.dev].nome;
      corpo = cab('Período') + '<tbody>' + series.slice().reverse().map(function (s) { return linha(esc(s.b.longo), s.a); }).join('') + '</tbody>';
    }
    return '<div class="pn-bloco"><h3 class="pn-bloco__t">' + esc(t) + '</h3><div class="tabela-wrap"><table class="pn-tabela">' + corpo + '</table></div></div>';
  }

  // a = soma das barras do gráfico (a janela inteira), para dev e dia não virarem uma lista de zeros.
  function comandos(a, estado, dados, janela) {
    var nomePlug = '/bia-credit-hive:';
    var real = { plan: a.planos, fechar: a.fechar };
    var lista = COMANDOS.map(function (c, i) { return [c[0], c[0] in real ? real[c[0]] : Math.round(a.fluxo * c[1] * (1 + ((i * 7 + (estado.squad || 0) * 3) % 5 - 2) * 0.04))]; });
    lista.sort(function (x, y) { return y[1] - x[1]; });
    var max = lista[0][1] || 1;
    var sq = estado.visao === 'todas' ? null : SQUADS[estado.visao === 'dev' ? dados.devs[estado.dev].squad : estado.squad];
    var exec = sq ? sq.executores : [['bchive-implementador', 0.5], ['java-plugin:spring-dev', 0.38], ['mf-plugin:cobol-dev', 0.12]];
    var impl = lista.filter(function (c) { return c[0] === 'implement'; })[0][1];
    return '<div class="pn-dupla"><div class="pn-bloco"><h3 class="pn-bloco__t">Comandos do Hive mais usados <small>' + janela + '</small></h3>' +
      lista.map(function (c) { return '<div class="grafico__linha"><span class="grafico__nome">' + nomePlug + c[0] + '</span><div class="grafico__trilho"><div class="grafico__barra" style="--v:' + Math.max(2, c[1] / max * 100).toFixed(1) + '%"></div></div><span class="grafico__v">' + fmt(c[1]) + '</span></div>'; }).join('') +
      '</div><div class="pn-bloco"><h3 class="pn-bloco__t">Quem executou as fatias <small>' + janela + '</small></h3><p class="nota">O Hive planeja e revisa; a fatia vai para o executor da stack. Agente de outro plugin entra como executor quando o dev confirma no plano.</p>' +
      exec.map(function (e) { var v = Math.round(impl * e[1]); return '<div class="grafico__linha grafico__linha--exec"><span class="grafico__nome">' + esc(e[0]) + '</span><div class="grafico__trilho"><div class="grafico__barra" style="--v:' + Math.max(2, e[1] * 100).toFixed(1) + '%"></div></div><span class="grafico__v">' + fmt(v) + '</span></div>'; }).join('') +
      '</div></div>';
  }

  function render(dados, estado) {
    var f = filtro(dados, estado);
    var meus = dados.regs.filter(f);
    var bs = baldes(dados, estado.periodo);
    var series = bs.map(function (b) { return { b: b, a: somar(meus.filter(function (r) { return b.tem(r.d); })) }; });
    var atual = series[series.length - 1], ant = series[series.length - 2];
    var uteis = function (b) { return dados.dias.filter(function (d) { return b.tem(d); }).length; };
    return '<p class="pn-contexto"><strong>' + esc(titulo(dados, estado)) + '</strong> · ' + esc(atual.b.longo) + '</p>' +
      kpis(atual.a, ant.a, estado.periodo === 'dia' ? 'dia útil anterior' : estado.periodo === 'semana' ? 'semana anterior' : ant.b.longo, uteis(ant.b) / (uteis(atual.b) || 1)) + grafico(series, estado) + tabela(dados, estado, atual.b, series) +
      comandos(somar(meus.filter(function (r) { return series.some(function (x) { return x.b.tem(r.d); }); })), estado, dados, { dia: 'nos 10 dias úteis', semana: 'nas 8 semanas', mes: 'nos 6 meses' }[estado.periodo]);
  }

  var api = { gerar: gerar, render: render, squads: SQUADS, padrao: { visao: 'todas', squad: 0, dev: 0, periodo: 'semana' } };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else raiz.PainelHive = api;
})(typeof window !== 'undefined' ? window : this);
