/* Fundamentos de IA · interativos: tokenizador, calculadora de custo, janela de contexto e o carro do harness.
   Sem script inline, sem eval. O mesmo arquivo roda no gerador (Node) para pré-renderizar as tabelas, então
   a página é completa sem JavaScript. */
(function (raiz) {
  'use strict';

  // Preços de tabela por 1 milhão de tokens (USD), lidos nas páginas oficiais em 23/11/2026. No GitHub Copilot,
  // desde 01/06/2026, o uso consome AI Credits pelas mesmas tarifas de API de cada modelo (1 crédito = US$ 0,01).
  var MODELOS = [
    { id: 'opus', nome: 'Claude Opus 5.5', de: 'Anthropic', entrada: 4, cache: 0.2, escritaCache: 5, saida: 20, janela: 1000000, saidaMax: 128000 },
    { id: 'luna', nome: 'GPT-6 Luna', de: 'OpenAI', entrada: 0.1, cache: 0.01, escritaCache: 0.125, saida: 0.5, janela: 1050000, saidaMax: 128000,
      longo: { acima: 272000, entrada: 2, cache: 2, saida: 1.5 } },
  ];

  function custo(m, c) {
    // c: { entrada, saida, cachePct, pedidos }. Entrada e saída somam todos os pedidos da cena.
    var pedidos = Math.max(1, c.pedidos || 1);
    var porPedido = c.entrada / pedidos;
    var k = { entrada: 1, cache: 1, saida: 1 };
    if (m.longo && porPedido > m.longo.acima) k = m.longo;
    var lido = c.entrada * (c.cachePct || 0) / 100;
    var novo = c.entrada - lido;
    var partes = {
      entrada: novo * m.entrada * k.entrada / 1e6,
      cache: lido * m.cache * k.cache / 1e6,
      saida: c.saida * m.saida * k.saida / 1e6,
    };
    var total = partes.entrada + partes.cache + partes.saida;
    return { partes: partes, total: total, creditos: total / 0.01, longo: k === m.longo };
  }

  function cenas(h) {
    // h: tokens reais do Hive (instruções), vindos do plugin gerado.
    return [
      { id: 'pergunta', nome: 'Pergunta rápida no chat', entrada: 3000, saida: 500, cachePct: 0, pedidos: 1,
        nota: 'Uma pergunta e uma resposta curta. Valores ilustrativos.' },
      { id: 'revisao', nome: 'Revisão isolada do Hive', entrada: h.gf + 12000, saida: 1500, cachePct: 0, pedidos: 1,
        nota: 'Instruções do revisor bchive-gf (' + h.gf.toLocaleString('pt-BR') + ' tokens, reais) + pacote e arquivos lidos (12 mil, ilustrativo).' },
      { id: 'plano', nome: 'Plano de uma mudança no Hive', entrada: (h.plan + h.contrato + 20000) * 6, saida: 6000, cachePct: 70, pedidos: 6,
        nota: 'Agente bchive-plan e contrato do fluxo (' + (h.plan + h.contrato).toLocaleString('pt-BR') + ' tokens, reais) + 20 mil de código lido (ilustrativo), em 6 pedidos com cache.' },
      { id: 'solto', nome: 'Chat solto com 30 turnos', entrada: 30 * 60000, saida: 30 * 800, cachePct: 80, pedidos: 30,
        nota: 'Cada turno reenvia a conversa inteira: 30 pedidos de ~60 mil tokens. Valores ilustrativos.' },
    ];
  }

  var usd = function (v) { return 'US$ ' + (v < 0.01 ? v.toLocaleString('pt-BR', { minimumFractionDigits: 4, maximumFractionDigits: 4 }) : v.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })); };
  var num = function (v) { return Math.round(v).toLocaleString('pt-BR'); };
  var cred = function (v) { var t = v < 10 ? v.toLocaleString('pt-BR', { maximumFractionDigits: 2 }) : num(v); return t + (t === '1' ? ' crédito' : ' créditos'); };
  var esc = function (s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;'); };

  function tabelaCenas(h) {
    var linhas = cenas(h).map(function (c) {
      return '<tr><th scope="row">' + esc(c.nome) + '<small>' + esc(c.nota) + '</small></th><td>' + num(c.entrada) + '</td><td>' + num(c.saida) + '</td><td>' + c.cachePct + '%</td>' +
        MODELOS.map(function (m) { var r = custo(m, c); return '<td><strong>' + usd(r.total) + '</strong><small>' + cred(r.creditos) + '</small></td>'; }).join('') + '</tr>';
    }).join('');
    return '<table class="fx-tabela"><thead><tr><th scope="col">Cena</th><th scope="col">Entrada</th><th scope="col">Saída</th><th scope="col">Cache</th>' +
      MODELOS.map(function (m) { return '<th scope="col">' + esc(m.nome) + '</th>'; }).join('') + '</tr></thead><tbody>' + linhas + '</tbody></table>';
  }

  function tabelaPrecos() {
    return '<table class="fx-tabela"><thead><tr><th scope="col">Modelo</th><th scope="col">Entrada</th><th scope="col">Entrada em cache</th><th scope="col">Escrita no cache</th><th scope="col">Saída</th><th scope="col">Janela</th></tr></thead><tbody>' +
      MODELOS.map(function (m) {
        return '<tr><th scope="row">' + esc(m.nome) + '<small>' + esc(m.de) + '</small></th><td>' + usd(m.entrada) + '</td><td>' + usd(m.cache) + '</td><td>' + usd(m.escritaCache) + '</td><td>' + usd(m.saida) + '</td><td>' + num(m.janela / 1000) + ' mil</td></tr>';
      }).join('') + '</tbody></table>';
  }

  function pedacosHtml(r) {
    return r.pedacos.map(function (p, i) {
      var vis = p.replace(/ /g, '·').replace(/\n/g, '↵\n').replace(/�/g, '▯');
      return '<span class="tk tk--' + (i % 6) + '" title="token ' + r.ids[i] + '">' + esc(vis) + '</span>';
    }).join('');
  }

  var api = { MODELOS: MODELOS, custo: custo, cenas: cenas, tabelaCenas: tabelaCenas, tabelaPrecos: tabelaPrecos, pedacosHtml: pedacosHtml, usd: usd, cred: cred, num: num };
  if (typeof module !== 'undefined' && module.exports) { module.exports = api; return; }
  raiz.Fundamentos = api;

  // ======================================================== navegador
  var doc = document;
  var $ = function (s, r) { return (r || doc).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || doc).querySelectorAll(s)); };
  var M = raiz.Motion || null;
  var reduzir = raiz.matchMedia && raiz.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var mostrar = function (el) { if (el) { el.removeAttribute('data-sem-js'); el.removeAttribute('aria-hidden'); } };

  /* ------------------------------------------------ tokenizador */
  var caixaTok = $('[data-tok]');
  if (caixaTok && raiz.TokenizadorFundamentos) {
    var T = raiz.TokenizadorFundamentos;
    var entrada = $('[data-tok-entrada]', caixaTok), saida = $('[data-tok-saida]', caixaTok);
    var nTok = $('[data-tok-n]', caixaTok), nCar = $('[data-tok-car]', caixaTok), nPal = $('[data-tok-pal]', caixaTok), razao = $('[data-tok-razao]', caixaTok);
    mostrar($('[data-tok-controles]', caixaTok));
    var atualizar = function () {
      var t = entrada.value;
      var r = T.pedacos(t);
      saida.innerHTML = pedacosHtml(r) || '<span class="nota">Digite algo acima.</span>';
      var pal = (t.match(/\S+/g) || []).length;
      nTok.textContent = num(r.ids.length); nCar.textContent = num(t.length); nPal.textContent = num(pal);
      razao.textContent = pal ? (r.ids.length / pal).toLocaleString('pt-BR', { maximumFractionDigits: 2 }) : '0';
    };
    var animar = function () { if (M && !reduzir) M.from($$('.tk', saida), { opacity: 0, y: 6, duration: 0.25, stagger: 0.012 }); };
    entrada.addEventListener('input', atualizar);
    $$('[data-tok-exemplo]', caixaTok).forEach(function (b) {
      b.addEventListener('click', function () {
        entrada.value = b.getAttribute('data-tok-exemplo').replace(/\\n/g, '\n');
        $$('[data-tok-exemplo]', caixaTok).forEach(function (x) { x.setAttribute('aria-pressed', String(x === b)); });
        atualizar(); animar();
      });
    });
    atualizar();
  }

  /* ------------------------------------------------ calculadora de custo */
  var calc = $('[data-calc]');
  if (calc) {
    var hive = JSON.parse(calc.getAttribute('data-hive'));
    var lista = cenas(hive);
    var est = { entrada: lista[2].entrada, saida: lista[2].saida, cachePct: lista[2].cachePct, pedidos: lista[2].pedidos };
    mostrar(calc);
    var cenasBox = $('[data-calc-cenas]', calc);
    cenasBox.innerHTML = lista.map(function (c, i) { return '<button type="button" data-i="' + i + '" aria-pressed="' + (i === 2) + '">' + esc(c.nome) + '</button>'; }).join('');
    var r = function (k) { return $('[data-calc-' + k + ']', calc); };
    var desenhar = function (anim) {
      r('entrada-v').textContent = num(est.entrada); r('saida-v').textContent = num(est.saida); r('cache-v').textContent = est.cachePct + '%';
      r('pedidos').textContent = est.pedidos > 1 ? 'em ' + est.pedidos + ' pedidos (cada turno reenvia o contexto)' : 'em 1 pedido';
      var res = MODELOS.map(function (m) { return { m: m, c: custo(m, est) }; });
      var max = Math.max.apply(null, res.map(function (x) { return x.c.total; })) || 1;
      r('resultado').innerHTML = res.map(function (x) {
        var p = x.c.partes, t = x.c.total || 1e-9;
        var seg = function (v, cls, rot) { return v > 0 ? '<span class="fx-seg fx-seg--' + cls + '" style="flex-grow:' + (v / t).toFixed(4) + '" title="' + rot + ': ' + usd(v) + '"></span>' : ''; };
        return '<div class="fx-modelo"><div class="fx-modelo__cab"><strong>' + esc(x.m.nome) + '</strong><span class="fx-total">' + usd(x.c.total) + '</span><span class="fx-cred">' + cred(x.c.creditos) + ' do Copilot</span></div>' +
          '<div class="fx-barra" style="--w:' + Math.max(2, x.c.total / max * 100).toFixed(1) + '%">' + seg(p.entrada, 'entrada', 'Entrada') + seg(p.cache, 'cache', 'Cache') + seg(p.saida, 'saida', 'Saída') + '</div>' +
          '<div class="fx-partes"><span><i class="fx-seg--entrada"></i>entrada ' + usd(p.entrada) + '</span><span><i class="fx-seg--cache"></i>cache ' + usd(p.cache) + '</span><span><i class="fx-seg--saida"></i>saída ' + usd(p.saida) + '</span></div>' +
          (x.c.longo ? '<p class="nota">Pedido acima de 272 mil tokens de entrada: o GPT-6 Luna cobra 2× na entrada e 1,5× na saída.</p>' : '') + '</div>';
      }).join('');
      var vezes = res[0].c.total && res[1].c.total ? res[0].c.total / res[1].c.total : 0;
      r('razao').textContent = vezes ? 'O mesmo trabalho custa ' + Math.round(vezes).toLocaleString('pt-BR') + '× mais no ' + res[0].m.nome + ' do que no ' + res[1].m.nome + '. Modelo maior não é sempre necessário.' : '';
      if (anim && M && !reduzir) M.from($$('.fx-barra', calc), { scaleX: 0, duration: 0.6, stagger: 0.1, ease: 'power2.out' });
    };
    var ligar = function (k, max, passo) {
      var el = r(k); el.max = max; el.step = passo; el.value = est[k === 'cache' ? 'cachePct' : k];
      el.addEventListener('input', function () { est[k === 'cache' ? 'cachePct' : k] = +el.value; desenhar(false); });
    };
    ligar('entrada', 2000000, 1000); ligar('saida', 50000, 100); ligar('cache', 95, 5);
    cenasBox.addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      var c = lista[+b.getAttribute('data-i')];
      est = { entrada: c.entrada, saida: c.saida, cachePct: c.cachePct, pedidos: c.pedidos };
      r('entrada').value = est.entrada; r('saida').value = est.saida; r('cache').value = est.cachePct;
      r('nota').textContent = c.nota;
      $$('button', cenasBox).forEach(function (x) { x.setAttribute('aria-pressed', String(x === b)); });
      desenhar(true);
    });
    r('nota').textContent = lista[2].nota;
    desenhar(true);
  }

  /* ------------------------------------------------ janela de contexto */
  var jan = $('[data-janela]');
  if (jan) {
    var h2 = JSON.parse(jan.getAttribute('data-hive'));
    var PECAS = [
      { id: 'sistema', nome: 'Instruções do Copilot e ferramentas', cor: 'sistema' },
      { id: 'time', nome: 'Instruções do time e do agente', cor: 'time' },
      { id: 'arquivos', nome: 'Arquivos lidos', cor: 'arquivos' },
      { id: 'historico', nome: 'Histórico da conversa', cor: 'historico' },
      { id: 'resposta', nome: 'Resposta', cor: 'resposta' },
    ];
    var CENAS = {
      solto: { nome: 'Chat solto', turnos: true, base: { sistema: 18000, time: 3000, arquivos: 45000, historico: 0, resposta: 2000 }, porTurno: 9000,
        texto: 'Tudo na mesma conversa: cada turno soma histórico, arquivos colados e respostas antigas. O começo vai perdendo peso e, perto do limite, o Copilot resume ou descarta parte do que veio antes.' },
      fase: { nome: 'Uma fase por chat', turnos: false, base: { sistema: 18000, time: h2.plan + h2.contrato, arquivos: 20000, historico: 8000, resposta: 6000 },
        texto: 'Chat novo para cada fase. O que importa passa de uma fase para a outra em arquivo (briefing, proposta, fatia), não na memória da conversa.' },
      sub: { nome: 'Subagente com contexto limpo', turnos: false, base: { sistema: 6000, time: h2.gf, arquivos: 12000, historico: 0, resposta: 1500 },
        texto: 'O subagente nasce sem a conversa: recebe só a tarefa e os arquivos dela. É o caso do revisor do Hive, que julga o que está escrito, não o que foi conversado.' },
    };
    var JANELA = 272000; // referência visual: a partir daqui o GPT-6 Luna cobra mais caro; não é o limite do modelo
    var estJ = { cena: 'solto', turnos: 12 };
    mostrar(jan);
    var barra = $('[data-janela-barra]', jan), legenda = $('[data-janela-legenda]', jan), info = $('[data-janela-info]', jan), texto = $('[data-janela-texto]', jan);
    var turnos = $('[data-janela-turnos]', jan), turnosV = $('[data-janela-turnos-v]', jan), turnosBox = $('[data-janela-turnos-box]', jan);
    var desenharJ = function (anim) {
      var c = CENAS[estJ.cena];
      var v = {}; PECAS.forEach(function (p) { v[p.id] = c.base[p.id]; });
      if (c.turnos) v.historico = c.porTurno * estJ.turnos;
      var total = PECAS.reduce(function (s, p) { return s + v[p.id]; }, 0);
      var escala = Math.max(total, JANELA) * 1.08;
      barra.innerHTML = PECAS.map(function (p) { return v[p.id] ? '<span class="jn-seg jn-seg--' + p.cor + '" style="width:' + (v[p.id] / escala * 100).toFixed(2) + '%" title="' + p.nome + ': ' + num(v[p.id]) + ' tokens"></span>' : ''; }).join('') +
        '<span class="jn-marca" style="left:' + (JANELA / escala * 100).toFixed(2) + '%"><b>272 mil</b></span>';
      legenda.innerHTML = PECAS.map(function (p) { return '<li><i class="jn-seg--' + p.cor + '"></i>' + p.nome + ' <strong>' + num(v[p.id]) + '</strong></li>'; }).join('');
      var o = custo(MODELOS[0], { entrada: total, saida: v.resposta, cachePct: c.turnos ? 80 : 50, pedidos: 1 });
      info.innerHTML = '<strong>' + num(total) + '</strong> tokens enviados no próximo pedido · ' + (total / MODELOS[0].janela * 100).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + '% da janela de 1 milhão · ' + usd(o.total) + ' só esse pedido no Claude Opus 5.5';
      texto.textContent = c.texto;
      turnosBox.hidden = !c.turnos;
      if (anim && M && !reduzir) M.from($$('.jn-seg', barra), { scaleX: 0, duration: 0.5, stagger: 0.06, ease: 'power2.out' });
    };
    $('[data-janela-cenas]', jan).addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      estJ.cena = b.getAttribute('data-cena');
      $$('[data-janela-cenas] button', jan).forEach(function (x) { x.setAttribute('aria-pressed', String(x === b)); });
      desenharJ(true);
    });
    turnos.addEventListener('input', function () { estJ.turnos = +turnos.value; turnosV.textContent = turnos.value; desenharJ(false); });
    desenharJ(true);
  }

  /* ------------------------------------------------ o carro do harness */
  var carro = $('[data-carro]');
  var tabela = $('[data-pecas]');
  if (carro && tabela) {
    var painel = $('[data-peca-painel]');
    var camadas = $('[data-camadas]');
    mostrar(painel); mostrar(camadas);
    var dados = {};
    $$('tr[data-peca]', tabela).forEach(function (tr) {
      var td = $$('td', tr);
      dados[tr.getAttribute('data-peca')] = { n: tr.getAttribute('data-n'), carro: $('th', tr).textContent, harness: td[0].innerHTML, onde: td[1].innerHTML, camada: tr.getAttribute('data-camada') };
    });
    var escolher = function (id) {
      var d = dados[id]; if (!d) return;
      $$('.peca', carro).forEach(function (p) { p.classList.toggle('ativa', p.getAttribute('data-peca') === id); p.setAttribute('aria-pressed', String(p.getAttribute('data-peca') === id)); });
      painel.innerHTML = '<p class="eyebrow">Peça do carro</p><h3>' + esc(d.carro) + '</h3><p class="pc-harness">' + d.harness + '</p><p class="nota">' + d.onde + '</p>';
      if (M && !reduzir) M.from(painel.children, { opacity: 0, y: 8, duration: 0.3, stagger: 0.05 });
    };
    $$('.peca', carro).forEach(function (p) {
      p.addEventListener('click', function () { escolher(p.getAttribute('data-peca')); });
      p.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); escolher(p.getAttribute('data-peca')); } });
    });
    var txtCamada = {};
    $$('[data-camada-txt]', doc).forEach(function (el) { txtCamada[el.getAttribute('data-camada-txt')] = el.innerHTML; });
    var descCamada = $('[data-camada-desc]');
    camadas.addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      var c = b.getAttribute('data-camada');
      $$('button', camadas).forEach(function (x) { x.setAttribute('aria-pressed', String(x === b)); });
      carro.classList.toggle('com-camada', c !== 'tudo');
      $$('.peca', carro).forEach(function (p) {
        var d = dados[p.getAttribute('data-peca')];
        p.classList.toggle('na-camada', c === 'tudo' || d.camada === c || d.camada === 'todas');
      });
      if (descCamada) descCamada.innerHTML = txtCamada[c] || '';
    });
    escolher('motor');
    if (M && !reduzir && 'IntersectionObserver' in raiz) {
      var v = $('.car-veiculo', carro);
      var io = new IntersectionObserver(function (es) {
        es.forEach(function (en) { if (en.isIntersecting) { M.from(v, { x: -260, duration: 1.4, ease: 'power3.out' }); io.disconnect(); } });
      }, { threshold: 0.3 });
      io.observe(carro);
    }
  }
})(typeof window !== 'undefined' ? window : this);
