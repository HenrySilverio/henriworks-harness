# Marca b.IA Credit Hive sobre o núcleo

`plugin/` é o núcleo, com nomes internos (`hwk`, `.henriworks/`, `/henriworks:`). O pacote que vai para o banco sai
dele pelo gerador, com os nomes da marca. Correção feita no núcleo chega ao pacote na próxima geração.

```
marcas/
  gerar.mjs                  gerador (Node 22+, sem dependência)
  bia-credit-hive/
    perfil.json              nome, autor, renomes, termos proibidos, arquivos sobrepostos
    pacote/docs/assets/      logos e SVGs do README, copiados por cima do pacote
    readme/                  README-final.md, spec.json e a skin hive da readme-skins
    site/ fundamentos/       documentação (Hive e Fundamentos de IA)
    montar-docs.mjs          junta as duas num site só
    motion-lite.js           motor de animação da documentação
    doc/ fonte/              fontes da decoração (colmeia, favo) e do logo
```

| Núcleo | b.IA Credit Hive |
| --- | --- |
| `hwk`, agentes `hwk-*`, `hwk.mjs` | `bchive`, agentes `bchive-*`, `bchive.mjs` |
| `.henriworks/` | `.bchive/` |
| `/henriworks:*` | `/bia-credit-hive:*` |
| `henrimap` | `bchivemap` |
| `HENRIWORKS_*` | `BCHIVE_*` |
| exemplos `ACME-10019` | `GPCNLS-10019` |

Comandos: ver `LEIA-ME.md` na raiz.
