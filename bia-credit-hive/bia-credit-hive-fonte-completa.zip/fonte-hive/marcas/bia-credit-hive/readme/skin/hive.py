"""Motivo `hive`: favos, alvéolos, mel e abelhas (identidade da apresentação do b.IA Credit Hive).

Mesmas regras dos outros motivos: tudo local, sem fonte web, estado final = estilo base, no máximo uma
animação infinita por arquivo (aqui, a abelha pairando no banner) e prefers-reduced-motion desliga tudo.
Abelhas e favos são desenhos originais, só com formas geométricas.
"""
import math

from components import W, dl, esc, wrap, clip, fit_title

INK = "#2B2118"  # contorno da abelha, igual nos dois temas


def hexpts(cx, cy, r, pointy=True):
    a0 = -90 if pointy else 0
    return " ".join(f"{cx + r * math.cos(math.radians(a0 + 60 * k)):.1f},{cy + r * math.sin(math.radians(a0 + 60 * k)):.1f}" for k in range(6))


def hexagon(cx, cy, r, fill, stroke, sw=2, cls="", extra=""):
    k = f' class="{cls}"' if cls else ""
    return f'<polygon{k}{extra} points="{hexpts(cx, cy, r)}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}" stroke-linejoin="round"/>'


def bee(x, y, s=1.0, cls="", delay=None):
    """Abelha original: corpo listrado, cabeça, ferrão e duas asas. O transform fica num <g> sem animação."""
    k = f' class="{cls}"' if cls else ""
    d = f' {dl(delay)}' if delay is not None else ""
    return (f'<g transform="translate({x:.1f} {y:.1f}) scale({s})"><g{k}{d}>'
            f'<ellipse cx="-3" cy="-10" rx="7" ry="9" fill="#FFFFFF" fill-opacity=".85" stroke="{INK}" stroke-width="1.2"/>'
            f'<ellipse cx="6" cy="-9" rx="6" ry="8" fill="#FFFFFF" fill-opacity=".85" stroke="{INK}" stroke-width="1.2"/>'
            f'<ellipse cx="0" cy="0" rx="13" ry="9" fill="#F2B21B" stroke="{INK}" stroke-width="1.6"/>'
            f'<path d="M-4 -8.6 V8.6 M3 -8.9 V8.9" stroke="{INK}" stroke-width="3"/>'
            f'<circle cx="14" cy="-1" r="5.5" fill="{INK}"/><circle cx="16" cy="-2.5" r="1.3" fill="#FFFFFF"/>'
            f'<path d="M-13 0 L-18 1 L-13 3 Z" fill="{INK}"/>'
            f'<path d="M17 -6 q3 -6 7 -6 M15 -6 q1 -7 4 -9" fill="none" stroke="{INK}" stroke-width="1.2" stroke-linecap="round"/>'
            "</g></g>")


def favo_pattern(pid, stroke, r=22):
    """Padrão de favo (hexágonos de ponta para cima) para fundo."""
    w, h = math.sqrt(3) * r, 3 * r
    cells = [(w / 2, r), (0, 2.5 * r), (w, 2.5 * r), (0, -0.5 * r), (w, -0.5 * r)]
    paths = "".join(f'<polygon points="{hexpts(cx, cy, r)}" fill="none" stroke="{stroke}" stroke-width="1.2"/>' for cx, cy in cells)
    return f'<pattern id="{pid}" width="{w:.3f}" height="{h:.3f}" patternUnits="userSpaceOnUse">{paths}</pattern>'


def honey_drips(c, w, delay=0.2):
    """Mel escorrendo da borda de cima: faixa + gotas que crescem para baixo."""
    drops = [(70, 26), (190, 14), (310, 34), (470, 18), (620, 30), (790, 16)]
    g = [f'<path d="M0 0 H{w} V10 Q{w-20} 14 {w-40} 10 H0 Z" fill="{c["accent"]}" opacity=".9"/>']
    for i, (x0, L) in enumerate(drops):
        g.append(f'<path class="drip" {dl(delay + i * .12)} d="M{x0-9} 8 C{x0-9} {8+L*.55} {x0-5} {8+L} {x0} {8+L} C{x0+5} {8+L} {x0+9} {8+L*.55} {x0+9} 8 Z" fill="{c["accent"]}"/>')
    return "".join(g)


DRIP_CSS = (".drip{transform-box:fill-box;transform-origin:top center;animation:drip .9s cubic-bezier(.165,.84,.44,1) both}"
            "@keyframes drip{from{transform:scaleY(0)}}"
            ".fill{animation:fill .6s ease both}@keyframes fill{from{fill-opacity:0}}")


# ------------------------------------------------------------------ banner

def banner_hive(x):
    c, p = x.c, x.spec["project"]
    H = 320
    name = p["name"]
    destaque = p.get("highlight", "")
    base = name[: -len(destaque)].rstrip() if destaque and name.endswith(destaque) else name
    _, fs = fit_title(name, 470, 56, 30, 0.56)
    defs = (
        f'<clipPath id="cp"><rect width="{W}" height="{H}" rx="18"/></clipPath>'
        + favo_pattern("favo", c["border"])
        + f'<linearGradient id="fade" x1="0" x2="1"><stop offset=".35" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#fff" stop-opacity="1"/></linearGradient>'
        + '<mask id="mfade"><rect width="900" height="320" fill="url(#fade)"/></mask>'
        + f'<linearGradient id="mel" x1="0" x2="1"><stop offset="0" stop-color="{c["title_a"]}"/><stop offset="1" stop-color="{c["title_b"]}"/></linearGradient>'
    )
    kick = ""
    if p.get("kicker"):
        kw = len(p["kicker"]) * 7.9 + 46
        kick = (f'<g class="rise" {dl(.15)}><rect x="48" y="50" width="{kw:.0f}" height="28" rx="14" fill="{c["surface"]}" stroke="{c["accent"]}"/>'
                + hexagon(66, 64, 6.5, c["accent"], c["accent"], 1)
                + x.text(80, 69, p["kicker"].upper(), 12, c["text"], "mono", "700") + "</g>")
    ty = 140
    title = (f'<text class="rise" style="animation-delay:.3s" x="48" y="{ty}" font-family="{x.f["display"]}" font-size="{fs}" font-weight="800">'
             f'<tspan fill="{c["text"]}">{esc(base)}</tspan>'
             + (f'<tspan fill="url(#mel)"> {esc(destaque)}</tspan>' if destaque and base != name else "") + "</text>")
    linhas = wrap(p.get("tagline", ""), 48, 3)
    tag = "".join(x.text(48, ty + 40 + i * 25, t, 17, c["muted"], cls="rise", style="animation-delay:.55s") for i, t in enumerate(linhas))
    stats, sx = [], 48
    for i, s in enumerate(x.spec.get("stats", [])[:3]):
        label = f'{s["value"]} {s["label"].lower()}'
        stats.append(f'<g class="rise" {dl(1.0 + i * .12)}>' + hexagon(sx + 6, 277, 6.5, c["accent"] if i != 1 else c["accent2"], "none", 0)
                     + x.text(sx + 18, 282, label, 13, c["text"], "mono", "600") + "</g>")
        sx += len(label) * 7.9 + 46
    # cacho de alvéolos: centro + 6 vizinhos (hexágonos de ponta para cima, vizinhos a 0°, 60°, ...)
    cx, cy, r = 700, 172, 47
    nodes = (p.get("nodes") or [])[:6]
    cells = []
    d = math.sqrt(3) * r + 4
    for i in range(6):
        a = math.radians(-120 + 60 * i)
        nx, ny = cx + d * math.cos(a), cy + d * math.sin(a)
        cheio = i % 2 == 0
        cells.append(f'<g class="pop" {dl(.6 + i * .13)}>'
                     + hexagon(nx, ny, r, c["honeybg"] if cheio else c["surface"], c["accent3"], 2)
                     + (hexagon(nx, ny, r - 7, c["accent"], "none", 0, cls="fill", extra=f' fill-opacity=".28" {dl(1.3 + i * .13)}') if cheio else "")
                     + (x.text(f"{nx:.1f}", f"{ny + 4:.1f}", clip(nodes[i], 10), 12, c["text"], "mono", "600", anchor="middle") if i < len(nodes) else "")
                     + "</g>")
    hub = (f'<g class="pop" {dl(.35)}>' + hexagon(cx, cy, r, c["accent"], c["accent2"], 3)
           + x.text(cx, cy + 5, p.get("hub", "HIVE"), 14, INK, "mono", "800", anchor="middle") + "</g>")
    # trilha pontilhada da abelha que chega, e a abelha que paira (o único loop)
    trilha = f'M560 {cy + 112} C600 {cy + 150} 640 {cy + 140} 676 {cy + 108}'
    L = 150
    voo = (f'<path class="draw" style="--L:{L};stroke-dasharray:3 7;animation-delay:1.6s" d="{trilha}" fill="none" stroke="{c["accent3"]}" stroke-width="2" stroke-linecap="round" opacity=".8"/>'
           + bee(548, cy + 104, 1.05, "pop", 1.5))
    pairando = bee(812, 58, 1.15, "bob")
    css = DRIP_CSS + (".bob{animation:bob 2.8s ease-in-out 2s infinite}@keyframes bob{50%{transform:translate(-3px,-6px)}}")
    body = (
        f'<rect width="{W}" height="{H}" rx="18" fill="{c["bg"]}"/>'
        f'<g clip-path="url(#cp)"><rect width="{W}" height="{H}" fill="url(#favo)" mask="url(#mfade)" opacity=".9"/>'
        + honey_drips(c, W) + "</g>"
        f'<rect x=".5" y=".5" width="{W-1}" height="{H-1}" rx="18" fill="none" stroke="{c["border"]}"/>'
        + kick + title + tag + "".join(stats) + "".join(cells) + hub + voo + pairando
    )
    alt = f'{name}: {p.get("tagline", "")}'
    return x.doc(H, f"{name} — banner", p.get("tagline", ""), body, defs, css), alt


# ------------------------------------------------------------------ seção

def section_hive(x, label=""):
    c = x.c
    H = 52 if label else 30
    body = []
    if label:
        body.append(f'<g class="pop">' + hexagon(22, 27, 14, c["accent"], c["accent3"], 2) + "</g>")
        body.append(x.text(48, 35, label, 22, c["text"], "display", "700", cls="rise"))
        x0 = 48 + len(label) * 12.6 + 18
        L = max(10, W - 40 - x0)
        body.append(f'<line class="draw" style="--L:{L:.0f};stroke-dasharray:2 8;animation-delay:.3s" x1="{x0:.0f}" y1="28" x2="{W-40}" y2="28" stroke="{c["accent3"]}" stroke-width="3" stroke-linecap="round"/>')
        body.append(bee(W - 22, 27, .8, "pop", .9))
    else:
        for i, xx in enumerate(range(380, 540, 36)):
            body.append(f'<g class="pop" {dl(.1 + i * .08)}>' + hexagon(xx, 15, 10, c["accent"] if i % 2 == 0 else c["surface"], c["accent3"], 1.5) + "</g>")
    return x.doc(H, label or "Divisor", label or "Divisor", "".join(body), css=DRIP_CSS), label or "—"


# ------------------------------------------------------------------ fluxo em alvéolos

def flow_hive(x):
    c, items = x.c, x.spec["flow"][:6]
    nodes = [(i if isinstance(i, dict) else {"label": i}) for i in items]
    n, H, r = len(nodes), 196, 44
    step = (W - 2 * 70) / max(1, n - 1)
    cy = 72
    body = []
    xs = [70 + i * step for i in range(n)]
    # trilha de mel ligando os alvéolos
    L = xs[-1] - xs[0]
    body.append(f'<line class="draw" style="--L:{L:.0f};stroke-dasharray:{L:.0f};animation-delay:.2s;animation-duration:1.6s" x1="{xs[0]:.0f}" y1="{cy}" x2="{xs[-1]:.0f}" y2="{cy}" stroke="{c["accent"]}" stroke-width="6" stroke-linecap="round" opacity=".45"/>')
    for i, nd in enumerate(nodes):
        nx = xs[i]
        ultimo = i == n - 1
        body.append(f'<g class="pop" {dl(.25 + i * .22)}>'
                    + hexagon(nx, cy, r, c["accent"] if ultimo else c["honeybg"], c["accent3"] if not ultimo else c["accent2"], 2.5)
                    + x.text(f"{nx:.0f}", cy + 9, f"{i + 1}", 26, INK if ultimo else c["accent3"], "display", "800", anchor="middle")
                    + "</g>")
        body.append(f'<g class="rise" {dl(.45 + i * .22)}>'
                    + x.text(f"{nx:.0f}", cy + r + 32, clip(nd["label"], 13), 15, c["text"], "display", "700", anchor="middle")
                    + (x.text(f"{nx:.0f}", cy + r + 52, clip(nd["sub"], 18), 12, c["muted"], "mono", anchor="middle") if nd.get("sub") else "")
                    + "</g>")
    body.append(bee(xs[-1] + 30, cy - 44, .85, "pop", .3 + n * .22))
    alt = "Fluxo: " + " → ".join(f'{nd["label"]}' + (f' ({nd["sub"]})' if nd.get("sub") else "") for nd in nodes)
    return x.doc(H, "Fluxo", alt, "".join(body)), alt


# ------------------------------------------------------------------ cards com alvéolo

def cards_hive(x):
    c, items = x.c, x.spec["cards"][:9]
    n = len(items)
    cols = min(3, n) if n != 4 else 2
    gap = 16
    cw = (W - 16 - gap * (cols - 1)) / cols
    cpl = max(16, int((cw - 40) / 6.9))
    wr = [wrap(i.get("desc", ""), cpl, 3) for i in items]
    rowh = [92 + max(len(w) for w in wr[r0:r0 + cols]) * 19 for r0 in range(0, n, cols)]
    r = 14
    body, y = [], 4
    for i, it in enumerate(items):
        row, col = divmod(i, cols)
        if col == 0 and row > 0:
            y += rowh[row - 1] + gap
        cx = 8 + col * (cw + gap)
        h = rowh[row]
        badge = it.get("badge", f"{i + 1}")
        g = (f'<g class="rise" {dl(.1 + i * .12)}><rect x="{cx:.0f}" y="{y}" width="{cw:.0f}" height="{h}" rx="{r}" fill="{c["surface"]}" stroke="{c["border"]}"/>'
             + hexagon(cx + 40, y + 44, 22, c["accent"] if i % 2 == 0 else c["honeybg"], c["accent3"], 2)
             + x.text(f"{cx + 40:.0f}", y + 50, clip(badge, 2), 16, INK if i % 2 == 0 else c["accent3"], "display", "800", anchor="middle")
             + x.text(f"{cx + 76:.0f}", y + 50, clip(it["title"], int((cw - 92) / 9.2)), 17, c["text"], "display", "700"))
        for li, l in enumerate(wr[i]):
            g += x.text(f"{cx + 24:.0f}", y + 94 + li * 19, l, 13.5, c["muted"])
        body.append(g + "</g>")
    H = y + rowh[-1] + 6
    alt = "; ".join(f'{i["title"]}: {i.get("desc", "")}' for i in items)
    return x.doc(H, "Cards", alt, "".join(body)), alt


# ------------------------------------------------------------------ indicadores em alvéolo

def stats_hive(x):
    c, items = x.c, x.spec["stats"][:4]
    n, gap, H = len(items), 14, 112
    tw = (W - 16 - gap * (n - 1)) / n
    body = []
    for i, s in enumerate(items):
        tx = 8 + i * (tw + gap)
        body.append(f'<g class="rise" {dl(.1 + i * .12)}><rect x="{tx:.0f}" y="4" width="{tw:.0f}" height="{H-8}" rx="14" fill="{c["surface"]}" stroke="{c["border"]}"/>'
                    + hexagon(tx + 46, 56, 30, c["honeybg"], c["accent3"], 2)
                    + x.text(f"{tx + 46:.0f}", 64, clip(str(s["value"]), 5), 22 if len(str(s["value"])) < 4 else 16, c["text"], "display", "800", anchor="middle")
                    + x.text(f"{tx + 88:.0f}", 61, clip(s["label"], int((tw - 100) / 7.4)), 13.5, c["muted"], "body", "600") + "</g>")
    alt = "; ".join(f'{s["label"]}: {s["value"]}' for s in items)
    return x.doc(H, "Indicadores", alt, "".join(body)), alt
