#!/usr/bin/env node
// Monta as duas documentações num site só: hive/ e fundamentos/ lado a lado, com a chave no topo de cada página
// para trocar entre elas, e uma página de entrada na raiz.
//
//   node montar-docs.mjs <saida> [--ext html|aspx] [--plugin <pasta do plugin gerado>]
//
// html: para abrir do disco (pasta compartilhada, zip). aspx: para publicar numa biblioteca do SharePoint.

import { spawnSync } from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync, rmSync, existsSync } from 'node:fs';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const AQUI = dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const op = (k, p) => { const i = args.indexOf(`--${k}`); return i >= 0 ? args[i + 1] : p; };
const SAIDA = resolve(args[0] || join(AQUI, 'out-docs'));
const EXT = op('ext', 'html');
const extra = op('plugin') ? ['--plugin', op('plugin')] : [];

if (existsSync(SAIDA)) rmSync(SAIDA, { recursive: true, force: true });
mkdirSync(SAIDA, { recursive: true });
for (const [pasta, dir] of [['hive', 'site'], ['fundamentos', 'fundamentos']]) {
  const r = spawnSync(process.execPath, [join(AQUI, dir, 'gerar.mjs'), join(SAIDA, pasta), '--ext', EXT, ...extra], { encoding: 'utf8' });
  if (r.status !== 0) { console.error(r.stderr || r.stdout); process.exit(1); }
  console.log(r.stdout.trim());
}

const entrada = EXT === 'html' ? 'ABRIR-AQUI.html' : `index.${EXT}`;
writeFileSync(join(SAIDA, entrada), `<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>b.IA Credit · documentação de IA</title>
  <meta name="description" content="Fundamentos de IA e a documentação do b.IA Credit Hive.">
  <link rel="icon" type="image/svg+xml" href="hive/img/simbolo-bia.svg">
  <link rel="stylesheet" href="hive/style.css">
</head>
<body>
${readFileSync(join(AQUI, 'site', 'colmeia.html'), 'utf8').replace(/src="img\//g, 'src="hive/img/')}
<header class="topo"><div class="conteudo topo__linha">
  <span class="marca"><img class="mlogo mlogo--c" src="hive/img/logo-bia.svg" alt="b.IA Credit" height="28"><img class="mlogo mlogo--e" src="hive/img/logo-bia-escuro.svg" alt="" height="28"></span>
</div></header>
<main id="conteudo">
<section class="hero hero--pagina conteudo">
  <div>
    <p class="eyebrow">Documentação · BU Crédito</p>
    <h1>Por onde você quer começar?</h1>
    <p class="lede">Duas documentações, um site só. Em qualquer página, a chave no topo troca entre elas.</p>
  </div>
</section>
<section class="secao conteudo" aria-label="Documentações">
  <div class="grade grade--2">
    <a class="card card--link" href="fundamentos/index.${EXT}"><h3>1 · Fundamentos de IA</h3><p><strong>Comece aqui se é a primeira vez.</strong> Tokens e custo, janela de contexto, modelo × agente, agents, skills, hooks, MCP e harness engineering, para negócio e técnico.</p></a>
    <a class="card card--link" href="hive/index.${EXT}"><h3>2 · b.IA Credit Hive</h3><p>O plugin na prática: como funciona por dentro, o fluxo, instalação, cenários, governança, o painel de uso e a referência de comandos.</p></a>
  </div>
  <p class="nota" style="margin-top:18px">Nas páginas: <kbd>P</kbd> liga o modo apresentação, as setas avançam e <kbd>Esc</kbd> sai.</p>
</section>
</main>
</body>
</html>
`);
console.log(`entrada: ${join(SAIDA, entrada)}`);
