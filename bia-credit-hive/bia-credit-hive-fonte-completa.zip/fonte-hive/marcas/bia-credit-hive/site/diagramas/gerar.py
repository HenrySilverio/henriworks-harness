# Gera os diagramas SVG da documentação (desenho original, cores por variável CSS: tema claro e escuro).
import math, os
AQUI = os.path.dirname(os.path.abspath(__file__))
def hexa(cx, cy, r):
    p = [(cx + r*math.cos(math.radians(60*i-90)), cy + r*math.sin(math.radians(60*i-90))) for i in range(6)]
    return 'M' + ' L'.join(f'{x:.1f},{y:.1f}' for x, y in p) + ' Z'
def esc(s): return s.replace('&', '&amp;').replace('<', '&lt;')
def salvar(nome, txt): open(os.path.join(AQUI, nome + '.html'), 'w').write(txt.strip() + '\n')

ABELHA = '''<g class="mini-abelha"><ellipse cx="0" cy="0" rx="7" ry="5" class="ma-corpo"/><path d="M-2,-5 v10 M2,-5 v10" class="ma-listra"/><ellipse cx="-2" cy="-7" rx="4" ry="5" class="ma-asa"/><ellipse cx="3" cy="-7" rx="3.5" ry="4.5" class="ma-asa"/></g>'''

# 1. Colmeia: rainha, operárias (fatias), peixinho e humano
W, H = 900, 400
q = (190, 200)
fatias = [(560, 80, '01', 'feature/'), (650, 160, '02', 'core/api/'), (560, 240, '03', 'bff/'), (650, 320, '04', 'Verificação')]
s = [f'<figure class="diagrama diagrama--colmeia revelar"><svg viewBox="0 0 {W} {H}" role="img" aria-labelledby="dc-t dc-d"><title id="dc-t">Orquestração da colmeia</title><desc id="dc-d">A rainha coordena e despacha cada fatia para uma operária num contexto limpo; o peixinho revisa sem a conversa; o humano decide nos portões.</desc>']
for (x, y, n, t) in fatias:
    cam = f'M{q[0]+70},{q[1]} C {q[0]+220},{q[1]} {x-160},{y} {x-48},{y}'
    s.append(f'<path d="{cam}" class="dg-rota desenhar"/>')
s.append(f'<path d="{hexa(*q, 78)}" class="dg-hex dg-hex--rainha"/><text x="{q[0]}" y="{q[1]-8}" class="dg-t dg-t--forte" text-anchor="middle">Rainha</text><text x="{q[0]}" y="{q[1]+14}" class="dg-t dg-t--peq" text-anchor="middle">agente de fase</text><text x="{q[0]}" y="{q[1]+32}" class="dg-t dg-t--peq" text-anchor="middle">coordena</text>')
for i, (x, y, n, t) in enumerate(fatias):
    s.append(f'<g class="dg-fatia" style="--i:{i}"><path d="{hexa(x, y, 46)}" class="dg-hex dg-hex--fatia"/><path d="{hexa(x, y, 46)}" class="dg-mel"/><text x="{x}" y="{y-4}" class="dg-t dg-t--forte" text-anchor="middle">Fatia {n}</text><text x="{x}" y="{y+14}" class="dg-t dg-t--mono" text-anchor="middle">{esc(t)}</text></g>')
for i, (x, y, n, t) in enumerate(fatias):
    cam = f'M{q[0]+70},{q[1]} C {q[0]+220},{q[1]} {x-160},{y} {x-48},{y}'
    s.append(f'<g class="voo">{ABELHA}<animateMotion dur="{3.2+i*0.35:.2f}s" begin="{i*0.8:.1f}s" repeatCount="indefinite" rotate="auto" keyPoints="0;1;1" keyTimes="0;0.8;1" calcMode="linear" path="{cam}"/></g>')
s.append(f'<g class="dg-papel"><rect x="760" y="40" width="124" height="74" rx="12" class="dg-caixa dg-caixa--humano"/><text x="822" y="72" class="dg-t dg-t--forte" text-anchor="middle">Humano</text><text x="822" y="92" class="dg-t dg-t--peq" text-anchor="middle">decide e commita</text></g>')
s.append(f'<g class="dg-papel"><rect x="760" y="200" width="124" height="74" rx="12" class="dg-caixa dg-caixa--peixe"/><text x="822" y="232" class="dg-t dg-t--forte" text-anchor="middle">Peixinho</text><text x="822" y="252" class="dg-t dg-t--peq" text-anchor="middle">revisa isolado</text></g>')
s.append('<path d="M700,200 C 725,205 735,235 760,237" class="dg-seta desenhar"/><path d="M822,200 L822,114" class="dg-seta desenhar"/><text x="832" y="162" class="dg-t dg-t--peq">veredito</text><text x="728" y="196" class="dg-t dg-t--peq" text-anchor="middle">diff</text>')
s.append(f'<text x="{q[0]}" y="{H-24}" class="dg-t dg-t--peq" text-anchor="middle">conhece o projeto, não executa</text><text x="605" y="{H-8}" class="dg-t dg-t--peq" text-anchor="middle">cada operária vê só a sua fatia e os ponteiros</text>')
s.append('</svg></figure>')
salvar('colmeia', ''.join(s))

# 2. Ciclo do agente
cx, cy, R = 240, 235, 160
nos = ['Ler', 'Planejar', 'Agir', 'Verificar', 'Registrar']
sub = ['contexto mínimo', 'fase e fatia', 'uma fatia', 'script prova', 'artefato']
s = ['<figure class="diagrama diagrama--loop revelar"><svg viewBox="0 0 480 490" role="img" aria-labelledby="dl-t dl-d"><title id="dl-t">Ciclo do agente</title><desc id="dl-d">Ler, planejar, agir, verificar e registrar, num ciclo curto; o portão humano interrompe o ciclo quando a decisão é de uma pessoa.</desc>']
s.append(f'<circle cx="{cx}" cy="{cy}" r="{R}" class="dg-anel"/><circle cx="{cx}" cy="{cy}" r="{R}" class="dg-anel dg-anel--vivo desenhar"/>')
for i, (n, t) in enumerate(zip(nos, sub)):
    a = math.radians(-90 + i*72); x, y = cx + R*math.cos(a), cy + R*math.sin(a)
    s.append(f'<g class="dg-no" style="--i:{i}"><path d="{hexa(x, y, 54)}" class="dg-hex dg-hex--no"/><text x="{x:.1f}" y="{y-2:.1f}" class="dg-t dg-t--forte" text-anchor="middle">{n}</text><text x="{x:.1f}" y="{y+14:.1f}" class="dg-t dg-t--peq" text-anchor="middle">{t}</text></g>')
s.append(f'<g class="voo"><circle r="7" class="dg-ponto"/><animateMotion dur="7.5s" repeatCount="indefinite" path="M{cx},{cy-R} a{R},{R} 0 1,1 -0.1,0"/></g>')
s.append(f'<path d="{hexa(cx, cy, 62)}" class="dg-hex dg-hex--humano"/><text x="{cx}" y="{cy-4}" class="dg-t dg-t--forte" text-anchor="middle">Portão</text><text x="{cx}" y="{cy+14}" class="dg-t dg-t--peq" text-anchor="middle">humano decide</text>')
s.append(f'<text x="{cx}" y="484" class="dg-t dg-t--peq" text-anchor="middle">cada volta termina com uma prova, não com a memória do chat</text></svg></figure>')
salvar('loop', ''.join(s))

# 3. Revisão: elefante x peixinho
s = ['<figure class="diagrama diagrama--revisao revelar"><svg viewBox="0 0 900 300" role="img" aria-labelledby="dr-t dr-d"><title id="dr-t">Revisão isolada</title><desc id="dr-d">O autor tem a conversa inteira; o script gera um pacote; o peixinho lê só o pacote e devolve um veredito que o script grava.</desc>']
s.append('<rect x="20" y="40" width="230" height="220" rx="16" class="dg-caixa"/><text x="135" y="72" class="dg-t dg-t--forte" text-anchor="middle">Autor (elefante)</text>')
for i, t in enumerate(['conversa inteira', 'suposições não escritas', 'decisões do chat', 'o código']):
    s.append(f'<rect x="44" y="{92+i*38}" width="182" height="28" rx="8" class="dg-bolha" style="--i:{i}"/><text x="135" y="{111+i*38}" class="dg-t dg-t--peq" text-anchor="middle">{t}</text>')
s.append('<path d="M250,150 L340,150" class="dg-seta desenhar"/>')
s.append(f'<path d="{hexa(420, 150, 70)}" class="dg-hex dg-hex--rainha"/><text x="420" y="144" class="dg-t dg-t--forte" text-anchor="middle">Script</text><text x="420" y="162" class="dg-t dg-t--mono" text-anchor="middle">pacote-revisao</text>')
s.append('<path d="M490,150 L580,150" class="dg-seta desenhar"/><text x="535" y="138" class="dg-t dg-t--peq" text-anchor="middle">só o pacote</text>')
s.append('<rect x="580" y="70" width="170" height="160" rx="16" class="dg-caixa dg-caixa--peixe"/><text x="665" y="104" class="dg-t dg-t--forte" text-anchor="middle">Peixinho</text><text x="665" y="128" class="dg-t dg-t--peq" text-anchor="middle">lente do estágio</text><text x="665" y="148" class="dg-t dg-t--peq" text-anchor="middle">lista do que ler</text><text x="665" y="168" class="dg-t dg-t--peq" text-anchor="middle">régua de severidade</text><text x="665" y="198" class="dg-t dg-t--mono" text-anchor="middle">read · search</text>')
s.append('<path d="M750,150 L800,150" class="dg-seta desenhar"/><rect x="800" y="112" width="84" height="76" rx="12" class="dg-caixa dg-caixa--veredito"/><text x="842" y="146" class="dg-t dg-t--forte" text-anchor="middle">Veredito</text><text x="842" y="166" class="dg-t dg-t--peq" text-anchor="middle">gravado</text>')
s.append('<path d="M250,110 C 330,40 520,30 580,90" class="dg-bloqueio"/><text x="420" y="40" class="dg-t dg-t--nao" text-anchor="middle">a conversa não passa (o canário prova)</text></svg></figure>')
salvar('revisao', ''.join(s))

# 4. Portões em série
portoes = [('Script', 'validar'), ('Peixinho', 'revisão da spec'), ('Humano', 'aprovar spec'), ('Script', 'verificação com escopo'), ('Peixinho', '3 eixos'), ('Humano', 'commit e PR'), ('Humano', 'OK do QA')]
s = ['<figure class="diagrama diagrama--portoes revelar"><svg viewBox="0 0 980 200" role="img" aria-labelledby="dp-t dp-d"><title id="dp-t">Portões em série</title><desc id="dp-d">Validar, revisão da spec, aprovação humana, verificação, três eixos, commit e PR, OK do QA: script, revisor e pessoa se alternam.</desc>']
s.append('<path d="M60,100 L920,100" class="dg-rota desenhar"/>')
for i, (q_, t) in enumerate(portoes):
    x = 70 + i*140; cls = {'Script': 'det', 'Peixinho': 'peixe', 'Humano': 'humano'}[q_]
    s.append(f'<g class="dg-portao dg-portao--{cls}" style="--i:{i}"><path d="{hexa(x, 100, 38)}" class="dg-hex"/><text x="{x}" y="105" class="dg-t dg-t--forte" text-anchor="middle">{i+1}</text><text x="{x}" y="160" class="dg-t dg-t--peq" text-anchor="middle">{t}</text><text x="{x}" y="46" class="dg-t dg-t--mono" text-anchor="middle">{q_.lower()}</text></g>')
s.append('<g class="voo"><circle r="6" class="dg-ponto"/><animateMotion dur="9s" repeatCount="indefinite" path="M60,100 L920,100"/></g></svg></figure>')
salvar('portoes', ''.join(s))

# 5. Fases (palco fixo da história)
fases = ['Preparação', 'Intenção', 'Discovery', 'Plano', 'Revisão da spec', 'Implementação', 'Revisão de código', 'Archive', 'QA e conhecimento']
r = 34; dx = r*math.sqrt(3); pts = []
for i in range(9):
    x = 70 + (i % 2) * dx/1.1 + 10; y = 50 + i*62
    pts.append((x, y))
s = ['<svg class="fases-svg" viewBox="0 0 300 600" role="img" aria-label="As nove fases do fluxo">']
cam = 'M' + ' L'.join(f'{x:.1f},{y:.1f}' for x, y in pts)
s.append(f'<path d="{cam}" class="dg-rota"/><path d="{cam}" class="dg-rota dg-rota--viva" data-traco-historia/>')
for i, ((x, y), n) in enumerate(zip(pts, fases)):
    s.append(f'<g class="dg-fase" data-fase-no="{i}"><path d="{hexa(x, y, r-4)}" class="dg-hex"/><text x="{x:.1f}" y="{y+5:.1f}" class="dg-t dg-t--forte" text-anchor="middle">{i}</text><text x="{x+44:.1f}" y="{y+5:.1f}" class="dg-t dg-t--rotulo">{n}</text></g>')
s.append('</svg>')
salvar('fases', ''.join(s))

# 6. Onde cada coisa mora
s = ['<figure class="diagrama diagrama--onde revelar"><svg viewBox="0 0 960 330" role="img" aria-labelledby="do-t do-d"><title id="do-t">Onde cada coisa mora</title><desc id="do-d">Na máquina do dev ficam o plugin e o uso; no repositório, a pasta .bchive fora do Git; no Git e na PR, só o código e o registro de conhecimento.</desc>']
cols = [('Máquina do dev', 'fora de qualquer repositório', ['plugin: agentes, skills, hooks', '~/.bchive/uso/ (contagens)', 'telemetria (se a TI ligar)']),
        ('Repositório, fora do Git', '.git/info/exclude', ['.bchive/bin/ (núcleo)', '.bchive/changes/ (artefatos)', 'specs, decisões, mapa', '.github/ e AGENTS.md seus']),
        ('Git e PR', 'o que o time revisa', ['o código da mudança', 'conhecimento/<data>-<ticket>.md', 'resumo.md na descrição da PR'])]
for i, (t, sub_, itens) in enumerate(cols):
    x = 20 + i*320
    cls = ['', '', ' dg-caixa--git'][i]
    s.append(f'<g class="dg-col" style="--i:{i}"><rect x="{x}" y="20" width="290" height="290" rx="18" class="dg-caixa{cls}"/><text x="{x+20}" y="56" class="dg-t dg-t--titulo">{t}</text><text x="{x+20}" y="78" class="dg-t dg-t--mono">{esc(sub_)}</text>')
    for j, it in enumerate(itens):
        s.append(f'<rect x="{x+18}" y="{100+j*50}" width="254" height="38" rx="10" class="dg-bolha"/><text x="{x+32}" y="{124+j*50}" class="dg-t dg-t--peq">{esc(it)}</text>')
    s.append('</g>')
s.append('<path d="M310,165 L340,165" class="dg-seta desenhar"/><path d="M630,165 L660,165" class="dg-seta desenhar"/></svg></figure>')
salvar('onde', ''.join(s))

# 7. Vários repositórios
s = ['<figure class="diagrama diagrama--multi revelar"><svg viewBox="0 0 960 380" role="img" aria-labelledby="dm-t dm-d"><title id="dm-t">Vários repositórios, um ticket</title><desc id="dm-d">MFE, BFF e serviço, cada um com seu Hive, sua cópia do contrato e sua PR; o ticket liga as mudanças.</desc>']
s.append(f'<path d="{hexa(480, 60, 56)}" class="dg-hex dg-hex--rainha"/><text x="480" y="56" class="dg-t dg-t--forte" text-anchor="middle">Ticket</text><text x="480" y="74" class="dg-t dg-t--mono" text-anchor="middle">GPCNLS-10019</text>')
repos = [(160, 'MFE (Angular)', 'o que consome', 'mostrar-saldo-projetado'), (480, 'BFF (Java)', 'o que expõe', 'expor-saldo-projetado'), (800, 'Serviço', 'o que expõe', 'calcular-saldo')]
for i, (x, t, papel, slug) in enumerate(repos):
    s.append(f'<path d="M480,116 C 480,140 {x},130 {x},158" class="dg-rota desenhar"/>')
    s.append(f'<g class="dg-col" style="--i:{i}"><rect x="{x-140}" y="158" width="280" height="170" rx="16" class="dg-caixa"/><text x="{x}" y="188" class="dg-t dg-t--titulo" text-anchor="middle">{t}</text><text x="{x}" y="210" class="dg-t dg-t--mono" text-anchor="middle">.bchive/ próprio</text>')
    s.append(f'<rect x="{x-120}" y="226" width="240" height="34" rx="9" class="dg-bolha"/><text x="{x}" y="248" class="dg-t dg-t--peq" text-anchor="middle">contrato próprio: {papel}</text>')
    s.append(f'<rect x="{x-120}" y="270" width="240" height="34" rx="9" class="dg-bolha dg-bolha--pr"/><text x="{x}" y="292" class="dg-t dg-t--peq" text-anchor="middle">PR · GPCNLS-10019-{esc(slug[:16])}…</text></g>')
s.append('<path d="M658,243 L622,243" class="dg-fluxo"/><path d="M338,243 L302,243" class="dg-fluxo"/><path d="M300,362 L340,362" class="dg-fluxo"/><text x="350" y="366" class="dg-t dg-t--peq">contrato combinado na discovery; cada repositório gera a partir da sua cópia</text>')
s.append('</svg></figure>')
salvar('multi', ''.join(s))
print('ok')
