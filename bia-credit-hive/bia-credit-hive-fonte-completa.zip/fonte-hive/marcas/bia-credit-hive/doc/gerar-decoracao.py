# Gera a decoração de colmeia da documentação b.IA Credit Hive: favo de fundo, cachos de alvéolos e abelhas.
# Saídas (nesta pasta): colmeia.html (camada fixa atrás do conteúdo) e favo-hero.svg (atrás do símbolo no topo).
# Tudo é desenho original, em SVG inline: funciona offline e no SharePoint.
import math, os, random

AQUI = os.path.dirname(os.path.abspath(__file__))
R3 = math.sqrt(3)

def hexagono(cx, cy, s):
    pts = [(cx + s * math.cos(math.radians(60 * i - 90)), cy + s * math.sin(math.radians(60 * i - 90))) for i in range(6)]
    return 'M' + ' L'.join(f'{x:.2f},{y:.2f}' for x, y in pts) + ' Z'

# Favo de fundo: padrão de hexágonos (pontudos em cima), lado 28.
S = 28
W = R3 * S
padrao = ''.join(
    f'<path d="{hexagono(cx, cy, S)}"/>'
    for cx, cy in [(W / 2, S), (0, S + 1.5 * S), (W, S + 1.5 * S), (0, S - 1.5 * S), (W, S - 1.5 * S)]
)

def cacho(celulas, s, mel, cls):
    """celulas: lista de (q, r) em coordenadas axiais; mel: conjunto das que têm mel."""
    paths, xs, ys = [], [], []
    for q, r in celulas:
        cx = s * R3 * (q + r / 2)
        cy = s * 1.5 * r
        xs.append(cx); ys.append(cy)
        paths.append((cx, cy, (q, r) in mel))
    pad = s * 1.2
    x0, y0 = min(xs) - pad, min(ys) - pad
    w, h = max(xs) - min(xs) + 2 * pad, max(ys) - min(ys) + 2 * pad
    corpo = ''.join(
        f'<path d="{hexagono(cx - x0, cy - y0, s * 0.94)}" class="{"mel" if m else "vazio"}"/>' for cx, cy, m in paths
    )
    return f'<svg class="{cls}" viewBox="0 0 {w:.1f} {h:.1f}" aria-hidden="true" focusable="false">{corpo}</svg>'

CELULAS = [(0, 0), (1, 0), (2, 0), (-1, 1), (0, 1), (1, 1), (2, 1), (-1, 2), (0, 2), (1, 2), (0, 3), (-2, 3), (-1, 3)]
MEL_A = {(0, 1), (1, 1), (0, 2), (-1, 2)}
MEL_B = {(1, 0), (2, 1), (1, 2)}
HERO = [(0, 0), (1, 0), (-1, 1), (0, 1), (1, 1), (-1, 2), (0, 2), (2, -1), (-2, 2), (2, 0)]
MEL_H = {(0, 0), (1, 1), (-1, 2)}

def abelha(cls, estilo):
    # Abelha original, vista de lado: corpo listrado, cabeça, antenas, ferrão e duas asas que batem.
    return f'''<svg class="abelha {cls}" style="{estilo}" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
<defs><clipPath id="corpo-{cls}"><ellipse cx="35" cy="38" rx="17" ry="11.5"/></clipPath></defs>
<g class="asas"><ellipse class="asa asa--a" cx="29" cy="21" rx="8.5" ry="13" transform="rotate(-22 29 21)"/><ellipse class="asa asa--b" cx="40" cy="22" rx="8" ry="12" transform="rotate(24 40 22)"/></g>
<path d="M52 38 L60 36 L52 41 Z" class="ferrao"/>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="corpo"/>
<g clip-path="url(#corpo-{cls})" class="listras"><rect x="30" y="20" width="5" height="40"/><rect x="40" y="20" width="5" height="40"/><rect x="49" y="20" width="6" height="40"/></g>
<ellipse cx="35" cy="38" rx="17" ry="11.5" class="contorno"/>
<circle cx="15" cy="37" r="8" class="cabeca"/><circle cx="12.5" cy="35" r="1.6" class="olho"/>
<path d="M14 30 Q11 22 6 20 M17 30 Q17 22 13 17" class="antenas"/>
</svg>'''

ABELHAS = [
    ('ab1', 'left:2.5%;top:20%;--d:13s'),
    ('ab2', 'right:3%;top:34%;--d:16s;--x:-16px'),
    ('ab3', 'left:4%;top:62%;--d:15s;--x:14px'),
    ('ab4', 'right:5%;top:76%;--d:12s'),
    ('ab5', 'right:22%;top:12%;--d:18s;--x:-12px'),
]

TRILHAS = '''<svg class="trilha" viewBox="0 0 200 120" style="left:1%;top:14%" aria-hidden="true" focusable="false"><path d="M10 100 C 40 20, 90 110, 130 50 S 180 20, 195 40"/></svg>
<svg class="trilha" viewBox="0 0 200 120" style="right:1%;top:70%;transform:scaleX(-1)" aria-hidden="true" focusable="false"><path d="M10 90 C 50 10, 80 100, 120 40 S 170 30, 195 60"/></svg>'''

CSS = '''<style>
.colmeia { position: fixed; inset: 0; z-index: -1; pointer-events: none; overflow: hidden; }
.colmeia, .favo-hero {
  --favo: #B9790F; --mel: #F2A51A; --favo-op: .10; --cacho-op: .20; --abelha-op: .55;
  --corpo: #F2B21B; --tinta: #2B2118; --asa: rgba(255,255,255,.75); --trilha: #B9790F; }
@media (prefers-color-scheme: dark) { :root:not([data-theme="light"]) :is(.colmeia, .favo-hero) {
  --favo: #E7AE45; --mel: #F2A51A; --favo-op: .09; --cacho-op: .18; --abelha-op: .5; --asa: rgba(255,255,255,.55); --trilha: #E7AE45; } }
:root[data-theme="dark"] :is(.colmeia, .favo-hero) { --favo: #E7AE45; --mel: #F2A51A; --favo-op: .09; --cacho-op: .18; --abelha-op: .5; --asa: rgba(255,255,255,.55); --trilha: #E7AE45; }
.colmeia__favo { position: absolute; inset: 0; width: 100%; height: 100%; opacity: var(--favo-op);
  -webkit-mask-image: linear-gradient(90deg, #000 0, #000 8%, transparent 28%, transparent 72%, #000 92%, #000 100%);
          mask-image: linear-gradient(90deg, #000 0, #000 8%, transparent 28%, transparent 72%, #000 92%, #000 100%); }
.colmeia__favo path { fill: none; stroke: var(--favo); stroke-width: 1.3; }
.colmeia__cacho { position: absolute; width: min(280px, 30vw); height: auto; opacity: var(--cacho-op); }
.colmeia__cacho--a { left: -46px; bottom: -36px; }
.colmeia__cacho--b { right: -60px; top: 22%; width: min(220px, 24vw); }
.colmeia__cacho path, .favo-hero path { stroke: var(--favo); stroke-width: 2; }
.colmeia__cacho .vazio, .favo-hero .vazio { fill: none; }
.colmeia__cacho .mel, .favo-hero .mel { fill: var(--mel); fill-opacity: .55; }
.colmeia .abelha { position: absolute; width: 44px; height: 44px; opacity: var(--abelha-op);
  animation: bchive-voo var(--d, 14s) ease-in-out infinite alternate; }
.abelha .corpo { fill: var(--corpo); }
.abelha .listras rect, .abelha .cabeca, .abelha .ferrao { fill: var(--tinta); }
.abelha .contorno { fill: none; stroke: var(--tinta); stroke-width: 1.6; }
.abelha .olho { fill: #fff; }
.abelha .antenas { fill: none; stroke: var(--tinta); stroke-width: 1.6; stroke-linecap: round; }
.abelha .asa { fill: var(--asa); stroke: var(--tinta); stroke-width: 1; transform-box: fill-box; transform-origin: 50% 100%;
  animation: bchive-asa .14s ease-in-out infinite alternate; }
.colmeia .trilha { position: absolute; width: min(220px, 22vw); height: auto; opacity: .35; }
.colmeia .trilha path { fill: none; stroke: var(--trilha); stroke-width: 1.6; stroke-dasharray: 2 7; stroke-linecap: round; }
@keyframes bchive-voo { 0% { translate: 0 0; rotate: -6deg; } 50% { translate: var(--x, 16px) -14px; rotate: 5deg; } 100% { translate: calc(var(--x, 16px) * -.6) 10px; rotate: -2deg; } }
@keyframes bchive-asa { to { scale: 1 .55; } }
.hero__marca { position: relative; }
.favo-hero { position: absolute; left: 50%; top: 50%; width: min(420px, 78vw); height: auto; translate: -50% -52%; opacity: .32; z-index: 0; pointer-events: none; }
.hero__marca img { position: relative; z-index: 1; }
/* Abelhas só nas margens livres: com a página estreita elas cairiam sobre o texto. */
@media (max-width: 1280px) { .colmeia .ab3, .colmeia .ab4, .colmeia .trilha { display: none; } .colmeia { --abelha-op: .35; } }
@media (max-width: 720px) { .colmeia .ab2, .colmeia .ab5 { display: none; } .colmeia { --favo-op: .07; --abelha-op: .3; } }
@media (prefers-reduced-motion: reduce) { .colmeia .abelha, .abelha .asa { animation: none; } }
@media print { .colmeia { display: none; } }
</style>'''

colmeia = (
    '<!-- marca: decoração de colmeia (gerada por gerar-decoracao.py) -->\n' + CSS + '\n'
    '<div class="colmeia" aria-hidden="true">\n'
    f'<svg class="colmeia__favo" aria-hidden="true" focusable="false"><defs><pattern id="bchive-favo" width="{W:.3f}" height="{3 * S}" patternUnits="userSpaceOnUse">{padrao}</pattern></defs><rect width="100%" height="100%" fill="url(#bchive-favo)"/></svg>\n'
    + cacho(CELULAS, 30, MEL_A, 'colmeia__cacho colmeia__cacho--a') + '\n'
    + cacho(CELULAS[:10], 26, MEL_B, 'colmeia__cacho colmeia__cacho--b') + '\n'
    + TRILHAS + '\n'
    + '\n'.join(abelha(c, e) for c, e in ABELHAS)
    + '\n</div>\n'
)
open(os.path.join(AQUI, 'colmeia.html'), 'w').write(colmeia)
open(os.path.join(AQUI, 'favo-hero.svg'), 'w').write(cacho(HERO, 40, MEL_H, 'favo-hero'))
print('colmeia.html', len(colmeia), 'bytes; favo-hero.svg ok')
