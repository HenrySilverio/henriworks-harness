# Compõe o lockup "BIA CREDIT": o logo oficial da BIA intacto + "CREDIT" em contorno (sem depender de fonte).
import re, sys
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
D = sys.argv[1]; FONTE = sys.argv[2]; PALAVRA = sys.argv[3] if len(sys.argv) > 3 else 'CREDIT'
orig = open(f'{D}/bia-log.svg').read()
f = TTFont(FONTE); gs = f.getGlyphSet(); cmap = f.getBestCmap()
cap = f['OS/2'].sCapHeight
TOPO, BASE = 15.716, 41.6          # altura de caixa-alta do "BIA" oficial
esc = (BASE - TOPO) / cap
x = 160 + 24.0                     # vão de palavra: maior que o vão entre as letras do BIA
track = 7.5                        # espaçamento aberto, perto do BIA
partes = []
for ch in PALAVRA:
    g = cmap[ord(ch)]
    pen = SVGPathPen(gs)
    gs[g].draw(TransformPen(pen, (esc, 0, 0, -esc, x, BASE)))
    partes.append(pen.getCommands())
    x += gs[g].width * esc + track
larg = round(x - track + 0.5, 3)
d = ' '.join(partes)
def lockup(cor_letras):
    s = orig.replace("width='160'", f"width='{larg}'").replace("viewBox='0 0 160 55.467'", f"viewBox='0 0 {larg} 55.467'")
    s = s.replace("fill='#454545'", f"fill='{cor_letras}'")
    return s.replace('</svg>', f"<path d='{d}' fill='{cor_letras}'/></svg>")
open(f'{D}/../logo-bia.svg', 'w').write(lockup('#454545'))
open(f'{D}/../logo-bia-escuro.svg', 'w').write(lockup('#F2F2F2'))
# Símbolo sozinho (favicon): só o círculo, recortado quadrado.
sim = re.sub(r"<path d='M\.824.*?fill='#454545'/>", '', orig).replace("width='160'", "width='55.549'").replace("viewBox='0 0 160 55.467'", "viewBox='0 -0.041 55.549 55.549'")
open(f'{D}/../simbolo-bia.svg', 'w').write(sim)
print('largura', larg)
