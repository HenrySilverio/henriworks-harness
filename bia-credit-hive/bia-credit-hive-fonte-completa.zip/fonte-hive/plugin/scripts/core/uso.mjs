#!/usr/bin/env node
// HenriWorks - uso e adoção. Sem dependência, Node LTS 22 ou 24. Só contagem, tempo e tokens: nenhum valor em
// dinheiro, crédito ou preço de modelo (isso fica com o painel de FinOps da empresa).
//
//   node .henriworks/bin/uso.mjs importar [--refazer]            lê a telemetria (OTel) nova: tokens por chamada
//   node .henriworks/bin/uso.mjs relatorio [--de AAAA-MM-DD] [--ate AAAA-MM-DD] [--json]
//                                                                adoção: sessões, turnos, fluxo × fora, tempo, tokens
//   node .henriworks/bin/uso.mjs resumo <change|pasta>           seção "Uso" do resumo e do registro de conhecimento
//   node .henriworks/bin/uso.mjs exportar [--de ...] [--ate ...]  JSON agregado do período (base do envio futuro)
//   node .henriworks/bin/uso.mjs selar                            sela os dias fechados (cadeia de hash)
//   node .henriworks/bin/uso.mjs verificar-selos                  confere se algum dia selado foi alterado
//
// Dados ficam em ~/.henriworks/uso/ (ou HENRIWORKS_USO), fora de qualquer repositório. O hook grava só
// nomes, contagens e carimbos: nunca prompt, resposta, argumento de ferramenta nem comando de terminal.
// A telemetria com tokens do harness Copilot depende da configuração gerenciada (TI); sem ela, o
// relatório sai sem tokens e diz isso.

import { createReadStream, existsSync, readFileSync, writeFileSync, mkdirSync, readdirSync, statSync, renameSync, openSync, closeSync, unlinkSync } from 'node:fs';
import { createInterface } from 'node:readline';
import { createHash } from 'node:crypto';
import { join, basename } from 'node:path';
import { userInfo } from 'node:os';
import { USO_DIR, HW, CHANGES, ARCHIVE, arquivosOtelDe, lerJson, gravarJson, anexarJsonl, linhasDe, config, sair, PLUGIN_PADRAO } from './lib/comum.mjs';

const OTEL_PADRAO = join(USO_DIR, 'otel', 'copilot-otel.jsonl');
const arquivosOtel = () => arquivosOtelDe(OTEL_PADRAO);
const mes = (t) => String(t).slice(0, 7);
const ORIGEM_FUNDO = /^(XtabProvider|gitCommitMessageGenerator|copilotLanguageModelWrapper\/|settingsEditorSearchSuggestions)/;
const ehFundo = (c) => ORIGEM_FUNDO.test(String(c.origem || '')) || /copilot-nes|metis|embedding/i.test(String(c.modelo || ''));

function lerTodos(sub) {
  const d = join(USO_DIR, sub);
  if (!existsSync(d)) return [];
  return readdirSync(d).filter((n) => n.endsWith('.jsonl')).sort().flatMap((n) => linhasDe(readFileSync(join(d, n), 'utf8')).filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean));
}

// ---------------------------------------------------------------- telemetria
const num = (v) => (Number.isFinite(Number(v)) ? Number(v) : 0);
function kv(a) {
  if (!a) return {};
  if (Array.isArray(a)) {
    const o = {};
    for (const x of a) {
      if (Array.isArray(x)) o[x[0]] = x[1];
      else if (x && x.key != null) { const v = x.value; o[x.key] = v && typeof v === 'object' ? (v.stringValue ?? v.intValue ?? v.doubleValue ?? v.boolValue ?? v) : v; }
    }
    return o;
  }
  return typeof a === 'object' ? a : {};
}
function tempoMs(v) {
  if (v == null) return null;
  if (Array.isArray(v) && v.length === 2) return num(v[0]) * 1000 + num(v[1]) / 1e6;
  if (typeof v === 'string' && !/^\d+$/.test(v)) { const d = Date.parse(v); return Number.isNaN(d) ? null : d; }
  const n = Number(v);
  if (!Number.isFinite(n)) return null;
  return n > 1e17 ? n / 1e6 : n > 1e14 ? n / 1e3 : n > 1e11 ? n : n * 1000;
}

// Varre qualquer forma (OTLP JSON, span achatado, logRecord do exportador) atrás de registro com uso.
function* registros(no, prof = 0) {
  if (!no || typeof no !== 'object' || prof > 8) return;
  if (Array.isArray(no)) { for (const x of no) yield* registros(x, prof + 1); return; }
  const at = kv(no.attributes);
  if (at['gen_ai.usage.input_tokens'] != null || at['gen_ai.usage.output_tokens'] != null) {
    const t = tempoMs(no.startTimeUnixNano ?? no.startTime ?? no.timeUnixNano ?? no.hrTime ?? no.timestamp ?? no.time);
    yield {
      t: t ? new Date(t).toISOString() : null,
      nome: String(no.name ?? no._body ?? at['event.name'] ?? at['gen_ai.operation.name'] ?? ''),
      conv: at['gen_ai.conversation.id'] ?? null,
      modelo: at['gen_ai.response.model'] ?? at['gen_ai.request.model'] ?? '?',
      in: num(at['gen_ai.usage.input_tokens']),
      out: num(at['gen_ai.usage.output_tokens']),
      cr: num(at['gen_ai.usage.cache_read.input_tokens'] ?? at['gen_ai.usage.cache_read_input_tokens']),
      cw: num(at['gen_ai.usage.cache_creation.input_tokens'] ?? at['gen_ai.usage.cache_creation_input_tokens']),
      rz: num(at['gen_ai.usage.reasoning.output_tokens']),
      id: at['gen_ai.response.id'] ?? null,
      trace: no.traceId ?? no.spanContext?.traceId ?? no.context?.trace_id ?? null,
      pedido: at['gen_ai.request.model'] ?? null,
      agente: at['gen_ai.agent.name'] ?? null,
      op: at['gen_ai.operation.name'] ?? null,
    };
    return;
  }
  for (const v of Object.values(no)) if (v && typeof v === 'object') yield* registros(v, prof + 1);
}

// --refazer: guarda o consumo importado (consumo.bak-<data>) e relê os arquivos OTel do começo. Serve
// depois de uma versão que passou a ler campo novo (origem, trace) ou um segundo arquivo.
async function importar({ refazer = false } = {}) {
  const arquivos = arquivosOtel().filter((a) => existsSync(a));
  if (!arquivos.length) return { novos: 0, motivo: `sem arquivo OTel (${arquivosOtel().join(' | ')})` };
  if (refazer) {
    const dir = join(USO_DIR, 'consumo');
    if (existsSync(dir)) renameSync(dir, `${dir}.bak-${new Date().toISOString().replace(/[:.]/g, '-')}`);
    for (const f of ['otel-offset.json', 'otel-vistos.json']) gravarJson(join(USO_DIR, 'cache', f), f.includes('offset') ? {} : []);
  }
  const pOff = join(USO_DIR, 'cache', 'otel-offset.json');
  const off = lerJson(pOff, {});
  const vistos = new Set(lerJson(join(USO_DIR, 'cache', 'otel-vistos.json'), []));
  // O span do chat e o log "inference.operation.details" trazem a mesma chamada: o span tem mais
  // campos (origem, trace), então ganha quando os dois chegam com o mesmo response.id.
  const porId = new Map();
  let novos = 0;
  for (const arq of arquivos) {
    const tam = statSync(arq).size;
    const inicio = off[arq] && off[arq] <= tam ? off[arq] : 0;
    const rl = createInterface({ input: createReadStream(arq, { start: inicio, encoding: 'utf8' }), crlfDelay: Infinity });
    for await (const linha of rl) {
      if (!linha.trim()) continue;
      let obj;
      try { obj = JSON.parse(linha); } catch { continue; }
      for (const r of registros(obj)) {
        // invoke_agent traz o total da sessão: só os registros por chamada (chat/eventos) contam.
        if (/invoke_agent/.test(r.nome) || r.op === 'invoke_agent') continue;
        const chave = r.id || createHash('sha1').update(`${r.t}|${r.modelo}|${r.in}|${r.out}|${r.conv}`).digest('hex').slice(0, 16);
        if (vistos.has(chave) || !r.t) continue;
        const ant = porId.get(chave);
        if (!ant || (r.agente && !ant.agente) || (r.trace && !ant.trace)) porId.set(chave, r);
      }
    }
    off[arq] = tam;
  }
  for (const [chave, r] of porId) {
    vistos.add(chave);
    anexarJsonl(join(USO_DIR, 'consumo', `${mes(r.t)}.jsonl`), { t: r.t, conv: r.conv, trace: r.trace, modelo: r.modelo, pedido: r.pedido, origem: r.agente, in: r.in, out: r.out, cr: r.cr, cw: r.cw, rz: r.rz, id: chave });
    novos++;
  }
  gravarJson(pOff, off);
  gravarJson(join(USO_DIR, 'cache', 'otel-vistos.json'), [...vistos].slice(-50000));
  return { novos, arquivos: arquivos.length };
}


// ------------------------------------------------------------------ sessões

const minutos = (ms) => ms / 60000;

// Classifica a sessão: fluxo do plugin, outros plugins, coisas do dev, ou chat solto (nada disso).
function sessoes(eventos, inativoMin = 5) {
  const s = new Map();
  for (const e of eventos) {
    if (!e.sid) continue;
    if (!s.has(e.sid)) {
      s.set(e.sid, {
        sid: e.sid, inicio: e.t, fim: e.t, tempos: [], repo: null, branch: null, ticket: null, plugin: null, traces: new Set(),
        turnos: { principal: 0, subagente: 0 }, subagentes: 0, comandos: {}, skills: {}, chamados: {}, mcp: {}, agentes: new Set(),
        categorias: {}, negacoes: {}, fluxo: false,
      });
    }
    const x = s.get(e.sid);
    if (e.t < x.inicio) x.inicio = e.t;
    if (e.t > x.fim) x.fim = e.t;
    x.tempos.push(Date.parse(e.t));
    for (const k of ['repo', 'branch', 'ticket', 'plugin']) if (e[k] && !x[k]) x[k] = e[k];
    if (e.trace) x.traces.add(e.trace);
    if (e.fluxo) x.fluxo = true;
    if (e.agente) x.agentes.add(e.agente);
    // O hook do frontmatter do agente (com --agente) repete o turno do hook global: conta só o global.
    if (e.ev === 'userPromptSubmitted' && !e.agente) x.turnos[e.turno === 'subagente' ? 'subagente' : 'principal']++;
    if (e.ev === 'subagentStart') x.subagentes++;
    const conta = (obj, k) => { if (k) obj[k] = (obj[k] || 0) + 1; };
    conta(x.comandos, e.comando);
    conta(x.skills, e.skill);
    conta(x.chamados, e.chama || e.subagente);
    conta(x.mcp, e.mcp);
    if (e.ev === 'preToolUse') conta(x.categorias, e.cat);
    if (e.decisao === 'negar') conta(x.negacoes, e.motivo || 'outro');
  }
  for (const x of s.values()) {
    const ts = x.tempos.sort((a, b) => a - b);
    let ativo = 0;
    for (let i = 1; i < ts.length; i++) { const d = ts[i] - ts[i - 1]; if (d <= inativoMin * 60000) ativo += d; }
    x.totalMin = minutos(Date.parse(x.fim) - Date.parse(x.inicio));
    x.ativoMin = minutos(ativo);
    delete x.tempos;
    x.classe = classificar(x);
  }
  return [...s.values()];
}

// Prefixo "<plugin>:" identifica o plugin de origem de comando, skill e subagente.
function classificar(x) {
  const meu = x.plugin || PLUGIN_PADRAO;
  const nomes = [...Object.keys(x.comandos).map((c) => c.slice(1)), ...Object.keys(x.chamados), ...Object.keys(x.skills)];
  const doFluxo = [...x.agentes].some((a) => /^hwk/.test(a)) || nomes.some((n) => n.startsWith(`${meu}:`)) || x.categorias.hwk || x.categorias.mapa;
  const outros = nomes.filter((n) => n.includes(':') && !n.startsWith(`${meu}:`));
  const doDev = nomes.filter((n) => !n.includes(':'));
  return { fluxo: Boolean(doFluxo), outrosPlugins: [...new Set(outros.map((n) => n.split(':')[0]))], dev: [...new Set(doDev)], mcp: Object.keys(x.mcp), solto: !doFluxo && !outros.length && !doDev.length && !Object.keys(x.mcp).length };
}

// Tokens vão para a sessão pelo trace (traceparent do hook = traceId do OTel), depois pelo id de
// conversa, por fim pela janela de tempo.
function atribuir(consumo, ss) {
  const porTrace = new Map();
  for (const s of ss) for (const t of s.traces) porTrace.set(t, s);
  const porSid = new Map(ss.map((s) => [s.sid, s]));
  const ord = [...ss].sort((a, b) => (a.inicio < b.inicio ? -1 : 1));
  for (const c of consumo) {
    let s = (c.trace && porTrace.get(c.trace)) || (c.conv && porSid.get(c.conv));
    if (!s) {
      const t = Date.parse(c.t);
      const cand = ord.filter((x) => Date.parse(x.inicio) - 60000 <= t && t <= Date.parse(x.fim) + 180000);
      s = cand[cand.length - 1];
    }
    c.sessao = s ? s.sid : null;
  }
}

function dados({ de, ate } = {}) {
  const cfg = config(process.cwd());
  const dentro = (t) => (!de || t >= de) && (!ate || t.slice(0, 10) <= ate);
  const eventos = lerTodos('eventos').filter((e) => e.t && dentro(e.t));
  const consumo = lerTodos('consumo').filter((c) => c.t && dentro(c.t) && !ehFundo(c));
  const ss = sessoes(eventos, cfg.uso.inativoMin || 5);
  atribuir(consumo, ss);
  const porSid = new Map(ss.map((s) => [s.sid, s]));
  for (const s of ss) s.tokens = { entrada: 0, saida: 0, cache: 0, porModelo: {} };
  for (const c of consumo) {
    const s = c.sessao && porSid.get(c.sessao);
    if (!s) continue;
    s.tokens.entrada += c.in || 0;
    s.tokens.saida += c.out || 0;
    s.tokens.cache += c.cr || 0;
    const m = (s.tokens.porModelo[c.modelo] ||= { entrada: 0, saida: 0, chamadas: 0 });
    m.entrada += c.in || 0; m.saida += c.out || 0; m.chamadas++;
  }
  return { eventos, consumo, ss, temTokens: consumo.length > 0 };
}

const soma = (xs, f) => xs.reduce((a, x) => a + (f(x) || 0), 0);
const fmt = (n, d = 0) => Number(n || 0).toLocaleString('pt-BR', { maximumFractionDigits: d, minimumFractionDigits: d });

// --------------------------------------------------------- replanejamentos

// Versões da spec revisadas por mudança (estado do repositório atual): cada replanejamento muda o hash.
function versoesDaSpec(raiz = process.cwd()) {
  const p = join(raiz, HW, 'estado', 'pacotes.jsonl');
  if (!existsSync(p)) return {};
  const spec = new Set(['zoom-out', 'compreensao', 'design', 'zoom-out-2', 'prontidao']);
  const porChange = {};
  for (const l of linhasDe(readFileSync(p, 'utf8')).filter(Boolean)) {
    try {
      const r = JSON.parse(l);
      if (spec.has(r.alvo)) (porChange[r.change] ||= new Set()).add(r.chave);
    } catch { /* linha ruim */ }
  }
  return Object.fromEntries(Object.entries(porChange).map(([k, v]) => [k, v.size]));
}

// ----------------------------------------------------------------- agregação

function agregar(ss, versoes = {}) {
  const grupo = (chave) => {
    const g = {};
    for (const s of ss) {
      const k = chave(s) || '(sem)';
      const a = (g[k] ||= { sessoes: 0, fluxo: 0, solto: 0, turnosPrincipal: 0, turnosSubagente: 0, totalMin: 0, ativoMin: 0, tokensEntrada: 0, tokensSaida: 0, planos: 0 });
      a.sessoes++;
      if (s.classe.fluxo) a.fluxo++;
      if (s.classe.solto) a.solto++;
      a.turnosPrincipal += s.turnos.principal;
      a.turnosSubagente += s.turnos.subagente;
      a.totalMin += s.totalMin;
      a.ativoMin += s.ativoMin;
      a.tokensEntrada += s.tokens.entrada;
      a.tokensSaida += s.tokens.saida;
      a.planos += Object.entries(s.comandos).filter(([c]) => /:plan$/.test(c)).reduce((x, [, n]) => x + n, 0);
    }
    return g;
  };
  const somaObj = (f) => { const o = {}; for (const s of ss) for (const [k, n] of Object.entries(f(s))) o[k] = (o[k] || 0) + n; return o; };
  const porModelo = {};
  for (const s of ss) for (const [m, v] of Object.entries(s.tokens.porModelo)) {
    const a = (porModelo[m] ||= { entrada: 0, saida: 0, chamadas: 0 });
    a.entrada += v.entrada; a.saida += v.saida; a.chamadas += v.chamadas;
  }
  return {
    totais: {
      sessoes: ss.length,
      sessoesFluxo: ss.filter((s) => s.classe.fluxo).length,
      sessoesOutrosPlugins: ss.filter((s) => !s.classe.fluxo && s.classe.outrosPlugins.length).length,
      sessoesDoDev: ss.filter((s) => !s.classe.fluxo && !s.classe.outrosPlugins.length && s.classe.dev.length).length,
      sessoesSoltas: ss.filter((s) => s.classe.solto).length,
      turnosPrincipal: soma(ss, (s) => s.turnos.principal),
      turnosSubagente: soma(ss, (s) => s.turnos.subagente),
      subagentesIniciados: soma(ss, (s) => s.subagentes),
      totalMin: soma(ss, (s) => s.totalMin),
      ativoMin: soma(ss, (s) => s.ativoMin),
      tokensEntrada: soma(ss, (s) => s.tokens.entrada),
      tokensSaida: soma(ss, (s) => s.tokens.saida),
      tokensCache: soma(ss, (s) => s.tokens.cache),
      negacoes: soma(ss, (s) => soma(Object.values(s.negacoes), (n) => n)),
    },
    comandos: somaObj((s) => s.comandos),
    skills: somaObj((s) => s.skills),
    agentesChamados: somaObj((s) => s.chamados),
    agentesDoFluxo: somaObj((s) => Object.fromEntries([...s.agentes].map((a) => [a, 1]))),
    mcp: somaObj((s) => s.mcp),
    ferramentas: somaObj((s) => s.categorias),
    tokensPorModelo: porModelo,
    porRepositorio: grupo((s) => s.repo),
    porBranch: grupo((s) => (s.repo ? `${s.repo} @ ${s.branch || '?'}` : s.branch)),
    porTicket: grupo((s) => s.ticket || (s.branch ? s.branch : null)),
    porDia: grupo((s) => s.inicio.slice(0, 10)),
    versoesDaSpec: versoes,
  };
}

// ----------------------------------------------------------------- comandos

function periodo(args) {
  const i = (k) => { const j = args.indexOf(k); return j >= 0 ? args[j + 1] : null; };
  const hoje = new Date().toISOString().slice(0, 10);
  const de = i('--de') || `${hoje.slice(0, 7)}-01`;
  const ate = i('--ate') || hoje;
  if (![de, ate].every((d) => /^\d{4}-\d{2}-\d{2}$/.test(d))) sair(2, 'datas no formato AAAA-MM-DD: --de 2026-11-01 --ate 2026-11-30');
  return { de, ate };
}

const linhaTab = (cols) => `| ${cols.join(' | ')} |`;
const top = (obj, n = 10) => Object.entries(obj).sort((a, b) => b[1] - a[1]).slice(0, n);

async function relatorio(args) {
  await importar().catch(() => null);
  const { de, ate } = periodo(args);
  const { ss, temTokens } = dados({ de, ate });
  const ag = agregar(ss, versoesDaSpec());
  if (args.includes('--json')) { console.log(JSON.stringify({ de, ate, temTokens, ...ag }, null, 2)); return; }
  const t = ag.totais;
  const out = [
    `# Uso e adoção · ${de} a ${ate}`,
    '',
    `Sessões: ${t.sessoes} · com o fluxo: ${t.sessoesFluxo} · outros plugins: ${t.sessoesOutrosPlugins} · agentes e comandos do dev: ${t.sessoesDoDev} · chat solto: ${t.sessoesSoltas}`,
    `Turnos: ${t.turnosPrincipal} do agente principal · ${t.turnosSubagente} de subagente (${t.subagentesIniciados} subagente(s) iniciados)`,
    `Tempo: ${fmt(t.totalMin / 60, 1)} h no total · ${fmt(t.ativoMin / 60, 1)} h ativas (pausas acima de ${config(process.cwd()).uso.inativoMin || 5} min não contam)`,
    temTokens ? `Tokens: ${fmt(t.tokensEntrada)} de entrada (${fmt(t.tokensCache)} de cache) · ${fmt(t.tokensSaida)} de saída` : 'Tokens: sem telemetria no período (no harness Copilot, depende da configuração gerenciada da TI)',
    `Guardas que negaram uma ação: ${t.negacoes}`,
    '',
    '## Por ticket ou branch',
    '',
    linhaTab(['Ticket / branch', 'Sessões', 'Com o fluxo', 'Soltas', 'Turnos (principal / sub)', 'Ativo (h)', 'Tokens (entrada / saída)', 'Planos']),
    linhaTab(['---', '---:', '---:', '---:', '---:', '---:', '---:', '---:']),
    ...top(Object.fromEntries(Object.entries(ag.porTicket).map(([k, v]) => [k, v.sessoes])), 30).map(([k]) => {
      const v = ag.porTicket[k];
      return linhaTab([k, v.sessoes, v.fluxo, v.solto, `${v.turnosPrincipal} / ${v.turnosSubagente}`, fmt(v.ativoMin / 60, 1), temTokens ? `${fmt(v.tokensEntrada)} / ${fmt(v.tokensSaida)}` : '-', v.planos]);
    }),
    '',
    '## Comandos, skills e agentes',
    '',
    ...top(ag.comandos).map(([k, n]) => `- comando ${k}: ${n}`),
    ...top(ag.skills).map(([k, n]) => `- skill ${k}: ${n}`),
    ...top(ag.agentesChamados).map(([k, n]) => `- subagente ${k}: ${n}`),
    ...top(ag.mcp).map(([k, n]) => `- MCP ${k}: ${n}`),
  ];
  if (temTokens) out.push('', '## Tokens por modelo', '', ...top(Object.fromEntries(Object.entries(ag.tokensPorModelo).map(([m, v]) => [m, v.entrada + v.saida]))).map(([m]) => `- ${m}: ${fmt(ag.tokensPorModelo[m].entrada)} de entrada, ${fmt(ag.tokensPorModelo[m].saida)} de saída, ${ag.tokensPorModelo[m].chamadas} chamada(s)`));
  const v = Object.entries(ag.versoesDaSpec);
  if (v.length) out.push('', '## Replanejamentos (repositório atual)', '', ...v.map(([c, n]) => `- ${c}: ${n} versão(ões) da spec revisada(s), ${Math.max(n - 1, 0)} replanejamento(s)`));
  console.log(out.join('\n'));
}

async function resumoMudanca(alvo) {
  await importar().catch(() => null);
  const id = String(alvo || '').replace(/^\d{4}-\d{2}-\d{2}-/, '');
  const ticket = (id.match(/^([A-Z][A-Z0-9]+-\d+)-/) || [])[1] || null;
  const { ss, temTokens } = dados();
  const daMudanca = ss.filter((s) => (ticket && s.ticket === ticket) || (s.branch && s.branch.includes(id)));
  if (!daMudanca.length) return 'Sem dados de uso coletados para esta mudança (hooks sem permissão ou sessões em outra máquina).';
  const ag = agregar(daMudanca, versoesDaSpec());
  const t = ag.totais;
  const versoes = ag.versoesDaSpec[id];
  return [
    `- Sessões: ${t.sessoes} (${t.sessoesFluxo} com o fluxo) · tempo ativo: ${fmt(t.ativoMin / 60, 1)} h de ${fmt(t.totalMin / 60, 1)} h`,
    `- Turnos: ${t.turnosPrincipal} do agente principal, ${t.turnosSubagente} de subagente`,
    temTokens ? `- Tokens: ${fmt(t.tokensEntrada)} de entrada (${fmt(t.tokensCache)} de cache), ${fmt(t.tokensSaida)} de saída` : '- Tokens: sem telemetria (configuração gerenciada da TI)',
    `- Agentes do fluxo: ${top(ag.agentesDoFluxo).map(([a, n]) => `${a} (${n})`).join(', ') || 'nenhum registrado'}`,
    `- Planos: ${soma(Object.values(ag.porTicket), (x) => x.planos)}${versoes ? ` · versões da spec revisadas: ${versoes} (${Math.max(versoes - 1, 0)} replanejamento(s))` : ''}`,
  ].join('\n');
}

async function exportar(args) {
  await importar().catch(() => null);
  const { de, ate } = periodo(args);
  const { ss, temTokens } = dados({ de, ate });
  selar();
  const selos = lerTodos('selos');
  const doc = {
    formato: 'henriworks-uso/1',
    geradoEm: new Date().toISOString(),
    dev: userInfo().username,
    de, ate, temTokens,
    selo: selos[selos.length - 1] || null,
    ...agregar(ss, versoesDaSpec()),
  };
  const p = join(USO_DIR, 'exportar', `${de}_${ate}.json`);
  gravarJson(p, doc);
  console.log(`exportado: ${p}`);
}

// ------------------------------------------------------------------ selos

// Cada dia fechado vira um hash das linhas daquele dia, encadeado com o dia anterior. O último elo vai
// junto de cada exportação: editar ou apagar um evento passado quebra a cadeia e o verificar-selos acusa.
function linhasDoDia(dia) {
  const p = join(USO_DIR, 'eventos', `${dia.slice(0, 7)}.jsonl`);
  if (!existsSync(p)) return [];
  return linhasDe(readFileSync(p, 'utf8')).filter((l) => l.startsWith(`{"t":"${dia}`));
}

function selar() {
  const trava = join(USO_DIR, 'cache', 'selar.lock');
  mkdirSync(join(USO_DIR, 'cache'), { recursive: true });
  let fd;
  try { fd = openSync(trava, 'wx'); } catch {
    try { if (Date.now() - statSync(trava).mtimeMs > 60000) unlinkSync(trava); } catch { /* outro processo */ }
    return 0;
  }
  try {
    const selos = lerTodos('selos');
    const ultimo = selos[selos.length - 1];
    const dias = [...new Set(lerTodos('eventos').map((e) => String(e.t).slice(0, 10)))].sort();
    const hoje = new Date().toISOString().slice(0, 10);
    let anterior = ultimo?.cadeia || '0'.repeat(64);
    let n = 0;
    for (const dia of dias) {
      if (dia >= hoje || (ultimo && dia <= ultimo.dia)) continue;
      const linhas = linhasDoDia(dia);
      const sha = createHash('sha256').update(linhas.join('\n')).digest('hex');
      const cadeia = createHash('sha256').update(anterior + sha).digest('hex');
      anexarJsonl(join(USO_DIR, 'selos', 'selos.jsonl'), { dia, linhas: linhas.length, sha, anterior, cadeia, em: new Date().toISOString() });
      anterior = cadeia;
      n++;
    }
    return n;
  } finally {
    closeSync(fd);
    try { unlinkSync(trava); } catch { /* já saiu */ }
  }
}

function verificarSelos() {
  const selos = lerTodos('selos');
  let anterior = '0'.repeat(64);
  const erros = [];
  for (const s of selos) {
    const sha = createHash('sha256').update(linhasDoDia(s.dia).join('\n')).digest('hex');
    if (s.anterior !== anterior) erros.push(`${s.dia}: elo anterior não confere`);
    if (sha !== s.sha) erros.push(`${s.dia}: eventos alterados depois do selo`);
    anterior = createHash('sha256').update(s.anterior + s.sha).digest('hex');
    if (anterior !== s.cadeia) erros.push(`${s.dia}: cadeia não confere`);
  }
  if (erros.length) sair(1, `selos com problema:\n- ${erros.join('\n- ')}`);
  console.log(`${selos.length} dia(s) selado(s), cadeia íntegra${selos.length ? ` até ${selos[selos.length - 1].dia}` : ''}.`);
}

// ------------------------------------------------------------------- main

const [cmd, ...args] = process.argv.slice(2);
if (cmd === 'importar') importar({ refazer: args.includes('--refazer') }).then((r) => console.log(r.motivo || `${r.novos} registro(s) novo(s) de ${r.arquivos} arquivo(s) de telemetria`));
else if (cmd === 'relatorio') await relatorio(args);
else if (cmd === 'resumo') console.log(await resumoMudanca(args[0]));
else if (cmd === 'exportar') await exportar(args);
else if (cmd === 'selar') { const n = selar(); if (n) console.log(`${n} dia(s) selado(s)`); }
else if (cmd === 'verificar-selos') verificarSelos();
else sair(2, readFileSync(new URL(import.meta.url), 'utf8').split('\n').slice(1, 17).map((l) => l.replace(/^\/\/ ?/, '')).join('\n'));
