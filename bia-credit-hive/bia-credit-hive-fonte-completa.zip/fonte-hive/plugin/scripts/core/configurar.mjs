#!/usr/bin/env node
// HenriWorks - configura verificacao.json e padroes.md a partir do que o repositório já tem.
// Sem dependência, Node LTS 22 ou 24. Base do /henriworks:configurar. Rode da raiz do repositório.
//
//   node .henriworks/bin/configurar.mjs verificacao            propõe (estado/verificacao.proposta.json) e mostra o diff
//   node .henriworks/bin/configurar.mjs verificacao --provar   roda cada comando da proposta uma vez por camada
//   node .henriworks/bin/configurar.mjs verificacao --gravar   instala a proposta, com backup do atual
//   node .henriworks/bin/configurar.mjs padroes                mapa de padrões e lista das fontes para o rascunho
//   node .henriworks/bin/configurar.mjs padroes --gravar       instala estado/padroes.proposta.md, com backup
//
// O que é fato (pastas, arquivos de configuração, dependências, se o comando roda) vem daqui. O que é
// decisão (quais regras o time audita) fica para o agente rascunhar e o dev aprovar.

import { spawnSync } from 'node:child_process';
import { readFileSync, writeFileSync, existsSync, copyFileSync, mkdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { listarPasta, testePastaLocal, problemaNode } from './lib/comum.mjs';

const BIN = dirname(fileURLToPath(import.meta.url));
const RAIZ = process.cwd();
const HW = '.henriworks';
const ESTADO = join(HW, 'estado');
const ATUAL = join(HW, 'verificacao.json');
const PROPOSTA = join(ESTADO, 'verificacao.proposta.json');
const PADROES = join(HW, 'padroes.md');
const PADROES_PROPOSTA = join(ESTADO, 'padroes.proposta.md');
const MAPA_PADROES = join(ESTADO, 'padroes-mapeados.md');

const sair = (c, m) => { (c ? console.error : console.log)(m); process.exit(c); };
const lerJson = (p) => { try { return JSON.parse(readFileSync(join(RAIZ, p), 'utf8')); } catch { return null; } };
const existe = (p) => existsSync(join(RAIZ, p));
const primeiro = (lista) => lista.find(existe) || null;
const carimbo = () => new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
const IGNORAR = /^(node_modules|dist|build|out|coverage|\.git|\.angular|\.henriworks|\.github|\.vscode|\.idea|\.husky|graphify-out|assets|public|target)$/;

{ const pn = problemaNode(); if (pn?.nivel === 'grave') sair(2, pn.texto); }
if (!existe(HW)) sair(2, `${HW}/ não existe aqui. Rode da raiz do repositório onde o HenriWorks foi instalado.`);
const ehLocal = testePastaLocal(lerJson(join(HW, 'henriworks.json')) || {});
// Código de qualquer stack que o fluxo conhece (para camadas de repositório que não é Node).
const CODIGO = /\.(ts|tsx|mts|js|jsx|mjs|cjs|java|kt|cs|py|go|scala|groovy|cbl|cob|cpy|jcl|pli|nat|rpgle|pas|bas|cls)$/i;
const ignorado = (p) => ehLocal(p) || p.split('/').slice(0, -1).some((seg) => IGNORAR.test(seg) || seg.startsWith('.'));

// Lista do repositório pelo Git: rastreados + novos dentro de pastas que já têm arquivo rastreado. Pasta de
// log ou massa de mock fora do Git não entra, e nada no disco é varrido (pasta presa, sem permissão ou com
// caminho longo no Windows não derruba). Sem Git: caminhada no disco que pula o que não consegue ler.
let LISTA;
function listaDoRepo() {
  if (LISTA !== undefined) return LISTA;
  const g = (args) => { const r = spawnSync('git', ['-c', 'core.quotePath=false', ...args], { cwd: RAIZ, encoding: 'utf8', maxBuffer: 1 << 28 }); return r.status === 0 ? r.stdout.split('\0').filter(Boolean) : null; };
  const rastreados = g(['ls-files', '-z']);
  if (!rastreados) { LISTA = null; return LISTA; }
  const topos = [...new Set(rastreados.filter((p) => p.includes('/')).map((p) => p.split('/')[0]))].filter((t) => !ehLocal(t));
  const novos = topos.length ? g(['ls-files', '-z', '--others', '--exclude-standard', '--', ...topos]) || [] : [];
  LISTA = [...new Set([...rastreados, ...novos])].filter((p) => existsSync(join(RAIZ, p)));
  return LISTA;
}

function arquivosDe(dir, re, max = 5000, { disco = false } = {}) {
  const lista = disco ? null : listaDoRepo();
  if (lista) {
    const pre = dir ? `${dir.replace(/\/$/, '')}/` : '';
    return lista.filter((p) => p.startsWith(pre) && !ignorado(p) && re.test(p.split('/').pop())).slice(0, max);
  }
  const out = [];
  const andar = (d) => {
    if (out.length >= max) return;
    for (const e of listarPasta(join(RAIZ, d))) {
      const p = d ? `${d}/${e.name}` : e.name;
      if (e.isDirectory()) { if (!IGNORAR.test(e.name) && !ehLocal(p)) andar(p); } else if (e.isFile() && re.test(e.name)) out.push(p);
    }
  };
  if (existe(dir)) andar(dir);
  return out;
}

// Camadas por pasta: os arquivos de código agrupados pelo primeiro nível abaixo de "base".
function camadasPorPasta(base, re, { pular = () => false } = {}) {
  const pre = base ? `${base}/` : '';
  const grupos = new Map();
  for (const a of arquivosDe(base, re, 1e6)) {
    const resto = a.slice(pre.length);
    if (!resto.includes('/')) continue;
    const n = resto.split('/')[0];
    if (IGNORAR.test(n) || n.startsWith('.') || pular(n)) continue;
    if (!grupos.has(n)) grupos.set(n, []);
    grupos.get(n).push(a);
  }
  return [...grupos.keys()].sort().map((n) => ({ nome: n, glob: `${pre}${n}/**`, arquivos: grupos.get(n).length, specs: grupos.get(n).filter((a) => /\.(spec|test)\.|Test\.|Tests\.|_test\./.test(a)).length }));
}

// ------------------------------------------------------------------ detecção

// Repositório que não é Node na raiz (Java, .NET, legado, monolito com o front numa subpasta): camadas por
// pasta e nenhum comando proposto. Comando que o script não prova não entra na proposta.
function detectarSemNode() {
  const camadas = camadasPorPasta('', CODIGO);
  const notas = [];
  const lista = listaDoRepo() || [];
  const subPkgs = lista.filter((p) => /(^|\/)package\.json$/.test(p) && p.includes('/') && !ignorado(p)).map((p) => p.replace(/\/package\.json$/, ''));
  if (subPkgs.length) notas.push(`projeto Node em ${subPkgs.slice(0, 5).map((d) => `${d}/`).join(', ')}${subPkgs.length > 5 ? ` e mais ${subPkgs.length - 5}` : ''}: a verificação roda da raiz do repositório e ainda não sabe entrar na pasta do front, então lint, tipos e testes dele ficam fora da proposta.`);
  const java = ['pom.xml', 'build.gradle', 'build.gradle.kts'].filter(existe);
  if (java.length) notas.push(`${java.join(' e ')} na raiz: sem comando proposto para Java. A fatia é conferida pelos comandos do time (executor da stack) e pela revisão.`);
  return { tipo: 'sem-node', deps: {}, tsconfig: null, eslintCfg: null, temEslint: false, templateLint: false, jestCfg: null, runner: null, app: null, camadas, fora: [], notas, temTs: false };
}

function detectar() {
  const pkg = lerJson('package.json');
  if (!pkg) return detectarSemNode();
  const deps = { ...(pkg.dependencies || {}), ...(pkg.devDependencies || {}) };
  const notas = [];

  // tsconfig do app: o que o angular.json usa no build; senão os nomes de costume.
  const tsCandidatos = [];
  const ang = lerJson('angular.json');
  for (const proj of Object.values(ang?.projects || {})) {
    for (const [alvo, t] of Object.entries(proj.architect || {})) {
      if (/test|lint/i.test(alvo)) continue;
      const tc = t?.options?.tsConfig;
      if (tc && !tsCandidatos.includes(tc)) tsCandidatos.push(tc);
    }
  }
  const tsconfig = primeiro([...tsCandidatos, 'tsconfig.app.json', 'tsconfig.build.json', 'tsconfig.json']);

  const eslintCfg = primeiro(['eslint.config.js', 'eslint.config.mjs', 'eslint.config.cjs', 'eslint.config.ts', '.eslintrc.json', '.eslintrc.js', '.eslintrc.cjs', '.eslintrc.yml', '.eslintrc']);
  const temEslint = Boolean(deps.eslint || eslintCfg);
  if (eslintCfg && /^\.eslintrc/.test(eslintCfg) && /^[\^~]?9/.test(deps.eslint || '')) notas.push(`ESLint 9 com ${eslintCfg} (formato antigo): o comando pode precisar de ESLINT_USE_FLAT_CONFIG=false.`);
  const templateLint = Boolean(deps['angular-eslint'] || deps['@angular-eslint/eslint-plugin-template']);

  const jestCfg = primeiro(['jest.config.js', 'jest.config.ts', 'jest.config.mjs', 'jest.config.cjs', 'jest.config.json']) || (pkg.jest ? 'package.json ("jest")' : null);
  const runner = deps.jest || jestCfg ? 'jest' : deps.vitest ? 'vitest' : deps.karma ? 'karma' : null;

  // Raiz do código: src/app (Angular), senão o sourceRoot do angular.json, senão src.
  const sourceRoot = Object.values(ang?.projects || {}).map((p) => p.sourceRoot).find(Boolean);
  const app = primeiro(['src/app', sourceRoot && `${sourceRoot}/app`, sourceRoot, 'src'].filter(Boolean));
  const codigo = /\.(ts|tsx|js|mjs)$/;
  const doTopo = (a) => !a.includes('/');
  const camadas = [];
  if (app) {
    camadas.push(...camadasPorPasta(app, codigo, { pular: (n) => /^environments?$/.test(n) }));
    const soltos = arquivosDe(app, codigo, 1e6).filter((a) => doTopo(a.slice(app.length + 1)));
    if (soltos.length) camadas.push({ nome: 'app', glob: `${app}/*`, arquivos: soltos.length, specs: soltos.filter((a) => /\.(spec|test)\./.test(a)).length });
    if (app !== 'src' && existe('src')) {
      const raizSrc = arquivosDe('src', /\.ts$/, 1e6).filter((a) => doTopo(a.slice(4)));
      if (raizSrc.length) camadas.push({ nome: 'bootstrap', glob: 'src/*.ts', arquivos: raizSrc.length, specs: raizSrc.filter((a) => /\.spec\./.test(a)).length });
    }
  } else camadas.push(...camadasPorPasta('', codigo));

  // Código fora das camadas: decisão do dev (mock, script, config). Pasta local (log, massa) não aparece.
  const fora = app ? camadasPorPasta('', codigo, { pular: (n) => n === 'src' }).map((c) => ({ pasta: c.nome, arquivos: c.arquivos, specs: c.specs })) : [];
  if (!app) notas.push('sem src/ nem sourceRoot no angular.json: uma camada por pasta da raiz com código. Diga ao agente se o código do produto está em outra pasta.');
  return { tipo: 'node', deps, tsconfig, eslintCfg, temEslint, templateLint, jestCfg, runner, app, camadas, fora, notas, temTs: Boolean(deps.typescript) };
}

function montar(d) {
  const verificacoes = {};
  if (d.temEslint) {
    verificacoes.lint = {
      comando: 'npx eslint -f json {arquivos}',
      comandoBase: 'npx eslint -f json --stdin --stdin-filename {arquivo}',
      extensoes: d.templateLint ? ['.ts', '.html'] : ['.ts'],
      formato: 'eslint-json',
      classificacao: 'base-stdin',
    };
  }
  if (d.temTs && d.tsconfig) {
    verificacoes.tipos = {
      comando: `npx tsc --noEmit --pretty false -p ${d.tsconfig}`,
      formato: 'linhas',
      padrao: '^(?<arquivo>[^\\s(][^(]*)\\((?<linha>\\d+),\\d+\\): error (?<mensagem>.+)$',
      regra: 'tsc',
      classificacao: 'baseline',
    };
  }
  if (d.runner === 'jest') {
    verificacoes.testes = {
      comando: 'npx jest --ci --passWithNoTests --json --outputFile={saida} --findRelatedTests {arquivos}',
      comandoBaseline: 'npx jest --ci --passWithNoTests --json --outputFile={saida} {raizes}',
      extensoes: ['.ts'],
      formato: 'jest-json',
      classificacao: 'baseline',
    };
  } else if (d.runner === 'vitest') {
    verificacoes.testes = {
      comando: 'npx vitest related --run --passWithNoTests --reporter=json --outputFile={saida} {arquivos}',
      comandoBaseline: 'npx vitest run --passWithNoTests --reporter=json --outputFile={saida} {raizes}',
      extensoes: ['.ts'],
      formato: 'jest-json',
      classificacao: 'baseline',
    };
  }
  const camadas = {};
  for (const c of d.camadas) {
    // testes em toda camada: --findRelatedTests acha o spec de outra pasta que importa o arquivo.
    const v = ['lint', 'tipos', 'testes'].filter((x) => verificacoes[x]);
    camadas[c.nome] = { arquivos: [c.glob], verificacoes: v };
  }
  return { verificacoes, camadas };
}

// Mesmo estilo do molde: lista de valores numa linha, uma camada por linha. Diff curto.
function formatar(p) {
  return JSON.stringify(p, null, 2)
    .replace(/\[\n\s*([^\[\]{}]*?)\n\s*\]/g, (_, i) => `[${i.split(/,\n\s*/).join(', ')}]`)
    .replace(/\{\n\s*("arquivos": \[[^\]]*\]),\n\s*("verificacoes": \[[^\]]*\])\n\s*\}/g, '{ $1, $2 }');
}

// ------------------------------------------------------------------ comandos

function cmdVerificacao(op) {
  if (op.gravar) {
    if (!existe(PROPOSTA)) sair(2, `sem proposta: rode antes node .henriworks/bin/configurar.mjs verificacao`);
    mkdirSync(join(RAIZ, ESTADO), { recursive: true });
    const bak = join(ESTADO, `verificacao.json.bak-${carimbo()}`);
    if (existe(ATUAL)) copyFileSync(join(RAIZ, ATUAL), join(RAIZ, bak));
    copyFileSync(join(RAIZ, PROPOSTA), join(RAIZ, ATUAL));
    sair(0, `gravado: ${ATUAL}${existe(bak) ? ` (anterior em ${bak})` : ''}. A primeira mudança usa esta configuração.`);
  }
  if (op.provar) {
    const alvo = existe(PROPOSTA) && !op.atual ? PROPOSTA : ATUAL;
    console.log(`provando ${alvo} (pode levar alguns minutos: tsc e testes rodam de verdade)\n`);
    const r = spawnSync(process.execPath, [join(BIN, 'verificar.mjs'), 'provar', '--config', alvo], { cwd: RAIZ, stdio: 'inherit' });
    process.exit(r.status ?? 1);
  }
  const d = detectar();
  const prop = montar(d);
  mkdirSync(join(RAIZ, ESTADO), { recursive: true });
  writeFileSync(join(RAIZ, PROPOSTA), `${formatar(prop)}\n`);

  console.log('O que o repositório tem:');
  console.log(`  código        ${d.app ? `${d.app}/` : d.tipo === 'sem-node' ? 'sem package.json na raiz (não é projeto Node)' : 'pastas da raiz'}`);
  console.log(`  tsconfig      ${d.tsconfig || 'NÃO ACHEI (sem verificação de tipos)'}`);
  console.log(`  eslint        ${d.eslintCfg || (d.temEslint ? 'no package.json, sem arquivo de config' : 'NÃO ACHEI (sem lint)')}${d.templateLint ? ', com regras de template (.html)' : ''}`);
  console.log(`  testes        ${d.runner ? `${d.runner}${d.jestCfg ? ` (${d.jestCfg})` : ''}` : 'NÃO ACHEI'}${d.runner === 'karma' ? ': Karma não roda por arquivo, fica fora da verificação' : ''}${d.runner === 'vitest' ? ' (experimental)' : ''}`);
  console.log('\nCamadas propostas (uma por pasta de código):');
  for (const c of d.camadas) console.log(`  ${c.nome.padEnd(14)} ${c.glob.padEnd(28)} ${String(c.arquivos).padStart(4)} arquivo(s), ${c.specs} spec(s)`);
  if (d.fora.length) {
    console.log('\nCódigo fora das camadas (não entra na verificação; diga se alguma pasta deve entrar):');
    for (const f of d.fora) console.log(`  ${f.pasta.padEnd(14)} ${String(f.arquivos).padStart(4)} arquivo(s), ${f.specs} spec(s)`);
  }
  if (!d.camadas.length) console.log('  (nenhuma pasta com código reconhecido: diga ao agente onde está o código)');
  for (const n of d.notas) console.log(`\nATENÇÃO ${n}`);
  if (!Object.keys(prop.verificacoes).length) console.log('\nSem verificação automática nesta proposta: nenhum lint, checagem de tipos ou teste que o script saiba rodar por arquivo. A fatia é conferida pelos comandos do time (executor da stack) e pela revisão. Gravar assim mesmo tira o molde de MFE Angular, que tentaria rodar npx eslint e tsc aqui.');
  console.log(`\nProposta: ${PROPOSTA}`);
  const diff = spawnSync('git', ['diff', '--no-index', '--no-color', '--', ATUAL, PROPOSTA], { cwd: RAIZ, encoding: 'utf8' });
  const texto = (diff.stdout || '').split('\n').filter((l) => !/^(diff --git|index |--- |\+\+\+ )/.test(l)).join('\n').trim();
  console.log(texto ? `\nDiferença para o verificacao.json atual:\n${texto}` : '\nIgual ao verificacao.json atual.');
  console.log('\nPróximo: node .henriworks/bin/configurar.mjs verificacao --provar');
}

const FONTES_PADROES = ['eslint.config.js', 'eslint.config.mjs', 'eslint.config.cjs', '.eslintrc.json', '.eslintrc.js', 'CONTRIBUTING.md', '.github/copilot-instructions.md', 'docs/padroes.md', 'docs/arquitetura.md'];

function cmdPadroes(op) {
  if (op.gravar) {
    if (!existe(PADROES_PROPOSTA)) sair(2, `sem rascunho em ${PADROES_PROPOSTA}`);
    const bak = join(ESTADO, `padroes.md.bak-${carimbo()}`);
    if (existe(PADROES)) copyFileSync(join(RAIZ, PADROES), join(RAIZ, bak));
    copyFileSync(join(RAIZ, PADROES_PROPOSTA), join(RAIZ, PADROES));
    sair(0, `gravado: ${PADROES}${existe(bak) ? ` (anterior em ${bak})` : ''}. A lente de padrões da revisão passa a usar estas regras, só nas linhas alteradas.`);
  }
  mkdirSync(join(RAIZ, ESTADO), { recursive: true });
  const fontes = [];
  if (existe('src/app')) {
    const r = spawnSync(process.execPath, [join(BIN, 'mapear-padroes.mjs'), RAIZ, '--saida', join(RAIZ, MAPA_PADROES)], { cwd: RAIZ, encoding: 'utf8' });
    if (r.status === 0) fontes.push(`${MAPA_PADROES}: quantos arquivos usam cada jeito, por camada (base para decidir o padrão alvo)`);
    else console.log(`ATENÇÃO mapa de padrões falhou: ${(r.stderr || r.stdout).trim().split('\n')[0]}`);
  }
  for (const f of FONTES_PADROES) if (existe(f)) fontes.push(`${f}: regra que o time já escreveu`);
  for (const f of arquivosDe('.github/instructions', /\.instructions\.md$/, 5000, { disco: true })) fontes.push(`${f}: instrução por área`);
  for (const f of arquivosDe('src', /\.md$/).slice(0, 30)) fontes.push(`${f}: guia de pasta escrito pelo time`);
  const atual = existe(PADROES) ? readFileSync(join(RAIZ, PADROES), 'utf8') : '';
  console.log(`padroes.md hoje: ${!atual ? 'não existe' : atual.includes('Apague os exemplos abaixo') ? 'molde do pacote (exemplos genéricos)' : 'já editado pelo time'}`);
  console.log(`\nFontes para o rascunho (leia só estas):\n${fontes.map((f) => `  - ${f}`).join('\n') || '  (nenhuma: o rascunho sai só do mapa e das perguntas ao dev)'}`);
  console.log(`\nRascunho vai em: ${PADROES_PROPOSTA}`);
  console.log('Critérios do rascunho: os do /henriworks:configurar (regra verificável num diff, que o lint ainda não pega, sem [grave] sem o dev decidir).');
  console.log(`Depois de aprovado: node .henriworks/bin/configurar.mjs padroes --gravar`);
}

const [cmd, ...resto] = process.argv.slice(2);
const op = { gravar: resto.includes('--gravar'), provar: resto.includes('--provar'), atual: resto.includes('--atual') };
if (cmd === 'verificacao') cmdVerificacao(op);
else if (cmd === 'padroes') cmdPadroes(op);
else sair(2, readFileSync(fileURLToPath(import.meta.url), 'utf8').split('\n').slice(1, 11).map((l) => l.replace(/^\/\/ ?/, '')).join('\n'));
