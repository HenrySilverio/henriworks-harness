# HenriWorks

Harness de engenharia para o GitHub Copilot no VS Code: leva uma demanda do briefing ao registro de
conhecimento, com spec revisada por um revisor sem contexto, implementação em fatias verticais, revisão de
código em três eixos, OK do QA antes de fechar e relatório de uso só com contagens e tokens.

O plugin traz agentes, skills (comandos), hooks e um núcleo de scripts em Node. Nada vai para o Git do
produto além de `conhecimento/`: o registro de cada entrega e as lições aprovadas pelo time.

## Onde usar

O melhor uso hoje é no **VS Code**, com o chat no harness Copilot, ou no **GitHub Copilot app**. O harness Local
não é suportado (nele o revisor recebe ferramentas que não deveria, e o canário reprova), e as outras
superfícies, como o Copilot CLI, ainda não foram validadas com o fluxo.

## Requisitos

- VS Code com o GitHub Copilot (chat no harness Copilot) ou o GitHub Copilot app.
- Node LTS atual (22 ou 24) no PATH do VS Code. Quem não tem pede a instalação pelo catálogo de software; depois, feche e abra o VS Code.
- Repositório Git aberto pela raiz.

## Como usar

### 1. Preparar o repositório (uma vez por repositório, e depois de cada atualização do plugin)

Num chat novo, selecione o agente **hwk** e envie:

```
/henriworks:init
```

Ele copia o núcleo para `.henriworks/bin/`, cria os arquivos do time que faltam, põe `.henriworks/` no
`.git/info/exclude`, constrói o mapa do código e roda o canário (a prova de que o revisor não recebe a
conversa). Pode rodar de novo quando quiser.

### 2. O fluxo

Uma fase por chat. Cada fase tem o seu agente; o comando só funciona com o agente certo selecionado.
Na dúvida, `/henriworks:start <o que você quer fazer>` diz o próximo passo.

| Fase | Agente | Comando |
| --- | --- | --- |
| Entender a dor ou o ticket | `hwk-discovery` | `/henriworks:grill <a necessidade>` ou `/henriworks:triagem <ticket>` |
| Decidir vendo funcionar | `hwk-prototipo` | `/henriworks:prototipo <a pergunta>` |
| Planejar | `hwk-plan` | `/henriworks:plan <caminho do briefing.md>` |
| Revisar a spec | `hwk-review` | `/henriworks:review spec <change-id>` |
| Aprovar a spec | você, no terminal | `node .henriworks/bin/hwk.mjs aprovar-spec <change-id> --por "<seu nome>"` |
| Implementar (uma fatia por sessão) | `hwk-implement` | `/henriworks:implement <change-id>` |
| Revisar o código | `hwk-review` | `/henriworks:review <change-id>` |
| Arquivar e escrever a descrição da PR | `hwk-archive` | `/henriworks:archive <change-id>` |
| OK de quem testou | QA ou você, no terminal | `node .henriworks/bin/hwk.mjs qa-ok <pasta arquivada> --por "<nome>" --ambiente "<ambiente>" --resultado "<o que passou>"` |
| Registro de conhecimento | `hwk-archive` | `/henriworks:fechar <pasta arquivada> <número da PR>` |

Comandos de terminal funcionam no Git Bash. Os agentes nunca rodam os portões humanos (aprovar a spec,
aceitar revisão reprovada, liberar rodada extra, OK do QA, descartar): o hook nega.

### 3. Se o QA achar erro depois do archive

Não reabra a mudança arquivada. Abra uma mudança nova e pequena na mesma branch e na mesma PR
(`/henriworks:start` com o erro), siga o fluxo dela, e quando o teste passar o `qa-ok` cobre as duas pastas
arquivadas de uma vez. Depois, `/henriworks:fechar` em cada uma.

### 4. Agentes de outros plugins

Se a sua máquina tem agentes de outras iniciativas (Java, Liberty, observabilidade, Angular, React, Swift…),
o plano lista os que encontrar, propõe um executor por fatia pela stack e só usa com o seu sim. Sem
confirmação, a fatia fica com o executor padrão do fluxo. Os portões (arquivos permitidos, verificação e
revisão isolada) continuam do fluxo para qualquer executor. `node .henriworks/bin/hwk.mjs executores` mostra
os registrados e os descobertos.

### Personalização que você já tem (AGENTS.md, `.github/`)

O fluxo convive com o que já existe no repositório e na sua máquina: `AGENTS.md`, `.github/instructions/`,
`.github/copilot-instructions.md`, agentes, skills, prompts e hooks seus. Nada disso é exigido, nada disso é
criado ou editado pelo plugin, e nada disso trava o fluxo:

- arquivo não versionado em `.github/`, `.vscode/` e qualquer `AGENTS.md`/`CLAUDE.md` não versionado nunca
  conta como "alteração não commitada" (`node .henriworks/bin/hwk.mjs arvore` mostra o que conta);
- em processo (fases, portões, Git, onde escrever, idioma dos artefatos) o fluxo vence; no jeito de escrever o
  código, valem as suas instruções;
- na revisão de padrões, só bloqueia regra declarada do time: `.henriworks/padroes.md` ou os arquivos listados
  em `"instrucoes": { "doTime": [".github/instructions/time-*.instructions.md"] }` no
  `.henriworks/henriworks.json`. O resto pode ser preferência sua e vira no máximo `[importante]`.

### Auditoria do seu harness

No agente `hwk`, `/henriworks:squad-audit` lê a sua personalização (repositório, `~/.copilot/` e plugins
instalados), estima o custo fixo em tokens por pedido e aponta verbosidade, ambiguidade, conflitos entre
arquivos, o que falta para um resultado melhor e riscos (hooks, agentes, executores). Grava o relatório em
`.henriworks/estado/auditoria/<data>/relatorio.md` com o texto `Antes`/`Depois` de cada sugestão. Só lê:
quem aplica é você.

### Preparar um agente seu para executar fatias (ex.: codificador Java)

`node .henriworks/bin/hwk.mjs executores conferir` diz se cada agente está pronto. O que ele precisa:

1. Estar onde o harness Copilot enxerga: num plugin, em `~/.copilot/agents/` ou em `.github/agents/` do
   repositório. A pasta de prompts do perfil do VS Code só serve ao harness Local.
2. Poder ser chamado como subagente: `disable-model-invocation: false` (ou sem a chave).
3. `description` dizendo a stack e a camada, por exemplo `"Implementa BFF em Java 21 / Spring Boot com testes JUnit"`:
   é por ela que o plano propõe o agente para a fatia.
4. Ferramentas de leitura, edição e terminal (`tools: ["read", "search", "edit", "execute"]`).
5. Sem `agents`, `handoffs` ou `argument-hint` no frontmatter (o harness Copilot recusa).
6. No corpo, o bloco abaixo, para que as regras dele não passem na frente da fatia:

```markdown
## When called with a slice file
If the message points to a slice file (`.henriworks/changes/<id>/tarefas/NN-*.md`), read it and only the
files in its `## Ponteiros`. Change only the paths in `Toca:`. Run the tests of what you changed. Do not
commit, push or create branches, and do not edit anything in `.henriworks/`. End with: files changed;
whether the `Demonstra:` behavior happens; what you could not do or verify.
```

Para o time inteiro receber a proposta do mesmo agente, registre-o em `.henriworks/executores.json`.

### Lições de uso: o que o time aprende fica

O que o uso ensina (o achado de revisão que se repete, o defeito que o QA pegou, a causa de um replanejamento,
a correção que você fez no agente) vira uma **lição**, nunca sozinho:

1. **Proposta.** No `/henriworks:fechar` o agente lê os sinais da mudança e propõe até três lições; a qualquer
   momento, `/henriworks:lembrar <o que lembrar>` propõe uma.
2. **Aprovação humana**, no terminal: `node .henriworks/bin/hwk.mjs licoes aprovar P-1 --por "<nome>"`. O agente
   não consegue rodar.
3. **Versionada** em `conhecimento/licoes/`, um arquivo por lição, com tipo, escopo (pastas), origem, quem aprovou
   e data de revisão. Entra na PR como o registro de conhecimento.
4. **Lida só onde vale:** o plano e o executor consultam `licoes para <pastas da tarefa>`, com teto de tokens; na
   revisão de padrões, a lição do tipo regra é regra do time.
5. **Revisada:** `licoes revisar` e o `/henriworks:squad-audit` mostram lição vencida ou de pasta que não existe mais.

Preferência pessoal não é lição: fica nas suas instruções ou no Copilot Memory.

### Legado: COBOL, mainframe e outros

O fluxo não depende da linguagem. Em COBOL, JCL, PL/I, Natural, RPG, Delphi ou VB, o mapa do projeto não lê os
arquivos, então:

- as fatias dessas stacks vão para o agente que o time já usa para elas (prepare-o como na seção acima e confira
  com `node .henriworks/bin/hwk.mjs executores conferir`);
- a verificação roda os comandos do time (compilação e teste, inclusive remotos) configurados no `verificacao.json`;
- o init avisa quantos arquivos de legado o mapa não cobre e, quando eles são maioria, desliga o "mapa antes de
  busca" naquele repositório.

O código precisa estar num repositório Git aberto no VS Code ou no Copilot app.

### Utilitários (qualquer agente com terminal)

| Comando | Para quê |
| --- | --- |
| `/henriworks:mapa <termos>` | onde fica, quem chama, o que quebra |
| `/henriworks:configurar` | ajusta `verificacao.json` e `padroes.md` ao repositório |
| `/henriworks:uso` | relatório de uso e adoção |
| `/henriworks:ticket` | mostra ou fixa o ticket do Jira da sessão |
| `/henriworks:canario` | repete a prova de isolamento do revisor |
| `/henriworks:adotar` | copia specs e decisões do `.sdd/` do HenriSpec |
| `/henriworks:squad-audit` (agente `hwk`) | qualidade e custo da sua personalização do Copilot |
| `/henriworks:lembrar <a lição>` | propõe uma lição de uso para o time aprovar |

## Uso e privacidade

Os hooks do plugin rodam em todo chat do harness Copilot, com ou sem o fluxo no repositório, e gravam em
`~/.henriworks/uso/` (fora de qualquer repositório):

- sessão, turnos do agente principal e de subagentes, tempo total e ativo;
- nome de comando, skill, agente, subagente e ferramenta, e se é do plugin, de outro plugin, do dev ou chat
  solto;
- repositório, branch e ticket (pelo nome da branch), inclusive `main`;
- versões da spec revisadas por mudança (replanejamentos);
- tokens por sessão, só quando a telemetria do Agent Host estiver ligada pela TI.

Nunca grava prompt, resposta, código, argumento de ferramenta nem comando de terminal. Nenhum valor em
dinheiro, crédito ou preço de modelo. Os dias fechados são selados numa cadeia de hash
(`uso.mjs verificar-selos` acusa evento alterado). `uso.mjs exportar` gera o JSON agregado do período; o
envio para outro sistema ainda não existe.

Para tirar um repositório do relatório: `"uso": { "coletar": false }` em `.henriworks/henriworks.json`.

## Atualizar e remover

- Atualizou o plugin: rode `/henriworks:init` em cada repositório (o chat avisa quando o núcleo copiado
  está atrás da versão instalada).
- Remover de um repositório: apague `.henriworks/` e o bloco `# >>> henriworks` do `.git/info/exclude`.
  O que já foi commitado em `conhecimento/` fica.

## Estrutura do plugin

| Pasta | Conteúdo |
| --- | --- |
| `com.github.copilot/agents/` | os 9 agentes (`hwk-gf` e `hwk-implementador` só como subagentes) |
| `com.github.copilot/hooks/hooks.json` | 6 eventos, todos para `scripts/core/hook.mjs` |
| `skills/` | os 18 comandos; `init` traz o script de preparação, os moldes do time e as referências do fluxo |
| `scripts/core/` | o núcleo determinístico, copiado para `.henriworks/bin/` pelo init |
| `testes/smoke.mjs` | teste de fumaça: `node testes/smoke.mjs` (sem rede, numa pasta temporária) |

Instruções para os agentes estão em inglês; artefatos, respostas e esta documentação, em português.
