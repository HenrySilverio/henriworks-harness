---
name: mapa
description: "Queries the project map before sweeping files: what exists, where it is, who calls it, what breaks."
argument-hint: "<query \"terms\" | explain <symbol> | affected <files> | path <A> <B> | resumo | status>"
disable-model-invocation: true
---
# /henriworks:mapa

Utility: runs in any agent with a terminal.

Run `node .henriworks/bin/henrimap.mjs` with the received argument. With no recognized subcommand, use
`query` with the whole text. Show the output without summarizing. Read `.henriworks/referencias/mapa.md` to
interpret EXTRACTED, INFERRED and AMBÍGUO.
