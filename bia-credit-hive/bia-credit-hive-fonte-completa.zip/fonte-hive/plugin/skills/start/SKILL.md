---
name: start
description: "Use when the developer, in a repository with a .henriworks/ folder, wants to start work on a feature, bug or Jira ticket, or asks what the next step of a HenriWorks change is. Says the route and the exact message for the next chat, then stops."
argument-hint: "<what you want to do, in one sentence>"
disable-model-invocation: false
---
# /henriworks:start

Say what the next step is and stop. Do not interview, plan or edit anything. Reply in Brazilian Portuguese.

Needs a terminal. With no terminal tool in this agent, answer in one line: select the `hwk` agent and send
`/henriworks:start` with the same request.

## Step 1 - State

Run `node .henriworks/bin/hwk.mjs estado`. With no `.henriworks/` folder: say HenriWorks is not prepared in
this repository and the way is the `hwk` agent with `/henriworks:init`; stop.

## Step 2 - Route

Apply the first that matches, in order:

1. Output with a `HENRISPEC` line: the branch has an open HenriSpec change. Point to the `henrispec-*` agent
   of its phase and stop. One branch, one harness.
2. An open change on this branch: say the phase, the next phase's agent and the exact message to send in a
   new chat (the `estado` output already gives the command). In phase `revisao-spec` with "humano: hwk
   aprovar-spec", show `node .henriworks/bin/hwk.mjs aprovar-spec <id> --por "<seu nome>"` and say that
   decision is the developer's.
3. An archived change with no knowledge record: it waits for the QA sign-off
   (`node .henriworks/bin/hwk.mjs qa-ok <folder> --por ... --ambiente ... --resultado ...`, run by whoever
   tested), then agent `hwk-archive`, `/henriworks:fechar <folder> <PR number>`. A defect found by QA: a new
   small change on the same branch, through discovery or straight to the plan with a short briefing.
4. No change: choose from the developer's message.

| Situation | Next |
| --- | --- |
| small request: broken test, text, configuration, a fix in a few files | none: do it in the normal chat, without the flow |
| pain or idea, nothing written | agent `hwk-discovery`, `/henriworks:grill <the need>` |
| ticket, incident or bug already written | agent `hwk-discovery`, `/henriworks:triagem <ticket>` |
| a decision that can only be made by seeing it work | agent `hwk-prototipo`, `/henriworks:prototipo <question>` |
| briefing ready in `.henriworks/briefings/` | `node .henriworks/bin/hwk.mjs briefing <path>`; with no error, agent `hwk-plan`, `/henriworks:plan <path>`; with a pending input, the developer provides it first |

If the message is not enough to choose, ask one question and stop.

5. With no `.henriworks/estado/init.json`, or with the canary not checked, add one line: before the first
   review, agent `hwk`, `/henriworks:init`.

## Output

Up to eight lines: where the branch is, the next agent, the message for the new chat, and the why in one
sentence. Do not open the next agent and do not do its work.
