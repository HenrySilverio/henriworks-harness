---
name: review
description: "Shortcut for /henriworks:review. The phase runs in the hwk-review agent."
argument-hint: "<spec | (nothing) | estrito> <change-id>"
disable-model-invocation: true
---
# /henriworks:review

This phase runs in the `hwk-review` agent, which sets its tools and steps.

If the instructions of this chat start with `# Agent hwk-review`, follow them with the text that came after the
command and ignore the rest of this file.

Otherwise, do not read or run anything. Answer in one line, in Brazilian Portuguese: select the `hwk-review` agent
in the agent picker, in a new chat, and send the same request. Running the phase
outside its agent skips the contract and grants tools it should not have.
