---
name: implement
description: "Shortcut for /henriworks:implement. The phase runs in the hwk-implement agent."
argument-hint: "<change-id> [N fatias | paralelo]"
disable-model-invocation: true
---
# /henriworks:implement

This phase runs in the `hwk-implement` agent, which sets its tools and steps.

If the instructions of this chat start with `# Agent hwk-implement`, follow them with the text that came after the
command and ignore the rest of this file.

Otherwise, do not read or run anything. Answer in one line, in Brazilian Portuguese: select the `hwk-implement` agent
in the agent picker, in a new chat, and send the same request. Running the phase
outside its agent skips the contract and grants tools it should not have.
