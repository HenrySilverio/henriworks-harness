# Executors

<!-- Copied from the plugin by /henriworks:init. Do not edit: the next init overwrites it. -->

Reference for the plan and implement phases. Read it when a slice may go to an executor other than
`hwk-implementador`.

## Two sources

- **Registered** (`.henriworks/executores.json`): what the team standardized. Including an agent is
  editing that JSON; no prompt changes.
- **Discovered** (`.henriworks/estado/executores-descobertos.json`): agents of other plugins or of the
  developer that are installed on this machine (Java, Liberty, observability, Angular, React, Swift...).
  Written by `hwk executores registrar`, never by hand.

`node .henriworks/bin/hwk.mjs executores` lists both, with the stacks inferred from each description.

## What an agent needs to execute slices

`node .henriworks/bin/hwk.mjs executores conferir [name]` checks it. Requirements:

1. **Visible in the Copilot harness**: installed by a plugin (called `<plugin>:<agent>`), in
   `~/.copilot/agents/`, or in the repository's `.github/agents/` (untracked is fine). Not in the VS Code
   profile prompts folder: that one only serves the Local harness.
2. **Callable as a subagent**: `disable-model-invocation` absent or `false`. With `true` the delegation fails
   with "Unknown agent_type".
3. **A `description` that names the stack and layer** (e.g. "Java 21 / Spring Boot BFF"): the plan matches
   executors to slices by it.
4. **Tools to implement**: read and search, edit, and a terminal to run the slice's tests and verification.
5. **No keys the Copilot harness rejects** (`agents`, `handoffs`, `argument-hint`).
6. **Works without asking**: a subagent cannot talk to the developer. Doubts go into its final report.
7. **Recommended compatibility block** in its body, so its own rules do not take over when it receives a slice:

```markdown
## When called with a slice file
If the message points to a slice file (`.henriworks/changes/<id>/tarefas/NN-*.md`), read it and only the
files in its `## Ponteiros`. Change only the paths in `Toca:`. Run the tests of what you changed. Do not
commit, push or create branches, and do not edit anything in `.henriworks/`. End with: files changed;
whether the `Demonstra:` behavior happens; what you could not do or verify.
```

Optional: register it in `.henriworks/executores.json` so the whole team's plan proposes it.

**Legacy stacks** (COBOL, JCL, PL/I, Natural, RPG, Delphi, VB…): the map does not read them, so these slices
should go to the agent the team already uses for that stack; the discovery tags it `mainframe` or `legado`.
`Toca:` lists members or folders as they are in the repository; verification runs the team's own commands
(remote compile, unit test) configured in `verificacao.json`.

## Discovering (plan phase, once per machine or when the developer asks)

1. Look at the agent types your subagent tool can call. List every one that is **not** from this flow
   (not `hwk*`, not `henriworks:*`). Use the exact name the tool accepts, with the plugin prefix when it
   has one (`<plugin>:<agent>`), and its description as shown.
2. Write `.henriworks/estado/executores-candidatos.json`:
   `[{ "nome": "<exact name>", "descricao": "<description>" }]`.
3. Run `node .henriworks/bin/hwk.mjs executores registrar --de .henriworks/estado/executores-candidatos.json`.

Do not invent an agent you did not see in the tool. An empty list is a valid result.

## Choosing (plan phase)

For each slice, look at the layer and stack of its `Toca:` (Java/Spring, Liberty, Angular, React, Swift,
observability...). If a discovered or registered executor covers exactly that stack, **propose** it to the
developer in one line per slice, with the reason, and wait for the answer. Only after a yes does the slice
get `Executor: <exact name>`. With no yes, or with no matching executor, the slice stays with
`hwk-implementador` (the fallback). Never choose an executor because it is "more powerful": the criterion is
the slice's stack.

The slice follows the same rules as any other: vertical, declared `Toca:`, observable criterion, and
`## Ponteiros` with everything the executor needs (for a screen from a Figma frame, the frame link).

## Delegating (implement phase)

1. **The input is the slice.** Delegate by the exact full name, with the slice path and the instruction to
   read its pointers. Nothing from the coordinator's conversation.
2. **Absent is not replaced.** If the agent no longer exists on the machine, or cannot be called as a
   subagent, stop and say which one is missing. Silently swapping to `hwk-implementador` delivers something
   the plan did not foresee: the way back is the plan with `replanejar:`.
3. **The output is not trusted by default.** After the session, `hwk conferir-toca` checks the changed
   files against `Toca:`, the verifier runs, and code review judges the slice like any other. The gates
   (Toca, verification, isolated review) always stay with this flow.
4. **Checking `[x]` belongs to the coordinator**, after confirming the `Demonstra:` line happens. The
   external agent does not know the checklist.
