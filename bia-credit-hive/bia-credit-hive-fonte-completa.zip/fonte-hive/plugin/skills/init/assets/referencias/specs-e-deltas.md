# Specs and deltas

<!-- Copied from the plugin by /henriworks:init. Do not edit: the next init overwrites it. -->

Contract of the `.henriworks/specs/` layer. Read on demand, when a change needs to read or change the
system's recorded behavior. Decisions (`decisoes.md`) are independent: do not load both by habit.

## Why this layer exists

Without it, `.henriworks/changes/archive/` is the only record of what the system does, and nobody reads
forty archived changes to find a module's current behavior. The archive answers "what changed and why";
`specs/` answers "how it works today". It is current state, not history.

## Structure

`.henriworks/specs/index.md` lists the capabilities, one line each, with name, short description and file
path. It is the only file of `specs/` that may be read without criteria: small by construction, it tells
what to read next.

`.henriworks/specs/<capability>/spec.md` holds that capability's requirements. A capability is a slice of
behavior with a clear owner, not a code folder (`confirmacao-efetivacao`, `consulta-dividas`). Unsure
whether two things are the same capability: would they be described in the same conversation with a
business analyst?

Never read the whole `specs/`. Read the index, decide which capabilities the task touches, read only those.

## Legacy system and partial coverage

`specs/` starts empty in an existing repository and grows only through what the flow touches. A missing
capability means "not documented", never "does not exist". No phase concludes that a behavior does not
exist because it is not in `specs/`: read the code for that.

## Requirement format

Each requirement has a stable identifier `REQ-<capability>-<number>`, three-digit sequential, never
reused. A removed requirement leaves its number vacant.

The body is a verifiable statement about observable behavior, in the present tense, in Brazilian
Portuguese. Write what the system does, not how. Below each requirement come the scenarios, one per line,
in the form condition then result. A requirement without a scenario is not auditable.

## Delta format

A change that alters behavior creates `.henriworks/changes/<change-id>/deltas.md`: one section per affected
capability, one entry per operation.

| Field | Content |
| --- | --- |
| Operação | `ADICIONAR`, `SUBSTITUIR` or `REMOVER` |
| Capacidade | capability name, equal to the folder name in `specs/` |
| Alvo | the `REQ-...` identifier to replace or remove; the word `novo` to add |
| Texto | the final text of the requirement and scenarios, exactly as it must be in the file |

The final text is literal: it is copied into `specs/` with no rewriting. The plan writes it (expensive
model, while judging the behavior anyway); the archive applies it (cheap model, mechanically). If the text
cannot be final at plan time, the matching acceptance criterion is still vague: fix the criterion.

For `ADICIONAR`, the number is assigned at application, continuing the capability's sequence: writing it in
the plan collides when two open changes add to the same capability. A new capability is an `ADICIONAR`
entry whose capability is not in the index; applying creates the folder, the file and the index line.

## Application rules

Application happens at archive, after the approved verdicts and before moving the folder. `SUBSTITUIR` and
`REMOVER` whose target does not exist are an error: stop and report, never match by text similarity.
Applying edits nothing beyond the cited capability files and the index: no reordering, no reformatting, no
fixing a neighboring typo.

## Where each phase comes in

| Phase | Role in the specs layer |
| --- | --- |
| plan | reads the index and the affected capabilities, writes `deltas.md` with final text |
| implement | does not touch `specs/` nor `deltas.md` |
| review | checks every criterion has a delta and vice versa |
| archive | applies the deltas, updates the index, then moves the folder |
