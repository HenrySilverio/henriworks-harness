---
name: init
description: "Prepares the current repository for HenriWorks after installing or updating the plugin: copies the core into .henriworks/, keeps it out of Git, builds the map, checks everything and runs the reviewer canary. Runs in the hwk agent."
disable-model-invocation: true
---
# /henriworks:init

Get the repository ready in one chat, after installing or updating the plugin: copy the core, check, fix
what is safe and prove the reviewer isolation. It can run again any time: what is ready is skipped. Reply in
Brazilian Portuguese.

Runs in the `hwk` agent. If the instructions of this chat do not start with the line `# Agent hwk`, do not
read or run anything: answer in one line that they should select the `hwk` agent in a new chat and send
`/henriworks:init` again.

## Step 1 - Prepare and check

The script is `scripts/init.mjs` inside the folder that contains this SKILL.md (the plugin install folder,
outside the repository). Run it from the repository root:

```
node "<folder of this SKILL.md>/scripts/init.mjs"
```

Run it yourself: preparing the repository is the purpose of this command, and the agent's edit limit does not
apply to the flow's scripts. Show the whole output. It copies the core to `.henriworks/bin/`, creates the team files that are missing,
copies the references, records the version, adds `.henriworks/` to `.git/info/exclude` (never
`.gitignore`), builds the map and runs `hwk init --corrigir`. A `GRAVE` line: show it and stop. Nothing
else runs with a broken installation. Do not fix anything by hand.

Before the script, run `node -v`. If `node` is not found, or the version is below v22 (or the script fails with
a `SyntaxError` before any report): tell the developer, in Portuguese, that the Hive needs Node LTS 22 or 24 and
that they must follow the HenriWorks installation and configuration document in the bank's Confluence (if it is
already installed, close and reopen VS Code). Stop there; do not install Node or work around it.

If the script exits with an error, prints no report or says the init did not finish: show stdout and stderr
verbatim, in full, and stop. Never summarize the failure, never say only that it failed, and never ask the
developer to run it again: the reason in the output is what has to change. A `pastas-locais` line lists
folders the init took out of the flow: show it as it is.

## Step 2 - Canary

`canário` line with "conferência do pacote ligada": skip to step 3. Otherwise:

1. `node .henriworks/bin/hwk.mjs canario preparar`. The code word is now in this chat's conversation: it is
   the bait. Never repeat it in any message of yours.
2. `node .henriworks/bin/hwk.mjs pacote-revisao canario`.
3. Delegate to the subagent `henriworks:hwk-gf` (this full name) with the printed literal prompt, nothing
   before or after.
4. Save its answer, unedited, to `.henriworks/estado/canario-resposta.md`.
5. `node .henriworks/bin/hwk.mjs canario conferir` and show the whole output.
   - "isolamento confirmado" and the subagent call recorded: run `node .henriworks/bin/hwk.mjs canario aplicar`.
   - "NENHUM evento registrado": the hooks did not run in this window. Tell the developer to run
     "Developer: Reload Window" and repeat the command.
   - "INCONCLUSIVO": the goldfish refused or explained instead of answering the lines. Do not say isolation
     was confirmed. Show the output and suggest repeating in a new chat; if the refusal repeats, change the
     chat model.
   - "ferramentas ... FORA DO PERMITIDO": the chat is running in the Local harness, which the flow does not
     support. Tell the developer to switch the chat to the Copilot harness and run `/henriworks:canario`
     again.
   - "isolamento FALHOU": show it and end the canary. The default review is not reliable on this machine
     until investigated; the way is strict mode (`estrito` in the review).

With no subagent tool in this session: say so and end the canary. Never simulate the goldfish's answer.

Hooks with no event or a failed canary do not stop the init: go to step 3 and keep it in the report.

## Step 3 - Report

Run `node .henriworks/bin/hwk.mjs init` and show the output. Close with up to six lines: what is ready,
what is pending and who solves it, and the next step: `/henriworks:start` with what they want to do.

- `tokens` warning: nothing to do in the repository. Tokens depend on IT enabling the Agent Host
  telemetry; usage counts are already collected.
- `instalacao-antiga` warning: list the files of the old zip installation for the developer to delete.
- `verificacao.json` and `padroes.md` belong to the team. Still on the template: point to
  `/henriworks:configurar` and do not edit them here.
- The flow runs only in the chat's Copilot harness. Do not recommend the Local harness.
