# Fonte completa · b.IA Credit Hive

Leia primeiro `PASSAGEM.md` (estado, regras, frentes em aberto).

Requisitos: Node 22 ou 24, Git Bash. Nada para instalar (sem dependências npm).

```bash
# 1. pacote do plugin com a marca
node marcas/gerar.mjs pacote plugin marcas/bia-credit-hive/perfil.json dist/bia-credit-hive-plugin
cp marcas/bia-credit-hive/readme/README-final.md dist/bia-credit-hive-plugin/README.md
(cd dist/bia-credit-hive-plugin && node testes/smoke.mjs)      # 47/47

# 2. documentação (Fundamentos + Hive num site só; precisa do passo 1)
node marcas/bia-credit-hive/montar-docs.mjs docs-html --ext html --plugin dist/bia-credit-hive-plugin
node marcas/bia-credit-hive/montar-docs.mjs docs-sp   --ext aspx --plugin dist/bia-credit-hive-plugin
```

- `plugin/` é o núcleo com nomes internos: edite aqui e gere o pacote; nunca entregue `plugin/` direto.
- O README do plugin é composto à mão (`marcas/bia-credit-hive/readme/README-final.md`); os SVGs ficam em `marcas/bia-credit-hive/pacote/docs/assets/`. Para regerar os SVGs, use a skill readme-skins com a skin `readme/skin/hive.py` + `hive.json`.
- `ferramentas/`: `anonimizar-uso.mjs` (antes de mandar arquivos de uso para fora), `limpar-henriworks.sh` (remove restos da versão de teste), `atualizar-plugin-json.mjs`.
